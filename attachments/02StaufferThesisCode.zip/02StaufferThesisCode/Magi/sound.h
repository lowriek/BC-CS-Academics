#ifndef SOUND_H
#define SOUND_H

/*		Magi Game Engine		 */
/*		Interface for DirectSound */
/*		Created: April 4, 2002	   */
/*      Cris Stauffer					*/
/*		Code Based off of Trent Polack */



#define WIN32_LEAN_AND_MEAN
#define INIT_GUID

#include <windows.h>		//Windows header file
#include <windowsx.h>		//Windows header with some kewl extras
#include <mmsystem.h>
#include <dsound.h>
#include <iostream.h>			
#include <conio.h>
#include <stdio.h> 
#include <stdarg.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>
#include <math.h>
#include <io.h>
#include <fcntl.h>
#include <time.h>

#include <dmusicc.h>
#include <dmusici.h>

#include "entity.h"
#define INITGUID

#define LPDIRECTMUSICLOADER8		IDirectMusicLoader8*
#define LPDIRECTMUSICPERFORMANCE8	IDirectMusicPerformance8*
#define LPDIRECTMUSICSEGMENT8		IDirectMusicSegment8*
#define LPDIRECTMUSICAUDIOPATH		IDirectMusicAudioPath*
#define LPDIRECTSOUNDBUFFER		IDirectSoundBuffer8*


class SoundObject
	{
	public:
		LPDIRECTMUSICSEGMENT8 dmSegment;
		LPDIRECTSOUNDBUFFER dsBuffer;
		bool is3DSound;
	
	
	void Shutdown();

	SoundObject(){ dmSegment = NULL;  dsBuffer = NULL; is3DSound = false; };
		bool SetVolume(float percent);
	~SoundObject() 
		{	};
	};



class SoundManager: public Entity
	{
	
	protected:
		LPDIRECTMUSICAUDIOPATH		audioPath;
		LPDIRECTMUSICLOADER8		loader;
		LPDIRECTMUSICPERFORMANCE8	performance;
		HWND		hwnd;	
		SoundObject * objList[10];
		
	public:
		
	bool Init(void);	
	void Shutdown(void);
	void Kill();
		bool SetVolume(float percent);

	bool Create(SoundObject * audio, char* filename, bool is3DSound);

	void Play(SoundObject * audio, DWORD numRepeats);
	void Stop(SoundObject * audio);

	SoundManager(HWND windowHandler ){ audioPath = NULL; loader = NULL;
			 performance = NULL;  hwnd = windowHandler; for(int i=0;i<10;i++)objList[i] = NULL; Entity();};

	~SoundManager()
		{	};
	};





#endif