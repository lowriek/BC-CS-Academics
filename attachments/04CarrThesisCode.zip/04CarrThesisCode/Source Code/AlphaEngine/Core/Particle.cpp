#include "Particle.h"

CParticle::CParticle()
{
	bump = 0;
	collideFlag = false;
	friction = 0;
	life = -1;
	mass = 0;
	radius = 0;
	
	pos = CVector3(0,0,0);
	force = CVector3(0,0,0);
	vel = CVector3(0,0,0);
}

CParticle::~CParticle()
{
}

bool CParticle::update(long deltaTime)
{
	bool moved = false;

	CVector3 still(0,0,0);

	if (vel != still)
	{
		pos += (vel / (float)deltaTime);
		moved = true;
	}

	return moved;
}

bool CParticle::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&mass, sizeof(float), 1, filePtr);
		fwrite(&radius, sizeof(float), 1, filePtr);
		fwrite(&friction, sizeof(float), 1, filePtr);
		fwrite(&bump, sizeof(float), 1, filePtr);
		fwrite(&life, sizeof(long), 1, filePtr);
		fwrite(&collideFlag, sizeof(bool), 1, filePtr);
	}
	else
	{
		fread(&mass, sizeof(float), 1, filePtr);
		fread(&radius, sizeof(float), 1, filePtr);
		fread(&friction, sizeof(float), 1, filePtr);
		fread(&bump, sizeof(float), 1, filePtr);
		fread(&life, sizeof(long), 1, filePtr);
		fread(&collideFlag, sizeof(bool), 1, filePtr);
	}

	if (!pos.serialize(filePtr, isStoring))
		return false;
	if (!vel.serialize(filePtr, isStoring))
		return false;
	if (!force.serialize(filePtr, isStoring))
		return false;

	return true;
}