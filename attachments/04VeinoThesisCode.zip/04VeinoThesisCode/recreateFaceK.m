function [] = recreateFaceK(loc,pagename,eigFaces,meanFace,J)
%INPUTS:
%     loc : the loc returned by kmeans
%     pagename: the name of the html file
%     eigFaces: the eigenFaces from PCA
%     meanFace: the meanFace from PCA
%     J : the number that's put after the filename

recreatedA = meanFace;
[dontcare,numeigs] = size(loc);
for I=1:numeigs
   recreatedA = recreatedA + (loc(1,I) * eigFaces(I,:));
end
myim = reshape(recreatedA,120,80); myim = normalize(myim);
imwrite(myim,[pagename int2str(J) '.jpg'],'jpeg');

fid = fopen([pagename '.htm'],'a');
fprintf(fid, 'Cluster ');fprintf(fid,'%s',int2str(J));fprintf(fid,':\n');
fprintf(fid, '<img src="');fprintf(fid,'%s',[pagename int2str(J) '.jpg']);fprintf(fid,'">\n');
fclose(fid);