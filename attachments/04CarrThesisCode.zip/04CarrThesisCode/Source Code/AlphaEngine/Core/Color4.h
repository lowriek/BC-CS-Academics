#ifndef _COLOR4_H_
#define _COLOR4_H_

#include <stdio.h>

class CColor4
{
public:
	CColor4();
	CColor4(unsigned int r, unsigned int g, unsigned int b);
	CColor4(unsigned int r, unsigned int g, unsigned int b, unsigned int a);
	CColor4(const CColor4 &rColor);

	virtual ~CColor4();
	
	bool		operator==(const CColor4 &rColor);
	CColor4&	operator=(const CColor4 &rColor);
	bool		serialize(FILE * filePtr, bool isStoring);

	unsigned int r, g, b, a;
};

#endif