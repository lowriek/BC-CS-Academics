function [faceness] = combineFaceness(eigFaceness,colFaceness)
%
%
%

[m,n] = size(eigFaceness);
[m2,n2] = size(colFaceness);

eigFaceness = padarray(eigFaceness,[(m2-m)/2 (n2-n)/2],0,'both');

faceness = (eigFaceness) .* (.5*colFaceness);
figure(4);imagesc(faceness);axis image;truesize;title('Combination of color and eigenface faceness');