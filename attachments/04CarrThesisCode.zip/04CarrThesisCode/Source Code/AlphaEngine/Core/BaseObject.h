#ifndef _BASEOBJECT_H_
#define _BASEOBJECT_H_

#include <stdio.h>

class CBaseObject
{
public:
	CBaseObject();
	virtual ~CBaseObject();

	void			assignObjectId();
	virtual bool	serialize(FILE * filePtr, bool isStoring);

	unsigned long	objectId;

};

#endif