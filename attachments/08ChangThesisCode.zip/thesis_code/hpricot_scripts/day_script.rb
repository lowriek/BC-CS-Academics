require 'rubygems'
require 'hpricot'
require 'open-uri'

if ( (url = ARGV[0]) == nil)
  puts "usage: day_script.rb url -- note: url of the form ?date=20080325\n"
  exit
end
doc = Hpricot(open("http://scores.espn.go.com/nba/scoreboard"+url))

prevday = (doc/'div#prevNext/a[1]').attr('href').to_s
nextday = (doc/'div#prevNext/a[2]').attr('href').to_s

# whole url = http://scores.espn.go.com/nba/scoreboard?date=20080307
# so, add http://scores.espn.go.com/nba/scoreboard before

# filename - new_day.list, old_day.list
newfn = 'new_day.list'
oldfn = 'old_day.list'

begin
  # if the found urls are not in the old, add them to new
  system("ruby -ne 'print if /"+prevday.gsub("?","")+"/' "+oldfn+" > temp")
  lines = File.readlines("temp")
  if (lines.length == 0)
    system("echo "+prevday+" >> "+newfn)
  end
  system("ruby -ne 'print if /"+nextday.gsub("?","")+"/' "+oldfn+" > temp")
  lines = File.readlines("temp")
  if (lines.length == 0)
    system("echo "+nextday+" >> "+newfn)
  end
  # add given url to old list
  system("echo "+url+" >> "+oldfn)
  # gets rid of duplicates
  system("cat "+newfn+" | sort | uniq > temp")
  system("cat temp > "+newfn)
  system("cat "+oldfn+" | sort | uniq > temp")
  system("cat temp > "+oldfn)
  # remove given url from new list
  system("grep -iv '"+url.gsub("?","")+"' "+newfn+" > temp")
  system("cat temp > "+newfn)	
rescue EOFError

end
