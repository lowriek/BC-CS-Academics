class GameTeam < ActiveRecord::Base
	validates_presence_of :game_id
	validates_presence_of :team_id

	validates_uniqueness_of :game_id, :scope => [:team_id]
end
