# master_tennis_script.rb
# The script should be able to run autonomously, infinitely
# It should handle new players, new games, etc. so long as ESPN does not change their layouts

# ruby tennis_player_script.rb
# ruby ../sports/script/console < import_tennis_players.rb


require 'rubygems'
require 'hpricot'
require 'open-uri'

counter=0
daylist = 'tennis_processed_days.list'
# currentdayurl is initialized to ESPN Tennis scores default daily page.
# this variable gets updated during each iteration through the loop

# this extraeneous code is necessary to ensure that all urls (including today's) are of the same format
# go back a day, then go forward a day to get to today
currentdayurl = 'http://sports.espn.go.com/sports/tennis/dailyResults'
doc = Hpricot(open(currentdayurl))
previousdayurl = 'http://sports.espn.go.com/sports/tennis/dailyResults'+(doc/'div.content/div.sp-col1/div/div.autoPageNav/div[1]/a[1]').attr('href')
doc = Hpricot(open(previousdayurl))
currentdayurl = 'http://sports.espn.go.com/sports/tennis/dailyResults'+(doc/'div.content/div.sp-col1/div/div.autoPageNav/div[1]/a[2]').attr('href')

statfile = 'tennis_statfile.list'
importfile = 'import_tennis_stats.rb'

while(true)
	counter+=1
	#if (counter%1000 == 0)
	if (counter %1000000 == 0)
		counter = 0
		# this takes forever (I believe around 6 or 7 hours)
		# if its run too fast espn will start denying requests
		system("ruby tennis_player_script.rb")
		system("ruby ../sports/script/console < import_tennis_players.rb")
	end

	doc = Hpricot(open(currentdayurl))
	# get date from currentdayurl
	# date = (doc/'div.content/div.sp-col1/div/div.autoPageNav/div[1]/b').inner_html
	# if date exists in daylist, go to previous day (get link from currentday)
	# x = system('grep -q "'+date+'" '+daylist)

	##
	# instead of getting date, just use the currentdayurl
	x = system('grep -q "'+currentdayurl+'" '+daylist)
	##
	# previous day's url
	partial = (doc/'div.content/div.sp-col1/div/div.autoPageNav/div[1]/a[1]').attr('href')
	if (x == true)	
		puts 'found: '+currentdayurl
		currentdayurl = 'http://sports.espn.go.com/sports/tennis/dailyResults'+partial
		puts 'Im napping...'		
		sleep 10
		puts 'Im refreshed!'
	else
		puts 'not found: '+currentdayurl
		#		add date to daylist
		system('echo "'+currentdayurl+'" >> '+daylist)
		# 	clear statfile
		system('echo -n > '+statfile)
		#		for each game, add the stats the statfile
		system('ruby tennis_stat_script.rb '+currentdayurl)
		# 	run import_tennis_stats.rb through console
		system('ruby ../sports/script/console < '+importfile)
		#		set currentdayurl to previous day
		currentdayurl = 'http://sports.espn.go.com/sports/tennis/dailyResults'+partial

		puts 'Im sleeping...'
		sleep 30
		puts 'Im awake!'
	end

end
