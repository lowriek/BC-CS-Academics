hpricot_scripts
contents: scripts to data mine ESPN, transfer data to Rails database

sports
contents: all code of my sports web service set up.