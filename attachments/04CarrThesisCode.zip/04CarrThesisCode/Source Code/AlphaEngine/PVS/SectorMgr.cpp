#include "AlphaEngine/PVS/SectorMgr.h"
#include "AlphaEngine/Math/Math.h"

CSectorMgr::CSectorMgr()
{
	numSector = 0;
	pSector = 0;
	pBspRoot = 0;
}

CSectorMgr::~CSectorMgr()
{
	if (pSector)
	{
		delete [] pSector;
		pSector = 0;
	}
	if (pBspRoot)
	{
		delete pBspRoot;
		pBspRoot = 0;
	}
}

void CSectorMgr::addPortal(CPortal* pPortal, CBspNode* pBspNode)
{
	if (pBspNode->isLeaf())
	{
		pSector[pBspNode->id].addPortal(pPortal);
		return;
	}

	int retval = classifyPortal(pPortal, pBspNode->plane);
	if (retval == ALPHA_INFRONT)
	{
		if (pBspNode->pFront)
			addPortal(pPortal, pBspNode->pFront);
	}
	if (retval == ALPHA_BEHIND)
	{
		if (pBspNode->pBack)
			addPortal(pPortal, pBspNode->pBack);
	}
	if (retval == ALPHA_COINCIDING)
	{
		if (pBspNode->pFront)
			addPortal(pPortal, pBspNode->pFront);

		if (pBspNode->pBack)
			addPortal(pPortal->clone(), pBspNode->pBack);
	}
}

void CSectorMgr::addPortalsToSectors(CPortalList* pPortalList)
{
	unsigned int numPortals = pPortalList->size();

	for (unsigned int x = 0; x < numPortals; x++)
	{
		CPortal* pPortal = pPortalList->get(x)->clone();
		addPortal(pPortal, pBspRoot);
	}
}

bool CSectorMgr::checkForSinglePortal(unsigned int sectorIndex, unsigned int portalIndex)
{
	unsigned int i, j;

	CPortal* pTest = pSector[sectorIndex].portalList.get(portalIndex);

	for (i=0; i<numSector; i++)
	{
		if (i != sectorIndex)
		{
			unsigned int numPortal = pSector[i].portalList.size();

			for (j=0; j < numPortal; j++)
			{
				CPortal* pPortal = pSector[i].portalList.get(j);
				if (pPortal->id == pTest->id)
				{
					pPortal->fromSectorId = i;
					pPortal->toSectorId = sectorIndex;

					pTest->fromSectorId = sectorIndex;
					pTest->toSectorId = i;
					return true;
				}
			}
		}
	}
	return false;
}

void CSectorMgr::checkForSinglePortals()
{
	for (unsigned int i=0; i<numSector; i++)
	{
		unsigned int numPortal = pSector[i].portalList.size();
		bool hasMorePortals = false;
		
		if (numPortal > 0)
		{
			hasMorePortals = true;
			numPortal--;
		}

		while (hasMorePortals)
		{
			if (checkForSinglePortal(i, numPortal))
			{
				CPortal* pPortal = pSector[i].portalList.get(numPortal);
				clipPortalToSector(pPortal, ALPHA_INFRONT);
				clipPortalToSector(pPortal, ALPHA_BEHIND);
			}
			else
			{
				pSector[i].portalList.remove(numPortal);
			}
			if (numPortal != 0)
				numPortal--;
			else
				hasMorePortals=false;
		}
	}
}

int CSectorMgr::classifyPortal(CPolygon* pPortal, CPlane plane)
{
	int numPos = 0; 
	int numNeg = 0;
	int numCo = 0;
	for (unsigned int x = 0; x < pPortal->numVert; x++)
	{
		int retval = plane.classifyPoint(pPortal->pVert[x]);
		switch(retval)
		{
		case ALPHA_INFRONT:
			numPos++;
			break;
		case ALPHA_BEHIND:
			numNeg++;
			break;
		case ALPHA_COINCIDING:
			numCo++;
			break;
		}
	}

	if (numPos > 0 && numNeg == 0)
		return ALPHA_INFRONT;
	if (numNeg > 0 && numPos == 0)
		return ALPHA_BEHIND;
	if (numPos == 0 && numNeg == 0)
		return ALPHA_COINCIDING;

	return ALPHA_SPANNING;
}

void CSectorMgr::clipPortalToSector(CPortal* pPortal, int side)
{
	unsigned int sectorId = pPortal->toSectorId;
	if (side == ALPHA_INFRONT)
		sectorId = pPortal->fromSectorId;

	CPolygon* pPolygon = pSector[sectorId].pPolygon;
	while (pPolygon != 0)
	{
		int retval = classifyPortal(pPortal, pPolygon->plane);
		if (retval == ALPHA_SPANNING)
		{
			CPortal* pFront = new CPortal();
			CPortal* pBack = new CPortal();
			CPortal* pSide = pBack;
			if (side == ALPHA_INFRONT)
				pSide = pFront;

			bool retsplit = pPortal->splitPolygon(pPolygon->plane, pFront, pBack);
			if (retsplit)
			{
				pPortal->deallocate();
				pPortal->allocate(pSide->numVert);
				for (unsigned int i = 0; i < pSide->numVert; i++)
				{
					pPortal->pVert[i] = pSide->pVert[i];
					pPortal->pBTxCoord[i] = pSide->pBTxCoord[i];
					pPortal->pDTxCoord[i] = pSide->pDTxCoord[i];
				}
				pPortal->calculatePlane();
			}
			delete pFront;
			delete pBack;
		}
		pPolygon = pPolygon->pNext;
	}
}

void CSectorMgr::create(CBspNode* pBspNode)
{
	pBspRoot = pBspNode;
	
	createSectors();
	
	CPortalList* pPortalList = createPortalList();
	addPortalsToSectors(pPortalList);
	
	// remove all portals from list and delete portal list object
	pPortalList->clear();
	delete pPortalList;

	findTruePortals();
}

CPortal* CSectorMgr::createLargePortal(CBspNode* pBspNode)
{
	CPortal* pPortal = new CPortal();
	pPortal->allocate(4);
    int axisFlag = 0;
	
	CVector3 planeNormal = pBspNode->plane.normal;
	planeNormal.unitize();
	
	float x, y, z;
	x = planeNormal.points[0];
	y = planeNormal.points[1];
	z = planeNormal.points[2];

	if (CMath::FAbs(x) > CMath::FAbs(y) && CMath::FAbs(x) > CMath::FAbs(z))
	{
		axisFlag = 1;
		pPortal->pVert[0].points[1] = pBspNode->boundBox.minY;
		pPortal->pVert[0].points[2] = pBspNode->boundBox.maxZ;
		pPortal->pVert[1].points[1] = pBspNode->boundBox.minY;
		pPortal->pVert[1].points[2] = pBspNode->boundBox.minZ;
		pPortal->pVert[2].points[1] = pBspNode->boundBox.maxY;
		pPortal->pVert[2].points[2] = pBspNode->boundBox.minZ;
		pPortal->pVert[3].points[1] = pBspNode->boundBox.maxY;
		pPortal->pVert[3].points[2] = pBspNode->boundBox.maxZ;
	} 
	else if (CMath::FAbs(y) > CMath::FAbs(x) && CMath::FAbs(y) > CMath::FAbs(z))
	{
		axisFlag = 2;
		pPortal->pVert[0].points[0] = pBspNode->boundBox.minX;
		pPortal->pVert[0].points[2] = pBspNode->boundBox.maxZ;
		pPortal->pVert[1].points[0] = pBspNode->boundBox.maxX;
		pPortal->pVert[1].points[2] = pBspNode->boundBox.maxZ;
		pPortal->pVert[2].points[0] = pBspNode->boundBox.maxX;
		pPortal->pVert[2].points[2] = pBspNode->boundBox.minZ;
		pPortal->pVert[3].points[0] = pBspNode->boundBox.minX;
		pPortal->pVert[3].points[2] = pBspNode->boundBox.minZ;
	}
    else
    {
        axisFlag = 3;

		pPortal->pVert[0].points[0] = pBspNode->boundBox.minX;
		pPortal->pVert[0].points[1] = pBspNode->boundBox.minY;
		pPortal->pVert[1].points[0] = pBspNode->boundBox.maxX;
		pPortal->pVert[1].points[1] = pBspNode->boundBox.minY;
		pPortal->pVert[2].points[0] = pBspNode->boundBox.maxX;
		pPortal->pVert[2].points[1] = pBspNode->boundBox.maxY;
		pPortal->pVert[3].points[0] = pBspNode->boundBox.minX;
		pPortal->pVert[3].points[1] = pBspNode->boundBox.maxY;
    }

	float d = pBspNode->plane.d;
	float a, b, c;

    switch (axisFlag)
    {
	case 1:		// YZ PLANE
		a = -(y * pBspNode->boundBox.minY + z * pBspNode->boundBox.maxZ + d) / x;
		pPortal->pVert[0].points[0] = a;
		a = -(y * pBspNode->boundBox.minY + z * pBspNode->boundBox.minZ + d) / x;
		pPortal->pVert[1].points[0] = a;
		a = -(y * pBspNode->boundBox.maxY + z * pBspNode->boundBox.minZ + d) / x;
		pPortal->pVert[2].points[0] = a;
		a = -(y * pBspNode->boundBox.maxY + z * pBspNode->boundBox.maxZ + d) / x;
		pPortal->pVert[3].points[0] = a;
		break;
	case 2:		// XZ PLANE
		b = -(x * pBspNode->boundBox.minX + z * pBspNode->boundBox.maxZ + d) / y;
		pPortal->pVert[0].points[1] = b;
		b = -(x * pBspNode->boundBox.maxX + z * pBspNode->boundBox.maxZ + d) / y;
		pPortal->pVert[1].points[1] = b;
		b = -(x * pBspNode->boundBox.maxX + z * pBspNode->boundBox.minZ + d) / y;
		pPortal->pVert[2].points[1] = b;
		b = -(x * pBspNode->boundBox.minX + z * pBspNode->boundBox.minZ + d) / y;
		pPortal->pVert[3].points[1] = b;
		break;
	case 3:		// XY PLANE
		c = -(x * pBspNode->boundBox.minX + y * pBspNode->boundBox.minY + d) / z;
		pPortal->pVert[0].points[2] = c;		
		c = -(x * pBspNode->boundBox.maxX + y * pBspNode->boundBox.minY + d) / z;
		pPortal->pVert[1].points[2] = c;
		c = -(x * pBspNode->boundBox.maxX + y * pBspNode->boundBox.maxY + d) / z;
		pPortal->pVert[2].points[2] = c;
		c = -(x * pBspNode->boundBox.minX + y * pBspNode->boundBox.maxY + d) / z;
		pPortal->pVert[3].points[2] = c;
		break;
    }
	pPortal->calculatePlane();
	
	pPortal->pBTxCoord[0] = CVector2(1,1);
	pPortal->pBTxCoord[1] = CVector2(1,0);
	pPortal->pBTxCoord[2] = CVector2(0,0);
	pPortal->pBTxCoord[3] = CVector2(0,1);
	pPortal->bTxId = 2;

	if (planeNormal != pPortal->plane.normal)
		pPortal->flip();

	return pPortal;
}

CPortalList* CSectorMgr::createPortalList()
{
	unsigned int x;
	unsigned int numPartitions = pBspRoot->getNumPartitions();
	unsigned int numPortals = numPartitions;
	
	CPortalList* pPortalList = new CPortalList();

	for (x = 0; x < numPartitions; x++)
	{
		CBspNode* pBspNode = pBspRoot->getPartitionNode(x);
		CPortal* pPortal = createLargePortal(pBspNode);
		pPortal->partitionId = x;
		pPortalList->add(pPortal);
	}

	for (x = 0; x < numPartitions; x++)
	{
		CBspNode* pNode = pBspRoot->getPartitionNode(x);
		unsigned int i = numPortals-1;
		bool hasMorePortals = true;
		while (hasMorePortals)
		{
			CPortal* pPortal = pPortalList->get(i);
			int retval = classifyPortal(pPortal, pNode->plane);
			if (retval == ALPHA_SPANNING)
			{
				CPortal* pFront = new CPortal();
				CPortal* pBack = new CPortal();
				bool retsplit = pPortal->splitPolygon(pNode->plane, pFront, pBack);
				if (retsplit)
				{
					pFront->partitionId = pPortal->partitionId;
					pBack->partitionId = pPortal->partitionId;
					pPortalList->add(pFront);
					pPortalList->add(pBack);
					pPortalList->remove(i);
					numPortals = numPortals+1;
				}
				else
				{
					delete pFront;
					delete pBack;
				}
			}
			if (i != 0)
				i--;
			else
				hasMorePortals=false;
		}
	}

	for (x = 0; x < numPortals; x++)
	{
		CPortal* pPortal = pPortalList->get(x);
		pPortal->id = x;
	}

	return pPortalList;
}

void CSectorMgr::createSectors()
{
	unsigned int x;
	numSector = pBspRoot->getNumLeaves();
	pSector = new CSector[numSector];
	for (x = 0; x < numSector; x++)
		pSector[x].addPolygon(pBspRoot->getLeafNode(x)->getPolygons());
}

void CSectorMgr::findTruePortals()
{
	checkForSinglePortals();
	makePortalsInward();
	removeExtraPortals();
}

void CSectorMgr::makePortalsInward()
{
	// MAKE SURE EVERY POLYGON IN THE SECTOR IS IN FRONT OR COINCIDING WITH ITS PORTAL
	for (unsigned int i=0; i < numSector; i++)
	{
		for (unsigned int j=0; j < pSector[i].portalList.size(); j++)
		{
			CPortal* pPortal = pSector[i].portalList.get(j);
			CPolygon* pPolygon = pSector[i].pPolygon;
			while (pPolygon != 0)
			{
				if (pPolygon->classify(pPortal->plane) == ALPHA_BEHIND)
				{
					pPortal->flip();
					pPolygon = pSector[i].pPolygon;
				}
				else
					pPolygon = pPolygon->pNext;
			}
		}
	}
}

void CSectorMgr::removeExtraPortals()
{
	unsigned int i,j;
	for (i=0; i < numSector; i++)
	{
		bool checkMore = true;
		while (checkMore)
		{
			checkMore = false;
			unsigned int numPortal = pSector[i].portalList.size();
			for (j=0; j < numPortal; j++)
			{
				bool invalid = false;
				CPortal* pPortal = pSector[i].portalList.get(j);
				// temporarily flip the portal
				pPortal->flip();
				// classify against all polygons in the toSector
				unsigned int toSector = pPortal->toSectorId;
				CPolygon* pPolygon = pSector[toSector].pPolygon;
				while (pPolygon != 0)
				{
					int retval = pPortal->classify(pPolygon->plane);
					if (retval == ALPHA_BEHIND)
					{
						// delete this portal
						invalid = true;
						break;
					}
					if (retval == ALPHA_COINCIDING && pPortal->plane.normal != pPolygon->plane.normal)
					{
						invalid = true;
						break;
					}
					pPolygon = pPolygon->pNext;
				}
				if (invalid)
				{	
					pSector[i].portalList.remove(j);
					checkMore = true;
					break;
				}
				else
				{
					// this portal is good
					pPortal->flip();
				}
			}
		}
	}

}

void CSectorMgr::render(int flags, CFrustum* pFrustum, CVector3 &location)
{
	CBspNode* pNode = pBspRoot->getLeafNode(location);
	if (!pNode)
	{
		pBspRoot->render(flags, location);
	}
	else
	{
		renderSector(flags, pNode->id, pNode->id, pFrustum, location);		
	}
}

void CSectorMgr::renderSector(int flags, unsigned int sectorId, unsigned int prevSectorId, CFrustum* pFrustum, CVector3 &location)
{
	if (sectorId >= numSector)
		return;

	if (pSector[sectorId].beingVisited)
		return;

	unsigned int i;
	pSector[sectorId].beingVisited = true;

	for (i=0; i < pSector[sectorId].portalList.size(); i++)
	{
		CPortal* pPortal = pSector[sectorId].portalList.get(i);
		if (pFrustum->polygonInFrustum(pPortal))
		{
			if (pPortal->toSectorId != prevSectorId)
			{
				CFrustum* pNewFrustum = pFrustum->adjust(pPortal, location);
				renderSector(flags, pPortal->toSectorId, sectorId, pNewFrustum, location);
				delete pNewFrustum;
			}
		}
	}

	// render polygons
	CPolygon* pPolygon = pSector[sectorId].pPolygon;
	while (pPolygon != 0)
	{
		pPolygon->render(flags);
		pPolygon = pPolygon->pNext;
	}


	// render portals
	glPushAttrib(GL_DEPTH_BUFFER_BIT);
		glDisable(GL_DEPTH_TEST);
	for (i=0; i < pSector[sectorId].portalList.size(); i++)
	{
		CPortal* pPortal = pSector[sectorId].portalList.get(i);
		pPortal->alpha = 0.25f;
		if (pFrustum->polygonInFrustum(pPortal))
			pPortal->render(flags);
	}
	glPopAttrib();

	pSector[sectorId].beingVisited = false;
}

bool CSectorMgr::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	bool hasBsp = pBspRoot != 0;

	if (isStoring)
	{
		fwrite(&numSector, sizeof(unsigned int), 1, filePtr);
		fwrite(&hasBsp, sizeof(bool), 1, filePtr);
	}
	else
	{
		fread(&numSector, sizeof(unsigned int), 1, filePtr);
		fread(&hasBsp, sizeof(bool), 1, filePtr);

		if (pBspRoot)
			delete pBspRoot;

		pBspRoot = new CBspNode();

		if (pSector) {
			delete [] pSector;
			pSector = 0;
		}
		if (numSector > 0)
			pSector = new CSector[numSector];
	}

	if (hasBsp)
	{
		if (!pBspRoot->serialize(filePtr, isStoring))
			return false;
	}

	for (unsigned int i = 0; i < numSector; i++)
	{
		if (!pSector[i].serialize(filePtr, isStoring))
			return false;
	}

	return true;
}
