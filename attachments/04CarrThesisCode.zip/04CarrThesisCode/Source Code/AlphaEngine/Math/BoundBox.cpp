#include "AlphaEngine/Math/BoundBox.h"
#include "AlphaEngine/Math/Math.h"
#include "AlphaEngine/Math/Plane.h"

void CBoundBox::addVert(CVector3 &vert)
{
	maxX = CMath::Max(maxX, vert.points[0]);
	maxY = CMath::Max(maxY, vert.points[1]);
	maxZ = CMath::Max(maxZ, vert.points[2]);

	minX = CMath::Min(minX, vert.points[0]);
	minY = CMath::Min(minY, vert.points[1]);
	minZ = CMath::Min(minZ, vert.points[2]);
}

CBoundBox::CBoundBox()
{
	maxX = maxY = maxZ = -CMath::INFINITY;
	minX = minY = minZ = CMath::INFINITY;
}

CBoundBox::~CBoundBox()
{
}

CBoundBox& CBoundBox::operator= (const CBoundBox& rBox)
{
	maxX = rBox.maxX;
	maxY = rBox.maxY;
	maxZ = rBox.maxZ;
	minX = rBox.minX;
	minY = rBox.minY;
	minZ = rBox.minZ;
    return *this;
}

float CBoundBox::getVolume()
{
	float lenX = maxX - minX;
	float lenY = maxY - minY;
	float lenZ = maxZ - minZ;
	return CMath::FAbs(lenX * lenY * lenZ);
}

bool CBoundBox::rayIntersect(CVector3 &ro, CVector3 &rd, float &tnear, float &tfar)
{
	CVector3 ip;
	float t;
	tfar = CMath::INFINITY;
	tnear = -CMath::INFINITY;
	CPlane plane1, plane2;

	plane1.normal = CVector3(1,0,0);	plane1.d = maxX;
	plane2.normal = CVector3(-1, 0, 0);	plane2.d = minX;
	if (plane1.rayIntersect(ro, rd, ip, t))
	{
		tfar = CMath::Min(tfar, t);
		if (plane2.rayIntersect(ro, rd, ip, t))
			tnear = CMath::Max(tnear, t);
	}

	plane1.normal = CVector3(0,1,0);		plane1.d = maxY;
	plane2.normal = CVector3(0, -1, 0);		plane2.d = minY;
	if (plane1.rayIntersect(ro, rd, ip, t))
	{
		tfar = CMath::Min(tfar, t);
		if (plane2.rayIntersect(ro, rd, ip, t))
			tnear = CMath::Max(tnear, t);
	}

	plane1.normal = CVector3(0,0,1);		plane1.d = maxZ;
	plane2.normal = CVector3(0, 0, -1);	plane2.d = minZ;
	if (plane1.rayIntersect(ro, rd, ip, t))
	{
		tfar = CMath::Min(tfar, t);
		if (plane2.rayIntersect(ro, rd, ip, t))
			tnear = CMath::Max(tnear, t);
	}

	if (tnear > tfar)
		return true;


	return false;


}

bool CBoundBox::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&maxX, sizeof(float), 1, filePtr);
		fwrite(&maxY, sizeof(float), 1, filePtr);
		fwrite(&maxZ, sizeof(float), 1, filePtr);
		fwrite(&minX, sizeof(float), 1, filePtr);
		fwrite(&minY, sizeof(float), 1, filePtr);
		fwrite(&minZ, sizeof(float), 1, filePtr);
	}
	else
	{
		fread(&maxX, sizeof(float), 1, filePtr);
		fread(&maxY, sizeof(float), 1, filePtr);
		fread(&maxZ, sizeof(float), 1, filePtr);
		fread(&minX, sizeof(float), 1, filePtr);
		fread(&minY, sizeof(float), 1, filePtr);
		fread(&minZ, sizeof(float), 1, filePtr);
	}
	return true;
}