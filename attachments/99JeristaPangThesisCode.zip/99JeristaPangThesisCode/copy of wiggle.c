
#include <windows.h>		//Standard Windows include
#include <gl\gl.h>			//OpenGL Library
#include <gl\glu.h>			// GLU library
#include "resource.h"		// About box resource identifiers.

//Initialize square position and size
GLfloat x1 = 100.0f;
GLfloat y1 = 150.0f;
GLsizei rsize = 50;

//Step size in x and y directions
//(Number of pixels to move each time)
GLfloat xstep = 1.0f;
GLfloat ystep = 1.0f;

//Keep track of window's changing width and height
GLfloat windowWidth;
GLfloat windowHeight;

//Check and display Opengl Errors
/*
static void checkErrors()

{

   GLenum glError;

	int i=0;

	do {
		glError = glGetError();
		SetDlgItemText(hDlg, IDC_ERROR1+i, gluErrorString(glError));
		i++;
	}
	while (i < 6 && glError != GL_NO_ERROR)

}
*/


//Select the pixel format for a given device context
void SetDCPixelFormat(HDC hDC)
{
	int nPixelFormat;

	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),	//size of this structure
			1,							//Version of this structure
			PFD_DRAW_TO_WINDOW |		//draw to window(not bitmap)
			PFD_SUPPORT_OPENGL |		//Support Opengl calls
			PFD_DOUBLEBUFFER,			//Double buffer mode
			PFD_TYPE_RGBA,				//RGBA Color mode
			24,							//Want 24 bit color
			0, 0, 0, 0, 0, 0,			//Not used to select mode
			0, 0,						//Not used to select mode
			0, 0, 0, 0 ,0,
			32,							//Size of depth buffer
			0,
			0,
			PFD_MAIN_PLANE,				//Draw in the main plane
			0,
			0, 0, 0 };

		//Choose a pixel format that best matches that describes in pfd
		nPixelFormat = ChoosePixelFormat(hDC, &pfd);

		//Set the pixel format for the device context
		SetPixelFormat(hDC, nPixelFormat, &pfd);
}

void CALLBACK ChangeSize(GLsizei w, GLsizei h)
{
	//Prevent a divide by zero, when window is too short
	//(you can't make a window of zero width)
	if(h==0)
		h=1;

	//Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	//Reset the coordinate system before modifiying
	glLoadIdentity();

	//Keep the square square, this time, save calculated
	//width and height for later use
	if(w<=h)
	{
		windowHeight = 250.0f*h/w;
		windowWidth = 250.0f;
	}
	else
	{
		windowWidth =250.0f*w/h;
		windowHeight = 250.0f;
	}

	//Set the clipping volume
	glOrtho(0.0f, windowWidth, 0.0f, windowHeight, 1.0f, -1.0f);
}

void CALLBACK RenderScene(void)
{
	//Set background clearing color to blue
	glClearColor(0.0f, 0.0f, 1.0f, 1.0f);

	//Clear the window with the current clearing color
	glClear(GL_COLOR_BUFFER_BIT);

	//Set the drawing color to red, and draw rectangle at
	//current position.

	glColor3f(1.0f, 0.0f, 0.0f);
	glRectf(x1, y1, x1+rsize, y1+rsize);

	glFlush();
}

void CALLBACK IdleFunction(void)
{
	//Reverse direction when you reach left or right edge
	if(x1 > windowWidth-rsize || x1 < 0)
		xstep = -xstep;

	//Reverse direction when you reach top or bottom edge
	if(y1 > windowHeight-rsize || y1 < 0)
		ystep = -ystep;
	
	//Check bounds. This is in case the window is made
	//smaller and the rectangle is outside the new 
	//clipping volume

	if(x1 > windowWidth - rsize)
		x1 = windowWidth-rsize-1;

	if(y1 > windowHeight-rsize)
		y1 = windowHeight-rsize-1;

	//actually move the square
	x1 += xstep;
	y1 += ystep;

	//Redraw the scene with new coordinates
	RenderScene();
}


//Window procedure, handels all messages for this program
LRESULT CALLBACK WndProc(	HWND hWnd,
						 UINT message,
						 WPARAM wParam,
						 LPARAM lParam)
{
	static HGLRC hRC;	//Permanent Rendering context
	static HDC hDC;		//Private GDI Device context

	switch (message)
	{
		//Window creation, setup for OpenGL
	case WM_CREATE:
		//store the device context
		hDC=GetDC(hWnd);

		//Select the pixel format
		SetDCPixelFormat(hDC);

		//Create the rendering context and make it current
		hRC = wglCreateContext(hDC);
		wglMakeCurrent(hDC, hRC);

		//Create a timer that fires every millisecond
		SetTimer(hWnd, 101, 1, NULL);
		break;

		//Window is being destroyed, cleanup
	case WM_DESTROY:
		//Kill the timer we created
		KillTimer(hWnd, 101);

		//Deselect the current rendering context and delete it
		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);

		//Tell the application to terminate after the window
		//is gone
		PostQuitMessage(0);
		break;

		//Window is resized
	case WM_SIZE:
		//Call ourfunction which modifies the clipping
		//volume and viewport
		ChangeSize(LOWORD(lParam), HIWORD(lParam));

		break;
		//Timer, moves and bounces the rectangle, simply calls 
		//our previous OnIdle function, then invalidates the 
		//window so it will be redrawn.
	case WM_TIMER:
		{
			IdleFunction();

			InvalidateRect(hWnd, NULL, FALSE);
		}
		break;
		//The painting function. This message sent by windows
		//whenever the screeen needs updating
	case WM_PAINT:
		{
			//Call OpenGL drawing code
			RenderScene();

			//Call function to swap the buffers
			SwapBuffers(hDC);

			//Validate the newly painted client area
			ValidateRect(hWnd, NULL);
		}
		break;

	default:		//Passes it on if unprocessed
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}

	return(0L);
}



int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine,
					 int nCmdShow)
					 
{

	static char lpszAppName[] = "Wiggle" ;

	MSG msg;		//Windows message structure
	WNDCLASS wc;	//Windows class structure
	HWND hWnd;		//Storage for windows handle

	//Register the windows style
	wc.style		=CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc	=(WNDPROC) WndProc;
	wc.cbClsExtra	=0;
	wc.cbWndExtra	=0;

	wc.hInstance	=hInstance;
	wc.hIcon		=NULL;
	wc.hCursor		=LoadCursor(NULL, IDC_ARROW);

	//No need for background brush for openGL window
	wc.hbrBackground	=NULL;

	wc.lpszMenuName		= MAKEINTRESOURCE(IDR_MENU);
//	wc.lpszMenuName	=NULL;

	wc.lpszClassName	=lpszAppName;

	//Register the window class
	if(RegisterClass(&wc)==0)
		return FALSE;

	//Create the main application window
	hWnd = CreateWindow(
		lpszAppName,
		lpszAppName,

		//OpenGl requires WS_CLIPCHILDREN and WS_CLIPSIBLINGS
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,

		//Window position and size
		100, 100,
		250, 250,

		NULL,
		NULL,
		hInstance,
		NULL);

	//If the window is not created then quit
	if(hWnd==NULL)
		return FALSE;

	//Display the window
	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);

	//Process application messages until the application cloases
	while(GetMessage(&msg, NULL, 0, 0))
		{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}

