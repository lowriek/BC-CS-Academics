# nascar_player_script.rb
# given: url to a player's page and name
# result: adds playerinfo to a file, for importing later

require 'rubygems'
require 'hpricot'
require 'open-uri'

if ( (url = ARGV[0]) == nil || (name = ARGV[1]) == nil)
	# expected url should be complete
  puts "usage: nascar_player_script.rb url driver_name\n"
  exit
end

doc = Hpricot(open(url))

birthday = (doc/'div#mc/table/tr.tablesm/td[2]/div[1]').inner_html.gsub(/<.*>/,'')

line = '<player name="'+name+'" birthday="'+birthday+'" />'
system('echo "<players>" > nascar_players.list')
system('echo \''+line+'\' >> nascar_players.list')
system('echo "</players>" >> nascar_players.list')


