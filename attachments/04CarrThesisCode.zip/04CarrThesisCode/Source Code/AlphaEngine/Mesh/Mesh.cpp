#include "Mesh.h"
#include <string.h>
#include <windows.h>
#include <gl/gl.h>
#include "AlphaEngine/Render/Render.h"
#include "AlphaEngine/Math/Plane.h"

CMesh * CMesh::clone()
{
	unsigned int i;

	CMesh* tMesh = new CMesh();
	
	tMesh->numFace = numFace;
	tMesh->numVert = numVert;
	
	if (pFace)
	{
		tMesh->pFace = new CFace[tMesh->numFace];
		for (i = 0; i < tMesh->numFace; i++)
			tMesh->pFace[i] = pFace[i];
	}
	if (pVert)
	{
		tMesh->pVert = new CVector3[tMesh->numVert];
		for (i = 0; i < tMesh->numVert; i++)
			tMesh->pVert[i] = pVert[i];
	}
	return tMesh;
}

CMesh::CMesh() : CBaseObject()
{
	numFace = 0;
	numVert = 0;
	pFace = 0;
	pVert = 0;
}

CMesh::~CMesh()
{
	reset();
}

void CMesh::insert(CMesh * pMesh)
{
	if (!pMesh)
		return;
	if (!pMesh->pFace)
		return;
	if (!pMesh->pVert)
		return;
	if (pMesh->numFace < 0 || pMesh->numVert < 0)
		return;

	CFace*		pOldFace = pFace;
	CVector3*	pOldVert = pVert;
	unsigned int oldNumFace = numFace;
	unsigned int oldNumVert = numVert;
	unsigned int x;

	numFace = oldNumFace + pMesh->numFace;
	numVert = oldNumVert + pMesh->numVert;
	pFace = new CFace[numFace];
	pVert = new CVector3[numVert];

	// copy local face and vert info in first
	for (x = 0; x < oldNumFace; x++)
		pFace[x] = pOldFace[x];

	for (x = 0; x < oldNumVert; x++)
		pVert[x] = pOldVert[x];

	// copy new face and vert info
	for (x = 0; x < pMesh->numVert; x++)
		pVert[oldNumVert + x] = pMesh->pVert[x];

	for (x=0; x < pMesh->numFace; x++)
	{
		unsigned int index = oldNumFace + x;
		pFace[index] = pMesh->pFace[x];
		// fix vert indices
		for (unsigned int y = 0; y < pFace[index].numVert; y++)
		{
			pFace[index].pVertIndex[y] += oldNumVert;
		}
	}

	delete [] pOldFace;
	delete [] pOldVert;
}

bool CMesh::load(char * meshName)
{
	return true;
}

bool CMesh::rayIntersect(CVector3 &ro, CVector3 &rdir, CVector3 &ip, float &t, unsigned int &faceId, float rad)
{
	bool		collision = false;
	bool		faceCollide = false;
	int			va, vb;
	float		t_t, d1;
	CPlane		t_plane;
	CVector3	t_ip, v1, v2, n1;
	t = 0;
	faceId = 0;
	if (rad < 0)
		rad *= -1;

	for (unsigned int x = 0; x < numFace; x++)
	{
		t_plane.d = -(pFace[x].surfaceNormal.dot(pVert[pFace[x].pVertIndex[0]]));
		t_plane.normal = pFace[x].surfaceNormal;
		if (t_plane.rayIntersect(ro, rdir, t_ip, t_t))
		{
			faceCollide = true;
			for (unsigned int y = 0; y < pFace[x].numVert; y++)
			{
				va = pFace[x].pVertIndex[y];
				vb = pFace[x].pVertIndex[(y+1)%pFace[x].numVert];
				v1 = pVert[va] - t_ip;
				v2 = pVert[vb] - t_ip;
				n1 = v1.unitCross(v2);
				d1 = t_plane.normal.dot(-ro);
				if ( (t_ip.dot(n1) + d1) < rad)
				{
					faceCollide = false;
					break;
				}
			}
			if (faceCollide)
			{
				if (t_t <= t)
				{
					faceId = x;
					t = t_t;
					ip = t_ip;
					collision = true;
				}
			}
		}
	}
	return collision;
}

bool CMesh::rayIntersectTest(CVector3 &ro, CVector3 &rdir, float rad)
{
	bool		faceCollide = false;
	int			va, vb;
	float		t_t, d1;
	CPlane		t_plane;
	CVector3	t_ip, v1, v2, n1;
	
	if (rad < 0)
		rad *= -1;

	for (unsigned int x = 0; x < numFace; x++)
	{
		t_plane.d = -(pFace[x].surfaceNormal.dot(pVert[pFace[x].pVertIndex[0]]));
		t_plane.normal = pFace[x].surfaceNormal;
		if (t_plane.rayIntersect(ro, rdir, t_ip, t_t))
		{
			faceCollide = true;
			for (unsigned int y = 0; y < pFace[x].numVert; y++)
			{
				va = pFace[x].pVertIndex[y];
				vb = pFace[x].pVertIndex[(y+1)%pFace[x].numVert];
				v1 = pVert[va] - t_ip;
				v2 = pVert[vb] - t_ip;
				n1 = v1.unitCross(v2);
				d1 = t_plane.normal.dot(-ro);
				if ( (t_ip.dot(n1) + d1) < rad)
				{
					faceCollide = false;
					break;
				}
			}
			if (faceCollide)
			{
				return true;
			}
		}
	}
	return false;
}

void CMesh::renderFace(unsigned int x, bool b, bool d, bool l)
{
	if (pFace[x].isTransparent)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glColor4f(1,1,1,pFace[x].transparencyValue);
	}
	
	// only b and (d | l) should be active
	glBegin(GL_POLYGON);
	for (unsigned int y = 0; y < pFace[x].numVert; y++)
	{
		if (b)
			Render::glMultiTexCoord2fARB(GL_TEXTURE0_ARB, pFace[x].pBTxCoord[y].x,pFace[x].pBTxCoord[y].y);
		if (d)
			Render::glMultiTexCoord2fARB(GL_TEXTURE1_ARB, pFace[x].pDTxCoord[y].x,pFace[x].pDTxCoord[y].y);
		if (l)
			Render::glMultiTexCoord2fARB(GL_TEXTURE1_ARB, pFace[x].pLTxCoord[y].x,pFace[x].pLTxCoord[y].y);
		glVertex3fv(pVert[pFace[x].pVertIndex[y]].points);
	}
	glEnd();

	if (pFace[x].isTransparent)
	{
		glDisable(GL_BLEND);
		glColor4f(1,1,1,1);
	}
}

void CMesh::render(int flags)
{
	unsigned int x;
	unsigned int y;
	if ((flags & ALPHA_WIREFRAME) == ALPHA_WIREFRAME)
	{
		for (x = 0; x < numFace; x++)
		{
			glBegin(GL_LINE_LOOP);
			for (y = 0; y < pFace[x].numVert; y++)
			{
				glVertex3fv(pVert[pFace[x].pVertIndex[y]].points);
			}
			glEnd();
		}
		return;
	}

	if ((flags & ALPHA_FILL) != ALPHA_FILL)
		return;

	bool bTex = (flags & ALPHA_B_TX) == ALPHA_B_TX;
	bool dTex = (flags & ALPHA_D_TX) == ALPHA_D_TX;
	bool lTex = (flags & ALPHA_L_TX) == ALPHA_L_TX;

	if (Render::glActiveTextureARB == 0 || Render::glMultiTexCoord2fARB == 0)
		return;

	for (x = 0; x < numFace; x++)
	{
		// 5 RENDERING CASES PER FACE
		if (!bTex)
		{
			renderFace(x, false, false, false);
		}
		if (bTex && !dTex && !lTex)
		{
			Render::glActiveTextureARB(GL_TEXTURE0_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].bTxId);
			renderFace(x, true, false, false);
		}
		if (bTex && dTex && !lTex)
		{
			Render::glActiveTextureARB(GL_TEXTURE0_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].bTxId);
			Render::glActiveTextureARB(GL_TEXTURE1_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].dTxId);
			renderFace(x, true, true, false);
		}
		if (bTex && !dTex && lTex)
		{
			Render::glActiveTextureARB(GL_TEXTURE0_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].bTxId);
			Render::glActiveTextureARB(GL_TEXTURE1_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].lTxId);
			renderFace(x, true, false, true);
		}
		if (bTex && dTex && lTex)
		{
			// have to do multipass multitexturing since only using
			// two texture units
			Render::glActiveTextureARB(GL_TEXTURE0_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].bTxId);
			Render::glActiveTextureARB(GL_TEXTURE1_ARB);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, pFace[x].dTxId);
			renderFace(x, true, true, false);
			Render::glActiveTextureARB(GL_TEXTURE0_ARB);
			glDisable(GL_TEXTURE_2D);

			Render::glActiveTextureARB(GL_TEXTURE1_ARB);
			glEnable(GL_TEXTURE_2D);
			glEnable(GL_BLEND);
			glDepthMask(GL_FALSE);
			glDepthFunc(GL_EQUAL);
			glBlendFunc(GL_ZERO, GL_SRC_COLOR);
				glBindTexture(GL_TEXTURE_2D, pFace[x].lTxId);
				renderFace(x, false, false, true);
			glDepthMask(GL_TRUE);
			glDepthFunc(GL_LESS);
			glDisable(GL_BLEND);
		}
		Render::glActiveTextureARB(GL_TEXTURE1_ARB);
		glDisable(GL_TEXTURE_2D);
		Render::glActiveTextureARB(GL_TEXTURE0_ARB);
		glDisable(GL_TEXTURE_2D);
	}
}

void CMesh::reset()
{
	if (pFace)
		delete [] pFace;
	if (pVert)
		delete [] pVert;
	numFace = 0;
	numVert = 0;
	pFace = 0;
	pVert = 0;
}

bool CMesh::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	unsigned int x;

	if (isStoring)
	{
		fwrite(&numFace, sizeof(unsigned int), 1, filePtr);
		fwrite(&numVert, sizeof(unsigned int), 1, filePtr);
		for (x = 0; x < numFace; x++)
			pFace[x].serialize(filePtr, isStoring);
		for (x = 0; x < numVert; x++)
			pVert[x].serialize(filePtr, isStoring);
	}
	else
	{
		CMesh::reset();
		fread(&numFace, sizeof(unsigned int), 1, filePtr);
		fread(&numVert, sizeof(unsigned int), 1, filePtr);
		pVert = new CVector3[numVert];
		pFace = new CFace[numFace];
		for (x = 0; x < numFace; x++)
			pFace[x].serialize(filePtr, isStoring);
		for (x = 0; x < numVert; x++)
			pVert[x].serialize(filePtr, isStoring);
	}

	return true;
}