function [a] = normalize(matrix);
%  Sends back a normalized A as a

%norm = double(matrix) - double(min( matrix(:) ));
a = matrix / max( matrix(:) );
