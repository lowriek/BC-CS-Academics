#ifndef _FRUSTUM_H_
#define _FRUSTUM_H_

#include <windows.h>
#include <gl\gl.h>	
#include <gl\glu.h>
#include <gl\glaux.h>

#include "AlphaEngine/Math/Vector3.h"
#include "AlphaEngine/Math/Plane.h"
#include "AlphaEngine/Math/BoundBox.h"
#include "AlphaEngine/Core/Polygon.h"

class CFrustum {
public:
	CFrustum();
	virtual ~CFrustum();
	
	CFrustum*	adjust(CPolygon* pPolygon, CVector3& position);
	bool		polygonInFrustum(CPolygon* pPolygon);
	bool		pointInFrustum(CVector3& pt);
	void		update();

private:

	void		deletePlanes();
	void		allocatePlanes(unsigned int num);

	CPlane* pPlanes;
	unsigned int numPlanes;
	// seperate near and far planes
	CPlane backPlane;
	CPlane frontPlane;
};

#endif



