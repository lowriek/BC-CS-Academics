// Viewport.h: interface for the CViewport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VIEWPORT_H__7ACA5ABD_D10A_4060_B2D5_F9D3FA95D6A3__INCLUDED_)
#define AFX_VIEWPORT_H__7ACA5ABD_D10A_4060_B2D5_F9D3FA95D6A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OpenGLView.h"

class CViewport  
{
protected:
	CViewport();
public:
	CViewport(COpenGLView * parent);
	virtual ~CViewport();

	virtual void Render();
	virtual void SetupViewport(float perX, float perY, float perWidth, float perHeight);

	virtual void OnSize(UINT nType, int cx, int cy);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	virtual void OnRButtonDown(UINT nFlags, CPoint point);
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	float perX;
	float perY;
	float perWidth;
	float perHeight;

protected:
	COpenGLView * GetParent();
private:
	COpenGLView * parent;
};

#endif // !defined(AFX_VIEWPORT_H__7ACA5ABD_D10A_4060_B2D5_F9D3FA95D6A3__INCLUDED_)
