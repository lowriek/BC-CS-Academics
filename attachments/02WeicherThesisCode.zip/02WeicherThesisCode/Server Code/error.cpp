/*	error.cpp
	John Weicher
	9-25-01
*/
#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>
#include "error.h"
#include "server.h"

/*  This file contains function definitions for the general error-handling 
	module for the raytracer.  These functions are use primarily by the
	ray scene file parser module
*/


//function for processing error messages and generating error messages.
void genError(int errCode, char * paramString)
{

	if(errCode==INVALID_SOURCE_FILE){
		printf("ERROR:  '%s' is not a valid source file.\n", paramString);
		printf("        -  File must have a '.ray' extension\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==FILE_NOT_FOUND){
		printf("ERROR:  File not found.\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==IMPROPER_FILE_CLOSING){
		printf("ERROR:  Error closing input file.\n");
		printf("		-  Aborting operations.\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==IMPROPER_FILE_HEADER){
		printf("ERROR:	Improper source file header.\n");
		printf("		- Line 1: '[rayfile]' expected, '%s' found instead.\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==OBJECT_DEFINITION_EXPECTED){
		printf("ERROR Line %d: Object Definition expected,\n", currentLine);
		printf("  '%s' found instead.\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==GLOBAL_DEFINITION_EXPECTED){
		printf("ERROR Line %d: Globalsl definition expected.\n", currentLine);
		printf(" '%s' found instead\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==MULTIPLE_GLOBAL_TAGS){
		printf("ERROR Line %d: Duplicate Globals declaration encountered.\n", currentLine);
		printf("  Only one global parameters group permitted.\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==MULTIPLE_FILE_HEADERS){
		printf("ERROR Line %d: Duplicate Ray-file header found\n", currentLine);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==PREMATURE_FILE_END){
		printf("ERROR Line %d: END-OF-FILE encountered prematurely,\n", currentLine);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==NESTED_OBJECT_DEFINITION){
		printf("ERROR Line %d: Nested object definition encountered.\n", currentLine);
		printf("  Current object definition must be closed before beginning another\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==INVALID_OBJECT_ATTRIBUTE){
		printf("ERROR Line %d: Unknown object attribute.\n", currentLine);
		printf("  %s is an invalid object attribute.\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==EMPTY_OBJECT_DEFINITION){
		printf("ERROR Line %d: Empty object definition.\n", currentLine);
		printf("  Object definition was closed before defining basic object type.\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==OBJECT_TYPE_NOT_DEFINED){
		printf("ERROR Line %d: Object type not defined.\n", currentLine);
		printf("  - Attempted to define attribute of not yet defined object.\n");
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==OBJECT_TYPE_ALREADY_DEFINED){
		printf("ERROR Line %d: Object type already defined.\n", currentLine);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==INVALID_GLOBAL_ATTRIBUTE){
		printf("ERROR Line %d: Invalid global attribute\n", currentLine);
		printf("  - '%s' is not a valid global attribute.\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==INVALID_OBJECT_TYPE){
		printf("ERROR Line %d:  Invalid object type.\n", currentLine);
		printf("  - Object Type %s Unknown\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	if(errCode==ERROR_EXTRACTING_THREE_VALUES){
		printf("ERROR Line %d:  Unable to extract three values\n", currentLine);
		printf("  - Are all three components numeric values?\n");
		printf("  - Are all three components seperated by commas?\n");
		printf("  - Are the components of the form '<a,b,c>' ?\n");
		printf("\n\n\n");
	}
	if(errCode==ERROR_EXTRACTING_FOUR_VALUES){
		printf("ERROR Line %d:  Unable to extract four values\n", currentLine);
		printf("  - Are all four components numeric values?\n");
		printf("  - Are all four components seperated by commas?\n");
		printf("  - Are the components of the form '<a,b,c,d>' ?\n");
		printf("\n\n\n");
	}
	if(errCode==INVALID_LIGHT_SOURCE_ATTRIBUTE){
		printf("ERROR Line %d: Invalid Light Source attribute\n", currentLine);
		printf("  - '%s' is not a valid light source component\n", paramString);
		printf("\n\n\n");
	}
	if(errCode==INVALID_ATTRIBUTE_VALUE){
		printf("ERROR Line %d: Invalid attribute value.\n", currentLine);
		printf("  - '%s' is not a valid value for the given attribute\n", paramString);
		printf("\n\n\n");
		exit(0);
	}
	
}
		 
