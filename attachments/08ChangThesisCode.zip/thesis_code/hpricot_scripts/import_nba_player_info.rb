# import_nba_player_info.rb
# run master_basketball_player_script.rb first

require 'rubygems'
require 'hpricot'

# import player info from basketball_player_info.list
doc = Hpricot(open('basketball_player_info.list'))
(doc/'playerprofile').each { |p|
	name = p.get_attribute('name')
	bday = p.get_attribute('bday')
	bplace = p.get_attribute('bplace')
	height = p.get_attribute('height')
	url = p.get_attribute('pictureurl')
	@player = Player.find_by_name(name)
	if (@player != nil)
		@player.birthday = "'"+bday.to_s+"'"
		@player.birthplace = "'"+bplace.to_s+"'"
		@player.height = "'"+height.to_s+"'"
		@player.pictureurl = "'"+url.to_s+"'"
		@player.save
	else
		Player.create :name => name, :birthday => bday.to_s, :birthplace => bplace.to_s, :height => height.to_s, :pictureurl => url.to_s
	end
}

# the names are written differently!
# in db, last,first
# in here, first,last
