// ArchitectViewport.cpp: implementation of the CArchitectViewport class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldEditor.h"
#include "ArchitectViewport.h"
#include "MainFrm.h"
#include "AlphaEngine/Math/Math.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


CArchitectViewport::CArchitectViewport()
{

}

CArchitectViewport::CArchitectViewport(COpenGLView* parent) : COrthoViewport(parent)
{
	// default to xy view
	m_axis = CVector3(1,1,0);
	m_maxDistance = 4096.0f;
	CheckGridSize();
	USER_MODE = NO_INTERACTION;
	fontMgr.CreateBitmapFont(GetParent()->m_pDC->GetSafeHdc(), "Arial Narrow", -12);

}

CArchitectViewport::~CArchitectViewport()
{

}


void CArchitectViewport::CheckGridSize()
{
	// keeps pane readable on every zoom level.
	int min = m_zoom - 5;
	int max = m_zoom - 2;
	
	if (min < 0)
		min = 0;
	
	if (max < 0)
		max = 0;
	
	if (m_nGridSize < min)
		m_nGridSize = min;
	if (m_nGridSize > max)
		m_nGridSize = max;	
}

void CArchitectViewport::DecreaseGridSize()
{
	m_nGridSize--;
	CheckGridSize();
}

void CArchitectViewport::DrawGridLabels()
{
	char buffer [10];
	
	int interval = (int) pow(2, m_nGridSize) * 4;
	float offset = GetSideLength() / 2.0f;
	float baseX = m_midPt[0] - offset;
	float baseY = m_midPt[1] - offset;
	float baseZ = m_midPt[2] - offset;
	for (float i = -4096; i <= 4096; i+=interval) {
		itoa((int)i, buffer, 10);

		// XY PERSPECTIVE (TOP)
		if (m_axis[0] == 1 && m_axis[1] == 1 && m_axis[2] == 0)
		{
			glColor3f(0.8f,0.0f,0.0f);
			fontMgr.PrintString(buffer, i, baseY, 0); 

			glColor3f(0.0f,0.5f,0.0f);
			fontMgr.PrintString(buffer, baseX, i, 0); 
		}
		// XZ PERSPECTIVE (FRONT)
		else if (m_axis[0] == 1 && m_axis[1] == 0 && m_axis[2] == 1)
		{
			glColor3f(0.8f,0.0f,0.0f);
			fontMgr.PrintString(buffer, i, 0, baseZ); 

			glColor3f(0.0f,0.0f,0.8f);
			fontMgr.PrintString(buffer, baseX, 0, i); 
		}

		// YZ PERSPECTIVE (SIDE)
		else if (m_axis[0] == 0 && m_axis[1] == 1 && m_axis[2] == 1)
		{
			glColor3f(0.0f,0.5f,0.0f);
			fontMgr.PrintString(buffer, 0, i, baseZ);
			
			glColor3f(0.0f,0.0f,0.8f);
			fontMgr.PrintString(buffer, 0, baseY, i); 
		}		
	}
}

void CArchitectViewport::DrawGridLines()
{
	int interval = (int) pow(2, m_nGridSize);
	int darkLine = interval * 4;
	
	glBegin(GL_LINES);
	for (float i = -m_maxDistance; i <= m_maxDistance; i+=interval)
	{
		if ((int)i % darkLine == 0)
			glColor3f(0,0,0);
		else
			glColor3f(0.8f, 0.8f, 0.8f);

		// XY PERSPECTIVE (TOP)
		if (m_axis[0] == 1 && m_axis[1] == 1 && m_axis[2] == 0)
		{
			glVertex3f(i,-m_maxDistance,0);
			glVertex3f(i,+m_maxDistance,0);
			
			glVertex3f(-m_maxDistance,i,0);
			glVertex3f(+m_maxDistance,i,0);
		}

		// XZ PERSPECTIVE (FRONT)
		else if (m_axis[0] == 1 && m_axis[1] == 0 && m_axis[2] == 1)
		{
			glVertex3f(i,0,-m_maxDistance);
			glVertex3f(i,0,+m_maxDistance);

			glVertex3f(-m_maxDistance,0,i);
			glVertex3f(+m_maxDistance,0,i);
		}
		// YZ PERSPECTIVE (SIDE)
		else if (m_axis[0] == 0 && m_axis[1] == 1 && m_axis[2] ==1)
		{
			glVertex3f(0,i,-m_maxDistance);
			glVertex3f(0,i,+m_maxDistance);

			glVertex3f(0,-m_maxDistance,i);
			glVertex3f(0,+m_maxDistance,i);
		}
	}
	glEnd();
}

void CArchitectViewport::DrawSelectedRegion()
{
	if (USER_MODE == REGION_SELECTED || USER_MODE == REGION_SELECTING)
	{
		glColor3f(1,0,0);
		glPushAttrib(GL_LINE_BIT);
			glLineWidth(2);
			glLineStipple(1, 0xAAAA);
			glEnable(GL_LINE_STIPPLE);
		glBegin(GL_LINES);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p2[2]);

			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p2[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p2[2]);

			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p2[2]);

			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p2[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p2[2]);

			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p1[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p1[2]);

			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p2[2]);
			glVertex3f(selectedRegion.p2[0], selectedRegion.p1[1], selectedRegion.p2[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p1[1], selectedRegion.p2[2]);
			glVertex3f(selectedRegion.p1[0], selectedRegion.p2[1], selectedRegion.p2[2]);
		glEnd();
		glPopAttrib();
	}
}

void CArchitectViewport::IncreaseGridSize()
{
	m_nGridSize++;
	CheckGridSize();
}

void CArchitectViewport::OnButtonBox()
{
	if (USER_MODE != REGION_SELECTED)
		return;
	
	GetParent()->GetDocument()->CreateBox(m_axis, selectedRegion.p1, selectedRegion.p2);

	USER_MODE = NO_INTERACTION;
}

void CArchitectViewport::OnButtonSphere()
{
	if (USER_MODE != REGION_SELECTED)
		return;
	
	GetParent()->GetDocument()->CreateSphere(m_axis, selectedRegion.p1, selectedRegion.p2);

	USER_MODE = NO_INTERACTION;
}
void CArchitectViewport::PrepareToRender()
{
	SetupProjection();
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (m_axis[0] == 1 && m_axis[1] == 1 && m_axis[2] == 0)
		glTranslatef(-m_midPt[0], -m_midPt[1], 0);	
	else if (m_axis[0] == 1 && m_axis[1] == 0 && m_axis[2] == 1)
	{
		glTranslatef(-m_midPt[0], -m_midPt[2], 0);
		glRotatef(-90, 1,0,0);
	}
	else if (m_axis[0] == 0 && m_axis[1] == 1 && m_axis[2] == 1)
	{
		glTranslatef(-m_midPt[1], -m_midPt[2], 0);
		glRotatef(-90, 1,0,0);
		glRotatef(-90, 0,0,1);
	}
}

void CArchitectViewport::Render()
{
	COrthoViewport::Render();
	PrepareToRender();
	DrawGridLines();
	DrawGridLabels();
	DrawSelectedRegion();
	if (GetParent()->GetDocument()->pAlphaEngine)
	{
		if (GetParent()->GetDocument()->pAlphaEngine->pCamera)
		{
			GetParent()->GetDocument()->pAlphaEngine->pCamera->Render();
			GetParent()->GetDocument()->Render(ALPHA_WIREFRAME);
		}
	}
}

CVector3 CArchitectViewport::ScreenToWorld(CVector2 pt)
{

	CVector3 val;
	
	float parentWidth = (float) GetParent()->winWidth;
	float parentHeight = (float) GetParent()->winHeight;

	float ratX = pt.x / (perWidth * parentWidth);
	float ratY = pt.y / (perHeight * parentHeight);
	
	float sideLength = GetSideLength();
	float halfSideLength = sideLength / 2.0f;

	float deltaX = (ratX * sideLength) - halfSideLength;
	float deltaY = (ratY * sideLength) - halfSideLength;

	// XY
	if (m_axis[0] == 1 && m_axis[1] == 1)
	{
		val[0] = deltaX + m_midPt[0];
		val[1] = deltaY + m_midPt[1];
		val[2] = 0;
	}
	// YZ
	if (m_axis[1] == 1 && m_axis[2] == 1)
	{
		val[0] = 0;
		val[1] = deltaX + m_midPt[1];
		val[2] = deltaY + m_midPt[2];
	}
	// XZ
	if (m_axis[0] == 1 && m_axis[2] == 1)
	{
		val[0] = deltaX + m_midPt[0];
		val[1] = 0;
		val[2] = deltaY + m_midPt[2];
	}
	return val;
}

CVector3 CArchitectViewport::SnapToGrid(CVector3 pt)
{
	CVector3 point;

	int denominator = (int)pow(2, m_nGridSize);
	
	for (int x = 0; x < 3; x++)
	{
		int div = (int)(pt[x] / denominator);

		point[x] = (float)(div * denominator);
	}

	return point;	
}

void CArchitectViewport::OnLButtonDown(UINT nFlags, CPoint point)
{
	
	if (nFlags & MK_CONTROL)
	{
		PrepareToRender();
		GetParent()->GetDocument()->PickPBrush(ALPHA_WIREFRAME, point.x, point.y);
	}
	else if (!GetParent()->GetDocument()->BrushesSelected())
	{
		CVector2 pt;
		pt.x = (float)point.x;
		pt.y = (float)point.y;
		selectedRegion.p1 = SnapToGrid(ScreenToWorld(pt));
		selectedRegion.p2 = selectedRegion.p1;
		USER_MODE = REGION_SELECTING;
	}
	else if (GetParent()->GetDocument()->BrushesSelected())
	{
		if (GetParent()->GetDocument()->BRUSH_MANIP_MODE == TRANSLATE)
			USER_MODE = TRANSLATE_BRUSH;
		else if (GetParent()->GetDocument()->BRUSH_MANIP_MODE == ROTATE)
			USER_MODE = ROTATE_BRUSH;
		else if (GetParent()->GetDocument()->BRUSH_MANIP_MODE == SCALE)
			USER_MODE = SCALE_BRUSH;
	}
}
void CArchitectViewport::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (USER_MODE == REGION_SELECTING)
	{
		CVector2 pt;
		pt.x = (float)point.x;
		pt.y = (float)point.y;
		selectedRegion.p2 = SnapToGrid(ScreenToWorld(pt));
		// check for valid selection
		int shareCount = 0;
		for (int x = 0; x < 3; x++)
		{
			if (selectedRegion.p1[x] == selectedRegion.p2[x])
				shareCount++;
		}
		if (shareCount <= 1)
			USER_MODE = REGION_SELECTED;
		else
		{
			USER_MODE = NO_INTERACTION;
			GetParent()->GetDocument()->UpdateAllViews(NULL);
		}
	}
	else
	{
		USER_MODE = NO_INTERACTION;
		GetParent()->GetDocument()->UpdateAllViews(NULL);
	}
}
void CArchitectViewport::OnMouseMove(UINT nFlags, CPoint point)
{
	CVector2 pt;
	pt.x = (float)point.x;
	pt.y = (float)point.y;

	CVector3 pt3 = SnapToGrid(ScreenToWorld(pt));
	CString strText;
	strText.Format("Mouse Pos:(%i, %i, %i)", (int)pt3[0], (int)pt3[1], (int)pt3[2]);
	CMainFrame *pMainFrame = (CMainFrame*)GetParent()->GetParentFrame();
	pMainFrame->SetMousePosText(strText);


	if (USER_MODE == REGION_SELECTING) 
	{
		selectedRegion.p2 = pt3;
		GetParent()->GetDocument()->UpdateAllViews(NULL);
	} else if (USER_MODE == TRANSLATE_BRUSH)
	{
		// translate the brush
		CMatrix44 transform;
		CVector3 lastPt3 = SnapToGrid(ScreenToWorld(lastMousePt));
		transform.translate(pt3 - lastPt3);
		GetParent()->GetDocument()->TransformBrushes(transform);
	} else if (USER_MODE == ROTATE_BRUSH)
	{
		CMatrix44 transform;
		CVector2 v;
		v.y = pt.y - lastMousePt.y;
		if (v.y != 0)
		{
			float angle = 0;
			if (v.y > 0)
				angle = CMath::TWO_PI / 36.0f;
			else 
				angle = -CMath::TWO_PI / 36.0f;

			if (m_axis[0] == 1 && m_axis[1] == 1)
				transform.rotateZ(angle);
			if (m_axis[0] == 1 && m_axis[2] == 1)
				transform.rotateY(angle);
			if (m_axis[1] == 1 && m_axis[2] == 1)
				transform.rotateX(angle);

			GetParent()->GetDocument()->TransformBrushes(transform);
		}
	} else if (USER_MODE == SCALE_BRUSH)
	{
		GetParent()->GetDocument()->BrushScale(pt3, SnapToGrid(ScreenToWorld(lastMousePt)));
	}
	lastMousePt.x = pt.x;
	lastMousePt.y = pt.y;
}
void CArchitectViewport::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	if (zDelta > 0) 
	{
		ZoomIn();
		CheckGridSize();
		GetParent()->GetDocument()->UpdateAllViews(NULL);
	} else
	{
		ZoomOut();
		CheckGridSize();
		GetParent()->GetDocument()->UpdateAllViews(NULL);
	}
}

void CArchitectViewport::OnRButtonDown(UINT nFlags, CPoint point)
{
	if (nFlags & MK_CONTROL)
	{
		CVector2 pt;
		pt.x = (float)point.x;
		pt.y = (float)point.y;
		m_midPt = SnapToGrid(ScreenToWorld(pt));
		GetParent()->GetDocument()->UpdateAllViews(NULL);
	}
}
void CArchitectViewport::OnRButtonUp(UINT nFlags, CPoint point)
{

}
