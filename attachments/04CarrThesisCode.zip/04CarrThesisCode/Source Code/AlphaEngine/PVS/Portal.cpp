#include "AlphaEngine/PVS/Portal.h"

CPortal::CPortal() : CPolygon()
{
	isMirror = false;
}

CPortal::~CPortal()
{
}

CPortal* CPortal::clone()
{
	CPortal* pPortal = new CPortal();
	pPortal->allocate(numVert);
	pPortal->alpha = alpha;
	pPortal->bTxId = bTxId;
	pPortal->dTxId = dTxId;
	pPortal->plane = plane;
	pPortal->flag = flag;
	for (unsigned int x = 0; x < numVert; x++)
	{
		pPortal->pBTxCoord[x] = pBTxCoord[x];
		pPortal->pDTxCoord[x] = pDTxCoord[x];
		pPortal->pVert[x] = pVert[x];
	}
	pPortal->fromSectorId = fromSectorId;
	pPortal->id = id;
	pPortal->isMirror = isMirror;
	pPortal->partitionId = partitionId;
	pPortal->toSectorId = toSectorId;

	return pPortal;
}

void CPortal::render(int flags)
{
//	if (isMirror)
		CPolygon::render(flags);
}

bool CPortal::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&id, sizeof(unsigned int), 1, filePtr);
		fwrite(&fromSectorId, sizeof(unsigned int), 1, filePtr);
		fwrite(&toSectorId, sizeof(unsigned int), 1, filePtr);
		fwrite(&isMirror, sizeof(bool), 1, filePtr);
		fwrite(&partitionId, sizeof(unsigned int), 1, filePtr);
	}
	else
	{
		fread(&id, sizeof(unsigned int), 1, filePtr);
		fread(&fromSectorId, sizeof(unsigned int), 1, filePtr);
		fread(&toSectorId, sizeof(unsigned int), 1, filePtr);
		fread(&isMirror, sizeof(bool), 1, filePtr);
		fread(&partitionId, sizeof(unsigned int), 1, filePtr);
	}

	return CPolygon::serialize(filePtr, isStoring);
}

// Begin CPortalList
void CPortalList::add(CPortal* pPortal)
{
	if (listSize == capacity)
		increaseCapacity();

	pPortalList[listSize]=pPortal;
	listSize++;
}

void CPortalList::clear()
{
	for (unsigned int i=0; i < listSize; i++)
	{
		CPortal* pPortal = pPortalList[i];
		if (pPortal)
			delete pPortal;

		pPortalList[i] = 0;
	}
	listSize = 0;
}

CPortalList::CPortalList()
{
	listSize=0;
	capacity=50;
	pPortalList = new CPortal*[capacity];
}

CPortalList::~CPortalList()
{
	if (pPortalList)
		delete [] pPortalList;
}

CPortal* CPortalList::get(unsigned int index)
{
	if (index >= listSize)
		return 0;

	return pPortalList[index];
}

void CPortalList::increaseCapacity()
{
	CPortal** pPortals = new CPortal*[capacity*2];
	for (unsigned int i=0; i < capacity; i++)
		pPortals[i] = pPortalList[i];

	delete [] pPortalList;
	pPortalList = pPortals;
	capacity = capacity*2;
}

void CPortalList::remove(unsigned int index)
{
	if (index >= listSize)
		return;

	CPortal* pPortal = pPortalList[index];
	delete pPortal;
	pPortalList[index] = 0;

	for (unsigned int i=index; i < listSize; i++)
		pPortalList[i] = pPortalList[i+1];

	listSize--;
}

unsigned int CPortalList::size()
{
	return listSize;
}

// End CPortalList

