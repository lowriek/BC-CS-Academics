#ifndef _BOUNDBOX_H_
#define _BOUNDBOX_H_

#include <stdio.h>
#include "AlphaEngine/Math/Vector3.h"

class CBoundBox {
public:
	CBoundBox();
	~CBoundBox();

	float minX, minY, minZ;
	float maxX, maxY, maxZ;

	void addVert(CVector3 &vert);
	bool rayIntersect(CVector3 &ro, CVector3 &rd, float &tnear, float &tfar);
	bool serialize(FILE * filePtr, bool isStoring);
	float getVolume();
	CBoundBox& operator= (const CBoundBox& rBox);
};
#endif