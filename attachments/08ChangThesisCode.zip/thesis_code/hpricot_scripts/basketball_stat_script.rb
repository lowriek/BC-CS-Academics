require 'rubygems'
require 'hpricot'
require 'open-uri'

# url (game)
# url = 'http://sports.espn.go.com/nba/boxscore?gameId=280307020'
if ( (url = ARGV[0]) == nil)
  puts "usage: basketball_stat_script.rb url\n"
  exit
end

doc = Hpricot(open("http://sports.espn.go.com"+url))
newfn = 'new_game.list'
oldfn = 'old_game.list'

# this script is given a game
# add the given game url to the old_game.list
system("echo "+url+" >> "+oldfn)
# and remove it from new_game.list
system("grep -iv '"+url.gsub("/nba/boxscore?","")+"' "+newfn+" > temp")
system("cat temp > "+newfn)

system("echo -n > temp")
#c# create game - name will be the url, date get from website
# Game.create :name => url, :date => ...
game_create = "Game.create :name => '"+url+"'"
system("echo \""+game_create+"\" >> temp")
#system("ruby ../sports1/script/console < temp")
gameid = "Game.find_by_name('"+url+"').id"

#c# create game_team(s) - should make 2, game-team1 and game-team2
# GameTeam.create :game_id => above, :team_id => firstteam
# GameTeam.create :game_id => above, :team_id => secondteam
team1 = (doc/'tr.stathead/td')[0].inner_html
team2 = (doc/'tr.stathead/td')[1].inner_html
team1id = "Team.find_by_name('"+team1+"').id"
team2id = "Team.find_by_name('"+team2+"').id"
game_team_create1 = "GameTeam.create :game_id => "+gameid+", :team_id => "+team1id
game_team_create2 = "GameTeam.create :game_id => "+gameid+", :team_id => "+team2id
system("echo \""+game_team_create1+"\" >> temp")
#system("ruby ../sports1/script/console < temp")
system("echo \""+game_team_create2+"\" >> temp")
#system("ruby ../sports1/script/console < temp")

# loop
# 	get name of player, split into fname, lname tokens

# 	playernames in db are of format 'lname, fname' <= must match this
#c# create stats: points
counter = 0
(doc/'div.gp-body/table/tr.oddrow').each { |p|
	if ((p/'a').to_s != "") then
		fullname = (p/'a').inner_html.gsub(/['"]/,'')
		counter += 1
		puts fullname+" "+counter.to_s
		fname = fullname.split[0]
		lname = fullname.split[1]
		name = lname+", "+fname
		playerid = 'Player.find_by_name(\"'+name+'\").id'
		statconceptid = "Statconcept.find_by_name('points').id"
		value = ( (p/'td[14]').inner_html ).to_i
		gameid = gameid
		input = "Stat.create :player_id=>"+playerid+",:statconcept_id=>"+statconceptid+", :value => "+value.to_s+", :game_id => "+gameid
		system("echo \""+input+"\" >> temp")
		#system("ruby ../sports1/script/console < temp")
	end
}

(doc/'div.gp-body/table/tr.evenrow').each { |p|
	if ((p/'a').to_s != "") then
		fullname = (p/'a').inner_html
		counter += 1
		puts fullname+" "+counter.to_s
		fname = fullname.split[0]
		lname = fullname.split[1]
		name = lname+", "+fname
		playerid = 'Player.find_by_name(\"'+name+'\").id'
		statconceptid = "Statconcept.find_by_name('points').id"
		value = ( (p/'td[14]').inner_html ).to_i
		gameid = gameid
		input = "Stat.create :player_id=>"+playerid+",:statconcept_id=>"+statconceptid+", :value => "+value.to_s+", :game_id => "+gameid
		system("echo \""+input+"\" >> temp")
		#system("ruby ../sports1/script/console < temp")
	end
}

# flush temp file
system("ruby ../sports1/script/console < temp")
