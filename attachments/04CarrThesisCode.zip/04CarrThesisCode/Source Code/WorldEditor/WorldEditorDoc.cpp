// WorldEditorDoc.cpp : implementation of the CWorldEditorDoc class
//

#include "stdafx.h"
#include "WorldEditorDoc.h"
#include <stdio.h>
#include <fstream>

using std::ifstream;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
void CWorldEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}
#endif

bool CWorldEditorDoc::BrushesSelected()
{
	if (!pAlphaEngine)
		return false;

	return pAlphaEngine->pBrushMgr->brushesSelected();
}

void CWorldEditorDoc::BrushScale(CVector3 p1, CVector3 p2)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->brushScale(p1, p2);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CreateBox(CVector3 axis, CVector3 p1, CVector3 p2)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->createBrush(ALPHA_BOX, axis, p1, p2, 32);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CreateSphere(CVector3 axis, CVector3 p1, CVector3 p2)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->createBrush(ALPHA_SPHERE, axis, p1, p2, 32);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CSGAdd()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->csgAdd();
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CSGSub()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->csgSub();
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CreateBsp()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->createBsp();
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::CreatePvs()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->createPvs();
	UpdateAllViews(NULL);
}

CWorldEditorDoc::CWorldEditorDoc()
{
	pAlphaEngine = 0;
}

CWorldEditorDoc::~CWorldEditorDoc()
{
	if (pAlphaEngine)
		delete pAlphaEngine;

	pAlphaEngine = 0;
}

void CWorldEditorDoc::DeleteBuilder()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->deleteBuilder();
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::DeletePBrush()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->deletePBrush();
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::DeselectPBrush()
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->deselectPBrush();
	pAlphaEngine->pBrushMgr->deselectPBrushPoly();
	UpdateAllViews(NULL);
}

#ifdef _DEBUG
void CWorldEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif 

CTexture* CWorldEditorDoc::GetTextures()
{
	if (!pAlphaEngine)
		return 0;
	
	return pAlphaEngine->pTextureMgr->getTextures();
}

BOOL CWorldEditorDoc::InitDocument()
{
	char szBuffer[_MAX_PATH]; 
	VERIFY(::GetModuleFileName(AfxGetInstanceHandle(), szBuffer, _MAX_PATH));
	CString sPath = (CString)szBuffer;
	sPath = sPath.Left(sPath.ReverseFind('\\'));
	CString pPath = sPath + "\\properties.txt";
	// read in texture pack file path
	char path[50];
	std::ifstream inputFile;

	inputFile.open(pPath, ios::in);
	if (!inputFile)
		return FALSE;

	inputFile >> path;

	inputFile.close();


	CString tPath = sPath + "\\" + path;

	if (pAlphaEngine)
	{
		pAlphaEngine->shutdown();
		delete pAlphaEngine;
		pAlphaEngine = 0;
	}

	pAlphaEngine = new CAlphaEngine();
	
	if (!pAlphaEngine->init())
		return FALSE;

	if (!pAlphaEngine->pTextureMgr->loadTexturePak(tPath))
		return FALSE;

	BRUSH_MANIP_MODE = TRANSLATE;
	RENDER_MODE = ALPHA_RENDER_BRUSH;
	UPDATE_LIST = TRUE;

	return TRUE;
}

BOOL CWorldEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// reset state to start state
	if (!InitDocument())
		return FALSE;

	UpdateAllViews(NULL);
	return TRUE;
}

BOOL CWorldEditorDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!InitDocument())
		return FALSE;

	FILE * filePtr = NULL;
	filePtr = fopen(lpszPathName, "rb");
	if (!filePtr)
		return FALSE;

	if (!pAlphaEngine->serialize(filePtr, false))
	{
		fclose(filePtr);
		return FALSE;
	}

	fclose(filePtr);

	UpdateAllViews(NULL);
	return TRUE;	
}

BOOL CWorldEditorDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	if (!pAlphaEngine)
		return FALSE;

	FILE * filePtr = NULL;
	filePtr = fopen(lpszPathName, "wb");
	if (!filePtr)
		return FALSE;

	if (!pAlphaEngine->serialize(filePtr, true))
	{
		fclose(filePtr);
		return FALSE;
	}

	fclose(filePtr);
	return TRUE;
}

void CWorldEditorDoc::PickPBrush(int displayMode, int x, int y)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->pickPBrush(displayMode, x, y);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::PickPoly(int displayMode, int x, int y)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->pickPBrushPoly(displayMode, x, y);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::Render(int mode) 
{
	if (pAlphaEngine)
		pAlphaEngine->render(RENDER_MODE, mode);
}

void CWorldEditorDoc::SetBaseTx(const char* textureName)
{
	if (!pAlphaEngine)
		return;

	unsigned int texId = pAlphaEngine->pTextureMgr->getTextureId(textureName);
	pAlphaEngine->pBrushMgr->setBaseTx(texId);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::SetDecalTx(const char *textureName)
{
	if (!pAlphaEngine)
		return;
	
	unsigned int texId = 0;

	if (textureName)
		texId = pAlphaEngine->pTextureMgr->getTextureId(textureName);

	pAlphaEngine->pBrushMgr->setDecalTx(texId);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::SetPolygonProp(const PolygonProp &polygonProp)
{
	if (!pAlphaEngine)
		return;

	pAlphaEngine->pBrushMgr->setPolygonProp(polygonProp);
	UpdateAllViews(NULL);
}

void CWorldEditorDoc::SetRenderBrush()
{
	RENDER_MODE = ALPHA_RENDER_BRUSH;
}

void CWorldEditorDoc::SetRenderCSG()
{
	RENDER_MODE = ALPHA_RENDER_CSG;
}

void CWorldEditorDoc::SetRenderFinal()
{
	RENDER_MODE = ALPHA_RENDER_FINAL;
}

void CWorldEditorDoc::TransformBrushes(const CMatrix44& matrix)
{
	if (!pAlphaEngine)
		return;
	
	pAlphaEngine->pBrushMgr->transform(matrix);
	UpdateAllViews(NULL);
}
/////////////////////////////////////////////////////////////////////////////
// CWorldEditorDoc

IMPLEMENT_DYNCREATE(CWorldEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CWorldEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CWorldEditorDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()








