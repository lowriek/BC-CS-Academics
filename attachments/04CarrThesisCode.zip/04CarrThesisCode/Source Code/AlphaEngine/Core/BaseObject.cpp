#include "BaseObject.h"
#include "BaseObjectMgr.h"

void CBaseObject::assignObjectId()
{
	objectId = CBaseObjectMgr::getInstance()->getObjectId();
}

CBaseObject::CBaseObject()
{
	objectId = 0;
}

CBaseObject::~CBaseObject()
{
	CBaseObjectMgr::getInstance()->freeObjectId(objectId);
}

bool CBaseObject::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&objectId, sizeof(unsigned long), 1, filePtr);
	}
	else
	{
		fread(&objectId, sizeof(unsigned long), 1, filePtr);
	}

	return true;
}
