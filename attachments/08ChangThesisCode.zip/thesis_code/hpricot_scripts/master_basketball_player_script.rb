require 'rubygems'
require 'hpricot'
require 'open-uri'

# process all players script
# given: the page with all the player links
# from this page, extract all the player's urls, along with the string for the team
# then, for each url
#		run script for each player (basketball_player_script.rb)

url = 'http://sports.espn.go.com/nba/players?league=nba&position=all'
playerurlsfile = 'basketball_player_urls.list'
playerinfofile = 'basketball_player_info.list'
system("echo -n > "+playerurlsfile)
system("echo -n > "+playerinfofile)
	puts "reached here a"
doc = Hpricot(open(url))
counter = 0
	puts "reached here b"

	puts "reached here c"
(doc/'div.content/div.sp-col1/div.sp-col1-inner/table[2]/tr.oddrow').each { |e|
	counter+=1
	puts counter.to_s
	#puts e
	name = (e/'td[1]/a').inner_html.gsub(/['"]/,'')
	puts name
	team = (e/'td[2]/a').inner_html
	playerurl = (e/'td[1]/a').attr('href')
	input = '<player name ="'+name+'" team="'+team+'" url="'+playerurl+'" />'
	puts input
	system("echo '<player name=\""+name+"\" team=\""+team+"\" url=\""+playerurl+"\" />' >> "+playerurlsfile)
	fullurl = "http://sports.espn.go.com/nba/"+playerurl
	system("ruby basketball_player_script.rb "+fullurl+" '"+name+"'")
}
puts "second loop"
(doc/'div.content/div.sp-col1/div.sp-col1-inner/table[2]/tr.evenrow').each { |e|
	#puts e
	counter+=1
	puts counter.to_s
	name = (e/'td[1]/a').inner_html.gsub(/['"]/,'')
	puts name
	team = (e/'td[2]/a').inner_html
	playerurl = (e/'td[1]/a').attr('href')
	input = '<player name ="'+name+'" team="'+team+'" url="'+playerurl+'" />'
	puts input
	system("echo '<player name=\""+name+"\" team=\""+team+"\" url=\""+playerurl+"\" />' >> "+playerurlsfile)
	fullurl = "http://sports.espn.go.com/nba/"+playerurl
	system("ruby basketball_player_script.rb "+fullurl+" '"+name+"'")
}
# remove duplicates (just in case)
system("cat "+playerurlsfile+" | sort | uniq > temp")
system("cat temp > "+playerurlsfile)
system("cat "+playerinfofile+" | sort | uniq > temp")
system("cat temp > "+playerinfofile)

# add xml starting/ending tags to make hpricot happy
system("echo '<players>' > temp")
system("cat "+playerurlsfile+" >> temp")
system("cat temp > "+playerurlsfile)
system("echo '</players>' >> "+playerurlsfile)

system("echo '<profiles>' > temp")
system("cat "+playerinfofile+" >> temp")
system("cat temp > "+playerinfofile)
system("echo '</profiles>' >> "+playerinfofile)


