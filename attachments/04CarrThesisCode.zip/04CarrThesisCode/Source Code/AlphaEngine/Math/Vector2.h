#ifndef _CVECTOR2_H_
#define _CVECTOR2_H_

#include <stdio.h>

class CVector2  
{
public:
	CVector2(float x, float y);
	CVector2();
	virtual ~CVector2();
	float x, y;

	CVector2& operator= (const CVector2& rVector);

	bool serialize(FILE * filePtr, bool isStoring);
};

#endif
