#ifndef _BSPOBJECT_H_
#define _BSPOBJECT_H_

#include "AlphaEngine/Core/BaseObject.h"
#include "AlphaEngine/Core/Particle.h"
#include "AlphaEngine/Math/LocalCoord.h"
#include "AlphaEngine/Mesh/Mesh.h"

class CBspObject : public CBaseObject, public CParticle, public CLocalCoord
{
public:
	CBspObject();
	virtual ~CBspObject();

	virtual void addBspObject(CBspObject* pBspObject);

	virtual CBspObject* clone();
	virtual void destroy();
	virtual CMesh* getMesh();
	virtual bool init();
	virtual bool rayIntersect(CVector3 &ro, CVector3 &rd, CVector3 &ip, float &t, float rad=0.0f);
	virtual void render(int flags);
	virtual bool serialize(FILE * filePtr, bool isStoring);
	virtual bool update(long deltaTime);

	CMesh * pMesh;
	CBspObject * pNext;
	CBspObject * pPrev;
	int type;
};

#endif