#include "Rect3d.h"
#include "Math.h"

CRect3d::CRect3d()
{

}

CRect3d::~CRect3d()
{

}

CMatrix44 CRect3d::GetScaleMatrix()
{
    CMatrix44 matrix;

	CVector3 scalar;

	for (int x = 0; x < 3; x++)
	{
		scalar[x] = CMath::FAbs(p2[x] - p1[x]) / 2.0f;
		if (scalar[x] == 0.0f)
			scalar[x] = 1.0f;
	}

	matrix.scale(scalar);

    return matrix;	
}

CVector3 CRect3d::GetCenter()
{
	return (p2+p1) / 2.0f;
}