#ifndef ENVIRONS_H
#define ENVIRONS_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENVIRONS.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	October 1, 2001 					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include <windows.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include "entity.h"
#include "Model.h"
#include "timeKeeper.h"


#define CLOUD_LIGHT    8
#define CLOUD_MEDIUM   5
#define CLOUD_HEAVY    3

class FogFX : public Entity
{
private:
	bool active;
	float cv[4];
	bool outDoor;

public: 
	FogFX();
	FogFX(float dens,float startFog, float endFog, float col[]);
	Toggle();
	void Draw();


};

class LightFX : public Entity
{
private:
	bool  toggleAmb;
	bool  toggleDif;
	bool  toggleSpc;
	float ambientLight[4];
	float ambPos[3];
	float diffuseLight[4];
	float difPos[3];
	float specularLight[4];
	
public:	
	LightFX(){Entity();};
	AddLight(int type,float cl[4],float loc[4]); 
	void Draw();
	

};

class Cloud : public Entity
{

private:
	bool			toggle;
	unsigned char * data; 
	unsigned int    texId;
	int				speed;
	int				amount;

public:
	Cloud(){Entity();};
	void CreateCloud(char * f, int height, int amt, int s);
	void Draw();

};

class Celestial: public Entity
{
private:
	unsigned int texId;
	float rot;
	TimeKeeper * localClock;


public:
	Celestial(TimeKeeper * clk){localClock = clk; Entity();};
	void CreateCelestial(char * f);
	void Draw();


};

class SkyBox: public Entity
{

private:
	unsigned int texId;
	TimeKeeper * localClock;

public:
	SkyBox(TimeKeeper * clk);
	void Draw();

};

#endif

