#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include "AlphaEngine/Math/Vector3.h"
#include <stdio.h>

class CParticle
{
public:
	CParticle();
	virtual ~CParticle();
	virtual bool update(long deltaTime);
	virtual bool serialize(FILE * filePtr, bool isStoring);

	CVector3 pos;
	CVector3 vel;
	CVector3 force;
	float mass;
	float radius;
	float friction;
	float bump;
	long life;
	bool collideFlag;

};

#endif