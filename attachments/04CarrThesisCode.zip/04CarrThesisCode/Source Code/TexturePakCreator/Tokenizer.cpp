#include "Tokenizer.h"
#include <string.h>

CTokenizer::CTokenizer(const char * tokenString, const char * delim)
{
	// make local copies of arguments
	lengthTokenString = GetStringLength(tokenString);
	lengthDelimString = GetStringLength(delim);

	this->tokenString = new char[lengthTokenString + 1];
	this->delim = new char[lengthDelimString + 1];

	strcpy(this->tokenString, tokenString);
	strcpy(this->delim, delim);

	curIndexToken = 0;
}

CTokenizer::~CTokenizer()
{
	delete [] tokenString;
	delete [] delim;
}

char * CTokenizer::NextToken()
{
	if (curIndexToken >= lengthTokenString)
		return 0;

	if (lengthDelimString == 0)
	{
		curIndexToken = lengthTokenString + 1;
		return tokenString;
	}
	bool eos = false;
	bool found = false;
	// Position curIndexToken at a non-delimiter character
	while (!eos && !found)
	{
		for (int x = 0; x < lengthDelimString; x++)
		{
			if (tokenString[curIndexToken] != delim[x])
			{
				found = true;
			}
		}
		if (!found)
			curIndexToken++;
		if (curIndexToken >= lengthTokenString)
			eos = true;
	}
	if (eos)
		return 0;
	// Iterate through buffer until eos or a delimeter is reached
	int index = curIndexToken;
	eos = false;
	found = false;
	while (!eos && !found)
	{
		for (int x = 0; x < lengthDelimString; x++)
		{
			if (tokenString[curIndexToken] == delim[x])
			{
				found = true;
			}
		}
		curIndexToken++;
		if (curIndexToken >= lengthTokenString)
			eos = true;
	}
	// COPY from i = index to curIndexToken -1
	int length = curIndexToken - index;
	char * val = new char[length + 1];
	val[length] = '\0';
	for (int i = 0; i < length; i++)
	{
		val[i] = tokenString[index + i];
	}
	return val;
}

int CTokenizer::GetStringLength(const char * buffer)
{
	return strlen(buffer);
}