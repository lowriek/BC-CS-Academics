/* ----------------------------------------------
   -											-
   -	PROJECT:		Hourglass				-
   -	FILE:			primitive.cpp			-	
   -	CREATED:		07/24/01				-
   -	MODIFIED:		07/24/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */

#include "primitive.h"


// ------ Class Constructor definitions

vertex::vertex()
{

}

vertex::vertex(Vector3D av, float r, float g, float b, float a, float tu, float tv)
{
	vec = av; red = r; green = g; blue = b; alpha = a; u = tu; v = tv;
}

vertex::~vertex()
{

}

triangle::triangle()
{

}

triangle::triangle(long arr[], Vector3D n)
{
	p[0] = arr[0]; p[1] = arr[1]; p[2] = arr[2];
	snormal = n;
}

triangle::~triangle()
{

}

mesh::mesh()
{

}

mesh::mesh(long vc, long tc, vertex * va, triangle * ta, Matrix4D otwt, Vector3D bsc, float bdr)
{
  vertexCount = vc;
  triangleCount = tc;    
  vertexArray = va;      
  triangleArray = ta;    
  objectToWorldTransform = otwt;
  boundingSphereCenter = bsc;
  boundingSphereRadius = bdr;
}

mesh::~mesh()
{
	
}