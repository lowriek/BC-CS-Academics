function [dist] = findSimilarity(point1,point2)
%  function [dist] = findSimilarity(point1,point2)
%INPUTS
%    point1,point2: the two "points" (can be any dimension)
%OUTPUT
%    dist: distance between the two points



dist = sqrt(sum(point1 - point2).^2);