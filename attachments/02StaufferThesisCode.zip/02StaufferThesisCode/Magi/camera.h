#ifndef	CAMERA_H
#define CAMERA_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						CAMERA.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	DECEMBER 29, 2001					   --
   --														       --
   --		Notes:	Controls camera view transformations info	   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "entity.h"


class MCamera : public Entity
{
		protected:
		float	x,y,z;
		float	direction;
		float	declination;
		bool	mainCamCtrl;
		

		public:
		MCamera();
		MCamera(float a, float b, float c, float dir, float dec);
		
		void Draw();
	
		inline MutX(float a){x = a;};
		inline MutY(float b){y = b;};
		inline MutZ(float c){z = c;};
		inline MutDir(float d){direction = d;};
		inline MutDec(float d){declination = d;};
		inline float GetX(){ return x;};
		inline float GetY(){ return y;};
		inline float GetZ(){ return z;};
		inline float GetDir(){ return direction;};
		inline float GetDec(){ return declination;};
		inline bool	 MainCameraControl(){ return mainCamCtrl;};
		inline ToggleCameraControl(){mainCamCtrl = !mainCamCtrl;};
		

};





#endif