function [] = recreateFaceIm(myim,pagename,I);
%  [] = function recreateFaceIm(loc,pagename);
%   Used to recreate a face from image pixels
%INPUT
%   myim : a 1x9600 matrix image
%   pagename: name of the index page made
%   I: number put after the filename

    myim = reshape(myim,120,80); myim = normalize(myim);
    imwrite(myim,[pagename int2str(I) '.jpg'],'jpeg');




fid = fopen([pagename '.htm'],'a');
fprintf(fid, 'Cluster ');fprintf(fid,'%s',int2str(I));fprintf(fid,':\n');
fprintf(fid, '<img src="');fprintf(fid,'%s',[pagename int2str(I) '.jpg']);fprintf(fid,'">\n');
fclose(fid);