function [D] = distanceMatrix(faceSpace,eigFaces,meanFace,A)
%  function [D] = distanceMatrix(faceSpace,eigFaces,meanFace)
%   Returns D, a matrix of the distance between pictures
%

numFaces = size(A,1);
D = zeros(numFaces,numFaces);

% for J=1:numFaces
%     im = A(J,:);
%     for I=1:n
%         weights(J,I) = dot(im(1,:),eigFaces(I,:));
%     end
% end

for I=1:numFaces
    for J=1:numFaces
        D(I,J) = findSimilarity(faceSpace(I,:),faceSpace(J,:));
    end
end
        