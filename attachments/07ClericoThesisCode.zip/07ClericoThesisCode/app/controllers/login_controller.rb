class LoginController < ApplicationController

	before_filter :authorize, :except => [:login, :add_user]
  	#before_filter :authorizeadmin, :except => [:login, :logout, :index]

  def add_user

  	@user = User.new(params[:user])
  	if request.post? and @user.save
  		flash.now[:notice] = "User #{@user.name} created"
  		redirect_to(:action => "login")
  		@user = User.new
  	end	
  end

  def login
  	session[:user_id] = nil
  	if request.post?
  		user = User.authenticate(params[:name], params[:password])
  		if user
  			session[:user_id] = user.id
  			uri = session[:original_uri]
  			session[:original_uri] = nil
  			redirect_to(uri || { :controller => 'portal', :action => "index"})
  		else
  			flash[:notice] = "Invalid user/password combination"
  		end
  	end
  	
  	
  end

  def logout
  	session[:user_id] = nil
  	flash[:notice] = "Logged out"
  	redirect_to(:action => "login")
  end

  def index
  end

  def delete_user

  		user = User.find(params[:id])
  		user.destroy
	  redirect_to(:action => :list_users)	
  end

  def list_users
  	@all_users = User.find(:all)
  end
end
