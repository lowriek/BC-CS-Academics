function [facemap,binFaces,numFaces] = getFaceness(im,colProb,eigProb);
%function facemap = getFaceness(im,colProb,eigProb);
%
%INPUT
%     im - An image read directly from imread
%     colProb - The probability the pixel is a face based on color (Saved as p2)
%     eigProb - The probability the box is a face based on STD/dist to face
%               space (saved as p3)

colorFacemap = colorFaceness(im,colProb);

im = rgb2gray(double(im)/255);
A = faceMatrix(60,90);
[eigFaces, faceSpace, meanFace] = PCA(15,A);
eigFacemap = eigenFacenessProb(im,eigFaces,meanFace,60,90,eigProb);
h = fspecial('gaussian',31,2);
eigFacemap = imfilter(eigFacemap,h);

facemap = combineFaceness(eigFacemap,colorFacemap);

[binFaces,numFaces] = findFaces(facemap);

figure(1);imagesc(facemap);axis image;truesize;title('Total Combined Faceness');
figure(2);imagesc(colorFacemap);axis image;truesize;title('Faceness based on Color');
figure(3);imagesc(eigFacemap);axis image;truesize;title('Faceness based on Eigenface Reconstruction');
figure(4);imagesc(binFaces);axis image;truesize;title('Location of the faces');