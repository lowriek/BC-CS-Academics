/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						CAMERA.CPP							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	DECEMBER 29, 2001					   --
   --														       --
   --		Notes:	Controls camera view transformations info	   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "camera.h"



MCamera::MCamera()
{
	x = 0;
	y = 0;
	z = 0;
	direction = 0;
	declination = 0;
	vPoint[0] = x;
	vPoint[1] = y;
	vPoint[2] = z;
	mainCamCtrl = true;

	Entity();
}

MCamera::MCamera(float a, float b, float c, float dir, float dec)
{
	x = a;
	y = b;
	z = c;
	direction = dir;
	declination = dec;
	mainCamCtrl = true;
	Entity();
}



void MCamera::Draw()
{
	Entity * e;
	vPoint[0] = x; vPoint[1] = y; vPoint[2] = z;
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();		
	glRotatef(declination,-1.0,0,0);
	glRotatef(direction,0,1,0);	
	glTranslatef(-x,-y,-z);
	frustum = MakeFrustum();


	e = child;
	while(e != NULL)
	{
		e->Draw();
		e = e->next;
	}
	return;
}

