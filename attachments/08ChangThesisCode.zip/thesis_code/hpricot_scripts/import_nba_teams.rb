# input nba_teams
# run this script by calling:
# script/console < this_script

require 'rubygems'
require 'hpricot'
require 'open-uri'

# import players(nba)
filename = 'basketball_player_urls.list'
sportname = 'basketball'

# for every player, add the team, then add player
# if the team already exists, the Team model validation will prevent updates

doc = Hpricot(open('basketball_player_urls.list'))
(doc/'player').each { |p|
	team = p.get_attribute('team')
	name = p.get_attribute('name')
	url = p.get_attribute('url')
	Team.create :name => team, :sport_id => Sport.find_by_name(sportname).id
	Player.create :name => name
	Rosterspot.create :team_id => Team.find_by_name(team).id, :player_id => Player.find_by_name(name).id
	
}
