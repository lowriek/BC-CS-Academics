#include <iostream.h>
#include <stdio.h>
#include "server.h"
#include "plane.h"

//Function definitions for the Plane object class

Plane::Plane(color c1, color c2, point3d l, float x){
	color1 = c1;
	color2 = c2;
	mirror1=0;
	mirror2=0;
	location = l;
	d = x;
	intersection.x = 0;
	intersection.y = 0;
	intersection.z = 0;
	//ray inRay;
	horizontalChecks=1;
	verticalChecks=1;
}

//empty constructor
Plane::Plane(){

	int i,j;
	//set object defaults
	color1.r = 1.0;	color1.g = 1.0;	color1.b = 1.0;
	color2.r = -1.0;	color2.g = -1.0;	color2.b = -1.0;
	mirror1 = 0; mirror2 = 0;
	WHICHCM=1;
	isTextured=0;
	reflectAmt1 = 0.0;
	refractIndex1 = 0.0;
	transAmt1 = 0.0;
	reflectAmt2 = 0.0;
	refractIndex2 = 0.0;
	transAmt2 = 0.0;
	location.x = 0.0;
	location.y = 1.0;
	location.z = 0.0;
	d = 0.0;
	sVector.x = 1;
	sVector.y = 0;
	sVector.z = 0;
	tVector.x = 0;
	tVector.y = 0;
	tVector.z = 1;
	horizontalChecks=1;
	verticalChecks=1;
	//Initialize a bunch of other variables...
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			object_rotation[i][j]=0;
			world_rotation[i][j]=0;
			translation[i][j]=0;
			scale[i][j]=0;
			compositeMatrix[i][j]=0;
			inverseCompositeMatrix[i][j]=0;
		}
	object_rotation[0][0]=object_rotation[1][1]=object_rotation[2][2]=object_rotation[3][3]=1;
	world_rotation[0][0]=world_rotation[1][1]=world_rotation[2][2]=world_rotation[3][3]=1;
	translation[0][0]=translation[1][1]=translation[2][2]=translation[3][3]=1;
	scale[0][0]=scale[1][1]=scale[2][2]=scale[3][3]=1;
	compositeMatrix[0][0]=compositeMatrix[1][1]=compositeMatrix[2][2]=compositeMatrix[3][3]=1;
	inverseCompositeMatrix[0][0]=inverseCompositeMatrix[1][1]=inverseCompositeMatrix[2][2]=inverseCompositeMatrix[3][3]=1;	
	didInverse=FALSE;
	didComposite=FALSE;
	didNormal=FALSE;
}

float Plane::getIntersection(ray r){
	
	float A,B,C,D;
	float X0,Y0,Z0;
	float Xd,Yd,Zd;
	float V0, Vd;
	float t;
	avector temp;																	//Temp vector for normalizing values

	if(didComposite==FALSE)
		computeCompositeMatrix();
	if(didInverse==FALSE)
		computeInverseCompositeMatrix(compositeMatrix, inverseCompositeMatrix);
	
	inRay.p0.x=r.p0.x;
	inRay.p0.y=r.p0.y;
	inRay.p0.z=r.p0.z;
	inRay.p1.x=r.p1.x;
	inRay.p1.y=r.p1.y;
	inRay.p1.z=r.p1.z;
	inRay.rIndex = r.rIndex;
	
	/* Uses formula in vector notation:		t= (-(Pn.R0 + D))/(Pn.Rd)	*/

		//MODIFICATIONS ON JAN. 10, 2001
	r.p0 = applyMatrixToPoint(r.p0, inverseCompositeMatrix);								/* Reverse Transform the ray points */
	r.p1 = applyMatrixToPoint(r.p1, inverseCompositeMatrix);

	if(r.p0.y == r.p1.y)
		return -1;																		/*  Ray is parallel to the plane */
	else{
		t = r.p0.y - r.p1.y;
		t = r.p0.y/t;
	}
	
	intersection.x = r.p0.x + (r.p1.x-r.p0.x)*t;
	intersection.y = r.p0.y + (r.p1.y-r.p0.y)*t;
	intersection.z = r.p0.z + (r.p1.z-r.p0.z)*t;
	
	intersection = applyMatrixToPoint(intersection, compositeMatrix);
	
	return t;

}

/******************************************************
	Mutator Methods
******************************************************/
void Plane::setLocation(point3d l){
	location.x = l.x;
	location.y = l.y;
	location.z = l.z;
}

void Plane::setD(float x){
	d = x;
}

/******************************************************
	Accessor Methods
******************************************************/
point3d Plane::getLocation(){
	return location;
}

float Plane::getD(){
	return d;
}

/******************************************************
	Methods required by getIllumintedColor Method
******************************************************/
int Plane::inShadow(point3d light){
	ray aray;
	avector v;
	
	v.x = light.x - intersection.x;
	v.y = light.y - intersection.y;
	v.z = light.z - intersection.z;
	
	v = normalizeVector(v);
					
	//create a ray
	aray.p0.x = intersection.x;
	aray.p0.y = intersection.y;
	aray.p0.z = intersection.z;
	
	aray.p1.x = aray.p0.x + v.x;
	aray.p1.y = aray.p0.y + v.y;
	aray.p1.z = aray.p0.z + v.z;
	
	return fireShadowRay(aray, light);
}

avector Plane::getNormal()
{
	avector snormal;														//Create new variable and copy contents of 
	snormal.x = location.x;													//  surface normal, to keep location truly
	snormal.y = location.y;													//  a protected variable
	snormal.z = location.z;
	
	snormal = applyMatrixToVector(snormal, compositeMatrix);

	
	return snormal;
}

color Plane::whichColor()
{
	int s,t;
	
	if(color2.r<0)
		return color1;
	
	intersection = applyMatrixToPoint(intersection, inverseCompositeMatrix);
	s = (int)intersection.x;
	s = s/(10*horizontalChecks);
	s = s%2;
	t = (int)intersection.z;
	t = t/(10*verticalChecks);
	t = t%2;
	intersection = applyMatrixToPoint(intersection, compositeMatrix);
	
	if(intersection.x >=0 && intersection.z <=0){							//Quadrant 1 hit
		t=-t;
		if(s==t){
			WHICHCM=1;
			return color1;
		}
		else{
			WHICHCM=2;
			return color2;
		}
	}
	else if(intersection.x < 0 && intersection.z <= 0){
		
		if(s==t){
			WHICHCM=2;
			return color2;
		}
		else{
			WHICHCM=1;
			return color1;
		}
	}		
	else if(intersection.x<0 && intersection.z >0){
		s=-s;
		if(s==t){
			WHICHCM=1;
			return color1;
		}
		else{
			WHICHCM=2;
			return color2;
		}
	}
	else if(intersection.x>=0 && intersection.z > 0){
		if(s==t){
			WHICHCM=2;
			return color2;
		}
		else{
			WHICHCM=1;
			return color1;
		}
	}
	else{
		WHICHCM=1;
		return color1;
	}
}

int Plane::whichMirror()
{
	if(WHICHCM==1)																/* Already found in whichColor() */
		return mirror1;
	else
		return mirror2;
}

float Plane::getLongitude()
{
  return 0.0;
}

float Plane::getLatitude()
{
  return 0.0;
}

color Plane::getTexturePixel()
{
	color temp;
	temp.r = 1.0; temp.g = 1.0; temp.b = 1.0;
	return temp;
}

avector Plane::getSCoordVector(){
	return sVector;
}

avector Plane::getTCoordVector(){
	return tVector;
}

void Plane::setSCoordVector(point3d sv){
	sVector.x = sv.x;
	sVector.y = sv.y;
	sVector.z = sv.z;
}

void Plane::setTCoordVector(point3d tv){
	tVector.x = tv.x;
	tVector.y = tv.y;
	tVector.z = tv.z;
}


