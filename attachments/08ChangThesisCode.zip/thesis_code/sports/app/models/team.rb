class Team < ActiveRecord::Base
	has_many :rosterspots
	has_many :players, :through => :rosterspots

	has_many :gameteams
	has_many :games, :through => :gameteams

	validates_uniqueness_of :name
	validates_presence_of :sport_id
end
