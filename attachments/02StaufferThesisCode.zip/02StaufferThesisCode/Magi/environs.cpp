/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENVIRONS.CPP						   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 29, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "environs.h"


//extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
//extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;





FogFX::FogFX()
{
	
	float tst[4];
	
	glGetFloatv(GL_COLOR_CLEAR_VALUE,tst);
	
	cv[0] = tst[0]; cv[1] = tst[1]; cv[2] = tst[2]; cv[3] = tst[3]; 
	
	glFogi(GL_FOG_MODE,GL_LINEAR);
	glFogf(GL_FOG_DENSITY,(float).001);
	glFogf(GL_FOG_START,6500);
	glFogf(GL_FOG_END,10500);
	glFogfv(GL_FOG_COLOR,cv);
	glHint(GL_FOG_HINT, GL_NICEST);
	outDoor = true;
	active = false;
	Entity();
	
}

FogFX::FogFX(float dens,float startFog, float endFog, float col[])
{

	cv[0] = col[0]; cv[1] = col[1]; cv[2] = col[2]; cv[3] = col[3];
	glFogi(GL_FOG_MODE,GL_LINEAR);
	glFogf(GL_FOG_DENSITY,dens);
	glFogf(GL_FOG_START,startFog);
	glFogf(GL_FOG_END,endFog);
	glFogfv(GL_FOG_COLOR,col);
	outDoor = false;
	active = false;
	Entity();
	
}

FogFX::Toggle()
{
	if(active)
	{
		glDisable(GL_FOG);
		active = false;
	}
	else
	{		
		//glEnable(GL_FOG);
		active = true;
	}

}

void FogFX::Draw()
{
	float tst[4];

	glGetFloatv(GL_COLOR_CLEAR_VALUE, tst);

	if(int(tst[0] * 10) != int(cv[0] * 10) || int(tst[1] * 10) != int(cv[1] * 10) ||
		int(tst[2] * 10) != int(cv[2] * 10))
	{
		glDisable(GL_FOG);
		cv[0] = tst[0]; cv[1] = tst[1]; cv[2] = tst[2]; cv[3] = tst[3]; 
		glFogfv(GL_FOG_COLOR,cv);
		active = false;
	}
	
	
	
	if(!active)
	{
		//glEnable(GL_FOG);
		active = true;
	}



}


	

LightFX::AddLight(int type, float cl[], float loc[])
{


	if(type == 0)
	{
		
		glLightfv(GL_LIGHT0,GL_AMBIENT,cl);
		glLightfv(GL_LIGHT0,GL_POSITION,loc);
		ambPos[0] = loc[0];ambPos[1] = loc[1];ambPos[2] = loc[2];
		toggleAmb = true;
	}
	if(type == 1)
	{
		glLightfv(GL_LIGHT1,GL_DIFFUSE,cl);
		glLightfv(GL_LIGHT1,GL_POSITION,loc);
		difPos[0] = loc[0];difPos[1] = loc[1];difPos[2] = loc[2];
		toggleDif = true;
	}
	if(type == 2)
	{
		glLightfv(GL_LIGHT2,GL_SPECULAR,cl);
		glLightfv(GL_LIGHT2,GL_POSITION,loc);
		toggleSpc = true;
	}


}



void LightFX::Draw()
{
	Entity * nd;
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	

	glEnable(GL_LIGHTING);
	if(toggleAmb)
	{
	glLightfv(GL_LIGHT0,GL_POSITION, ambPos);
	glEnable(GL_LIGHT0);
	
	}
	if(toggleDif)
	{
	glLightfv(GL_LIGHT1,GL_POSITION,difPos);
		glEnable(GL_LIGHT1);
	}
	glEnable(GL_COLOR_MATERIAL);
	if(toggleAmb && toggleDif)
		glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	else
		if(toggleAmb)
			glColorMaterial(GL_FRONT,GL_AMBIENT);
		else
			glColorMaterial(GL_FRONT,GL_DIFFUSE);
	nd = child;
	while(nd != NULL)
	{
		nd->Draw();
		nd = nd->next;
	}
	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHTING);
}




void Cloud::CreateCloud(char * f,int height, int amt, int s)
{
	FILE * fp;
	long count = 0;
	

	
	texId = LoadTGA(f, GL_MODULATE);
								
	x = 0;
	y = height;
	z = 0;
	amount = amt;
	speed = s;
}



void Cloud::Draw()
{



	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	//glDisable(GL_DEPTH_TEST);
	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	//glEnable(GL_LIGHTING);
	glAlphaFunc(GL_GREATER, 0);
	glEnable(GL_ALPHA_TEST);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
	//glTranslatef(0,0,0);
	//glMaterialf(
	int a,b;
	 static float cnt = 0.0;

	cnt /= 4;

	for(a = -15000; a <30000; a = a +  15000)
	{
		for(b =-15000; b < 30000; b = b + 15000)
		{
			glBegin(GL_QUADS);
			
				glTexCoord2f(0.0 + cnt ,0.0); glVertex3f(a, 2000, b);
				glTexCoord2f(0.0 + cnt ,1.0 ); glVertex3f(a, 2000 , b + 15000);	
				glTexCoord2f(1.0 + cnt,1.0 ); glVertex3f(a + 15000, 2000,b + 15000);
				glTexCoord2f(1.0 + cnt ,0.0 ); glVertex3f(a + 15000 , 2000, b );
					
				glEnd();

					
			
			
				
		}
			
	}

	cnt *= 4;

	
	for(a = -15000; a <30000; a = a +  20000)
	{
		for(b =-15000; b < 30000; b = b + 20000)
		{
			glBegin(GL_QUADS);
			
				glTexCoord2f(0.0 + cnt,0.0  ); glVertex3f(a , 1000, b);
				glTexCoord2f(0.0 + cnt,1.0 ); glVertex3f(a , 1000 , b + 20000);	
				glTexCoord2f(1.0 + cnt,1.0 ); glVertex3f(a + 20000 , 1000,b + 20000);
				glTexCoord2f(1.0 + cnt ,0.0 ); glVertex3f(a + 20000 , 1000, b );
					
				glEnd();

					
			
			
				
		}
			
	}
/*
	glPushMatrix();
	glTranslatef(0,40,0);
	glScalef(-1.0,-1.0,-1.0);
	//glDisable(GL_DEPTH_TEST);

	for(a = -15000; a <30000; a = a +  15000)
	{
		for(b =-15000; b < 30000; b = b + 15000)
		{
			glBegin(GL_QUADS);
			
				glTexCoord2f(0.0 + cnt ,0.0f ); glVertex3f(a, 2000, b);
				glTexCoord2f(0.0 + cnt ,4.0f ); glVertex3f(a, 2000 , b + 15000);	
				glTexCoord2f(4.0 + cnt,4.0f); glVertex3f(a + 15000, 2000,b + 15000);
				glTexCoord2f(4.0 + cnt ,0.0f); glVertex3f(a + 15000 , 2000, b );
					
				glEnd();

					
			
			
				
		}
			
	}


	
	for(a = -15000; a <30000; a = a +  20000)
	{
		for(b =-15000; b < 30000; b = b + 20000)
		{
			glBegin(GL_QUADS);
			
				glTexCoord2f(0.0 + cnt,0.0f ); glVertex3f(a , 1000, b);
				glTexCoord2f(0.0 + cnt,4.0f ); glVertex3f(a , 1000 , b + 20000);	
				glTexCoord2f(4.0 + cnt,4.0f); glVertex3f(a + 20000 , 1000,b + 20000);
				glTexCoord2f(4.0 + cnt ,0.0f); glVertex3f(a + 20000 , 1000, b );
					
				glEnd();

					
			
			
				
		}
			
	}


	
	glPopMatrix();
*/	
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);

	glPopMatrix();
	cnt += .002;
	  glDisable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);

}

void	Celestial::CreateCelestial(char * fn)
{

	texId = LoadTGA(fn, GL_MODULATE);
	rot = 350;

}

void	Celestial::Draw()
{

	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_CULL_FACE);
	glPushMatrix();
	float clColor[4];
	glGetFloatv(GL_COLOR_CLEAR_VALUE, clColor);
	glColor4f(1,1,1,1 - clColor[2]);

	rot = localClock->GetAngle();
	glEnable(GL_BLEND);
	glBlendFunc( GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glAlphaFunc(GL_GREATER, 0);
	glEnable(GL_ALPHA_TEST);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_FOG);
	glBindTexture(GL_TEXTURE_2D,texId);

	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
	
	glRotatef(rot,1,0,0);
	glTranslatef(vPoint[0],vPoint[1],vPoint[2] + 20000);
	glBegin(GL_QUADS);
			
			    glTexCoord2f(0.0f ,0.0f ); glVertex3f(-2000,-2000,0);
				glTexCoord2f(0.0f ,1.0f ); glVertex3f(2000, -2000,0);	
				glTexCoord2f(1.0f,1.0f); glVertex3f(2000,2000,0);
				glTexCoord2f(1.0f ,0.0f); glVertex3f(-2000, 2000,0 );
					
				glEnd();

	glColor3f(1.0,1.0,1.0);
					
			
			
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glPopMatrix();
	
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glEnable(GL_CULL_FACE);
	glEnable(GL_FOG);
	

}

SkyBox::SkyBox(TimeKeeper * clk)
{
	localClock = clk;
	Entity();
	texId = LoadTGA("Data/milkyway2.tga",GL_MODULATE);



}

void	SkyBox::Draw()
{
		float epsilon = (cos(localClock->GetAngle()/180 * 3.14) + 1)/2;

	glClearColor(.0f, .1 * epsilon, 0.8 * epsilon, 1.0f); 	
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
//	glDisable(GL_ALPHA_TEST);
//	glEnable(GL_BLEND);
//glEnable(GL_ALPHA_TEST);
glAlphaFunc(GL_GREATER, 0.0);
glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
glDisable(GL_LIGHTING);
glDisable(GL_TEXTURE_2D);
glDepthMask(0);

//glPushMatrix();
//float rot = localClock->GetAngle();
//glRotatef(rot,1,0,0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
glTexCoord2f(0.0f ,0.0f );
  glVertex3f(vPoint[0] - 5000, vPoint[1]-5000,vPoint[2] -5000);
  glTexCoord2f(2.0f ,0.0f );
  glVertex3f(vPoint[0]-5000, vPoint[1]+5000,vPoint[2] -5000);
 glTexCoord2f(2.0f ,2.0f );
  glVertex3f(vPoint[0]-5000, vPoint[1]+5000, vPoint[2]+5000);
glTexCoord2f(0.0f ,2.0f );
  glVertex3f(vPoint[0]-5000, vPoint[1]-5000, vPoint[2]+5000);	
  glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
glTexCoord2f(2.0f ,0.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]-5000, vPoint[2]+5000);
 glTexCoord2f(2.0f ,2.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]+5000, vPoint[2]+5000);
 glTexCoord2f(0.0f ,2.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]+5000);
glTexCoord2f(0.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]-5000, vPoint[2]+5000);	
glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
 glTexCoord2f(2.0f ,2.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]-5000, vPoint[2]+5000);
 glTexCoord2f(2.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]+5000);
  glTexCoord2f(0.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]-5000);
glTexCoord2f(0.0f ,2.0f );
 glVertex3f(vPoint[0]+5000,vPoint[1]-5000,vPoint[2]-5000);	
glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
 glTexCoord2f(0.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]-5000, vPoint[2]-5000);
 glTexCoord2f(2.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]-5000);
 glTexCoord2f(2.0f ,2.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]+5000, vPoint[2]-5000);
glTexCoord2f(0.0f ,2.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]-5000, vPoint[2]-5000);	
glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 glTexCoord2f(0.0f ,2.0f );
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
 glVertex3f(vPoint[0]-5000, vPoint[1]+5000, vPoint[2]-5000);
 glTexCoord2f(2.0f ,2.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]-5000);
 glTexCoord2f(2.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]+5000, vPoint[2]+5000);
 glTexCoord2f(0.0f ,0.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]+5000, vPoint[2]+5000);



 glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,  texId);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

glBegin(GL_QUADS);
 glTexCoord2f(0.0f ,2.0f );
 glColor4f(1.0f, 1.0, 1.0, 1.0f);
 glVertex3f(vPoint[0]-5000, vPoint[1]-5000, vPoint[2]-5000);
 glTexCoord2f(2.0f ,2.0f );
 glVertex3f(vPoint[0]-5000, vPoint[1]-5000, vPoint[2]+5000);
 glTexCoord2f(2.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]-5000, vPoint[2]+5000);
 glTexCoord2f(0.0f ,0.0f );
 glVertex3f(vPoint[0]+5000, vPoint[1]-5000, vPoint[2]-5000);



 glEnd();
 glDisable(GL_TEXTURE_2D);

 glEnable(GL_ALPHA_TEST);
 glEnable(GL_BLEND);
 glBegin(GL_QUADS);

 glColor4f(.0f, .1 * epsilon, 0.8 * epsilon, epsilon); 	

 
glVertex3f(vPoint[0]-500, vPoint[1]-500, vPoint[2]-500);
glVertex3f(vPoint[0]-500, vPoint[1]-500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]-500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]-500, vPoint[2]-500);

  glVertex3f(vPoint[0] - 500, vPoint[1]-500,vPoint[2] -500);
  glVertex3f(vPoint[0]-500, vPoint[1]+500,vPoint[2] -500);
  glVertex3f(vPoint[0]-500, vPoint[1]+500, vPoint[2]+500);
  glVertex3f(vPoint[0]-500, vPoint[1]-500, vPoint[2]+500);	

 glVertex3f(vPoint[0]-500, vPoint[1]-500, vPoint[2]+500);
 glVertex3f(vPoint[0]-500, vPoint[1]+500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]-500, vPoint[2]+500);
 
 glVertex3f(vPoint[0]+500, vPoint[1]-500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]+500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]-500);
 glVertex3f(vPoint[0]+500,vPoint[1]-500,vPoint[2]-500);	

 glVertex3f(vPoint[0]+500, vPoint[1]-500, vPoint[2]-500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]-500);
 glVertex3f(vPoint[0]-500, vPoint[1]+500, vPoint[2]-500);
 glVertex3f(vPoint[0]-500, vPoint[1]-500, vPoint[2]-500);	

 glVertex3f(vPoint[0]-500, vPoint[1]+500, vPoint[2]-500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]-500);
 glVertex3f(vPoint[0]+500, vPoint[1]+500, vPoint[2]+500);
glVertex3f(vPoint[0]-500, vPoint[1]+500, vPoint[2]+500);

 glEnd();
 //glPopMatrix();
glDisable(GL_LIGHTING);
glDisable(GL_BLEND);
glEnable(GL_BLEND);

glDepthMask(1);
	
Entity * e = child;
	
	while(e != NULL)
	{
		e->Draw();
	    e = e->next;
	}
}