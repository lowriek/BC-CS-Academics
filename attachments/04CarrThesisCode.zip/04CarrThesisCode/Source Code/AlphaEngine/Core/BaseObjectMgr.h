#ifndef _BASEOBJECTMGR_H_
#define _BASEOBJECTMGR_H_

#include <list>
#include <stdio.h>

using namespace std;

class CBaseObjectMgr
{

public:
	virtual ~CBaseObjectMgr();
	static CBaseObjectMgr * getInstance();
	unsigned long			getObjectId();
	void					freeObjectId(unsigned long n);
	static bool				serialize(FILE* filePtr, bool isStoring);
	static void				shutdown();
private:
	CBaseObjectMgr();

	list<unsigned long>		freeIds;
	unsigned long			nextId;
	static CBaseObjectMgr*	objMgr;
};

#endif