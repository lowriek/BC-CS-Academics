#ifndef _PLANE_H_
#define _PLANE_H_

#include "AlphaEngine/Math/Vector3.h"

#include <stdio.h>

class CPlane
{
public:
	CPlane();
	CPlane(CVector3 normal, float d);
	virtual ~CPlane();

	int			classifyPoint(const CVector3 &vert);
	float		getDistanceToPlane(const CVector3& vertex);
	bool		rayIntersect(const CVector3& ro, const CVector3 &rd, CVector3 &ip, float &t);	
	bool		serialize(FILE * filePtr, bool isStoring);

	CPlane&		operator=(const CPlane &rPlane);

	bool		operator==(const CPlane &rPlane);
	bool		operator!=(const CPlane &rPlane);

public:
	CVector3 normal;
	float d;
	float epsilon;
};
#endif