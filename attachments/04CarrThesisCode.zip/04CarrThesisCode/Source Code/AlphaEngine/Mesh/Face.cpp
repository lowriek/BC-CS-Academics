#include "AlphaEngine/Mesh/Face.h"
#include "AlphaEngine/Math/Math.h"

bool CFace::allocate(int numVertice)
{
	if (numVertice <= 0)
		return false;

	numVert = numVertice;
	pVertIndex = new unsigned int[numVert];
	pBTxCoord = new CVector2[numVert];
	pDTxCoord = new CVector2[numVert];
	pLTxCoord = new CVector2[numVert];
	return true;
}

CFace::CFace()
{
	bTxId = 0;
	dTxId = 0;
	lTxId = 0;
	numVert = 0;
	pBTxCoord = 0;
	pDTxCoord = 0;
	pLTxCoord = 0;
	pVertIndex = 0;
	baseOffsetS = 0;
	baseOffsetT = 0;
	baseScaleS = 0;
	baseScaleT = 0;

	decalOffsetS = 0;
	decalOffsetT = 0;
	decalScaleS = 0;
	decalScaleT = 0;

	transparencyValue = 0;
	isTransparent = false;
}

CFace::~CFace()
{
	reset();
}

CFace& CFace::operator= (const CFace& rFace)
{
	reset();

	isTransparent = rFace.isTransparent;
	transparencyValue = rFace.transparencyValue;

	baseOffsetS = rFace.baseOffsetS;
	baseOffsetT = rFace.baseOffsetT;
	baseScaleS = rFace.baseScaleS;
	baseScaleT = rFace.baseScaleT;

	decalOffsetS = rFace.decalOffsetS;
	decalOffsetT = rFace.decalOffsetT;
	decalScaleS = rFace.decalScaleS;
	decalScaleT = rFace.decalScaleT;

	bTxId = rFace.bTxId;
	dTxId = rFace.dTxId;
	lTxId = rFace.lTxId;
	surfaceNormal = rFace.surfaceNormal;
	numVert = rFace.numVert;
	allocate(numVert);
	for (unsigned int x = 0; x < numVert; x++)
	{
		pBTxCoord[x] = rFace.pBTxCoord[x];
		pDTxCoord[x] = rFace.pDTxCoord[x];
		pLTxCoord[x] = rFace.pLTxCoord[x];
		pVertIndex[x] = rFace.pVertIndex[x];
	}

    return *this;
}

void CFace::reset()
{
	if (pVertIndex)
		delete [] pVertIndex;
	if (pBTxCoord)
		delete [] pBTxCoord;
	if (pDTxCoord)
		delete [] pDTxCoord;
	if (pLTxCoord)
		delete [] pLTxCoord;
	
	bTxId = 0;
	dTxId = 0;
	lTxId = 0;
	numVert = 0;
	pBTxCoord = 0;
	pDTxCoord = 0;
	pLTxCoord = 0;
	pVertIndex = 0;

	bTxId = 0;
	dTxId = 0;
	lTxId = 0;
	numVert = 0;
	pBTxCoord = 0;
	pDTxCoord = 0;
	pLTxCoord = 0;
	pVertIndex = 0;
	baseOffsetS = 0;
	baseOffsetT = 0;
	baseScaleS = 0;
	baseScaleT = 0;

	decalOffsetS = 0;
	decalOffsetT = 0;
	decalScaleS = 0;
	decalScaleT = 0;

	transparencyValue = 0;
	isTransparent = false;
}

void CFace::reverseVertexOrder()
{
	unsigned int temp;
	for (int k = 0; k < (int)CMath::Floor(numVert / 2.0f); k++)
	{
		temp = pVertIndex[numVert - 1 - k];
		pVertIndex[numVert - 1 - k] = pVertIndex[k];
		pVertIndex[k] = temp;
	}
}

bool CFace::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	int x;
	if (isStoring)
	{
		fwrite(&isTransparent, sizeof(bool), 1, filePtr);
		fwrite(&transparencyValue, sizeof(float), 1, filePtr);

		fwrite(&baseOffsetS, sizeof(float), 1, filePtr);
		fwrite(&baseOffsetT, sizeof(float), 1, filePtr);
		fwrite(&baseScaleS, sizeof(float), 1, filePtr);
		fwrite(&baseScaleT, sizeof(float), 1, filePtr);

		fwrite(&decalOffsetS, sizeof(float), 1, filePtr);
		fwrite(&decalOffsetT, sizeof(float), 1, filePtr);
		fwrite(&decalScaleS, sizeof(float), 1, filePtr);
		fwrite(&decalScaleT, sizeof(float), 1, filePtr);

		fwrite(&bTxId, sizeof(unsigned int), 1, filePtr);
		fwrite(&dTxId, sizeof(unsigned int), 1, filePtr);
		fwrite(&lTxId, sizeof(unsigned int), 1, filePtr);
		fwrite(&numVert, sizeof(unsigned int), 1, filePtr);
		if (numVert > 0)
		{
			fwrite(pVertIndex, sizeof(unsigned int), numVert, filePtr);
			for (x = 0; x < numVert; x++)
			{
				if (!pBTxCoord[x].serialize(filePtr, isStoring)) return false;
				if (!pDTxCoord[x].serialize(filePtr, isStoring)) return false;
				if (!pLTxCoord[x].serialize(filePtr, isStoring)) return false;
			}
		}
	}
	else
	{
		reset();

		fread(&isTransparent, sizeof(bool), 1, filePtr);
		fread(&transparencyValue, sizeof(float), 1, filePtr);

		fread(&baseOffsetS, sizeof(float), 1, filePtr);
		fread(&baseOffsetT, sizeof(float), 1, filePtr);
		fread(&baseScaleS, sizeof(float), 1, filePtr);
		fread(&baseScaleT, sizeof(float), 1, filePtr);

		fread(&decalOffsetS, sizeof(float), 1, filePtr);
		fread(&decalOffsetT, sizeof(float), 1, filePtr);
		fread(&decalScaleS, sizeof(float), 1, filePtr);
		fread(&decalScaleT, sizeof(float), 1, filePtr);

		fread(&bTxId, sizeof(unsigned int), 1, filePtr);
		fread(&dTxId, sizeof(unsigned int), 1, filePtr);
		fread(&lTxId, sizeof(unsigned int), 1, filePtr);
		fread(&numVert, sizeof(unsigned int), 1, filePtr);
		if (numVert > 0)
		{
			if (!allocate(numVert))
				return false;

			fread(pVertIndex, sizeof(unsigned int), numVert, filePtr);
			for (x = 0; x < numVert; x++)
			{
				if (!pBTxCoord[x].serialize(filePtr, isStoring)) return false;
				if (!pDTxCoord[x].serialize(filePtr, isStoring)) return false;
				if (!pLTxCoord[x].serialize(filePtr, isStoring)) return false;
			}
		}		
	}
	if (!surfaceNormal.serialize(filePtr, isStoring))
		return false;

	return true;
}
