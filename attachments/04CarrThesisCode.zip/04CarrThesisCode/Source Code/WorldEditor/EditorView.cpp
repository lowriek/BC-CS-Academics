// EditorView.cpp : implementation file
//

#include "stdafx.h"
#include "WorldEditor.h"
#include "EditorView.h"
#include "AlphaEngine/Math/Math.h"
#include "AlphaEngine/Texture/TextureMgr.h"
#include "AlphaEngine/AlphaConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditorView

IMPLEMENT_DYNCREATE(CEditorView, CViewportContainer)

CEditorView::CEditorView()
{
}

CEditorView::~CEditorView()
{
}

BOOL CEditorView::InitOpenGL()
{
	if (!CViewportContainer::InitOpenGL())
	{
		return FALSE;
	}

	fullScreen = false;

	xyViewport = new CArchitectViewport(this);
	xyViewport->SetupViewport(0.0f, 0.5f, 0.50f, 0.5f);
	xyViewport->m_axis = CVector3(1,1,0);

	xzViewport = new CArchitectViewport(this);
	xzViewport->SetupViewport(0.50f, 0.50f, 0.50f, 0.5f);
	xzViewport->m_axis = CVector3(1,0,1);

	yzViewport = new CArchitectViewport(this);
	yzViewport->SetupViewport(0.0f, 0.0f, 0.50f, 0.5f);
	yzViewport->m_axis = CVector3(0,1,1);

	perspectiveViewport = new CPerspectiveViewport(this);
	perspectiveViewport->SetupViewport(0.50f, 0.0f, 0.50f, 0.5f);

	AddViewport(xyViewport);
	AddViewport(xzViewport);
	AddViewport(yzViewport);
	AddViewport(perspectiveViewport);

	return TRUE;
}

BEGIN_MESSAGE_MAP(CEditorView, CViewportContainer)
	//{{AFX_MSG_MAP(CEditorView)
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_BUTTON_DELETE, OnButtonDelete)
	ON_COMMAND(ID_BUTTON_TRANSLATE, OnButtonTranslate)
	ON_COMMAND(ID_BUTTON_SCALE, OnButtonScale)
	ON_COMMAND(ID_BUTTON_ROTATE, OnButtonRotate)
	ON_COMMAND(ID_DISPLAY_WIREFRAME, OnDisplayWireframe)
	ON_COMMAND(ID_COMPUTE_BSP, OnComputeBsp)
	ON_COMMAND(ID_VIEW_FILLED, OnViewFilled)
	ON_COMMAND(ID_BUTTON_BOX, OnButtonBox)
	ON_COMMAND(ID_BUTTON_CSG_SUB, OnButtonCsgSub)
	ON_COMMAND(ID_BUTTON_CSG_ADD, OnButtonCsgAdd)
	ON_COMMAND(ID_BUTTON_DELETE_BUILDER, OnButtonDeleteBuilder)
	ON_COMMAND(ID_BUTTON_SPHERE, OnButtonSphere)
	ON_COMMAND(ID_VIEW_BRUSHMODE, OnViewBrushmode)
	ON_COMMAND(ID_VIEW_CSGMODE, OnViewCsgmode)
	ON_COMMAND(IDC_VIEW_FINALMODE, OnViewFinalmode)
	ON_COMMAND(ID_COMPUTE_PVS, OnComputePvs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

void CEditorView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar)
	{
		case VK_ESCAPE:
			GetDocument()->DeselectPBrush();
			OnDraw(NULL);
			break;
		case VK_INSERT:
			xyViewport->IncreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_DELETE:
			xyViewport->DecreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_HOME:
			xzViewport->IncreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_END:
			xzViewport->DecreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_PRIOR:
			yzViewport->IncreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_NEXT:
			yzViewport->DecreaseGridSize();
			OnDraw(NULL);
			break;
		case VK_LEFT:
			GetDocument()->pAlphaEngine->pCamera->RotateView(CMath::PI / 10, 0, 0, 1);
			OnDraw(NULL);
			break;
		case VK_RIGHT:
			GetDocument()->pAlphaEngine->pCamera->RotateView(-CMath::PI / 10, 0, 0, 1);
			OnDraw(NULL);
			break;
		case 'A':
			GetDocument()->pAlphaEngine->pCamera->Strafe(8);
			OnDraw(NULL);
			break;
		case 'D':
			GetDocument()->pAlphaEngine->pCamera->Strafe(-8);
			OnDraw(NULL);
			break;
		case 'E':
			GetDocument()->pAlphaEngine->pCamera->Lift(-8);
			OnDraw(NULL);
			break;
		case 'Q':
			GetDocument()->pAlphaEngine->pCamera->Lift(8);
			OnDraw(NULL);
			break;
		case 'S':
			GetDocument()->pAlphaEngine->pCamera->Move(-8);
			OnDraw(NULL);
			break;
		case 'W':
			GetDocument()->pAlphaEngine->pCamera->Move(8);
			OnDraw(NULL);
			break;
		case 'F':
			ToggleFullscreen();
			OnDraw(NULL);
			break;
	}	
}

void CEditorView::OnButtonDelete() 
{
	GetDocument()->DeletePBrush();
}

void CEditorView::OnButtonTranslate() 
{
	GetDocument()->BRUSH_MANIP_MODE = TRANSLATE;	
}

void CEditorView::OnButtonScale() 
{
	GetDocument()->BRUSH_MANIP_MODE = SCALE;
}

void CEditorView::OnButtonRotate() 
{
	GetDocument()->BRUSH_MANIP_MODE = ROTATE;	
}

void CEditorView::OnDisplayWireframe() 
{
	if (perspectiveViewport)
		perspectiveViewport->RENDER_MODE = ALPHA_WIREFRAME;

	GetDocument()->UpdateAllViews(NULL);
}

void CEditorView::OnComputeBsp() 
{
	GetDocument()->CreateBsp();
}

void CEditorView::OnViewFilled() 
{
	if (perspectiveViewport)
		perspectiveViewport->RENDER_MODE = ALPHA_FILL | ALPHA_B_TX | ALPHA_D_TX;

	GetDocument()->UpdateAllViews(NULL);		
}

void CEditorView::OnButtonBox() 
{
	xyViewport->OnButtonBox();		
	xzViewport->OnButtonBox();		
	yzViewport->OnButtonBox();		
}

void CEditorView::OnButtonCsgSub() 
{
	GetDocument()->CSGSub();	
}

void CEditorView::OnButtonCsgAdd() 
{
	GetDocument()->CSGAdd();	
}

void CEditorView::OnButtonDeleteBuilder() 
{
	GetDocument()->DeleteBuilder();	
}

void CEditorView::OnButtonSphere() 
{
	xyViewport->OnButtonSphere();		
	xzViewport->OnButtonSphere();		
	yzViewport->OnButtonSphere();	
}

void CEditorView::OnViewBrushmode() 
{
	GetDocument()->SetRenderBrush();
	GetDocument()->UpdateAllViews(NULL);
}

void CEditorView::OnViewCsgmode() 
{
	GetDocument()->SetRenderCSG();
	GetDocument()->UpdateAllViews(NULL);
}

void CEditorView::OnViewFinalmode() 
{
	GetDocument()->SetRenderFinal();
	GetDocument()->UpdateAllViews(NULL);	
}

void CEditorView::OnComputePvs() 
{
	GetDocument()->CreatePvs();	
}

void CEditorView::ToggleFullscreen()
{
	if (fullScreen)
	{
		xyViewport->SetupViewport(0.0f, 0.5f, 0.50f, 0.5f);
		xzViewport->SetupViewport(0.50f, 0.50f, 0.50f, 0.5f);
		yzViewport->SetupViewport(0.0f, 0.0f, 0.50f, 0.5f);
		perspectiveViewport->SetupViewport(0.50f, 0.0f, 0.50f, 0.5f);
	}
	else
	{
		xyViewport->SetupViewport(0.0f, 0.0f, 0.0f, 0.0f);
		xzViewport->SetupViewport(0.0f, 0.0f, 0.0f, 0.0f);
		yzViewport->SetupViewport(0.0f, 0.0f, 0.0f, 0.0f);
		perspectiveViewport->SetupViewport(0.0f, 0.0f, 1.00f, 1.0f);
	}

	fullScreen = !fullScreen;
}