#ifndef	 TERRAIN_H
#define TERRAIN_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						TERRAIN.H						       --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	OCTOBER 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <math.h>
#include "Glext.h"
#include "entity.h"
#define MIN( a, b ) ((a < b)?(a):(b))
#define MAX(a,b) ((a>b)?(a):(b))



class Terrain : public Entity
{

protected:

	
	short int height;
	short int width;
	int	scaleHeight;
	static float * normalList[10];
	static float * terrainData;
	static float *  terrainMatrix;
	static char * roughMatrix;
	static float * colorTerrain;
	static unsigned int terrainTextures[10];
	int	xStep, zStep;
	int	quadWidth;
	int	depth;
		long  numTriangles;

	

public:
	Terrain(){ x = y = z = 0; Entity();};
	Terrain(int sH, int xS, int zS, int a, int b, int c, int rad);

	int     TerrainLoad(char * fn);
	void    Draw();
	void    Kill();
	void	Render(int xTrue, int zTrue, int qW, int corner);
	void    MakeNormals();
	float *	MakeNormalMap(int qWidth);
	void	MakeVertexNormal(int qWidth, int tempX, int tempZ, float * loc, long cnt);
	void	TerrainCrossProduct(float * v1, float * v2, float * result);
	void CalculateFaceNormal(float * v1, float * v2, float * v3, float * final);
	void	SetTerrainData(int w, int h, int qW){width = w;	height = h; quadWidth = qW;};
	float	GetHeight(float xPos, float zPos);
	void BlendNormal(float * middle, float * base1, float * base2, float blend);
	void BlendColorCenter(long centerPos,float * center, float * c1, float * c2, float * c3, float * c4,float * nwC, float * neC, float * swC, float * seC, float bld);
	void BlendColorSide(float * mid, float * crn1, float * crn2, float bld);
};

class MasterTerrain : public Terrain
{

protected:
	bool TessellateComplete;
	int	   terrainStat[20];

public:
	MasterTerrain(int sH, int xS, int zS, int a, int b, int c, int rad);

	~MasterTerrain(){Kill();};
	void Init();
	void Tessellate();
	void RecursiveTessellate(int nWx, int nWz, int qWidth); 
	int ComputeRoughness(long nWx, long nWz, int qWidth);
	void Draw();
	void Kill();
	

};



#endif