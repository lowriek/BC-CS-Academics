function [p,x,y,faceHist,noFaceHist] = getColorHist(bins,amin,amax,bmin,bmax);
%
%

txt = dlmread('facialpoints.txt');
index=0;
faceHist=zeros(bins+1,bins+1);
noFaceHist=zeros(bins+1,bins+1);
mina = 9999;  maxa = -9999;
minb = 9999;  maxb = -9999;

for I=1:100
    [q,numfaces] = size(find(txt((3*I)-1,:)~=0));
    numfaces=numfaces/3;
    filename = [ int2str(I) , '.jpg' ];
    im = imread(filename);
    %im = padarray(im,[200 200], 0, 'both');
    [one,two,three] = size(im);
    mask = zeros(one,two);
    for J=1:numfaces
        index = index+1;
        xs=txt(3*I-1,(3*J)-2:(3*J));
        ys=txt(3*I,(3*J)-2:(3*J));
        %xs = xs + 200;
        %ys = ys + 200;
        points = [ xs ; ys ];   %The 3 points are now in points, for the face we have
        dist = sqrt((points(1,1)-points(1,2))^2 + (points(2,1) - points(2,2))^2);
        midpoint = [ mean([points(1,1) points(1,2)]) mean([points(2,1) points(2,2)]) ];
        
            width = round(1 * dist);
            width = width + (1-mod(width,2));
            height = round(1.5 * dist);
            height = height + (1-mod(height,2));
            RECT = [ midpoint(1)-(width/2) midpoint(2)-(height/3) width height ];
            %im = imcrop(im,RECT);
            %figure(2);clf;imagesc(im);axis image;truesize;
            RECT = round(RECT);
            if RECT(2)+height >480
                RECT(4) = height - mod(RECT(2)+height,480);
            end
            if RECT(1)+width >6400
                RECT(3) = height - mod(RECT(1)+height,640);
            end
            mask(RECT(2):(RECT(2)+RECT(4)),RECT(1):(RECT(1)+RECT(3)))=1;
    end
    I
    [L,a,b] = RGB2Lab(im);
    %size(mask)
    %figure(1);clf;imagesc(mask);axis image;truesize;
    %Now we have the mask, we're going to plot the a and b values now
    %imwrite(mask,['mask' int2str(I) '.jpg'],'jpeg');
%     a=a+100;b=b+100;

    if max(a(:))>maxa
        maxa=max(a(:));
    end
    if min(a(:))<mina
        mina=min(a(:));
    end
    if max(b(:))>maxb
        maxb=max(b(:));
    end
    if min(b(:))<minb
        minb=min(b(:));
    end
    
    
%     a = round(a);b = round(a);

    [one,two,three]=size(im);
    for I=1:one
        for J=1:two
            aval = 1+floor(bins*(a(I,J)-(amin))/(amax-(amin)));
            bval = 1+floor(bins*(b(I,J)-(bmin))/(bmax-(bmin)));
            if aval>bins
                aval=bins;
            end
            if aval<1
                aval=1;
            end
            if bval>bins
                bval=bins;
            end
            if bval<1
                bval=1;
            end
            if mask(I,J) == 0
                noFaceHist(aval,bval)=noFaceHist(aval,bval)+1;
            end
            if mask(I,J) == 1
                faceHist(aval,bval)=faceHist(aval,bval)+1;
            end
        end
    end
end
x = linspace(amin,amax,bins);
y = linspace(bmin,bmax,bins);
figure(1);imagesc(x,y,log(1+faceHist));colorbar;title('Face Histogram');
figure(2);imagesc(x,y,log(1+noFaceHist));colorbar;title('Not-Face Histogram');
p = faceHist ./ (1 + faceHist + noFaceHist);
figure(3);imagesc(x,y,p);colorbar;title('Probability of Face');
[ mina maxa minb maxb ]
