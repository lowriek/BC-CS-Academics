function [eigFaceHist,eigNoFaceHist,p] = getEigHist(bins,eigFaces,meanFace,width,height);
%function [eigFaceHist,eigNoFaceHist] = getEigHist(bins,eigFaces,meanFace,width,height);
%

eigFaceHist=zeros(bins+1,bins+1);
eigNoFaceHist=zeros(bins+1,bins+1);
mindev = 0;  maxdev = .4;
mindist = .04;  maxdist = .7;
%bigmatrix = zeros(101,390*580);
% mina=9999;maxa=-9999;minb=9999;maxb=-9999;

for I=50:100
    counter=1;
    filename = [ int2str(I) , '.jpg' ];
    im = rgb2gray(double(imread(filename))/255);
    %im = padarray(im,[200 200], 0, 'both');
    h = fspecial('gaussian',31,4);
    im = imfilter(im,h);
    [m,n] = size(im);
    filename2 = ['mask' int2str(I) '.jpg']
    mask = double(imread(filename2))/255;
    
    topleft = [(height/2)+1 (width/2)+1];
    bottomright = [m-(height/2) n-(width/2)];

    for I= topleft(1):bottomright(1)
       for J= topleft(2):bottomright(2)
           RECT = [J-(width/2) I-(height/2) width-1 height-1];
           thispic = imcrop(im,RECT);
                
           %figure(1);clf;imagesc(thispic);axis image;truesize;
           imbefore = thispic;
			thispic  = thispic / sum(abs(thispic(:)));
			thispic = reshape(thispic,1,width*height);
			
			%subtract the mean face
			im2 = double(thispic) - meanFace;
			myWeights = im2 * eigFaces';
			recreatedFace = meanFace + myWeights*eigFaces;
			
            dev = std(imbefore(:));
            dist = sum(abs(thispic - recreatedFace));
            %bigmatrix(I,counter) = dev;bigmatrix(I+1,counter)=dist;
            counter=counter+1;
            
            devval = 1+floor(bins*(dev-(mindev))/(maxdev-(mindev)));
            distval = 1+floor(bins*(dist-(mindist))/(maxdist-(mindist)));
            if devval>bins
                devval=bins;
            end
            if devval<1
                devval=1;
            end
            if distval>bins
                distval=bins;
            end
            if distval<1
                distval=1;
            end
            if mask(I,J) == 0
                eigNoFaceHist(devval,distval)=eigNoFaceHist(devval,distval)+1;
            end
            if mask(I,J) == 1
                eigFaceHist(devval,distval)=eigFaceHist(devval,distval)+1;
            end
%             if dev>maxa
%                 maxa=dev;
%             end
%             if dev<mina
%                 mina=dev;
%             end
%             if dist>maxb
%                 maxb=dist;
%             end
%             if dist<minb
%                 minb=dist;
%             end
        end
    end
end
x = linspace(mindev,maxdev,bins);
y = linspace(mindist,maxdist,bins);
figure(1);imagesc(x,y,log(1+eigFaceHist));colorbar;title('Face Histogram std vs dist');
figure(2);imagesc(x,y,log(1+eigNoFaceHist));colorbar;title('Not-Face Histogram std vs dist');
p = eigFaceHist ./ (1 + eigFaceHist + eigNoFaceHist);
figure(3);imagesc(x,y,p);colorbar;title('Probability of Face using eigenFaces');
% [maxdev mindev maxdist mindist]
% [mina maxa minb maxb]