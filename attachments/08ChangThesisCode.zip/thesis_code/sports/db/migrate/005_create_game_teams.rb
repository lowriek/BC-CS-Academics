class CreateGameTeams < ActiveRecord::Migration
  def self.up
    create_table :game_teams do |t|
			t.column :game_id, :integer, :null => false
			t.column :team_id, :integer, :null => false
      t.timestamps
    end
  end

  def self.down
    drop_table :game_teams
  end
end
