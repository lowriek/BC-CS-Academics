#include "thread.h"


Thread::Thread(LPSECURITY_ATTRIBUTES att, DWORD size, LPTHREAD_START_ROUTINE fn,
				LPVOID par, DWORD flags)
{
	id = (LPDWORD)malloc(sizeof(DWORD));
	hnd = CreateThread(att, size, fn, par, flags, id);

}

Thread::~Thread()
{
	CloseHandle(hnd);
}


Semaphore::Semaphore()
{
	#if defined( _WIN32 ) && defined( _MT )
    d_mutex = CreateMutex( NULL, false, NULL );
    if( d_mutex == NULL )
      throw cError( " Mutex creation failed." );
#endif
}


Semaphore::~Semaphore()
{
#if defined( _WIN32 ) && defined( _MT )
    if( d_mutex != NULL )
    {
      CloseHandle( d_mutex );
      d_mutex = NULL;
    }
#endif

}

Semaphore::Lock() 
{
	#if defined( _WIN32 ) && defined( _MT )
    WaitForSingleObject( mutex, INFINITE );
	locked = true;

	#endif
}

Semaphore::Unlock()
{
	#if defined( _WIN32 ) && defined( _MT )
    ReleaseMutex( mutex );  // To be safe...
	locked = false;
	#endif

}

