# nascar_raceresults_script.rb
# given: url to a race results page
# output: calls nascar_player on every person
#					adds stat to a temp file, then call import script on file (create import file)

require 'rubygems'
require 'hpricot'
require 'open-uri'

playerfile = 'nascar_player_script.rb'
statfile = 'nascar_statfile.list'
system('echo -n > '+statfile)
importplayerfile = 'import_nascar_players.rb'
importstatfile = 'import_nascar_stats.rb'
preurl = 'http://sports.espn.go.com/rpm/'

if ( (url = ARGV[0]) == nil)
	# expected url should be complete
  puts "usage: nascar_raceresults_script.rb url \n"
  exit
end

doc = Hpricot(open(url))

system('echo "<nascarstats>" > '+statfile)
gamename = (doc/'div.content/div.autoPageHeader/h1').inner_html.gsub(/ Results/,'')
system('echo "<race name=\"'+gamename+'\" >" >>'+statfile)
(doc/'div.sp-col1-inner/table/tr.oddrow').each { |d|
	name = (d/'td[2]/a').inner_html.gsub(/&nbsp;/,'').gsub(/[\'\"\n]/, '')
	url = preurl+(d/'td[2]/a').attr('href').gsub(/&nbsp;/,'')
	finalpos = (d/'td[1]').inner_html.gsub(/&nbsp;/,'')
	carnum = (d/'td[3]').inner_html.gsub(/&nbsp;/,'')
	make = (d/'td[4]').inner_html.gsub(/&nbsp;/,'')
	laps = (d/'td[5]').inner_html.gsub(/&nbsp;/,'')
	money = (d/'td[6]').inner_html.gsub(/&nbsp;/,'')
	startpos = (d/'td[7]').inner_html.gsub(/&nbsp;/,'')
	lapsled = (d/'td[8]').inner_html.gsub(/&nbsp;/,'')
	points = (d/'td[9]').inner_html.gsub(/&nbsp;/,'')
	bonus = (d/'td[10]').inner_html.gsub(/&nbsp;/,'')
	penalty = (d/'td[11]').inner_html.gsub(/&nbsp;/,'')

	# call player script
	system('ruby '+playerfile+' "'+url+'" "'+name+'"')
	# call import 
	system('ruby ../sports/script/console < '+importplayerfile)

	line = '<stat name="'+name+'" carnum="'+carnum+'" make="'+make+'" laps="'+laps+'" money="'+money+'" startpos="'+startpos+'" finalpos="'+finalpos+'" lapsled="'+lapsled+'" points="'+points+'" bonus="'+bonus+'" penalty="'+penalty+'" />'

	system('echo \''+line+'\' >> '+statfile)
}

(doc/'div.sp-col1-inner/table/tr.evenrow').each { |d|
name = (d/'td[2]/a').inner_html.gsub(/&nbsp;/,'').gsub(/[\'\"\n]/, '')
	url = preurl+(d/'td[2]/a').attr('href').gsub(/&nbsp;/,'')
	finalpos = (d/'td[1]').inner_html.gsub(/&nbsp;/,'')
	carnum = (d/'td[3]').inner_html.gsub(/&nbsp;/,'')
	make = (d/'td[4]').inner_html.gsub(/&nbsp;/,'')
	laps = (d/'td[5]').inner_html.gsub(/&nbsp;/,'')
	money = (d/'td[6]').inner_html.gsub(/&nbsp;/,'')+""
	startpos = (d/'td[7]').inner_html.gsub(/&nbsp;/,'')
	lapsled = (d/'td[8]').inner_html.gsub(/&nbsp;/,'')
	points = (d/'td[9]').inner_html.gsub(/&nbsp;/,'')+""
	bonus = (d/'td[10]').inner_html.gsub(/&nbsp;/,'')
	penalty = (d/'td[11]').inner_html.gsub(/&nbsp;/,'')

	# call player script
	system('ruby '+playerfile+' "'+url+'" "'+name+'"')
	# call import 
	system('ruby ../sports/script/console < '+importplayerfile)

	line = '<stat name="'+name+'" carnum="'+carnum+'" make="'+make+'" laps="'+laps+'" money="'+money+'" startpos="'+startpos+'" finalpos="'+finalpos+'" lapsled="'+lapsled+'" points="'+points+'" bonus="'+bonus+'" penalty="'+penalty+'" />'

	system('echo \''+line+'\' >> '+statfile)
}
system('echo "</race>" >> '+statfile)
system('echo "</nascarstats>" >> '+statfile)

# call import script
system('ruby ../sports/script/console < import_nascar_stats.rb')
