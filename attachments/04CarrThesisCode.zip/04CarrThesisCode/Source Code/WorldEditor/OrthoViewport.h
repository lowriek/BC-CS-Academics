// OrthoViewport.h: interface for the COrthoViewport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ORTHOVIEWPORT_H__43BF5408_8095_4E6D_BDDB_C899B3B529E5__INCLUDED_)
#define AFX_ORTHOVIEWPORT_H__43BF5408_8095_4E6D_BDDB_C899B3B529E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Viewport.h"

class COrthoViewport : public CViewport  
{
protected:
	COrthoViewport();
public:
	COrthoViewport(COpenGLView* parent);
	virtual ~COrthoViewport();

	virtual float	GetSideLength();
	virtual void	Render();
	virtual void	SetupProjection();
	virtual void	ZoomIn();
	virtual void	ZoomOut();

	int				m_zoom;
	int				m_minZoom;
	int				m_maxZoom;


	
};

#endif // !defined(AFX_ORTHOVIEWPORT_H__43BF5408_8095_4E6D_BDDB_C899B3B529E5__INCLUDED_)
