/* 
   server.c
   - Raytracing server for distributed raytracer.
   - Given a scene definition file, and a set of ray points to trace, returns pixel colors
       back to the connecting client
*/


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <math.h>
#include "server.h"
#include "parser.h"



//Globals 
float AMBIENT;				 	  //Ambient scene light level
int NUM_OBJECTS;				  //Number of objects in scene
int ANTI_ALIAS;				     	  //0=no, 1=yes
int CAST_SHADOWS;			       	  //0=no, 1=yes
int ENABLE_FOG;				       	  //0=no, 1=yes
float fog_min_dist;			       	  //distance at which fogging effects become initially apparent
float fog_max_dist;				  //distance at which scene is in full fog
float SHADOW_FACTOR;				  //amount to affect base color if in shadow



/*Other, typedef and class dependant variables and functions
	-must therefore be defined after the above.   */
	
int currentLine=0;
color fog_color, light_color;
point3d eye, screen, light;
ray theray;


//Some globals for the scene
int IMAGE_DONE=0;
int SCREEN_RES_X=500;
int SCREEN_RES_Y=500;
float WORLD_RES_X=100.0;
float WORLD_RES_Y=100.0;
int XPIXEL, YPIXEL;
float * imageBuf;


int main(int argc, char *argv[])
{
    int sockfd, new_fd;  /* listen on sock_fd, new connection on new_fd */
    struct sockaddr_in my_addr;    /* my address information */
    struct sockaddr_in their_addr; /* connector's address information */
    socklen_t sin_size;
    char *pname;
    int port;
    int pid, childnum=0;
  
    /*
     * set signal catchers to properly clean up resources if
     * the program dies for one of several reasons.
     */
    
    signal (SIGHUP, bailOut);
    signal (SIGILL, bailOut);
    signal (SIGINT, bailOut);
    signal (SIGQUIT, bailOut);
    signal (SIGTRAP, bailOut);
    signal (SIGABRT, bailOut);
    signal (SIGFPE, bailOut);
    signal (SIGTERM, bailOut);
    signal (SIGSEGV, bailOut);
    signal (SIGBUS, bailOut);
    signal (SIGPIPE, bailOut);
    signal (SIGALRM, bailOut);    
    signal (SIGCLD,SIG_IGN);
    
    printf("\n\n");
    printf("RayServer v1.0\n");
    printf("***********************************\n\n");
    
    printf("SERVER: Initializing...\n");

    if (argc < 2){
      printf("SERVER: No port number specified- using default port %d\n", MYPORT);
      printf("        To use an alternate port, restart server with additional command line argument\n");

    }
    

    pname = argv[0];
    
    if(argc > 1){
      port = atoi(argv[1]);                                           /*save the port number from the command line*/
      printf("SERVER: Port number manually specified- using port %d\n", port);
    }
    else
      port = MYPORT;                                                  /*Use default port number */

    printf("SERVER: Getting socket...\n");
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {           /* Get socket from the OS */
      perror("SERVER: Error establishing socket... aborting server.\n");
      exit(1);
    }
    printf("SERVER: Got socket.\n");

    my_addr.sin_family = AF_INET;                                 /* host byte order */
    my_addr.sin_port = htons(port);                               /* short, network byte order */
    my_addr.sin_addr.s_addr = INADDR_ANY;                         /* automatically fill with my IP */
    bzero(&(my_addr.sin_zero), 8);                                /* zero the rest of the struct */
    
    printf("SERVER: Attempting to bind to socket...\n");
    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
      perror("SERVER: Unable to bind to socket... aborting server.\n");
      exit(1);
    }
    printf("SERVER: Socket bind successful.\n");

    printf("SERVER: Attempting to listen on socket...\n");
    if (listen(sockfd, BACKLOG) == -1) {
        perror("SERVER: Error listening on socket... aborting server.\n");
        exit(1);
    }
    printf("SERVER: Listening...\n");

    while(1) {  /* main accept() loop */
        sin_size = sizeof(struct sockaddr_in);
        printf("SERVER: Waiting for Connections...\n");
	if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) == -1) {
            perror("SERVER: Error accepting connection... aborting server.\n");
            continue;
        }
	else{
	  printf("SERVER: Got connection from %s\n",inet_ntoa(their_addr.sin_addr));
	  pid = fork();                 /* Fork a server to handle the client */
	  if (pid==0) { /* this is the child process */
	    child_server(new_fd, childnum++);
	  }
	  close(new_fd);  /* parent doesn't need this */
	}
    }

}

int child_server(int new_fd, int mynum){
  char frame[100], request[100];
  char temp[5];
  char theTime[20];
  char * fName;
  char c1,c2,c;
  FILE * fp;
  int x=0, n, ch, error=0, numfloats=0;
  int XMIN, XMAX, XSTEP, YMAX, YMIN, YSTEP;
  //float * dataBuf;

  printf("CHILD: Child server started.\n");  
  printf("       Getting unique file name...\n");

  sprintf(theTime, "%d\0", time(NULL));                                   //generate filename for ray file using time
  fName = (char *) malloc(40 * sizeof(char));
  strcpy(fName, theTime);

  strcpy(&(fName[strlen(theTime)]),".ray\0");                           //add the rayfile extension 
  printf("CHILD: Generated unique file '%s'\n", fName);
  
  fp = fopen(fName, "wb");
  printf("CHILD: Got and opened unique temporary file.\n\n");

  
  printf("CHILD: Sending SENDSOURCEFILE request...\n");                // Send source file request
  sendFileRequest(new_fd);
  printf("CHILD: Sent request successfully.\n\n");

  printf("CHILD: Receiving scene file...\n");                          // Receive source file
  receiveFile(fp, new_fd);
  printf("CHILD: Received scene file succesfully.\n\n");

  printf("CHILD: Sending SENDRAYRANGE request...\n");                  // Send ray params request
  sendParamsRequest(new_fd);
  printf("CHILD: Send request successfully.\n\n");

  printf("CHILD: Receiving Param String...\n");                        // Receive params string
  receiveParamString(frame, new_fd);
  printf("CHILD: Received string successfully.\n\n");

  printf("CHILD: Parsing params string...\n");
  error=parseParams(frame, &XMIN, &XMAX, &XSTEP, &YMIN, &YMAX, &YSTEP);  // Parse parameter string
  if(error==1){
    printf("CHILD: Error parsing range to raytrace.\n");
    printf("       Aborting child server...\n");
    exit(1);
  }
  printf("CHILD:  Parsed: xMin: %d\txMax: %d\txStep: %d\n", XMIN, XMAX, XSTEP);
  printf("                yMin: %d\tyMax: %d\tyStep: %d\n\n", YMIN, YMAX, YSTEP);
  

  
  printf("CHILD: Initializing scene variables...\n");                 //Initialize scene vars like eye, screen, and ray
  initSceneVars();
  printf("CHILD: Initialize successful.\n\n");
  
  printf("CHILD: Switching to parser...\n");
  parseFile(fName);
  printf("CHILD: Done parsing scene file.\n");
  printf("       Beginning to raytrace...\n");
 
  numfloats = traceScene(XMIN,XMAX,XSTEP,YMIN,YMAX,YSTEP);
  printf("CHILD: Tracing completed successfully.\n");
  printf("       All pixel data has been written to buffer for sending.\n\n");
  
  printf("CHILD: Waiting for data request from client...\n");
  receiveDataRequest(new_fd);
  printf("CHILD: Receive request for pixel data.\n\n");

  printf("CHILD: Sending data to client...\n");
  sendPixelData(new_fd, numfloats);
  printf("CHILD: Sent data back to client successfully.\n\n");

  
  printf("CHILD: Disconnecting from client...\n");
  error = close(new_fd);
  if(error==-1)
    printf("       **Error closing socket**\n\n");
  else
    printf("       Close successful.\n\n");

  printf("CHILD:  Process terminating\n\n");
 
  printf("SERVER: Waiting for more connections...\n\n");

  exit(0);
 

}

void sendPixelData(int sock, int numfloats){
  int n;
  
  //send number of floats to follow
  n = write(sock, &numfloats, sizeof(int));
  if( n < sizeof(int) ){
    printf("Error sending number of floats to receive.\n");
    printf("Aborting.\n\n");
    exit(1);
  }


  //write the pixel buffer to the socket
  n = write(sock, imageBuf, (numfloats * sizeof(float)));
  if( n <= 0){
    printf("Error sending pixel data.\n");
    printf("Aborting.\n\n");
    exit(1);
  }

}

void receiveDataRequest(int sock){
  int n;
  char frame[100];

  n = read(sock, frame, sizeof(frame));
  if(n <= 0){                                       //No bytes read or error
    printf("Error reading pixel data request.\n");
    printf("Aborting.\n\n");
    exit(1);
  }

  if( strcmp(frame, "SENDPIXELDATA") != 0){
    printf("Improper pixel data request.\n");
    printf("Aborting.\n");
    exit(1);
  }

}


  


int traceScene(int xmin, int xmax, int xstep, int ymin, int ymax, int ystep){
  
  color drawcolor;
  color aColor1, aColor2, aColor3, aColor4, aColor5;
  int x, y, xPixel, yPixel, memsize, numfloats;
  float pixIncY, pixIncX;


  printf("CHILD: Switched to tracing engine successfully.\n");

  //Initialize pixel buffer
  numfloats = ( ((ymax-ymin)+1) * ((xmax-xmin)+1) * 5);
  memsize   = ( ((ymax-ymin)+1) * ((xmax-xmin)+1) * 5 * sizeof(float));
  imageBuf = (float *) malloc(memsize);
  printf("CHILD: Allocated buffer successfully.\n");
  printf("       Buffer size: %d bytes\n\n", memsize);
  
  xPixel = 0;  //counters 
  yPixel = 0;
  
  //Need to set these to the proper starting values
  
  theray.p1.x = 0.0;
  theray.p1.y = (float)((float)(ymin)*(WORLD_RES_Y))/((float)SCREEN_RES_Y);
  theray.p1.z = 0.0;  
  theray.rIndex = 1.0;
  
  YPIXEL=0;
  printf("CHILD: Tracing...\n");
  for( y=0; y<=(ymax-ymin); y+=1){
    theray.p1.x = 0.0;
    XPIXEL=0;
    for( x=0; x<=xmax; x+=1){
     
      if(ANTI_ALIAS==1){
	float tempx, tempy, pixIncX, picIncY;
      
	tempx = theray.p1.x;
	tempy = theray.p1.y;

	pixIncX = (WORLD_RES_X/(float)SCREEN_RES_X)/3.0;
	pixIncY = (WORLD_RES_Y/(float)SCREEN_RES_Y)/3.0;
	
	theray.p1.x = theray.p1.x - pixIncX;
	theray.p1.y = theray.p1.y + pixIncY;
	aColor1 = fireRay(theray);
	
	theray.p1.x = theray.p1.x + 2.0*pixIncX;
	aColor2 = fireRay(theray);
	
	theray.p1.y = theray.p1.y - 2.0*pixIncY;
	aColor3 = fireRay(theray);
	
	theray.p1.x = theray.p1.x - 2.0*pixIncX;
	aColor4 = fireRay(theray);
	
	theray.p1.x = tempx;
	theray.p1.y = tempy;
	aColor5 = fireRay(theray);
	
	drawcolor.r = (aColor1.r + aColor2.r + aColor3.r + aColor4.r + aColor5.r)/5.0;
	drawcolor.g = (aColor1.g + aColor2.g + aColor3.g + aColor4.g + aColor5.g)/5.0;
	drawcolor.b = (aColor1.b + aColor2.b + aColor3.b + aColor4.b + aColor5.b)/5.0;
	
      }  //End antialiasing
      else
	drawcolor = fireRay(theray);
      
      // Done getting color for this pixel, need to put it into the buffer
      //   [xval][yval][red][green][blue]
      if((5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+0)>=(memsize-4)){
	printf("About to exceed buffer size\n");
	printf("aborting.\n\n");
	exit(0);
      }
      imageBuf[(5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+0)] = theray.p1.x;
      imageBuf[(5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+1)] = theray.p1.y;
      imageBuf[(5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+2)] = drawcolor.r;
      imageBuf[(5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+3)] = drawcolor.g;
      imageBuf[(5*SCREEN_RES_X*YPIXEL) + ((5*XPIXEL)+4)] = drawcolor.b;
      
      XPIXEL++;
      rayIncrementX();
    
    }
    if(YPIXEL%10 == 0)
      printf("       Finished tracing row %d   (in range %d to %d)\n", (ymin + YPIXEL), ymin, ymax);
    YPIXEL++;
    rayIncrementY();
  }

  return numfloats;

}

void rayIncrementY(){
  theray.p1.y += (WORLD_RES_Y/(float)SCREEN_RES_Y);
}

void rayIncrementX(){
  theray.p1.x += (WORLD_RES_X/(float)SCREEN_RES_X);
}



void initSceneVars(){

  eye.x    = 50.0;    eye.y    = 50.0;    eye.z    = 200.0;
  light.x  = 50.0;    light.y  = 60.0;    light.z  = -25.0;
  screen.x = 0.0;     screen.y = 0.0;     screen.z = 0.0;

  theray.p0.x = eye.x;  theray.p0.y = eye.y;  theray.p0.z = eye.z;
  
  fog_color.r = 1.0;   fog_color.g = 1.0;   fog_color.b = 1.0;
  fog_min_dist = 100.0;   fog_max_dist = 2000.0;

  CAST_SHADOWS = 1;
  SHADOW_FACTOR = 0.5;
  ENABLE_FOG = 0;
  AMBIENT = 0.3;
  ANTI_ALIAS = 0;  

}

void receiveParamString(char * buf, int sock){
  int n;
  char frame[100];
 
  n = read(sock, frame, sizeof(frame));
  if(n <= 0){                                   // no bytes read, or error was encountered
    printf("CHILD: Error receiving param string.\n");
    printf("       Aborting child server.\n");
    exit(1);
  }

  printf("Received param string: '%s' \n", frame);
  strcpy(buf, frame);                          //copy param string to buffer

}

void sendParamsRequest(int sock){

  char * frame = "SENDRAYRANGE";

  if(write(sock, frame, strlen(frame)+1) != strlen(frame)+1){
    printf("CHILD: Error sending SENDRAYRANGE request.\n");
    printf("       Aborting child server...\n");
    exit(1);
  }
  
}

void sendFileRequest(int sock){
  
  char * frame = "SENDSOURCEFILE";

  if(write(sock, frame, strlen(frame)+1) != strlen(frame)+1){
    printf("CHILD: Error sending SENDSOURCEFILE request.\n");
    printf("       Aborting child server...\n");
    exit(1);
  }

}

void receiveFile(FILE * iFile, int sock){
  int n;
  unsigned char c;
  
  //Read the file byte by byte and write to the file
  n=read(sock, &c, sizeof(unsigned char));
  while(n > 0  && c != '\0'){
    fprintf(iFile, "%c", c);
    n=read(sock, &c, sizeof(unsigned char));
  }
  fclose(iFile); 
} // File Received Successfully  
  


/*********************************
  Parse Params Function
**********************************/

int parseParams(char * params, int * xmax, int * xmin, int * xstep,
		int * ymax, int * ymin, int * ystep)
{
  int x=0, y=0;
  char value[10];

  //Extract XMAX value
  while(params[x] != '&'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *xmax = atoi(value);

  //Extract XMIN value
  y=0;
  x++;
  while(params[x] != '&'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *xmin = atoi(value);
  
  //Extract XSTEP value
  y=0;
  x++;
  while(params[x] != '&'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *xstep = atoi(value);
  
  //Extract YMAX value
  y=0;
  x++;
  while(params[x] != '&'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *ymax = atoi(value);

  //Extract YMIN value
  y=0;
  x++;
  while(params[x] != '&'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *ymin = atoi(value);

  //Extract YSTEP value
  y=0;
  x++;
  while(params[x] != '\0'){
    if(isdigit(params[x]) || params[x] == '-' || params[x] == '.')
      value[y++] = params[x];
    else
      return 1;
    x++;
  }
  value[y] = '\0';
  *ystep = atoi(value);

  //All values successfully extracted and set
  return 0;
} // End parseParams()

/************************
  bailOut function
*************************/
void bailOut (int aSignal) {
 /*
  * input   : aSignal, not used, required by the
  * returns : -
  * output  : -
  * desc    : destroys ipc resources and exits
  */
  int i;
  if (aSignal != 0) {
    fprintf(stderr, "received signal %d\n", aSignal);
  }
  for (i=3;i<MAXFD;i++)
   close(i);
  system("killall -9 rayserver");
  exit(1);
}

/********************************
  Fire ray functon
********************************/

color fireRay(ray r) {
	float tempT, bestT;
	color theColor;
	TCB* closest=NULL;

	bestT=1./0;
	for(current=top; current!=NULL; current=current->next){
		tempT = current->obj->getIntersection(r);
		if(tempT<bestT && tempT >0.05){										//fudge factor test
			closest=current;
			bestT = tempT;
		}
	}
																			//If there were no intersections, closest will never
	if(closest==NULL){														//   have been updated from NULL.
		theColor.r = 0.0;
		theColor.g = 0.0;
		theColor.b = 0.0;
		return theColor;
	}
	else
		theColor = closest->obj->getIlluminatedColor(light);				//Query object pointed to by closest for the color
	return theColor;

}


/************************************
Fire Shadow ray function
**************************************/

int fireShadowRay(ray r, point3d light){
	
	float bestT, tempT, maxT;
  	TCB * closest;
    
	maxT = (light.x - r.p0.x)/(r.p1.x-r.p0.x);

	bestT=1./0;
	for(current2=top; current2!=NULL; current2=current2->next)
	{
		tempT = current2->obj->getIntersection(r);
		if(tempT>0.005 && tempT < maxT)
			return 1;
	}
	return 0;
	      
}


//Various inline power functions
float Power(float a, int b){
	if(b<0)
		return pow(a,b);
	else if(b==0)
		return 1;
	else if(b==1)
		return a;
	else{
		float temp = a * a;
		for(int i=2;i<b;i++)
			temp = temp * a;
		return temp;
	}
}
	
float Power(float a, float b)
{	return pow(a,b);}


float Power(float a, double b)
{	return pow(a,b);}

float Power(int a, float b)
{	return pow(a,b);}

float Power(int a, int b)
{	return Power((float)a,b);}

float Power(int a, double b)
{   return pow(a,b);}

float Power(double a, float b)
{	return pow(a,b);}

float Power(double a, int b)
{	return Power((float)a,b);}

float Power(double a, double b)
{   return pow(a,b);}

float SQRT(float a){
	float r;
	if(a<(-.05))
		return 0;
	else if( a<0 && a>(-.05))
		r=0;
	else
		r = sqrt(a);
	
	return r;
}
