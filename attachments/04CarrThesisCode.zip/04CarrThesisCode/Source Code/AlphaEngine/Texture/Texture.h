#ifndef _TEXTURE_H_
#define _TEXTURE_H_

#include <windows.h>
#include <stdio.h>

#define BITMAP_ID 0x4D42

#define INVALID_TEXTURE -1
#define BASE_TEXTURE 0
#define DECAL_TEXTURE 1
#define LIGHTMAP_TEXTURE 2

/*
	CTexture holds image data (rgb), height, width of image.
	Supports 16,24 bit bitmap files that are not encoded.
*/

class CTexture  
{
public:
	CTexture();
	virtual			~CTexture();
	
	void			add(CTexture* pTexture);
	void			clear();
	unsigned char*	getData();
	int				getHeight();
	CTexture*		getNext();
	int				getTextureType();
	int				getWidth();
	bool			load(const char *filename, const char *textureName, int type);
	bool			serialize(FILE * filePtr, bool isStoring);

	short int		textureType;
	int				height;
	int				width;
	unsigned char*	imageData;
	char			name[15];
	unsigned int	texId;
	CTexture*		pNext;
private:
	bool			loadBitmapFile(char* filename);
};

#endif
