#include "Math.h"

const float CMath::PI = 4.0f*CMath::ATan(1.0f);
const float CMath::TWO_PI = 2.0f*PI;
const float CMath::HALF_PI = 0.5f*PI;
const float CMath::INV_TWO_PI = 1.0f/TWO_PI;
const float CMath::DEG_TO_RAD = CMath::PI/180.0f;
const float CMath::RAD_TO_DEG = 1.0f/CMath::DEG_TO_RAD;
const float CMath::INFINITY = 64000;

float CMath::ACos (float value)
{
    if ( -1.0f < value )
    {
        if ( value < 1.0f )
            return (float)acos(value);
        else
            return 0.0f;
    }
    else
    {
        return PI;
    }
}

float CMath::ASin (float value)
{
    if ( -1.0f < value )
    {
        if ( value < 1.0f )
            return (float)asin(value);
        else
            return -HALF_PI;
    }
    else
    {
        return HALF_PI;
    }
}
//----------------------------------------------------------------------------
float CMath::ATan (float value)
{
    return (float)atan(value);
}
//----------------------------------------------------------------------------
float CMath::ATan2 (float fY, float fX)
{
    return (float)atan2(fY,fX);
}
//----------------------------------------------------------------------------
float CMath::Ceil (float value)
{
    return (float)ceil(value);
}
//----------------------------------------------------------------------------
float CMath::Cos (float value)
{
    return (float)cos(value);
}
//----------------------------------------------------------------------------
float CMath::Exp (float value)
{
    return (float)exp(value);
}
//----------------------------------------------------------------------------
float CMath::FAbs (float value)
{
    return (float)fabs(value);
}
//----------------------------------------------------------------------------
float CMath::Floor (float value)
{
    return (float)floor(value);
}
//----------------------------------------------------------------------------
float CMath::InvSqrt (float value)
{
    return (float)(1.0/sqrt(value));
}
//----------------------------------------------------------------------------
float CMath::Log (float value)
{
    return (float)log(value);
}
//----------------------------------------------------------------------------
float CMath::Max(float a, float b)
{
	if (a > b)
		return a;
	else
		return b;
}
float CMath::Min(float a, float b)
{
	if (a < b)
		return a;
	else
		return b;
}
float CMath::Pow (float kBase, float kExponent)
{
    return (float)pow(kBase,kExponent);
}
//----------------------------------------------------------------------------
int CMath::Sign (int iValue)
{
    if ( iValue > 0 )
        return 1;

    if ( iValue < 0 )
        return -1;

    return 0;
}
//----------------------------------------------------------------------------
float CMath::Sign (float value)
{
    if ( value > 0.0f )
        return 1.0f;

    if ( value < 0.0f )
        return -1.0f;

    return 0.0f;
}
//----------------------------------------------------------------------------
float CMath::Sin (float value)
{
    return (float)sin(value);
}
//----------------------------------------------------------------------------
float CMath::Sqr (float value)
{
    return value*value;
}
//----------------------------------------------------------------------------
float CMath::Sqrt (float value)
{
    return (float)sqrt(value);
}
//----------------------------------------------------------------------------
float CMath::Tan (float value)
{
    return (float)tan(value);
}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
float CMath::UnitRandom (float seed)
{
    if ( seed > 0.0f )
        srand((unsigned int)seed);

     return float(rand())/float(RAND_MAX);
}
//----------------------------------------------------------------------------
float CMath::SymmetricRandom (float seed)
{
    if ( seed > 0.0f )
        srand((unsigned int)seed);

    return 2.0f*float(rand())/float(RAND_MAX) - 1.0f;
}
//----------------------------------------------------------------------------
float CMath::IntervalRandom (float min, float max, float seed)
{
    if ( seed > 0.0f )
        srand((unsigned int)seed);

    return min + (max-min)*float(rand())/float(RAND_MAX);
}
//----------------------------------------------------------------------------
