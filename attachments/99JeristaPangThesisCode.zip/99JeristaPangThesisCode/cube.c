// Converted by OpenGL Export Plugin 0.2

#include <windows.h>		//Standard Windows include
#include <gl\gl.h>			//OpenGL Library
#include <gl\glu.h>			// GLU library
#include "resource.h"		// About box resource identifiers.


static GLfloat color_val[1][3] = 
{
	{1.000000f, 0.000000f, 0.000000f}
};
void cube1(void)
{
	glColor3fv(color_val[0]);
	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(-1.000000f, 1.000000f, 1.000000f);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(-1.000000f, -1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(1.000000f, -1.000000f, 1.000000f);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
		glNormal3f(0.000000f, 0.000000f, -1.000000f);
		glVertex3f(-1.000000f, -1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, 1.000000f);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, -1.000000f);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, -1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, 1.000000f);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, 1.000000f);
		glNormal3f(1.000000f, 0.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, -1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, 1.000000f);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(-1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, -1.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, -1.000000f);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, 1.000000f);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
		glNormal3f(-1.000000f, 0.000000f, 0.000000f);
		glVertex3f(1.000000f, 1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, 1.000000f);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, -1.000000f);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
		glNormal3f(0.000000f, 1.000000f, 0.000000f);
		glVertex3f(-1.000000f, -1.000000f, 1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(-1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
	glEnd();

	glBegin(GL_TRIANGLES);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(-1.000000f, -1.000000f, -1.000000f);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(-1.000000f, 1.000000f, -1.000000f);
		glNormal3f(0.000000f, 0.000000f, 1.000000f);
		glVertex3f(1.000000f, -1.000000f, -1.000000f);
	glEnd();

}

