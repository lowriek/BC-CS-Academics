class Sport < ActiveRecord::Base
end
