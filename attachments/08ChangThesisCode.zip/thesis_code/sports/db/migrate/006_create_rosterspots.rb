class CreateRosterspots < ActiveRecord::Migration
  def self.up
    create_table :rosterspots do |t|
			t.column :team_id, :integer, :null => false
			t.column :player_id, :integer, :null => false
			t.column :start, :datetime
			t.column :end, :datetime
      t.timestamps
    end
  end

  def self.down
    drop_table :rosterspots
  end
end
