#include "AlphaEngine/Bsp/BspNode.h"
#include "AlphaEngine/Math/Math.h"
#include "AlphaEngine/AlphaConstants.h"

unsigned int CBspNode::numLeaf = 0;
unsigned int CBspNode::numPart = 0;

CBspNode::CBspNode()
{
	id = ALPHA_NO_ID;
	pBack = 0;
	pFront = 0;
	pPolygon = 0;
	augmented = false;
}

CBspNode::~CBspNode()
{
	if (pBack)
		delete pBack;
	if (pFront)
		delete pFront;
	if (pPolygon)
		delete pPolygon;

	pBack = 0;
	pFront = 0;
	pPolygon = 0;
}

CPolygon* CBspNode::clip(CPolygon* ptrPolygon, int side)
{
	if (isLeaf())
	{
		if (side == ALPHA_INFRONT)
		{
			delete ptrPolygon;
			ptrPolygon=0;
		}
		return ptrPolygon;
	}

	int retval = ptrPolygon->classify(plane);

	if (retval == ALPHA_COINCIDING)
	{
		if (!augmented)
			retval = side;
		else
		{
			if (ptrPolygon->plane.normal.dot(plane.normal) >= 0)
			{
				switch(side)
				{
				case ALPHA_INFRONT:
					if (pBack)
						return pBack->clip(ptrPolygon, side);
					else
					{
						if (side == ALPHA_INFRONT)
						{
							delete ptrPolygon;
							ptrPolygon = 0;
						}
						return ptrPolygon;
					}
					break;
				case ALPHA_BEHIND:
					if (pFront)
						return pFront->clip(ptrPolygon, side);
					else
					{
						if (side == ALPHA_BEHIND)
						{
							delete ptrPolygon;
							ptrPolygon = 0;
						}
						return ptrPolygon;
					}
					break;
				}
			}
			else
			{
				retval = side;
			}
		}
	}

	switch(retval)
	{
	case ALPHA_INFRONT:
		if (pFront)
			return pFront->clip(ptrPolygon, side);
		else
		{
			if (side == ALPHA_INFRONT)
			{
				delete ptrPolygon;
				ptrPolygon = 0;
			}
			return ptrPolygon;
		}
		break;
	case ALPHA_BEHIND:
		if (pBack)
			return pBack->clip(ptrPolygon, side);
		else
		{
			if (side == ALPHA_BEHIND)
			{
				delete ptrPolygon;
				ptrPolygon = 0;
			}
			return ptrPolygon;
		}
		break;
	case ALPHA_SPANNING:
		CPolygon* pPos = new CPolygon();
		CPolygon* pNeg = new CPolygon();
		CPolygon* pRetFront = 0;
		CPolygon* pRetBack = 0;
		bool flag = true;

		ptrPolygon->splitPolygon(plane, pPos, pNeg);

		if (pFront)
		{
			pRetFront = pFront->clip(pPos, side);
			if (pRetFront != pPos)
				flag = false;
		}
		else if (side == ALPHA_INFRONT)
		{
			delete pPos;
			pPos = 0;
			flag=false;
		}
		else
			pRetFront = pPos;

		if (pBack)
		{
			pRetBack = pBack->clip(pNeg, side);
			if (pRetBack != pNeg)
				flag = false;
		}
		else if (side == ALPHA_BEHIND)
		{
			delete pNeg;
			pNeg = 0;
			flag = false;
		}
		else
			pRetBack = pNeg;

		if (flag)
		{
			if (pPos)
				delete pPos;
			if (pNeg)
				delete pNeg;
			return ptrPolygon;
		}
		else
		{
			delete ptrPolygon;
			ptrPolygon = 0;
			if (pRetFront)
			{
				pRetFront->add(pRetBack);
				return pRetFront;
			}
			else
				return pRetBack;
		}
		break;
	}
	return 0;
}

CBspNode* CBspNode::clone()
{
	CBspNode* node = new CBspNode();
	node->boundBox = boundBox;
	node->id = id;
	node->plane = plane;
	CPolygon* pTemp = pPolygon;
	while (pTemp != 0)
	{
		if (node->pPolygon)
			node->pPolygon->add(pTemp->clone());
		else
			node->pPolygon = pTemp->clone();

		pTemp = pTemp->pNext;
	}
	
	CBspNode* front = 0;
	CBspNode* back = 0;
	if (pFront)
		front = pFront->clone();
	if (pBack)
		back = pBack->clone();

	node->pFront = front;
	node->pBack = back;

	return node;
}

void CBspNode::computeBoundBox(CPolygon* ptrPolygon)
{
	CPolygon* pTemp = ptrPolygon;
	while (pTemp != 0)
	{
		for (unsigned int i=0; i < pTemp->numVert; i++)
			boundBox.addVert(pTemp->pVert[i]);

		pTemp = pTemp->pNext;
	}
}

int CBspNode::create(CPolygon *ptrPolygon)
{
	if (!ptrPolygon)
		return 1;

	numLeaf = 0;
	numPart = 0;
	return createBsp(ptrPolygon);
}

int CBspNode::createBsp(CPolygon* ptrPolygon)
{
	CPolygon* pRoot = 0;
	
	computeBoundBox(ptrPolygon);

	bool retval = selectPartition(ptrPolygon);

	if (!retval)
	{
		pRoot = ptrPolygon;
		while (pRoot != 0)
		{
			if (pPolygon)
				pPolygon->add(pRoot->clone());
			else
				pPolygon = pRoot->clone();

			pRoot = pRoot->pNext;
		}
		
		delete ptrPolygon;

		id = numLeaf;
		numLeaf++;

		return 0;
	}
	else
	{
		// assign an id to this partition (check if too many partitions)
		id = numPart;
		numPart++;

		pRoot = ptrPolygon;
		
		CPolygon* pPos = 0;
		CPolygon* pNeg = 0;
		CPolygon* pClone = 0;
		while (pRoot != 0)
		{
			int retint = pRoot->classify(plane);
			switch(retint)
			{
			case ALPHA_INFRONT:
				if (pPos)
					pPos->add(pRoot->clone());
				else
					pPos = pRoot->clone();
				break;
			case ALPHA_BEHIND:
				if (pNeg)
					pNeg->add(pRoot->clone());
				else
					pNeg = pRoot->clone();

				break;
			case ALPHA_COINCIDING:
				pClone = pRoot->clone();
				if (pClone->plane.normal.dot(plane.normal) >= 0)
				{
					pClone->flag = true;
					if (pPos)
						pPos->add(pClone);
					else
						pPos = pClone;
				} 
				else
				{
					augmented = true;
					pClone->flag = true;
					if (pNeg)
						pNeg->add(pClone);
					else
						pNeg = pClone;
				}
				break;
			case ALPHA_SPANNING:
				CPolygon* pPosSide = new CPolygon();
				CPolygon* pNegSide = new CPolygon();
				pRoot->splitPolygon(plane, pPosSide, pNegSide);
				pPosSide->flag = pRoot->flag;
				pNegSide->flag = pRoot->flag;

				if (pPos)
					pPos->add(pPosSide);
				else
					pPos = pPosSide;

				if (pNeg)
					pNeg->add(pNegSide);
				else
					pNeg = pNegSide;

				break;
			}

			pRoot = pRoot->pNext;
		}
		
		delete ptrPolygon;

		int retPos = 0;
		int retNeg = 0;

		if (pPos)
		{
			pFront = new CBspNode();
			retPos = pFront->createBsp(pPos);
		}
		if (retPos == 0)
		{
			if (pNeg)
			{
				pBack = new CBspNode();
				retNeg = pBack->createBsp(pNeg);
				return retNeg;
			}
		}
		return retPos;
	}
}

unsigned int CBspNode::getNumLeaves()
{
	if (isLeaf())
		return 1;
	else
	{
		unsigned int front = 0;
		unsigned int back = 0;
		if (pFront)
			front = pFront->getNumLeaves();
		if (pBack)
			back = pBack->getNumLeaves();

		return front + back;
	}
}

CBspNode* CBspNode::getLeafNode(unsigned int id)
{
	if (isLeaf())
	{
		if (this->id == id)
		{
			return this;
		}
		return 0;
	}
	else
	{
		CBspNode* retval = 0;
		if (pFront)
			retval = pFront->getLeafNode(id);
		
		if (retval != 0)
			return retval;

		if (pBack)
			retval = pBack->getLeafNode(id);

		return retval;
	}
}

CBspNode* CBspNode::getLeafNode(CVector3 &location)
{
	if (isLeaf())
		return this;

	int retval = plane.classifyPoint(location);
	if (retval == ALPHA_BEHIND)
	{
		if (pBack)
			return pBack->getLeafNode(location);
		else
			return 0;
	}
	if (pFront)
		return pFront->getLeafNode(location);
	else
		return 0;
}

CBspNode* CBspNode::getPartitionNode(unsigned int id)
{
	if (isLeaf())
		return 0;

	if (this->id == id)
		return this;

	CBspNode* retval = 0;
	if (pFront)
		retval = pFront->getPartitionNode(id);

	if (retval != 0)
		return retval;

	if (pBack)
		retval = pBack->getPartitionNode(id);

	return retval;
}

CPolygon* CBspNode::getPolygons()
{
	if (!pPolygon)
		return 0;

	CPolygon* pResult = 0;
	CPolygon* pTemp = pPolygon;
	while (pTemp != 0)
	{
		if (pResult)
			pResult->add(pTemp->clone());
		else
			pResult = pTemp->clone();

		pTemp = pTemp->pNext;
	}

	return pResult;
}

unsigned int CBspNode::getNumPartitions()
{
	if (isLeaf())
		return 0;
	else
	{
		unsigned int front = 0;
		unsigned int back = 0;
		if (pFront)
			front = pFront->getNumPartitions();
		if (pBack)
			back  = pBack->getNumPartitions();

		return 1 + front + back;
	}
}

bool CBspNode::selectPartition(CPolygon *ptrPolygon)
{
	CPolygon* pRoot = ptrPolygon;
	bool foundPart = false;

	while (pRoot != 0 && !foundPart)
	{
		if (!pRoot->flag)
		{
			pRoot->flag = true;
			foundPart = true;
			plane = pRoot->plane;
		}
		pRoot = pRoot->pNext;
	}

	return foundPart;
}

bool CBspNode::isLeaf()
{
	return !(pFront || pBack);
}

void CBspNode::render(int flags, CVector3 &location)
{

	CPolygon* tPolygon = 0;

	if (isLeaf())
	{
		tPolygon=pPolygon;
		while (tPolygon != 0)
		{
			tPolygon->render(flags);
			tPolygon = tPolygon->pNext;
		}
		return;
	}

	int retval = plane.classifyPoint(location);

	if (retval == ALPHA_INFRONT)
	{
		if (pBack)
			pBack->render(flags, location);
		if (pFront)
			pFront->render(flags, location);
	}
	else
	{
		if (pFront)
			pFront->render(flags, location);
		if (pBack)
			pBack->render(flags, location);
	}
}

bool CBspNode::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	bool hasBack = pBack != 0;
	bool hasFront = pFront != 0;
	
	unsigned int numPolygon = 0;
	CPolygon* pRoot = 0;
	
	if (pPolygon)
	{
		pRoot = pPolygon;	
		while (pRoot != 0)
		{
			numPolygon++;
			pRoot = pRoot->pNext;
		}
	}

	if (isStoring)
	{
		fwrite(&id, sizeof(unsigned int), 1, filePtr);
		fwrite(&augmented, sizeof(bool), 1, filePtr);
		fwrite(&hasBack, sizeof(bool), 1, filePtr);
		fwrite(&hasFront, sizeof(bool), 1, filePtr);
		fwrite(&numPolygon, sizeof(unsigned int), 1, filePtr);
		if (numPolygon > 0)
		{
			pRoot = pPolygon;
			while (pRoot != 0)
			{
				pRoot->serialize(filePtr, isStoring);
				pRoot = pRoot->pNext;
			}
		}
	}
	else
	{
		fread(&id, sizeof(unsigned int), 1, filePtr);
		fread(&augmented, sizeof(bool), 1, filePtr);
		fread(&hasBack, sizeof(bool), 1, filePtr);
		fread(&hasFront, sizeof(bool), 1, filePtr);
		fread(&numPolygon, sizeof(unsigned int), 1, filePtr);
		for (unsigned int i = 0; i < numPolygon; i++)
		{
			CPolygon* pTemp = new CPolygon();
			pTemp->serialize(filePtr, isStoring);
			if (pPolygon)
				pPolygon->add(pTemp);
			else
				pPolygon = pTemp;
		}
		if (hasBack)
			pBack = new CBspNode();
		if (hasFront)
			pFront = new CBspNode();
	}
	
	if (hasBack)
	{
		if (!pBack->serialize(filePtr, isStoring)) return false;
	}

	if (hasFront)
	{
		if (!pFront->serialize(filePtr, isStoring)) return false;
	}

	if (!boundBox.serialize(filePtr, isStoring)) return false;
	if (!plane.serialize(filePtr, isStoring)) return false;

	return true;
}



