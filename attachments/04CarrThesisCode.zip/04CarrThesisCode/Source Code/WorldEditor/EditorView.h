#if !defined(AFX_EDITORVIEW_H__5E57F9DF_BF52_4BB6_9E46_940DFE00E799__INCLUDED_)
#define AFX_EDITORVIEW_H__5E57F9DF_BF52_4BB6_9E46_940DFE00E799__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ViewportContainer.h"
#include "ArchitectViewport.h"
#include "PerspectiveViewport.h"

class CEditorView : public CViewportContainer
{
protected:
	CEditorView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CEditorView)

// Attributes
public:
	CArchitectViewport*		xyViewport;
	CArchitectViewport*		xzViewport;
	CArchitectViewport*		yzViewport;
	CPerspectiveViewport*	perspectiveViewport;
	
// Operations
public:
	virtual BOOL InitOpenGL();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditorView)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual void ToggleFullscreen();

	virtual ~CEditorView();

	bool					fullScreen;
	// Generated message map functions
protected:
	//{{AFX_MSG(CEditorView)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnButtonDelete();
	afx_msg void OnButtonTranslate();
	afx_msg void OnButtonScale();
	afx_msg void OnButtonRotate();
	afx_msg void OnDisplayWireframe();
	afx_msg void OnComputeBsp();
	afx_msg void OnViewFilled();
	afx_msg void OnButtonBox();
	afx_msg void OnButtonCsgSub();
	afx_msg void OnButtonCsgAdd();
	afx_msg void OnButtonDeleteBuilder();
	afx_msg void OnButtonSphere();
	afx_msg void OnViewBrushmode();
	afx_msg void OnViewCsgmode();
	afx_msg void OnViewFinalmode();
	afx_msg void OnComputePvs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITORVIEW_H__5E57F9DF_BF52_4BB6_9E46_940DFE00E799__INCLUDED_)
