#ifndef	ENTITY_H
#define ENTITY_H


/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENTITY.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 29, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */
#include <string.h>
//#include <afxcmn.h>
#include "matrix.h"
#include "math.h"
#include "font.h"
#include "keyboardMap.h"
#include "Glext.h"
#include "resource.h"

class Entity 
{
		
	protected:
		double		x,y,z;
		
		long		boundingRadius;
		static float		* frustum;
		static Font	* messenger;
		static bool	debugOut;
		static long  vPoint[3];
		static int	   drawMode;
		static bool	 keys[256];
		bool			testSight;

	public:
		Entity * parent;
		Entity * child;
		Entity * next;
		Entity * prev;

		
		Entity();
		Entity(float x, float y, float z);
		~Entity(){};
		virtual void Draw();
		virtual void Kill();
		virtual float GetHeight(float xPos, float zPos);
		AddChild(Entity * e);
		Entity * KillChild();
		inline SetFrustum(float * f){frustum = f;};
		float IsVisible();
		float IsVisible(long x, long y, long z, long rd);
		void  SetCoordinates(float a, float b, float c, bool test){x=a;y=b;z=c;testSight=test;};
		
		
		float * MakeFrustum();
};

unsigned int LoadTGA(const char * filename, float envType);


#endif