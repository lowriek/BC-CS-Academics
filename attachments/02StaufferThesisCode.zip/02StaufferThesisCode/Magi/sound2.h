#ifndef SOUND_H
#define SOUND_H

/*		Magi Game Engine		 */
/*		Interface for DirectSound */
/*		Created: April 4, 2002	   */
/*      Cris Stauffer					*/
/*		Code Based off of Trent Polack */



#define WIN32_LEAN_AND_MEAN
#define INIT_GUID

#include <windows.h>		//Windows header file
#include <windowsx.h>		//Windows header with some kewl extras
#include <mmsystem.h>
#include <dsound.h>
#include <iostream.h>			
#include <conio.h>
#include <stdio.h> 
#include <stdarg.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>
#include <math.h>
#include <io.h>
#include <fcntl.h>
#include <time.h>

#include <dmusicc.h>
#include <dmusici.h>

#include "entity.h"
#define INITGUID

#define LPDIRECTMUSICLOADER8		IDirectMusicLoader8*
#define LPDIRECTMUSICPERFORMANCE8	IDirectMusicPerformance8*
#define LPDIRECTMUSICSEGMENT8		IDirectMusicSegment8*
#define LPDIRECTMUSICAUDIOPATH		IDirectMusicAudioPath*
#define LPDIRECTSOUND3DBUFFER		IDirectSound3DBuffer*
#define LPDIRECTSOUND3DLISTENER		IDirectSound3DListener*



class SoundObject
	{
	public:
		LPDIRECTMUSICSEGMENT8 dmSegment;
		LPDIRECTSOUND3DBUFFER ds3DBuffer;
		bool is3DSound;
	
	bool SetVolume(float percent);
	void Set3DPos(float x, float y, float z);
	void Set3DDistances(float minDistance, float maxDistance);	
	void Shutdown();

	SoundObject(){ dmSegment = NULL;  ds3DBuffer = NULL; is3DSound = false; };

	~SoundObject() 
		{	};
	};



class SoundManager: public Entity
	{
	
	protected:
		LPDIRECTMUSICAUDIOPATH		audioPath3;
		LPDIRECTSOUND3DLISTENER		listener3;
		DS3DLISTENER			listParams;
		LPDIRECTMUSICLOADER8		loader;
		LPDIRECTMUSICPERFORMANCE8	performance;
		HWND		hwnd;	
		SoundObject * objList[10];
		
	public:
	bool Init(void);	
	void Shutdown(void);
	void Kill();

	bool Create(SoundObject * audio, char* filename, bool is3DSound);

	void Play(SoundObject * audio, DWORD numRepeats);
	void Stop(SoundObject * audio);

	void SetListenerPos(float x, float y, float z);
	void SetListenerRolloff(float rolloff);
	void SetListenerOrientation(	float forwardX, float forwardY, float forwardZ,
					float topX, float topY, float topZ);

	SoundManager(HWND windowHandler ){ audioPath3 = NULL; loader = NULL;
			 performance = NULL; listener3 = NULL; hwnd = windowHandler; for(int i=0;i<10;i++)objList[i] = NULL; Entity();};

	~SoundManager()
		{	};
	};





#endif