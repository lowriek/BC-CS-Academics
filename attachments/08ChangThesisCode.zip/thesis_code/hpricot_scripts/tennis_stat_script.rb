# needs to be given url to a dailyResult page

require 'rubygems'
require 'hpricot'
require 'open-uri'

if ( (url = ARGV[0]) == nil)
  puts "usage: tennis_stat_script.rb full_url\n"
  exit
end

# url = 'http://sports.espn.go.com/sports/tennis/dailyResults'+url
tennis_statfile = 'tennis_statfile.list'
doc = Hpricot(open(url))

#// this is each column in each match type (us open mens 1st round, etc)
(doc/'div.content/div.sp-col1/div/div.leagueColR').each { |c|
	
	#// this is for each game within each column	
	(c/'div.gameContainer').each { |g|
		#// get some sort of game id
		#// stats will consist of player, game, and statconcept
		gamename = (g/'div[4]').attr('id').gsub(/-linescoreHeader/,'')

		doubles1 = false
		doubles2 = false
		t1p1 = ''; t1p2 = ''; t2p1 = ''; t2p2 = '';
		#// team1
		(g/'div.teams/table/tr[2]').each { |t1|
			if ((t1/'td/a').size == 2)
				#//doubles
				t1p1 = (t1/'td/a')[0].inner_html
				t1p2 = (t1/'td/a')[1].inner_html
				doubles1 = true
			else
				#//singles, or doubles with 1 or more non-links
				t1p1 = (t1/'td/a').inner_html
			end
		}
		#// team2
		(g/'div.teams/table/tr[3]').each { |t2|
			if ((t2/'td/a').size == 2)
				#//doubles
				t2p1 = (t2/'td/a')[0].inner_html
				t2p2 = (t2/'td/a')[1].inner_html
				doubles2 = true
			else
				#//singles, or doubles with 1 or more non-links
				t2p1 = (t2/'td/a').inner_html
			end
		}

		#// linescoreHeader
		#// number of sets		
		numsets = (g/'div[4]/table/tr[1]/td.lsTop').size
		#// or (g/'div[4]/table/tr[2]/td').size
		
		top = []
		bot = []
		
		#// for each top set
		(g/'div[4]/table/tr[2]/td').each { |s|
			if ( (s/'sup').size == 1)
				#// there is a tie breaker score
				sup = (s/'sup').inner_html
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				top = top+[setscore.to_s+'+'+sup.to_s]
			else
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				top = top+[setscore.to_s]
			end
		}
		(g/'div[4]/table/tr[3]/td').each { |s|
			if ( (s/'sup').size == 1)
				#// there is a tie breaker score
				sup = (s/'sup').inner_html
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				bot = bot+[setscore.to_s+'+'+sup.to_s]
			else
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				bot = bot+[setscore.to_s]
			end
		}
		
		# //'<game name=\'gamename\'>' # create the game
		s = '<game name=\''+gamename+'\'>'
		system("echo \""+s+"\" >> "+tennis_statfile)
			# add the lines for the two teams
			t = '<team1 p1=\''+t1p1+'\' p2=\''+t1p2+'\' />'
			system("echo \""+t+"\" >> "+tennis_statfile)
			t = '<team2 p1=\''+t2p1+'\' p2=\''+t2p2+'\' />'
			system("echo \""+t+"\" >> "+tennis_statfile)
			
		if (doubles1)
			for i in (1..numsets)
				s = '<stat pname=\''+t1p1+'\' gamename=\''+gamename+'\' statconcept=\'doublesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
				s =	'<stat pname=\''+t1p2+'\' gamename=\''+gamename+'\' statconcept=\'doublesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		else
			for i in (1..numsets)
				s = '<stat pname=\''+t1p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		end

		if (doubles2)
			for i in (1..numsets)
				s = '<stat pname=\''+t2p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
				s =	'<stat pname=\''+t2p2+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		else
			for i in (1..numsets)
				s = '<stat pname=\''+t2p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		end

		#//'</game>'
		system("echo '</game>' >> "+tennis_statfile)
		#//end game
	}
}

#####################################################################
#// need same code for other column
(doc/'div.content/div.sp-col1/div/div.leagueColL').each { |c|
	
	#// this is for each game within each column	
	(c/'div.gameContainer').each { |g|
		#// get some sort of game id
		#// stats will consist of player, game, and statconcept
		gamename = (g/'div[4]').attr('id').gsub(/-linescoreHeader/,'')

		doubles1 = false
		doubles2 = false
		t1p1 = ''; t1p2 = ''; t2p1 = ''; t2p2 = '';
		#// team1
		(g/'div.teams/table/tr[2]').each { |t1|
			if ((t1/'td/a').size == 2)
				#//doubles
				t1p1 = (t1/'td/a')[0].inner_html
				t1p2 = (t1/'td/a')[1].inner_html
				doubles1 = true
			else
				#//singles, or doubles with 1 or more non-links
				t1p1 = (t1/'td/a').inner_html
			end
		}
		#// team2
		(g/'div.teams/table/tr[3]').each { |t2|
			if ((t2/'td/a').size == 2)
				#//doubles
				t2p1 = (t2/'td/a')[0].inner_html
				t2p2 = (t2/'td/a')[1].inner_html
				doubles2 = true
			else
				#//singles, or doubles with 1 or more non-links
				t2p1 = (t2/'td/a').inner_html
			end
		}

		#// linescoreHeader
		#// number of sets		
		numsets = (g/'div[4]/table/tr[1]/td.lsTop').size
		#// or (g/'div[4]/table/tr[2]/td').size
		
		top = []
		bot = []
		
		#// for each top set
		(g/'div[4]/table/tr[2]/td').each { |s|
			if ( (s/'sup').size == 1)
				#// there is a tie breaker score
				sup = (s/'sup').inner_html
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				top = top+[setscore.to_s+'+'+sup.to_s]
			else
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				top = top+[setscore.to_s]
			end
		}
		(g/'div[4]/table/tr[3]/td').each { |s|
			if ( (s/'sup').size == 1)
				#// there is a tie breaker score
				sup = (s/'sup').inner_html
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				bot = bot+[setscore.to_s+'+'+sup.to_s]
			else
				setscore = s.inner_html.gsub(/<sup>\d*<\/sup>/,'')
				bot = bot+[setscore.to_s]
			end
		}
		
		# //'<game name=\'gamename\'>' # create the game
		s = '<game name=\''+gamename+'\'>'
		system("echo \""+s+"\" >> "+tennis_statfile)
			# add the lines for the two teams
			t = '<team1 p1=\''+t1p1+'\' p2=\''+t1p2+'\' />'
			system("echo \""+t+"\" >> "+tennis_statfile)
			t = '<team2 p1=\''+t2p1+'\' p2=\''+t2p2+'\' />'
			system("echo \""+t+"\" >> "+tennis_statfile)

		if (doubles1)
			for i in (1..numsets)
				s = '<stat pname=\''+t1p1+'\' gamename=\''+gamename+'\' statconcept=\'doublesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
				s =	'<stat pname=\''+t1p2+'\' gamename=\''+gamename+'\' statconcept=\'doublesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		else
			for i in (1..numsets)
				s = '<stat pname=\''+t1p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+top[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		end

		if (doubles2)
			for i in (1..numsets)
				s = '<stat pname=\''+t2p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
				s =	'<stat pname=\''+t2p2+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		else
			for i in (1..numsets)
				s = '<stat pname=\''+t2p1+'\' gamename=\''+gamename+'\' statconcept=\'singlesset'+i.to_s+'\' value=\''+bot[i-1]+'\' />'
				system("echo \""+s+"\" >> "+tennis_statfile)
			end
		end

		#//'</game>'
		system("echo '</game>' >> "+tennis_statfile)
		#//end game
	}
}

# sanity checks

