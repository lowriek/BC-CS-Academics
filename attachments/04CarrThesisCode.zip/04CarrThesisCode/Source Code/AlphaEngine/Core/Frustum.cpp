#include "AlphaEngine/Core/Frustum.h"
#include "AlphaEngine/Math/Math.h"

CFrustum* CFrustum::adjust(CPolygon* pPolygon, CVector3& position)
{

	unsigned int i, j;
	CPolygon* pFront = 0;
	CPolygon* pBack = 0;
	CFrustum* pFrustum = new CFrustum();
	bool doDelete = false;

	for (i=0; i < numPlanes; i++)
	{
		int retval = pPolygon->classify(pPlanes[i]);
		if (retval == ALPHA_SPANNING)
		{
			pFront = new CPolygon();
			pBack = new CPolygon();
			pPolygon->splitPolygon(pPlanes[i], pFront, pBack);

			delete pBack;
			if (doDelete) {
				delete pPolygon;
				pPolygon = 0;
			}

			doDelete = true;
			pPolygon = pFront;
		}
	}

	pFrustum->allocatePlanes(pPolygon->numVert);
	CVector3 normal;
	float d = 0;
	for (i=0; i < pPolygon->numVert; i++)
	{
		j = (i+1) % pPolygon->numVert;
		CVector3 s1 = pPolygon->pVert[i] - position;
		CVector3 s2 = pPolygon->pVert[j] - position;
		normal = -s1.cross(s2);
		d = -normal.dot(position);
		d /= normal.length();
		normal.unitize();
		pFrustum->pPlanes[i].normal = normal;
		pFrustum->pPlanes[i].d = d;
/*
		normal = -s1.cross(s2);
		normal.unitize();
		d = -normal.dot(pPolygon->pVert[j]);
		pFrustum->pPlanes[i].normal = normal;
		pFrustum->pPlanes[i].d = d;
*/
	}

	pFrustum->backPlane = backPlane;
	pFrustum->frontPlane = frontPlane;

	// clean up memory
	if (doDelete) {
		delete pPolygon;
		pPolygon = 0;
	}

	return pFrustum;
}

void CFrustum::allocatePlanes(unsigned int num)
{
	if (pPlanes)
		deletePlanes();

	pPlanes = new CPlane[num];
	numPlanes = num;
}

CFrustum::CFrustum() 
{
	numPlanes = 0;
	pPlanes = 0;
}

CFrustum::~CFrustum()
{
	deletePlanes();
}

void CFrustum::deletePlanes()
{
	if (pPlanes)
	{
		delete [] pPlanes;
		pPlanes = 0;
	}
	numPlanes = 0;
}

bool CFrustum::pointInFrustum(CVector3& pt)
{
	unsigned int i=0;
	int retval;
	for (i=0; i < numPlanes; i++)
	{
		retval = pPlanes[i].classifyPoint(pt);
		if (retval == ALPHA_BEHIND)
			return false;
	}

	if (backPlane.classifyPoint(pt) == ALPHA_BEHIND)
		return false;
	
	if (frontPlane.classifyPoint(pt) == ALPHA_BEHIND)
		return false;

	return true;
}

bool CFrustum::polygonInFrustum(CPolygon* pPolygon)
{
	unsigned int i=0;
	int retval;
	for (i=0; i< numPlanes; i++)
	{
		retval = pPolygon->classify(pPlanes[i]);

		if (retval == ALPHA_BEHIND)
			return false;
	}

	if (pPolygon->classify(frontPlane) == ALPHA_BEHIND)
		return false;

	if (pPolygon->classify(backPlane) == ALPHA_BEHIND)
		return false;

	return true;
}

void CFrustum::update()
{
	float proj[16];
	float modl[16];
	float clip[16];
	float d;
	CVector3 normal;

	deletePlanes();

	glGetFloatv(GL_PROJECTION_MATRIX, proj);
	glGetFloatv(GL_MODELVIEW_MATRIX, modl);

	clip[ 0] = modl[ 0] * proj[ 0] + modl[ 1] * proj[ 4] + modl[ 2] * proj[ 8] + modl[ 3] * proj[12];
	clip[ 1] = modl[ 0] * proj[ 1] + modl[ 1] * proj[ 5] + modl[ 2] * proj[ 9] + modl[ 3] * proj[13];
	clip[ 2] = modl[ 0] * proj[ 2] + modl[ 1] * proj[ 6] + modl[ 2] * proj[10] + modl[ 3] * proj[14];
	clip[ 3] = modl[ 0] * proj[ 3] + modl[ 1] * proj[ 7] + modl[ 2] * proj[11] + modl[ 3] * proj[15];
	clip[ 4] = modl[ 4] * proj[ 0] + modl[ 5] * proj[ 4] + modl[ 6] * proj[ 8] + modl[ 7] * proj[12];
	clip[ 5] = modl[ 4] * proj[ 1] + modl[ 5] * proj[ 5] + modl[ 6] * proj[ 9] + modl[ 7] * proj[13];
	clip[ 6] = modl[ 4] * proj[ 2] + modl[ 5] * proj[ 6] + modl[ 6] * proj[10] + modl[ 7] * proj[14];
	clip[ 7] = modl[ 4] * proj[ 3] + modl[ 5] * proj[ 7] + modl[ 6] * proj[11] + modl[ 7] * proj[15];
	clip[ 8] = modl[ 8] * proj[ 0] + modl[ 9] * proj[ 4] + modl[10] * proj[ 8] + modl[11] * proj[12];
	clip[ 9] = modl[ 8] * proj[ 1] + modl[ 9] * proj[ 5] + modl[10] * proj[ 9] + modl[11] * proj[13];
	clip[10] = modl[ 8] * proj[ 2] + modl[ 9] * proj[ 6] + modl[10] * proj[10] + modl[11] * proj[14];
	clip[11] = modl[ 8] * proj[ 3] + modl[ 9] * proj[ 7] + modl[10] * proj[11] + modl[11] * proj[15];
	clip[12] = modl[12] * proj[ 0] + modl[13] * proj[ 4] + modl[14] * proj[ 8] + modl[15] * proj[12];
	clip[13] = modl[12] * proj[ 1] + modl[13] * proj[ 5] + modl[14] * proj[ 9] + modl[15] * proj[13];
	clip[14] = modl[12] * proj[ 2] + modl[13] * proj[ 6] + modl[14] * proj[10] + modl[15] * proj[14];
	clip[15] = modl[12] * proj[ 3] + modl[13] * proj[ 7] + modl[14] * proj[11] + modl[15] * proj[15];

	allocatePlanes(4);

	// RIGHT
	normal.points[0] = clip[ 3] - clip[ 0];
	normal.points[1] = clip[ 7] - clip[ 4];
	normal.points[2] = clip[11] - clip[ 8];
	d = clip[15] - clip[12];
	d /= normal.length();
	normal.unitize();
	pPlanes[0].normal = normal;
	pPlanes[0].d = d;

	// LEFT
	normal.points[0] = clip[ 3] + clip[ 0];
	normal.points[1] = clip[ 7] + clip[ 4];
	normal.points[2] = clip[11] + clip[ 8];
	d = clip[15] + clip[12];
	d /= normal.length();
	normal.unitize();
	pPlanes[1].normal = normal;
	pPlanes[1].d = d;

	// BOTTOM
	normal.points[0] = clip[ 3] + clip[ 1];
	normal.points[1] = clip[ 7] + clip[ 5];
	normal.points[2] = clip[11] + clip[ 9];
	d = clip[15] + clip[13];
	d /= normal.length();
	normal.unitize();
	pPlanes[2].normal = normal;
	pPlanes[2].d = d;

	// TOP
	normal.points[0] = clip[ 3] - clip[ 1];
	normal.points[1] = clip[ 7] - clip[ 5];
	normal.points[2] = clip[11] - clip[ 9];
	d = clip[15] - clip[13];
	d /= normal.length();
	normal.unitize();
	pPlanes[3].normal = normal;
	pPlanes[3].d = d;

	// BACK
	normal.points[0] = clip[ 3] - clip[ 2];
	normal.points[1] = clip[ 7] - clip[ 6];
	normal.points[2] = clip[11] - clip[10];
	d = clip[15] - clip[14];
	d /= normal.length();
	normal.unitize();
	backPlane.normal = normal;
	backPlane.d = d;
	
	// FRONT
	normal.points[0] = clip[ 3] + clip[ 2];
	normal.points[1] = clip[ 7] + clip[ 6];
	normal.points[2] = clip[11] + clip[10];
	d = clip[15] + clip[14];
	d /= normal.length();
	normal.unitize();
	frontPlane.normal = normal;
	frontPlane.d = d;
}
