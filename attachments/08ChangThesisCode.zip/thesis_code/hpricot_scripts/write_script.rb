# write_script

# this script is given a filename and a string
# it scans the file, seeing if the string is present
# if so, do nothing
# else, add it in

# to be used for listing urls, not data

filename = "day.list"
string = "byehello"

file = File.open(filename, File::RDWR|File::CREAT)

begin
  while (line = file.readline)
    line.chomp
    if (line == string+"\n")
      # the string is already present in the file, exit script
      file.close
      exit
    end
  end
rescue EOFError
  # reached the eof without seeing the string
  # add it in
  file.puts string
  file.close
end
