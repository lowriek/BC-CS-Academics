system('wc -l temp')
puts 'done the deed'
puts $stdout.to_s
