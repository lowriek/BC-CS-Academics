// PerspectiveViewport.cpp: implementation of the CPerspectiveViewport class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldEditor.h"
#include "PerspectiveViewport.h"
#include "AlphaEngine/AlphaConstants.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPerspectiveViewport::CPerspectiveViewport()
{

}

CPerspectiveViewport::CPerspectiveViewport(COpenGLView * parent) : CViewport(parent)
{
	RENDER_MODE = ALPHA_FILL | ALPHA_B_TX | ALPHA_D_TX;
}

CPerspectiveViewport::~CPerspectiveViewport()
{

}

void CPerspectiveViewport::Render()
{
	SetupProjection();
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	if (GetParent()->GetDocument()->pAlphaEngine)
	{
		if (GetParent()->GetDocument()->pAlphaEngine->pCamera)
		{
			GetParent()->GetDocument()->pAlphaEngine->pCamera->Look();
			GetParent()->GetDocument()->Render(RENDER_MODE);
		}
	}

	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_COLOR_MATERIAL);
}

void CPerspectiveViewport::SetupProjection()
{
	float cx = GetParent()->winWidth * perWidth;
	float cy = GetParent()->winHeight * perHeight;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0f, (cx)/(cy), 1.0f, 4096.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void CPerspectiveViewport::OnLButtonDown(UINT nFlags, CPoint point)
{
	int pickRenderMode = ALPHA_FILL;
	if (RENDER_MODE & ALPHA_WIREFRAME == ALPHA_WIREFRAME)
		pickRenderMode = ALPHA_WIREFRAME;

	if (nFlags & MK_SHIFT)
	{
		SetupProjection();
		GetParent()->GetDocument()->pAlphaEngine->pCamera->Look();
		GetParent()->GetDocument()->PickPoly(pickRenderMode, point.x, point.y);
	} else if (nFlags & MK_CONTROL)
	{
		SetupProjection();
		GetParent()->GetDocument()->pAlphaEngine->pCamera->Look();
		GetParent()->GetDocument()->PickPBrush(pickRenderMode, point.x, point.y);
	}
}