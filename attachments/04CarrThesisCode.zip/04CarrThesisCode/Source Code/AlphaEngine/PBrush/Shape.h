#ifndef _SHAPE_H_
#define _SHAPE_H_

#include "AlphaEngine/PBrush/PBrush.h"

class CShape
{
public:
	static CPBrush * createBox(float lengthX, float lengthY, float lengthZ);
	static CPBrush * createSphere(float radius, int slices, int stacks);
};

#endif