class CreateStatconcepts < ActiveRecord::Migration
  def self.up
    create_table :statconcepts do |t|
			t.column :name, :string
			t.column :abbrev, :string
			t.column :unit_id, :integer, :null => false
			t.column :sport_id, :integer, :null => false
			t.column :start, :datetime
			t.column :end, :datetime
      t.timestamps
    end
  end

  def self.down
    drop_table :statconcepts
  end
end
