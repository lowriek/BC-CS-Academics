#include "stdafx.h"
#include "OpenGLView.h"
#include "WorldEditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(COpenGLView, CView)

#ifdef _DEBUG
void COpenGLView::AssertValid() const
{
	CView::AssertValid();
}
#endif //_DEBUG

COpenGLView::COpenGLView()
{
}

COpenGLView::~COpenGLView()
{
}

#ifdef _DEBUG
void COpenGLView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

CWorldEditorDoc* COpenGLView::GetDocument()
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWorldEditorDoc)));
	return (CWorldEditorDoc*)m_pDocument;
}

BOOL COpenGLView::InitOpenGL()
{
	m_pDC = new CClientDC(this);

	if(m_pDC == NULL)
		return FALSE;

	if(!SetupPixelFormat())
		return FALSE;

	m_hRC = ::wglCreateContext(m_pDC->GetSafeHdc());

    if(m_hRC == 0)
        return FALSE;

	if(::wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC) == FALSE)
		return FALSE;

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );

	return TRUE;
}

int COpenGLView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!InitOpenGL())
	{
		MessageBox("Error setting up OpenGL!", "Init Error!", MB_OK | MB_ICONERROR);
		return -1;
	}

	return 0;	
}

void COpenGLView::OnDestroy() 
{
	CView::OnDestroy();
	
	wglMakeCurrent(0,0);
	wglDeleteContext(m_hRC);
	if( m_pDC )
	{
		delete m_pDC;
	}
	m_pDC = NULL;	
}

void COpenGLView::OnDraw(CDC* pDC)
{
	SetContext();
		Render();
	SwapGLBuffers();
}

BOOL COpenGLView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

BOOL COpenGLView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.lpszClass = ::AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC,
		::LoadCursor(NULL, IDC_ARROW), NULL, NULL);
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	
	return CView::PreCreateWindow(cs);	
}

void COpenGLView::Render()
{
	glClear(GL_COLOR_BUFFER_BIT);
}

void COpenGLView::SetContext()
{
	wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC);
}

BOOL COpenGLView::SetupPixelFormat() 
{
	static PIXELFORMATDESCRIPTOR pfd = 
	{
		sizeof(PIXELFORMATDESCRIPTOR),    // size of this pfd
		1,                                // version number
		PFD_DRAW_TO_WINDOW |              // support window
		PFD_SUPPORT_OPENGL |              // support OpenGL
		PFD_DOUBLEBUFFER,                 // double buffered
		PFD_TYPE_RGBA,                    // RGBA type
		24,                               // 32-bit color depth
		0, 0, 0, 0, 0, 0,                 // color bits ignored
		0,                                // no alpha buffer
		0,                                // shift bit ignored
		0,                                // no accumulation buffer
		0, 0, 0, 0,                       // accumulation bits ignored
		32,                               // 16-bit z-buffer
		0,                                // no stencil buffer
		0,                                // no auxiliary buffer
		PFD_MAIN_PLANE,                   // main layer
		0,                                // reserved
		0, 0, 0                           // layer masks ignored
	};

   int m_nPixelFormat = ::ChoosePixelFormat( m_pDC->GetSafeHdc(), &pfd );

    if ( m_nPixelFormat == 0 )
        return FALSE;

    return ::SetPixelFormat( m_pDC->GetSafeHdc(), m_nPixelFormat, &pfd );
}

void COpenGLView::SwapGLBuffers()
{
	SwapBuffers(m_pDC->GetSafeHdc());
}

BEGIN_MESSAGE_MAP(COpenGLView, CView)
	//{{AFX_MSG_MAP(COpenGLView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()









