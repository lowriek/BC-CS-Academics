class PortalController < ApplicationController

  #require 'rubygems' # Unless you install from the tarball or zip.
  #require 'icalendar'
  #require 'date'
  #include Icalendar # Probably do this in your class to limit namespace overlap

  before_filter :authorize

  def index
  	@currentuser = User.find_by_id(session[:user_id])
  	@myprofile = Profile.find_by_id(@currentuser.profileid)
  	#flash[:notice] = "Current user name: " + @currentuser.name.to_s + " Profile: " + @currentuser.profileid.to_s
  end
  
  def find_user_id
  	unless session[:user_id]
  		session[:user_id] = Login.login
  	end
  	session[:user_id]
  end
 
  
  def availability
    @profiles = Profile.find_available
  	@availprofiles = Profile.find_available
  	@currentuser = User.find_by_id(session[:user_id])
  end
  
  def create
	@profile = Profile.new(params[:profile])
    if @profile.save
      @user = User.find_by_id(session[:user_id])
      if @user.update_attribute(:profileid, @profile.id)
			lookup_geocode(@profile.street_address)
	      redirect_to :action => 'index'
	  else
	  	flash[:notice] = "Error updating user.  Please contact technical support."
	  	render :action => 'new'
	  end    
    else
	  flash[:notice] = "Error saving profile.  Please contact technical support."
      render :action => 'new'
    end
  end
  
  def edit_profile
  	@user = User.find_by_id(session[:user_id])
    #flash[:notice] = "User id: " + @user.id.to_s + " Profile id: " + @user.profileid.to_s	
    @profile = Profile.find_by_id(@user.profileid)
    @user.save

  end
  
   def update
    @profile = Profile.find(params[:id])
    if @profile.update_attributes(params[:profile])
      lookup_geocode(@profile.street_address)
      redirect_to :action => 'show', :id => @profile
    else
      flash[:notice] = "There was an error updating your profile."
      render :action => 'edit_profile'
    end
  end

  def show
    @profile = Profile.find(params[:id])
  end
  
  def display
  	@profile = Profile.find(params[:od])
  end
  
  def new
    @profile = Profile.new
  end
  
  def search
  end
  
  def search2first
  	@profiles = Profile.find(:all, :conditions=> params[:profile])
  end
  
  def search2last
  	@profiles = Profile.find(:all, :conditions=> params[:profile])
  end

  def lookup_geocode(address)
		@currentuser = User.find_by_id(session[:user_id])
		@myprofile = Profile.find_by_id(@currentuser.profileid)
      	geocode = get_geocode address
      
      	# geo_code is now a hash with keys :latitude and :longitude
      	# place these values back into our "database" (array of hashes)
      	@myprofile.latitude = geocode[:latitude]
      	@myprofile.longitude = geocode[:longitude]    
    	@myprofile.save

  end

  
  def show_google_map
    # all we're going to do is loop through the @places array on the page
  	  	@currentuser = User.find_by_id(session[:user_id])
  		@myprofile = Profile.find_by_id(@currentuser.profileid)
        @profiles = Profile.find_available
  end
  
  private
  def get_geocode(address)
    logger.debug 'starting geocoder call for address: '+address
    # this is where we call the geocoding web service
    server = XMLRPC::Client.new2('http://rpc.geocoder.us/service/xmlrpc')
    result = server.call2('geocode', address)
    logger.debug "Geocode call: "+result.inspect
    if result
    	return {:success=> true, :latitude=> result[1][0]['lat'], 
			:longitude=> result[1][0]['long']}
	else
		flash[:notice] = "There was an error looking up your address for GeoCoding.  Please check it."
	end			
  end  
  
end
