#ifndef _SECTORMGR_H_
#define _SECTORMGR_H_

#include "AlphaEngine/Bsp/BspNode.h"
#include "AlphaEngine/PVS/Portal.h"
#include "AlphaEngine/Math/Plane.h"
#include "AlphaEngine/PVS/Sector.h"
#include "AlphaEngine/Core/Frustum.h"

class CSectorMgr
{
public:
	CSectorMgr();
	virtual ~CSectorMgr();

	void		create(CBspNode* pBspNode);
	void		render(int flags, CFrustum* pFrustum, CVector3& location);
	bool		serialize(FILE* filePtr, bool isStoring);

private:
	void		addPortal(CPortal* pPortal, CBspNode* pBspNode);
	void		addPortalsToSectors(CPortalList* pPortalList);
	bool		checkForSinglePortal(unsigned int sectorIndex, unsigned int portalIndex);
	void		checkForSinglePortals();
	int			classifyPortal(CPolygon* pPortal, CPlane plane);
	void		clipPortalToSector(CPortal* pPortal, int side);
	CPortal*	createLargePortal(CBspNode* pBspNode);
	CPortalList* createPortalList();
	void		createSectors();
	void		findTruePortals();
	void		makePortalsInward();
	void		removeExtraPortals();
	void		renderSector(int flags, unsigned int sectorId, unsigned int prevSectorId, CFrustum* pFrustum, CVector3& location);

	CBspNode*	pBspRoot;
	CSector*	pSector;
	unsigned int numSector;	
};


#endif