#ifndef	FONT_H
#define FONT_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						FONT.H								   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	November 10, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include <windows.h>		// Header File For Windows
#include <math.h>			// Header File For Windows Math Library
#include <stdio.h>			// Header File For Standard Input/Output
#include <stdarg.h>			// Header File For Variable Argument Routines
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

class	Font
{
	private:
	
		int base;
		int pulse;
		float height;
		float width;
		char message[100][256];
		int count;
	public:
		Font(HDC h);
		Font(HDC hc, int h, int w, int ang, int oang, int fw, BYTE ital, BYTE ul, BYTE so,
			 BYTE csi, BYTE op, BYTE cp, BYTE oq, BYTE fp, LPCTSTR  fn);

		DestroyFont();	
		void FontPrint(const char *fmt, ...);
		FontFlush();
};

#endif