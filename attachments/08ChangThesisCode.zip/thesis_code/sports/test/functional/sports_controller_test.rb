require File.dirname(__FILE__) + '/../test_helper'

class SportsControllerTest < ActionController::TestCase
  def test_should_get_index
    get :index
    assert_response :success
    assert_not_nil assigns(:sports)
  end

  def test_should_get_new
    get :new
    assert_response :success
  end

  def test_should_create_sport
    assert_difference('Sport.count') do
      post :create, :sport => { }
    end

    assert_redirected_to sport_path(assigns(:sport))
  end

  def test_should_show_sport
    get :show, :id => sports(:one).id
    assert_response :success
  end

  def test_should_get_edit
    get :edit, :id => sports(:one).id
    assert_response :success
  end

  def test_should_update_sport
    put :update, :id => sports(:one).id, :sport => { }
    assert_redirected_to sport_path(assigns(:sport))
  end

  def test_should_destroy_sport
    assert_difference('Sport.count', -1) do
      delete :destroy, :id => sports(:one).id
    end

    assert_redirected_to sports_path
  end
end
