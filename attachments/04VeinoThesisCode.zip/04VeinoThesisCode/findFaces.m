function [faces,numfaces] = findFaces(faceness);
%
%
%

h = fspecial('gaussian',31,1.5);
faceness = imfilter(faceness,h);

faceness(faceness<.028)=0;
faceness(faceness>=.028)=1;
faceness = bwmorph(faceness,'clean');
faceness = bwmorph(faceness,'fill');

[faces,numfaces] = bwlabel(faceness);

[m,n] = size(faces);
counter = 1;
for I=1:numfaces
    [num, dontcare] = size(find(faces(:)==I))
    if num<250
        faces(faces==I)=0;
        numfaces=numfaces-1;
    else
        faces(faces==I)=counter;
        counter=counter+1;
    end
end
    
figure(1);imagesc(faces);