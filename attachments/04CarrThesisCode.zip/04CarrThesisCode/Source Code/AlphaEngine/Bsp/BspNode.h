#ifndef _BSPNODE_H_
#define _BSPNODE_H_

#include "AlphaEngine/Core/Camera.h"
#include "AlphaEngine/Math/BoundBox.h"
#include "AlphaEngine/Math/Plane.h"
#include "AlphaEngine/Core/Polygon.h"
#include "AlphaEngine/AlphaConstants.h"

class CBspNode {
public:
	CBspNode();
	virtual ~CBspNode();
	
	CPolygon*		clip(CPolygon* ptrPolygon, int side);
	CBspNode*		clone();
	int				create(CPolygon* ptrPolygon);
	unsigned int	getNumPartitions();
	unsigned int	getNumLeaves();
	CBspNode*		getPartitionNode(unsigned int id);
	CPolygon*		getPolygons();
	CBspNode*		getLeafNode(unsigned int id);
	CBspNode*		getLeafNode(CVector3& location);
	bool			isLeaf();
	void			render(int flags, CVector3& location);
	bool			serialize(FILE* filePtr, bool isStoring);

	unsigned int	id;
	CPlane			plane;
	CBspNode*		pFront;
	CBspNode*		pBack;
	CPolygon*		pPolygon;
	CBoundBox		boundBox;
	bool			augmented;

private:
	int				classifyPolygon(CPolygon* ptrPolygon);
	bool			selectPartition(CPolygon* ptrPolygon);
	int				createBsp(CPolygon* ptrPolygon);
	void			computeBoundBox(CPolygon* ptrPolygon);
	static unsigned int	numLeaf;
	static unsigned int	numPart;
};

#endif