#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "server.h"
#include "tracer.h"


//function definitions for the Tracer Class

Tracer::Tracer()
{
	int i,j, val;
	//set object defaults
	color1.r = 1.0;	color1.g = 1.0;	color1.b = 1.0;
	color2.r = 1.0;	color2.g = 1.0;	color2.b = 1.0;
	mirror1 = 0; mirror2 = 0;
	isTextured=0;
	reflectAmt1 = 0.0;
	reflectAmt2 = 0.0;
	refractIndex1 = 0.0;
	refractIndex2 = 0.0;
	transAmt1 = 0.0;
	transAmt2 = 0.0;

	for(i=0;i<4;i++)													/* Set all matrices to identity matrices */
		for(j=0;j<4;j++){
			if(i==j) val = 1;
			else val=0;
			
			object_rotation[i][j]=val;
			world_rotation[i][j]=val;
			translation[i][j]=val;
			scale[i][j]=val;
			compositeMatrix[i][j]=val;
			inverseCompositeMatrix[i][j]=val;
		}
	didInverse=FALSE;
	didComposite=FALSE;
	didNormal=FALSE;
}

Tracer::Tracer(color c1, int m1)
{
	color1.r = c1.r;
	color1.g = c1.g;
	color1.b = c1.b;
	mirror1 = m1;
}

void Tracer::setColor1(color c1)
{
	color1.r = c1.r;
	color1.g = c1.g;
	color1.b = c1.b;
}

void Tracer::setColor2(color c2)
{
	color2.r = c2.r;
	color2.g = c2.g;
	color2.b = c2.b;
}

void Tracer::setMirror1(int m1)
{
	mirror1 = m1;
}

void Tracer::setMirror2(int m2)
{
	mirror2 = m2;
}

void Tracer::setReflectAmt1(float ra)
{
	reflectAmt1 = ra;
}

void Tracer::setReflectAmt2(float ra)
{
	reflectAmt2 = ra;
}

void Tracer::setRefractIndex1(float ri)
{
	refractIndex1 = ri;
}

void Tracer::setRefractIndex2(float ri)
{
	refractIndex2 = ri;
}

void Tracer::setTransAmt1(float ta)
{
	transAmt1 = ta;
}

void Tracer::setTransAmt2(float ta)
{
	transAmt2 = ta;
}

void Tracer::setTXRes(int txr)
{
	TXRes = txr;
}

void Tracer::setTyRes(int tyr)
{
	TYRes = tyr;
}

color Tracer::getColor1()
{
	return color1;
}

color Tracer::getColor2()
{
	return color2;
}

int Tracer::getMirror1()
{
	return mirror1;
}

int Tracer::getMirror2()
{
	return mirror2;
}

float Tracer::getReflectAmt1()
{
	return reflectAmt1;
}

float Tracer::getReflectAmt2()
{
	return reflectAmt2;
}

float Tracer::getRefractIndex1()
{
	return refractIndex1;
}

float Tracer::getRefractIndex2()
{
	return refractIndex2;
}

float Tracer::getTransAmt1()
{
	return transAmt1;
}

float Tracer::getTransAmt2()
{
	return transAmt2;
}

int Tracer::getTXRes()
{
	return TXRes;
}

int Tracer::getTYRes()
{
	return TYRes;
}

avector Tracer::normalizeVector(avector v){
	float bigV;
	
	bigV = sqrt(pow(v.x,2) + pow(v.y,2) + pow(v.z,2));
	v.x = v.x/fabs(bigV);	
	v.y = v.y/fabs(bigV);
	v.z = v.z/fabs(bigV);
	
	return v;
}

void Tracer::setHorizontalChecks(int i){
	horizontalChecks=i;
}

void Tracer::setVerticalChecks(int i){
	verticalChecks=i;
}

int Tracer::getHorizontalChecks(){
	return horizontalChecks;
}

int Tracer::getVerticalChecks(){
	return verticalChecks;
}


//Matrix Operations Functions
void Tracer::setWorldRotationMatrix(point3d inM)
{
	float arrayX[4][4], arrayY[4][4], arrayZ[4][4];
	float arrayWR[4][4];
	double rads;
	float sum;
	int i,j,k;
	
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			arrayX[i][j] = 0;
			arrayY[i][j] = 0;
			arrayZ[i][j] = 0;
			if(i==j){
				arrayX[i][j]=1;
				arrayY[i][j]=1;
				arrayZ[i][j]=1;
			}
		}

	//X-component of rotation
	rads = (2*pi*inM.x)/360.0;
	arrayX[1][1] = cos(rads);
	arrayX[1][2] = -sin(rads);
	arrayX[2][1] = sin(rads);
	arrayX[2][2] = cos(rads);
	
	//Y-component of rotation
	rads = (2*pi*inM.y)/360.0;
	arrayY[0][0] = cos(rads);
	arrayY[0][2] = sin(rads);
	arrayY[2][0] = -sin(rads);
	arrayY[2][2] = cos(rads);
	
	//Z-component of rotation
	rads = (2*pi*inM.z)/360.0;
	arrayZ[0][0] = cos(rads);
	arrayZ[0][1] = -sin(rads);
	arrayZ[1][0] = sin(rads);
	arrayZ[1][1] = cos(rads);
	
	//Multiply the XY components together
	for(i=0; i<4; i++)
		for(j=0;j<4;j++){
			sum =0;
			for(k=0;k<4;k++)
				sum = sum + arrayX[i][k]*arrayY[k][j];
			arrayWR[i][j]=sum;
		}
	//Multiply results together with the Z Component and store in final array
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			sum=0;
			for(k=0;k<4;k++)
				sum = sum + arrayZ[i][k]*arrayWR[k][j];
			world_rotation[i][j] = sum;
		}
	//FINAL WORLD ROTATION ARRAY NOW SET	
}

void Tracer::setObjectRotationMatrix(point3d inM)
{
	float arrayX[4][4], arrayY[4][4], arrayZ[4][4];
	float arrayOR[4][4];
	double rads;
	float sum;
	int i,j,k;
	
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			arrayX[i][j] = 0;
			arrayY[i][j] = 0;
			arrayZ[i][j] = 0;
			if(i==j){
				arrayX[i][j]=1;
				arrayY[i][j]=1;
				arrayZ[i][j]=1;
			}
		}

	//X-component of rotation
	rads = (2*pi*inM.x)/360.0;
	arrayX[1][1] = cos(rads);
	arrayX[1][2] = -sin(rads);
	arrayX[2][1] = sin(rads);
	arrayX[2][2] = cos(rads);
	
	//Y-component of rotation
	rads = (2*pi*inM.y)/360.0;
	arrayY[0][0] = cos(rads);
	arrayY[0][2] = sin(rads);
	arrayY[2][0] = -sin(rads);
	arrayY[2][2] = cos(rads);
	
	//Z-component of rotation
	rads = (2*pi*inM.z)/360.0;
	arrayZ[0][0] = cos(rads);
	arrayZ[0][1] = -sin(rads);
	arrayZ[1][0] = sin(rads);
	arrayZ[1][1] = cos(rads);
	
	//Multiply the XY components together
	for(i=0; i<4; i++)
		for(j=0;j<4;j++){
			sum =0;
			for(k=0;k<4;k++)
				sum = sum + arrayX[i][k]*arrayY[k][j];
			arrayOR[i][j]=sum;
		}
	//Multiply results together with the Z Component and store in final array
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			sum=0;
			for(k=0;k<4;k++)
				sum = sum + arrayZ[i][k]*arrayOR[k][j];
			object_rotation[i][j] = sum;
		}
	//FINAL OBJECT ROTATION ARRAY NOW SET
}

void Tracer::setTranslationMatrix(point3d inM)
{
	int i,j;
	for(i=0; i<4; i++)
		for(j=0; j<4; j++){
			translation[i][j]=0;
			if(i==j) translation[i][j]=1;
		}
	
	translation[0][3] = inM.x;
	translation[1][3] = inM.y;
	translation[2][3] = inM.z;
}

void Tracer::setScaleMatrix(point3d inM)
{
	int i,j;
	for(i=0; i<4; i++)
		for(j=0; j<4; j++){
			scale[i][j]=0;
			if(i==j) scale[i][j]=1;
		}
			
	scale[0][0] = inM.x;
	scale[1][1] = inM.y;
	scale[2][2] = inM.z;
	
}

void Tracer::computeCompositeMatrix()
{
	/* This method simply combines all the transformation matrices in the following order:
			[WORLD_ROT]*[TRANSLATE]*[OBJECT_ROT]*[SCALE] = [COMPOSITE]
	
		- In other words, scale is applied first, the any object-oriented rotation, then 
			translation, then any rotation of the entire object about the world origin
	*/
	
	int i,j,k;
	float tempA1[4][4], tempA2[4][4];
	float sum;

	//Multiply world-rot and trans matrices together.
	for(i=0; i<4; i++)
		for(j=0; j<4; j++){
			sum=0.0;
			for(k=0; k<4; k++)
				sum = sum + world_rotation[i][k]*translation[k][j];
			tempA1[i][j] = sum;
		}
	
	//next multiple that with the object_rotation matrix
	for(i=0; i<4; i++)
		for(j=0; j<4; j++){
			sum=0.0;
			for(k=0; k<4; k++)
				sum = sum + tempA1[i][k]*object_rotation[k][j];
			tempA2[i][j] = sum;
		}

	//Finally multiply that be the scale matrix and store in the Composite
	for(i=0; i<4; i++)
		for(j=0; j<4; j++){
			sum=0.0;
			for(k=0; k<4; k++)
				sum = sum + tempA2[i][k]*scale[k][j];
			compositeMatrix[i][j] = sum;
		}
	//Composite Transformation matrix has now been calculated and stored	
	setDidComposite(TRUE);
}

void Tracer::setInverseCompositeMatrix(float inM[4][4])
{}

void Tracer::setTranslatedIntersection(point3d ti)
{
	translatedIntersection.x = ti.x;
	translatedIntersection.y = ti.y;
	translatedIntersection.z = ti.z;
}

void Tracer::setDidComposite(int i)
{
	if(i<=0)
		didComposite=0;
	else 
		didComposite=1;
}

void Tracer::setDidInverse(int i)
{
	if(i<=0)
		didInverse=0;
	else
		didInverse=1;
}

void Tracer::setDidNormal(int i)
{
	if(i<=0)
		didNormal=0;
	else
		didNormal=1;
}

point3d	  Tracer::getTranslatedIntersection(){  return translatedIntersection; }

int	      Tracer::getDidInverse()			 {	return didInverse;			   }
 
void Tracer::setCompositeMatrix(float inM[4][4]){
//Really a useless method, not coded
}

void Tracer::computeInverseCompositeMatrix(float from[4][4], float to[4][4]){
	float wtemp[4][8];
    float m0,m1,m2,m3,s;
    float *r0,*r1,*r2,*r3, *rtemp;

    r0 = wtemp[0];
    r1 = wtemp[1];
    r2 = wtemp[2];
    r3 = wtemp[3];
    r0[0] = from[0][0];		/* build up [A][I]	*/
    r0[1] = from[0][1];
    r0[2] = from[0][2];
    r0[3] = from[0][3];
    r0[4] = 1.0;
    r0[5] = 0.0;
    r0[6] = 0.0;
    r0[7] = 0.0;
    r1[0] = from[1][0];
    r1[1] = from[1][1];
    r1[2] = from[1][2];
    r1[3] = from[1][3];
    r1[4] = 0.0;
    r1[5] = 1.0;
    r1[6] = 0.0;
    r1[7] = 0.0;
    r2[0] = from[2][0];
    r2[1] = from[2][1];
    r2[2] = from[2][2];
    r2[3] = from[2][3];
    r2[4] = 0.0;
    r2[5] = 0.0;
    r2[6] = 1.0;
    r2[7] = 0.0;
    r3[0] = from[3][0];
    r3[1] = from[3][1];
    r3[2] = from[3][2];
    r3[3] = from[3][3];
    r3[4] = 0.0;
    r3[5] = 0.0;
    r3[6] = 0.0;
    r3[7] = 1.0;

    if (r0[0] == 0.0) {		/* swap rows if needed		*/
	if (r1[0] == 0.0) {
	    if (r2[0] == 0.0) {
		if (r3[0] == 0.0) goto singular;
		rtemp = r0; r0 = r3; r3 = rtemp;
	    }
	    else {rtemp = r0; r0 = r2; r2 = rtemp;}
	}
	else {rtemp = r0; r0 = r1; r1 = rtemp;}
    }
    m1 = r1[0]/r0[0];		/* eliminate first variable	*/
    m2 = r2[0]/r0[0];
    m3 = r3[0]/r0[0];
    s = r0[1];
    r1[1] = r1[1] - m1 * s;
    r2[1] = r2[1] - m2 * s;
    r3[1] = r3[1] - m3 * s;
    s = r0[2];
    r1[2] = r1[2] - m1 * s;
    r2[2] = r2[2] - m2 * s;
    r3[2] = r3[2] - m3 * s;
    s = r0[3];
    r1[3] = r1[3] - m1 * s;
    r2[3] = r2[3] - m2 * s;
    r3[3] = r3[3] - m3 * s;
    s = r0[4];
    if (s != 0.0) {
	r1[4] = r1[4] - m1 * s;
	r2[4] = r2[4] - m2 * s;
	r3[4] = r3[4] - m3 * s;
    }
    s = r0[5];
    if (s != 0.0) {
	r1[5] = r1[5] - m1 * s;
	r2[5] = r2[5] - m2 * s;
	r3[5] = r3[5] - m3 * s;
    }
    s = r0[6];
    if (s != 0.0) {
	r1[6] = r1[6] - m1 * s;
	r2[6] = r2[6] - m2 * s;
	r3[6] = r3[6] - m3 * s;
    }
    s = r0[7];
    if (s != 0.0) {
	r1[7] = r1[7] - m1 * s;
	r2[7] = r2[7] - m2 * s;
	r3[7] = r3[7] - m3 * s;
    }

    if (r1[1] == 0.0) {		/* swap rows if needed		*/
	if (r2[1] == 0.0) {
	    if (r3[1] == 0.0) goto singular;
	    rtemp = r1; r1 = r3; r3 = rtemp;
	}
	else {rtemp = r1; r1 = r2; r2 = rtemp;}
    }
    m2 = r2[1]/r1[1];		/* eliminate second variable	*/
    m3 = r3[1]/r1[1];
    r2[2] = r2[2] - m2 * r1[2];
    r3[2] = r3[2] - m3 * r1[2];
    r3[3] = r3[3] - m3 * r1[3];
    r2[3] = r2[3] - m2 * r1[3];
    s = r1[4];
    if (s != 0.0) {
	r2[4] = r2[4] - m2 * s;
	r3[4] = r3[4] - m3 * s;
    }
    s = r1[5];
    if (s != 0.0) {
	r2[5] = r2[5] - m2 * s;
	r3[5] = r3[5] - m3 * s;
    }
    s = r1[6];
    if (s != 0.0) {
	r2[6] = r2[6] - m2 * s;
	r3[6] = r3[6] - m3 * s;
    }
    s = r1[7];
    if (s != 0.0) {
	r2[7] = r2[7] - m2 * s;
	r3[7] = r3[7] - m3 * s;
    }

    if (r2[2] == 0.0) {		/* swap last 2 rows if needed	*/
	if (r3[2] == 0.0) goto singular;
	rtemp = r2; r2 = r3; r3 = rtemp;
    }
    m3 = r3[2]/r2[2];		/* eliminate third variable	*/
    r3[3] = r3[3] - m3 * r2[3];
    r3[4] = r3[4] - m3 * r2[4];
    r3[5] = r3[5] - m3 * r2[5];
    r3[6] = r3[6] - m3 * r2[6];
    r3[7] = r3[7] - m3 * r2[7];

    if (r3[3] == 0.0) goto singular;
    s = 1.0/r3[3];		/* now back substitute row 3	*/
    r3[4] = r3[4] * s;
    r3[5] = r3[5] * s;
    r3[6] = r3[6] * s;
    r3[7] = r3[7] * s;

    m2 = r2[3];			/* now back substitute row 2	*/
    s = 1.0/r2[2];
    r2[4] = s * (r2[4] - r3[4] * m2);
    r2[5] = s * (r2[5] - r3[5] * m2);
    r2[6] = s * (r2[6] - r3[6] * m2);
    r2[7] = s * (r2[7] - r3[7] * m2);
    m1 = r1[3];
    r1[4] = (r1[4] - r3[4] * m1);
    r1[5] = (r1[5] - r3[5] * m1);
    r1[6] = (r1[6] - r3[6] * m1);
    r1[7] = (r1[7] - r3[7] * m1);
    m0 = r0[3];
    r0[4] = (r0[4] - r3[4] * m0);
    r0[5] = (r0[5] - r3[5] * m0);
    r0[6] = (r0[6] - r3[6] * m0);
    r0[7] = (r0[7] - r3[7] * m0);

    m1 = r1[2];			/* now back substitute row 1	*/
    s = 1.0/r1[1];
    r1[4] = s * (r1[4] - r2[4] * m1);
    r1[5] = s * (r1[5] - r2[5] * m1);
    r1[6] = s * (r1[6] - r2[6] * m1);
    r1[7] = s * (r1[7] - r2[7] * m1);
    m0 = r0[2];
    r0[4] = (r0[4] - r2[4] * m0);
    r0[5] = (r0[5] - r2[5] * m0);
    r0[6] = (r0[6] - r2[6] * m0);
    r0[7] = (r0[7] - r2[7] * m0);

    m0 = r0[1];			/* now back substitute row 0	*/
    s = 1.0/r0[0];
    r0[4] = s * (r0[4] - r1[4] * m0);
    r0[5] = s * (r0[5] - r1[5] * m0);
    r0[6] = s * (r0[6] - r1[6] * m0);
    r0[7] = s * (r0[7] - r1[7] * m0);

    to[0][0] = r0[4];		/* copy results back		*/
    to[0][1] = r0[5];
    to[0][2] = r0[6];
    to[0][3] = r0[7];
    to[1][0] = r1[4];
    to[1][1] = r1[5];
    to[1][2] = r1[6];
    to[1][3] = r1[7];
    to[2][0] = r2[4];
    to[2][1] = r2[5];
    to[2][2] = r2[6];
    to[2][3] = r2[7];
    to[3][0] = r3[4];
    to[3][1] = r3[5];
    to[3][2] = r3[6];
    to[3][3] = r3[7];
    return;

singular:
    fprintf(stderr,"invertmat: singular matrix\n");
    return;

	setDidInverse(TRUE);
	//Inverse of Composite Matrix is now calculated

}


point3d Tracer::applyMatrixToPoint(point3d p, float mat[4][4]){
	point3d newP;
	float temp[4];
	float term4;

	temp[0] = p.x; temp[1] = p.y; temp[2] = p.z; temp[3] = 1;           								/* Put point in matrix */
	
	term4 = temp[0]*mat[3][0] + temp[1]*mat[3][1] + temp[2]*mat[3][2] + temp[3]*mat[3][3];				/* Determine fourth element */
	
	newP.x = (temp[0]*mat[0][0] + temp[1]*mat[0][1] + temp[2]*mat[0][2] + temp[3]*mat[0][3])/term4;		/* Calculate new point */
	newP.y = (temp[0]*mat[1][0] + temp[1]*mat[1][1] + temp[2]*mat[1][2] + temp[3]*mat[1][3])/term4;
	newP.z = (temp[0]*mat[2][0] + temp[1]*mat[2][1] + temp[2]*mat[2][2] + temp[3]*mat[2][3])/term4;
	
	return newP;																						/* Return transformed point */
}

avector Tracer::applyMatrixToVector(avector v, float mat[4][4]){
	avector newV;
	float temp[4];
	float term4;
	
	temp[0]=v.x; temp[1]=v.y; temp[2]=v.z; temp[3]=1;													/* Put vector in matrix */
	
	term4 = temp[0]*mat[3][0] + temp[1]*mat[3][1] + temp[2]*mat[3][2] + temp[3]*mat[3][3];				/* Determine fourth element */

	newV.x = (temp[0]*mat[0][0] + temp[1]*mat[0][1] + temp[2]*mat[0][2] + temp[3]*mat[0][3])/term4;		/* Calculate new vector */
	newV.y = (temp[0]*mat[1][0] + temp[1]*mat[1][1] + temp[2]*mat[1][2] + temp[3]*mat[1][3])/term4;
	newV.z = (temp[0]*mat[2][0] + temp[1]*mat[2][1] + temp[2]*mat[2][2] + temp[3]*mat[2][3])/term4;
	
	return newV;																						/* Return transformed vector */

}


color Tracer::getIlluminatedColor(point3d light){
	color baseColor;
	int baseMirror;
	float baseReflectAmt, baseRefractAmt, baseTransAmt;
	
	baseColor = whichColor();															//Determine which color and mirror value (1 or 2) 
	if(baseColor.r==color1.r && baseColor.g == color1.g && baseColor.b==color1.b)		//First Components
	{
		baseMirror=mirror1;
		baseReflectAmt=reflectAmt1;
		baseRefractAmt=refractIndex1;
		baseTransAmt=transAmt1;
	}
	else{																				//Second Components
		baseMirror=mirror2;
		baseReflectAmt=reflectAmt2;
		baseRefractAmt=refractIndex2;
		baseTransAmt=transAmt2;
	}
		
	if(isTextured==1){
		baseColor = getTexturePixel();											//If texture-mapping is enabled determine which pixel
		baseMirror=mirror1;
		baseReflectAmt=reflectAmt1;
		baseRefractAmt=refractIndex1;
		baseTransAmt=transAmt1;
	}  //  End of Texture Mapping portion
																				//Once object's baseColor and baseMirror values have been determined
																				//  for the intersection point, begin calculations for mirroring,
																				//  transparency(therefore refraction if any), fog, shadowing, and
																				//  ambient lighting values if any of these apply or are enabled
	
	
	if(baseMirror==1){															//If mirroring is enabled on this point on the object
		ray reflectedRay;
		avector incomingVector, sNormalVector, reflectedVector;					//Compute relfected vector
		
		incomingVector.x = inRay.p0.x - inRay.p1.x;								//Generate incident vector (flipped from incoming vector)
		incomingVector.y = inRay.p0.y - inRay.p1.y;
		incomingVector.z = inRay.p0.z - inRay.p1.z;
		
		sNormalVector = getNormal();											//Get the surface Normal vector for the intersection point
		
		incomingVector = normalizeVector(incomingVector);						//Normalize incident vector with baseclass method
		sNormalVector =	normalizeVector(sNormalVector);							//Normalize surface normal vector with baseclass method
				
																				//Calculate relfected vector using:
					 															//     2(n.l)n - 1    (where l=incoming vector, n=surface normal)
		float dotp = (sNormalVector.x*incomingVector.x) +
					 (sNormalVector.y*incomingVector.y) +
					 (sNormalVector.z*incomingVector.z);
		
		dotp = dotp * 2.0;
		
		sNormalVector.x = sNormalVector.x * dotp;
		sNormalVector.y = sNormalVector.y * dotp;
		sNormalVector.z = sNormalVector.z * dotp;
		
		reflectedVector.x = sNormalVector.x - incomingVector.x;
		reflectedVector.y = sNormalVector.y - incomingVector.y;
		reflectedVector.z = sNormalVector.z - incomingVector.z;
		
		reflectedRay.p0.x = intersection.x;										//Assemble the new ray along the reflected ray
		reflectedRay.p0.y = intersection.y;								
		reflectedRay.p0.z = intersection.z;
		reflectedRay.p1.x = intersection.x + reflectedVector.x;					//Add the reflected vector to the first point in the new ray
		reflectedRay.p1.y = intersection.y + reflectedVector.y;					//  to get the second point along the ray
		reflectedRay.p1.z = intersection.z + reflectedVector.z;
		reflectedRay.rIndex=RINDEX_AIR;
	
		color reflectedColor = fireRay(reflectedRay);							//Fire this reflected ray at the scene, and the color that is 
																				//  returned gets factored into the base color of the object
																				//  at this point proportionally to the reflection value
																				//  of this object
		
		baseColor.r = (reflectedColor.r*baseReflectAmt) + baseColor.r*(1-baseReflectAmt);
		baseColor.g = (reflectedColor.g*baseReflectAmt) + baseColor.g*(1-baseReflectAmt);
		baseColor.b = (reflectedColor.b*baseReflectAmt) + baseColor.b*(1-baseReflectAmt);
		
	}  // End of Mirroring/Reflection Portion
	
	if(baseTransAmt > 0.0){																//Now, if the object has any transparency compute the vector for
		avector T, N, I, Ineg;														//  the refracted ray and fire that ray at the scene
		float Nit, Ni, Nt, Ci, temp;
			
		if(inRay.rIndex==RINDEX_AIR){												//Set the proper refraction indexs for medium being left(Ni)
			Ni = inRay.rIndex;														//  and the medium being entered(Nt)
			Nt = baseRefractAmt;												
			N = getNormal();														//Get Surface Normal vector
			N = normalizeVector(N);													//Normalize the vector
		}																			//Right now only supports Air-into-Object, and Object-into-Air
		else{																		//   refraction, not Object-into-Object refraction
			Ni = baseRefractAmt;
			Nt = RINDEX_AIR;	
			N = getNormal();														//get the surface normal vector
			N.x = -N.x;													
			N.y = -N.y;																//Reverse the surface Normal
			N.z = -N.z;														
			N = normalizeVector(N);													//Normalize the vector
		}
		
		Nit = Ni/Nt;																//Compute the ratio of index	
		
		I.x = inRay.p1.x - inRay.p0.x;												//Compute the Incident vector
		I.y = inRay.p1.y - inRay.p0.y;
		I.z = inRay.p1.z - inRay.p0.z;
		I = normalizeVector(I);														//Normalize the vector
		
		Ineg.x = inRay.p0.x - inRay.p1.x;											//Compute the negative incident vector for the dot product in the
		Ineg.y = inRay.p0.y - inRay.p1.y;											//  computation we are going to be doing
		Ineg.z = inRay.p0.z - inRay.p1.z;
		Ineg = normalizeVector(Ineg);												//Normalize the vector
		
		
		Ci = (N.x*Ineg.x) + (N.y*Ineg.y) + (N.z*Ineg.z);							//Compute the dot product (-I.N)
			
		temp = 1 + (Power(Nit,2))*((Power(Ci,2))-1);								//Compute what is under the radical first
		if(temp < 0.0){																//If its negative, then Total-Internal-Reflection is occuring
			color TIR;																//  and no light will be reflected, so just modify the basecolor
			TIR.r = 0.0; TIR.g = 0.0;  TIR.b=0.0;									//  proportionally with black
			
			baseColor.r = (TIR.r*baseTransAmt) + baseColor.r*(1-baseTransAmt);
			baseColor.g = (TIR.g*baseTransAmt) + baseColor.g*(1-baseTransAmt);
			baseColor.b = (TIR.b*baseTransAmt) + baseColor.b*(1-baseTransAmt);						

		}
		else{
			temp = -SQRT(temp);														//perform the square root, make it negative
			temp = (Nit*Ci) + temp;
			N.x = N.x * temp;														//Apply this to the Surface Normal Vector
			N.y = N.y * temp;
			N.z = N.z * temp;
		
			I.x = I.x * Nit;														//Apply Nit to Incident Vector;
			I.y = I.y * Nit;
			I.z = I.z * Nit;
		
			T.x = N.x + I.x;														//Compute Transmitted vector
			T.y = N.y + I.y;
			T.z = N.z + I.z;		
			T = normalizeVector(T);													//Normalize the new trasmitted vector
				
			ray newRay;																//Create and assemble new ray along transmitted vector
			newRay.rIndex = baseRefractAmt;
			newRay.p0.x = intersection.x;
			newRay.p0.y = intersection.y;
			newRay.p0.z = intersection.z;
			newRay.p1.x = intersection.x + T.x;
			newRay.p1.y = intersection.y + T.y;
			newRay.p1.z = intersection.z + T.z;
		
			color newColor = fireRay(newRay);										//Fire new ray at the scene, and get returned color.
																		
			baseColor.r = (newColor.r*baseTransAmt) + baseColor.r*(1-baseTransAmt);			//Modify base color with new color, proportionally to the
			baseColor.g = (newColor.g*baseTransAmt) + baseColor.g*(1-baseTransAmt); 		//  amount of transparency in the object
			baseColor.b = (newColor.b*baseTransAmt) + baseColor.b*(1-baseTransAmt);
		}
	}  //  End of Transparency/Refraction Portion
	
	if(baseMirror==0){																//Include this line to disable illumination model
																					//  when object is at all mirrored
	avector lightVector, surfaceNormal;												//Compute lambertian illumination for intersection point
	lightVector.x = light.x - intersection.x;										//Initialize light vector
	lightVector.y = light.y - intersection.y;
	lightVector.z = light.z - intersection.z;
	lightVector = normalizeVector(lightVector);										//Normalize light vector													
	
	surfaceNormal = getNormal();													//Get surface normal
	surfaceNormal = normalizeVector(surfaceNormal);									//Normalize the surfaceNormal
	
	float V1 = (sqrt(pow(lightVector.x,2) + pow(lightVector.y, 2) + pow(lightVector.z, 2)));
	float V2 = (sqrt(pow(surfaceNormal.x,2) + pow(surfaceNormal.y, 2) + pow(surfaceNormal.z, 2)));
	float cTheta;
	cTheta = ( ((lightVector.x * surfaceNormal.x)/fabs(V1*V2)) +						//Compute the dot product of two vectors	
			   ((lightVector.y * surfaceNormal.y)/fabs(V1*V2)) +
			   ((lightVector.z * surfaceNormal.z)/fabs(V1*V2)));
	if(cTheta < 0) cTheta=0;
	
	baseColor.r = baseColor.r * (AMBIENT + cTheta * (1.0-AMBIENT));					//Apply illumination to base color
	baseColor.g = baseColor.g * (AMBIENT + cTheta * (1.0-AMBIENT));
	baseColor.b = baseColor.b * (AMBIENT + cTheta * (1.0-AMBIENT));			  
	}																				//Include this line to disable illumination model
																					//when object is at all mirrored

	if(CAST_SHADOWS==1){
		int shadows = inShadow(light);												//Call function to fire shadow rays to test if in shadows
		if(shadows==1){																//if so, alter the color by a proportional factor
			baseColor.r = baseColor.r * SHADOW_FACTOR;
			baseColor.g = baseColor.g * SHADOW_FACTOR;
			baseColor.b = baseColor.b * SHADOW_FACTOR;
		}
	}  //  End of Shadow Casting Protion
	
	if(ENABLE_FOG==1){
		float dist;
																			
		dist = SQRT(Power(intersection.x - inRay.p1.x,2)+ 							//compute the distance of the intersection point to the point
					Power(intersection.y - inRay.p1.y,2)+ 							// of the ray that lies on the screen (z=0);
					Power(intersection.z - inRay.p1.z,2));
		
		if(dist>fog_min_dist){														//Far enough to be affected by fog at all?
			float fogval;
			fogval = (dist - fog_min_dist) / (fog_max_dist-fog_min_dist);
			if(fogval > 1.0) fogval=1.0;											//Make sure no value greater than 1. If so set to 1.0
			baseColor.r = (fog_color.r*fogval) + baseColor.r*(1-fogval);
			baseColor.g = (fog_color.g*fogval) + baseColor.g*(1-fogval);
			baseColor.b = (fog_color.b*fogval) + baseColor.b*(1-fogval);
		}
	}  //  End of Fog Effects Portion
	
	return baseColor;
}
