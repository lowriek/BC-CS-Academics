class CreateProfiles < ActiveRecord::Migration
  def self.up
    create_table :profiles do |t|
      t.column :first_name, 	:string
      t.column :last_name, 		:string
      t.column :phone_number, 	:string
      t.column :email,			:string
    end
  end

  def self.down
    drop_table :profiles
  end
end
