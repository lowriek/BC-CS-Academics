#include "Vector3.h"
#include "Math.h"

// static variables
const CVector3 CVector3::ZERO(0.0f,0.0f,0.0f);
const CVector3 CVector3::UNIT_X(1.0f,0.0f,0.0f);
const CVector3 CVector3::UNIT_Y(0.0f,1.0f,0.0f);
const CVector3 CVector3::UNIT_Z(0.0f,0.0f,1.0f);

float CVector3::FUZZ = 0.0f;
//////////////////////////////////////////////////////////////////////////////
float& CVector3::operator[] (int i) const
{
    return ((float*)points)[i];
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::cross (const CVector3& rVector) const
{
	float x, y, z;
	// x = y1 * z2 - z1 * y2
	x = points[1] * rVector.points[2] - points[2] * rVector.points[1];
	// y = z1 * x2 - x1 * z2
	y = points[2] * rVector.points[0] - points[0] * rVector.points[2];
	// z = x1 * y2 - y1*x2
	z = points[0] * rVector.points[1] - points[1] * rVector.points[0];
    return CVector3(x,y,z);
}
//////////////////////////////////////////////////////////////////////////////
float CVector3::dot (const CVector3& rVector) const
{
    return points[0] * rVector.points[0] + points[1] * rVector.points[1] + points[2] * rVector.points[2];
}
//////////////////////////////////////////////////////////////////////////////
float CVector3::length () const
{
    return CMath::Sqrt(points[0] * points[0] + points[1] * points[1] + points[2] * points[2]);
}
//////////////////////////////////////////////////////////////////////////////
bool CVector3::operator!= (const CVector3& rVector) const
{
    if ( FUZZ == 0.0f )
    {
        return points[0] != rVector.points[0] || points[1] != rVector.points[1] || points[2] != rVector.points[2];
    }
    else
    {
        return CMath::FAbs(points[0] - rVector.points[0]) > FUZZ
            || CMath::FAbs(points[1] - rVector.points[1]) > FUZZ
            || CMath::FAbs(points[2] - rVector.points[2]) > FUZZ;
    }
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::operator* (float fScalar) const
{
    return CVector3(fScalar*points[0],fScalar*points[1],fScalar*points[2]);
}
//////////////////////////////////////////////////////////////////////////////
CVector3& CVector3::operator*= (float fScalar)
{
    points[0] *= fScalar;
    points[0] *= fScalar;
    points[0] *= fScalar;
    return *this;
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::operator+ (const CVector3& rVector) const
{
    return CVector3(points[0]+rVector.points[0],points[1]+rVector.points[1],points[2]+rVector.points[2]);
}
//////////////////////////////////////////////////////////////////////////////
CVector3& CVector3::operator+= (const CVector3& rVector)
{
    points[0] += rVector.points[0];
    points[1] += rVector.points[1];
    points[2] += rVector.points[2];
    return *this;
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::operator- () const
{
    return CVector3(-points[0],-points[1],-points[2]);
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::operator- (const CVector3& rVector) const
{
    return CVector3(points[0]-rVector.points[0],points[1]-rVector.points[1],points[2]-rVector.points[2]);
}
//////////////////////////////////////////////////////////////////////////////
CVector3& CVector3::operator-= (const CVector3& rVector)
{
    points[0] -= rVector.points[0];
    points[1] -= rVector.points[1];
    points[2] -= rVector.points[2];
    return *this;
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::operator/ (float fScalar) const
{
    CVector3 kQuot;

    if ( fScalar != 0.0f )
    {
        float fInvScalar = 1.0f/fScalar;
        kQuot.points[0] = fInvScalar*points[0];
        kQuot.points[1] = fInvScalar*points[1];
        kQuot.points[2] = fInvScalar*points[2];
        return kQuot;
    }
    else
    {
        return CVector3(0.0f, 0.0f, 0.0f);
    }
}
//////////////////////////////////////////////////////////////////////////////
CVector3& CVector3::operator/= (float fScalar)
{
    if ( fScalar != 0.0f )
    {
        float fInvScalar = 1.0f/fScalar;
        points[0] *= fInvScalar;
        points[1] *= fInvScalar;
        points[2] *= fInvScalar;
    }
    else
    {
        points[0] = 0;
        points[1] = 0;
        points[2] = 0;
    }

    return *this;
}
//////////////////////////////////////////////////////////////////////////////
CVector3& CVector3::operator= (const CVector3& rVector)
{
    points[0] = rVector.points[0];
    points[1] = rVector.points[1];
    points[2] = rVector.points[2];
    return *this;
}
//////////////////////////////////////////////////////////////////////////////
bool CVector3::operator== (const CVector3& rVector) const
{
	return CMath::FAbs(points[0] - rVector.points[0]) <= FUZZ
		&& CMath::FAbs(points[1] - rVector.points[1]) <= FUZZ
        && CMath::FAbs(points[2] - rVector.points[2]) <= FUZZ;
}
//////////////////////////////////////////////////////////////////////////////
float CVector3::squaredLength () const
{
    return points[0]*points[0] + points[1]*points[1] + points[2]*points[2];
}
//////////////////////////////////////////////////////////////////////////////
CVector3 CVector3::unitCross (const CVector3& rVector) const
{
    CVector3 kCross(points[1]*rVector.points[2]-points[2]*rVector.points[1],points[2]*rVector.points[0]-points[0]*rVector.points[2],
        points[0]*rVector.points[1]-points[1]*rVector.points[0]);
    kCross.unitize();
    return kCross;
}
//////////////////////////////////////////////////////////////////////////////
float CVector3::unitize (float fTolerance)
{
    float fLength = length();

    if ( fLength > fTolerance )
    {
        float fInvLength = 1.0f/fLength;
        points[0] *= fInvLength;
        points[1] *= fInvLength;
        points[2] *= fInvLength;
    }
    else
    {
        fLength = 0.0f;
    }

    return fLength;
}
//////////////////////////////////////////////////////////////////////////////
CVector3::CVector3 (float tPoints[3])
{
    points[0] = tPoints[0];
    points[1] = tPoints[1];
    points[2] = tPoints[2];
}
//////////////////////////////////////////////////////////////////////////////
CVector3::CVector3 (float tX, float tY, float tZ)
{
    points[0] = tX;
    points[1] = tY;
    points[2] = tZ;
}
//////////////////////////////////////////////////////////////////////////////
CVector3::CVector3 (const CVector3& rVector)
{
    points[0] = rVector.points[0];
    points[1] = rVector.points[1];
    points[2] = rVector.points[2];
}
//////////////////////////////////////////////////////////////////////////////
CVector3::CVector3 ()
{ 
	points[0] = 0; points[1]=0; points[2]=0;
}

bool CVector3::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&points[0], sizeof(float), 1, filePtr);
		fwrite(&points[1], sizeof(float), 1, filePtr);
		fwrite(&points[2], sizeof(float), 1, filePtr);
	}
	else
	{
		fread(&points[0], sizeof(float), 1, filePtr);
		fread(&points[1], sizeof(float), 1, filePtr);
		fread(&points[2], sizeof(float), 1, filePtr);
	}
	return true;
}