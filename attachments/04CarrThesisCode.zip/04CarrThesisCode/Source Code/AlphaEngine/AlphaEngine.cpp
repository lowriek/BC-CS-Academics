#include "AlphaEngine.h"

CAlphaEngine::CAlphaEngine()
{
	pBrushMgr =0;
	pBspRoot = 0;
	pCamera = 0;
	pTextureMgr = 0;
	pSectorMgr = 0;
}

CAlphaEngine::~CAlphaEngine()
{
	shutdown();
	CBaseObjectMgr::shutdown();
}

bool CAlphaEngine::createBsp()
{
	if (pBspRoot)
		delete pBspRoot;

	pBspRoot = new CBspNode();

	int retval = pBspRoot->create(pBrushMgr->getPolygons());
	if (retval == 0)
		return true;
	else
		return false;
}

bool CAlphaEngine::createPvs()
{
	if (!createBsp())
		return false;
	
	if (pSectorMgr)
		delete pSectorMgr;

	pSectorMgr = new CSectorMgr();

	pSectorMgr->create(pBspRoot->clone());

	return true;
}

bool CAlphaEngine::init()
{
	if (!Render::init())
		return false;

	pBrushMgr = new CPBrushMgr();
	pCamera = new CCamera();
	pTextureMgr = new CTextureMgr();
	pBspRoot = new CBspNode();
	pSectorMgr = new CSectorMgr();

	CBaseObjectMgr::getInstance();
	

	numBspFace = 0;
	numBspNode = 0;
	return true;
}

void CAlphaEngine::render(int flag1, int flag2)
{
	if ((flag1 & ALPHA_RENDER_BRUSH) == ALPHA_RENDER_BRUSH)
	{
		if (pBrushMgr)
			pBrushMgr->render(flag2);
	}
	else if ((flag1 & ALPHA_RENDER_CSG) == ALPHA_RENDER_CSG)
	{
		if ((flag2 & ALPHA_WIREFRAME) == ALPHA_WIREFRAME)
			glColor3f(0, 0.5f, 0.25f);
		else
			glColor3f(1,1,1);

		flag2 = flag2 | ALPHA_TRANSPARENT;

		if (pBspRoot)
			pBspRoot->render(flag2, pCamera->position);

	} else if ((flag1 & ALPHA_RENDER_FINAL) == ALPHA_RENDER_FINAL)
	{
		// render in portal mode
		glColor3f(1, 0, 0);
		if (pSectorMgr)
			pSectorMgr->render(flag2, pCamera->pFrustum, pCamera->position);

		glColor3f(1,1,1);
	}
}

bool CAlphaEngine::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (!isStoring)
	{
		if (pBrushMgr)
			delete pBrushMgr;
		
		if (pBspRoot)
			delete pBspRoot;

		if (pSectorMgr)
			delete pSectorMgr;

		pBrushMgr = new CPBrushMgr();
		pBspRoot = new CBspNode();
		pSectorMgr = new CSectorMgr();
	}

	if (!pBrushMgr->serialize(filePtr, isStoring))
		return false;
	
	if (!pBspRoot->serialize(filePtr, isStoring))
		return false;

	if (!pSectorMgr->serialize(filePtr, isStoring))
		return false;

	if (!CBaseObjectMgr::serialize(filePtr, isStoring))
		return false;

	return true;
}

void CAlphaEngine::shutdown()
{
	if (pBrushMgr)
		delete pBrushMgr;

	if (pBspRoot)
		delete pBspRoot;

	if (pCamera)
		delete pCamera;

	if (pTextureMgr)
		delete pTextureMgr;

	if (pSectorMgr)
		delete pSectorMgr;

	pBrushMgr = 0;
	pBspRoot = 0;
	pCamera = 0;
	pTextureMgr = 0;
	pSectorMgr = 0;

	Render::shutdown();
	CBaseObjectMgr::shutdown();
}