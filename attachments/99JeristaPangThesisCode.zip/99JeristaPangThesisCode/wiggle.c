/**
  * Joseph Jerista and Yun Pang
  * Hidden Surface Removal/Occlusion Algorithm with OpenGL
  * Latest revision: 05/06/99
  */



#include <windows.h>		//Standard Windows include
#include <gl\gl.h>			//OpenGL Library
#include <gl\glu.h>			// GLU library
#include "resource.h"		// About box resource identifiers.

#include "world.h"          // contains movement functions, among other 
                            // user-defined externs


#include <stdlib.h>
#include <stdio.h>
#include <iostream.h> 
#include <math.h>
#include <time.h>

#define GL_PI 3.1415f
#define D_WIDTH 640 
#define D_HEIGHT 480
#define NUM_POLYS 48   //number of polygons per leaf

GLdouble eye2x, eye2y, eye2z; //eyept projected onto screen
GLdouble intersectx, intersecty, intersectz;
GLdouble x2,y2,z2;
GLdouble x3=0.0,y3=1.0,z3=0.0;
GLdouble vertAngle;
GLdouble objx, objy, objz;

GLint toggle=GL_TRUE, toggle2=GL_FALSE, toggle3=GL_FALSE;
GLint flip=GL_TRUE;
GLint toggle_average=GL_FALSE;
GLint dump_to_file=GL_FALSE;
GLint timer1=0, timer2=0;
GLint result, leafCountOld = 0;

//to hold clock information plus debugging material
char timer_string[80];
char intersection_string[120];

//Initialize square position and size 
GLfloat xCoord1 = 100.0f;
GLfloat yCoord1 = 150.0f;
GLsizei rsize = 50;

//Step size in x and y directions
//(Number of pixels to move each time)
GLfloat xstep = 1.0f;
GLfloat ystep = 1.0f;
 
//Keep track of window's changing width and height
GLfloat windowWidth;
GLfloat windowHeight;

//for lighting
//GLfloat model_ambient[] = {.75 ,.75 ,.75 , 0.0}; 
//GLfloat light_pos[] = { 1.0, 1.0, 1.0, 0.0};
//GLfloat mat_sp[] = { 1.0, 1.0, 1.0, 1.0 };
//GLfloat mat_sh[] = { 50.0 };

float viewAngle;
GLdouble eyex,eyey,eyez;

//char screen_coord_string[30];
GLdouble screenx=0.0, screeny=0.0, screenz=0.0;


octnode *root;  //"head" of octree   
point p;

int dump_coord=0;

int leafCount=0;
float avgLeafCount=0;
float avgPolyCount=0;
float avgFPS=0;
int num_iterations=0;

int dumpcount=0;
int numRays=0;
 static FILE *dumpfile;

static HINSTANCE hInstance;

// Dialog procedure for about box
BOOL APIENTRY AboutDlgProc (HWND hDlg, UINT message, UINT wParam, LONG lParam);

//Check and display Opengl Errors

void checkErrors(void)
{
   GLenum errCode;
   const GLubyte *errString;
   if((errCode = glGetError()) != GL_NO_ERROR) 
   {
      errString = gluErrorString(errCode);
   }
}

static void init(void)
{

   static int first = 1;

   glClearColor(0.0, 0.0, 0.0, 1.0);

   eyex=0;
   eyey=0;
   eyez=1.0;

   //4.7 because then origin is visible at start
   viewAngle=4.7f;
   //vertAngle=1.5;   
   vertAngle=0.0;

	if (first) {
		first = 0;
		dumpfile = fopen("dump.txt", "w");
	}

   glShadeModel(GL_SMOOTH);
   
   glMatrixMode(GL_MODELVIEW);
   glEnable(GL_DEPTH_TEST);

   //initialize point p to be center of universe.. 0,0,0
   p.x = 0;    p.y = 0;    p.z = 0;
   root = (octnode *)malloc(sizeof(octnode));
   mallocTree(root, LEVELS);
   fillCoords(root, VALUE, LEVELS, p);
   //dumpTree(root, LEVELS);
   glLoadIdentity();  
   //Lighting code
/*
   glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   glShadeModel(GL_SMOOTH);
   glMaterialfv(GL_FRONT,GL_SPECULAR, mat_sp);
   glMaterialfv(GL_FRONT,GL_SHININESS, mat_sh);
*/
}


void vectorLine(GLdouble P1x, GLdouble P1y, GLdouble P1z, 
				GLdouble P2x, GLdouble P2y, GLdouble P2z,
				GLdouble *Ax,GLdouble *Ay,GLdouble *Az)

{
	*Ax=P2x-P1x;
	*Ay=P2y-P1y;
	*Az=P2z-P1z;
}

int intersectionPlaneLine(GLdouble A, GLdouble B, GLdouble C, GLdouble D,
						  GLdouble Px, GLdouble Py, GLdouble Pz,
						  GLdouble Ax, GLdouble Ay, GLdouble Az,
						  GLdouble *x, GLdouble *y, GLdouble *z)

// returns a 1 for an intersection
//           0 for line in same plane 
//           -1 for no intersection  
{
	GLdouble valTotal, tTotal, t;

	valTotal=-1*(A*Px+B*Py+C*Pz+D);
	tTotal=A*Ax+B*Ay+C*Az;

	if( ((valTotal<0.001) && (valTotal>-0.001)) 
		&&((tTotal<0.001) && (tTotal>-0.001)) )
		return 0;
		else if ((tTotal<0.001) && (tTotal>-0.001))  		
			return -1;
		else
			
		{
			t=valTotal/tTotal;

			if (t<0)
				return -1;

			*x=Px+Ax*t;
			*y=Py+Ay*t;
			*z=Pz+Az*t;

			return 1;
		}
	

}

//int testCubeVerticies(GLdouble vertexPts[8][3])  //STEP 1
int testCubeVerticies(octnode *current)  //STEP 1
// returns visibility for cube
// 0 for not visible
// 1 for partially visible
// 2 for fully visible
{

	int match=0, i, x;
	int intersect = GL_FALSE;

   GLint viewport[4];
   GLdouble mvmatrix[16];
   GLdouble projmatrix[16];

   GLdouble A1x, A1y, A1z, A2x, A2y, A2z;

   float dotValue;

   glGetIntegerv(GL_VIEWPORT, viewport);
   glGetDoublev(GL_MODELVIEW_MATRIX, mvmatrix);
   glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
 
   gluUnProject(windowWidth/2, windowHeight/2, 0.0, mvmatrix, projmatrix, viewport, &eye2x, &eye2y, &eye2z);
/*
   eye2x=x2;
   eye2y=y2;
   eye2z=z2;
*/
   vectorLine(eyex, eyey, eyez, eye2x, eye2y, eye2z, &A1x, &A1y, &A1z);

  // gluUnProject(windowWidth/2, windowHeight/2, 0.0, mvmatrix, projmatrix, viewport, &eye2x, &eye2y, &eye2z);

  // vectorLine(eye2x, eye2y, eye2z, objx, objy, objz, &A1x, &A1y, &A1z);

/*
   gluProject(20.0, 20.0, -20.0, mvmatrix, projmatrix, viewport, &screenx, &screeny, &screenz);  

   		   if (dump_coord == 1)
		
		   {
				fprintf(dumpfile, "screenWidth %1.3f screenHeight %1.3f \n", windowWidth, windowHeight);
					fprintf(dumpfile, "(20, 20, -20) map to (%1.3f,%1.3f) \n", screenx, screeny);
		   }
		   */
		   
   for(i=0; i<8; i++)
   {
	   //gluProject(vertexPts[i][0], vertexPts[i][1], vertexPts[i][2], mvmatrix, projmatrix, viewport, &screenx, &screeny, &screenz);
	   
	  
	   vectorLine(eyex, eyey, eyez, current->bb[i].x, current->bb[i].y, current->bb[i].z, &A2x, &A2y, &A2z);

	   //vectorLine(eye2x, eye2y, eye2z, current->bb[i].x, current->bb[i].y, current->bb[i].z, &A2x, &A2y, &A2z);
		   if (dump_coord == 1)
		
		   {
				fprintf(dumpfile, "i: %d match: %d\n", i, match);
		   }

		   
		dotValue=(float) ((A1x*A2x)+(A1y*A2y)+(A1z*A2z));

	   if (dotValue>=0)  //i.e. it's in front of the screen
	   {



	   intersect = gluProject(current->bb[i].x, current->bb[i].y, current->bb[i].z, mvmatrix, projmatrix, viewport, &screenx, &screeny, &screenz);  
	   //test to see if vertex appears on the screen...	   

	   }   		   

		   	  
	   //if((screenx>0 && screenx<windowWidth) && (screeny>0 && screeny<windowHeight))

	   	
	  // if((intersect == GL_TRUE)&&(screenx>0 && screenx<windowWidth) && (screeny>0 && screeny<windowHeight))
	   if((dotValue>0)&&(screenx>0 && screenx<windowWidth) && (screeny>0 && screeny<windowHeight))
	   {
		   if ((i==7)&&(match==0)) //last one matched and no match before then it's a partial 
			   return 1;

		   match++;
		   
		   if (dump_coord == 1)
		
		   {
				fprintf(dumpfile, "match %d intersect: %d  object (%d, %d, %d) maps to  %1.3f %1.3f \n", match, intersect, current->bb[i].x, current->bb[i].y, 
					current->bb[i].z, screenx, screeny);
		   }
		   
	   }
	   else if (match>0) //if it's not on the screen and we already have a visible vertex then volume is  partially visible
	   {
		   
		   if (dump_coord == 1)
		
		   {
				fprintf(dumpfile, "partial match: %d didn't match\n", match+1);
							for(x=0;x<8;x++)
			{
			  fprintf(dumpfile,"x %d y %d z %d        ", current->bb[x].x,current->bb[x].y,current->bb[x].z);
			  
			  if((x%2)==1)
                fprintf(dumpfile,"\n");

			}
	  

	   
		   }


		   return 1;
	   
	   }

   
	   


   }

   if (match==0) //if not visible at all
	   return 0;
   else 
   {
	   		   if (dump_coord == 1)
		
		   {
				fprintf(dumpfile, "fully visible: %d match\n", match);
			   }
	   return 2; //fully visible
   }
}


int testScreenCorners(octnode *root)  //STEP 2
// returns 1 for partially visible
//         0 for not visible 
{


	int match=0, i;
   GLint viewport[4];
   GLdouble mvmatrix[16];
   GLdouble projmatrix[16];
   int intersect;

   GLdouble Ax, Ay, Az, x, y, z; //Axyz are vectors of the eyept corner line, xyz are the points of intersection w/ cube plane

   

   glGetIntegerv(GL_VIEWPORT, viewport);
   glGetDoublev(GL_MODELVIEW_MATRIX, mvmatrix);
   glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
 

   for(i=0; i<4; i++)
   {

	   switch(i)
	   {
	   case 0:
		   gluUnProject(0.0, 0.0, 0.0, mvmatrix, projmatrix, viewport, &objx, &objy, &objz); //lower left corner
		   break;
	   case 1:
		   gluUnProject(0.0, windowHeight, 0.0, mvmatrix, projmatrix, viewport, &objx, &objy, &objz); //upper left corner
		   break;
	   case 2:
		   gluUnProject(windowWidth, 0.0, 0.0, mvmatrix, projmatrix, viewport, &objx, &objy, &objz); //lower right corner
		   break;
	   case 3:
		   gluUnProject(windowWidth, windowHeight, 0.0, mvmatrix, projmatrix, viewport, &objx, &objy, &objz); //upper right corner
		   break;
	   }
   

   vectorLine(eyex, eyey, eyez, objx, objy, objz, &Ax, &Ay, &Az);
/*
   if (dump_coord == 1)
	   fprintf(dumpfile,"Object x %1.3lf, Object y %1.3lf, Object z %1.3lf Ax %1.3lf Ay %1.3lf, Az %1.3lf\n", \
		                objx, objy, objz, Ax, Ay, Az);

*/





//   intersect=intersectionPlaneLine(1.0, 0.0, 0.0, (GLdouble)((-1.0)*(root->bb[0].x)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);

     intersect=intersectionPlaneLine(1.0, 0.0, 0.0, (GLdouble)((-1.0)*(root->bb[0].x)), objx, objy, objz, Ax, Ay, Az, &x, &y, &z);


    //printf("node is %d",root->child[0]->child[0]->bb[3].z);


   if((intersect==1)&&(y>root->bb[7].y && y<root->bb[0].y) && (z<root->bb[7].z && z>root->bb[0].z)) //z pos out of screen
   { 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 X=%d",root->bb[0].x); */
	   return 1; //partially visible
   }
	
   intersect=intersectionPlaneLine(0.0, 0.0, 1.0, (GLdouble)((-1.0)*(root->bb[0].z)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);
   if((intersect==1)&&(y>root->bb[5].y && y<root->bb[0].y) && (x<root->bb[0].x && x>root->bb[5].x))
   { 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 Z=%d",root->bb[0].z);*/
	   return 1; //partially visible
   }

   intersect=intersectionPlaneLine(0.0, 1.0, 0.0, (GLdouble)((-1.0)*(root->bb[0].y)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);
   if((intersect==1)&&(z>root->bb[0].z && z<root->bb[2].z) && (x<root->bb[0].x && x>root->bb[2].x))
   { 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 Y=%d",root->bb[0].y); */
	   return 1; //partially visible
   }
   intersect=intersectionPlaneLine(1.0, 0.0, 0.0, (GLdouble)((-1.0)*(root->bb[6].x)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);
  
   
   if((intersect==1)&&(y>root->bb[6].y && y<root->bb[1].y) && (z<root->bb[6].z && z>root->bb[1].z))
   { 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 X=%d",root->bb[6].x); */
	   return 1; //partially visible
   }
   intersect=intersectionPlaneLine(0.0, 1.0, 0.0, (GLdouble)((-1.0)*(root->bb[6].y)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);

   if((intersect==1)&&(x<root->bb[4].x && x>root->bb[6].x) && (z>root->bb[4].z && z<root->bb[6].z))
   { 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 Y=%d",root->bb[6].y); */
	   return 1; //partially visible
   }
   
   intersect=intersectionPlaneLine(0.0, 0.0, 1.0, (GLdouble)((-1.0)*(root->bb[6].z)), eyex, eyey, eyez, Ax, Ay, Az, &x, &y, &z);

   if((intersect==1)&&(y>root->bb[6].y && y<root->bb[3].y) && (x<root->bb[3].x && x>root->bb[6].x))
	{ 
	   /*
     if(dump_coord == 1)
       fprintf(dumpfile,"Plane1 Z=%d",root->bb[6].z); */
	   return 1; //partially visible
   }
   }

   return 0;


}
/*
void drawAll(octnode *current)
{
	int u=0;

	if(current->isLeaf==0) //if not a leaf
		for (u=0; u<8; u++)
			drawAll(current->child[u]);
		else if (current->dl!=0) //if it is a leaf and it has a display list
		{
			//glColor3f(0.0, 0.0, 1.0);
			//glColor3f((current->bb[0].x)/240.0, (current->bb[0].x)/240.0, (current->bb[0].z)/240.0);
			glColor3f( 1.0, (current->bb[0].x)/240.0, (current->bb[0].z)/240.0 );
			glCallList(current->dl); 
			leafCount++;
		}
}

void drawAll(octnode *current)
{
	int u=0;

	if(current->isLeaf==0) //if not a leaf
		for (u=0; u<8; u++)
			drawAll(current->child[u]);
		else if (current->dl!=0) //if it is a leaf and it has a display list
		{
			//glColor3f(0.0, 0.0, 1.0);
			//glColor3f((current->bb[0].x)/240.0, (current->bb[0].x)/240.0, (current->bb[0].z)/240.0);
			glColor3f( 1.0, (current->bb[0].x)/240.0, (current->bb[0].z)/240.0 );
			glCallList(current->dl); 
		}
}
*/
void drawAll(octnode *current)
{
	int u=0;
   

	if(current->isLeaf==0) //if not a leaf
		for (u=0; u<8; u++)
			drawAll(current->child[u]);
		else if (current->dl!=0) //if it is a leaf and it has a display list
		{
			//glColor3f(0.0, 0.0, 1.0);
			//glColor3f((current->bb[0].x)/240.0, (current->bb[0].x)/240.0, (current->bb[0].z)/240.0);
			glColor3f( (float)1.0, (float)((current->bb[0].x)/240.0), (float)((current->bb[0].z)/240.0) );
			glCallList(current->dl);
			leafCount++;

			if(dump_coord)
			{
			fprintf(dumpfile,"************Drawing***************\n");
			for (u=0; u<8; u++)
				fprintf(dumpfile,"(%d, %d, %d) \n", current->bb[u].x, current->bb[u].y, current->bb[u].z);
			}

		}
}


void testVolume(octnode *current)
{
	int result, i, u;
	//step 1

	
	result=testCubeVerticies(current);
	if(result==0) //if not visible at all as determined by step 1
		result=testScreenCorners(current); //do step 2

			if (dump_coord==1)
		{

				fprintf(dumpfile,"testVolume %d  \n", result);
				for (u=0; u<8; u++)
				fprintf(dumpfile,"(%d, %d, %d) \n", current->bb[u].x, current->bb[u].y, current->bb[u].z);
			}
	if((result==2) || ((current->isLeaf==1)&&(result==1)) ) //if fully visible or already at a leaf
	{
		drawAll(current);
	    /*
		if (dump_coord==1)
		{

			fprintf(dumpfile,"\nResult: %d \n",result);
            
			for(x=0;x<8;x++)
			{
			  fprintf(dumpfile,"x: %d  x%d y %d z %d        ",x,current->bb[x].x,current->bb[x].y,current->bb[x].z);
			  
			  if((x%2)==1)
                fprintf(dumpfile,"\n");

			}
            
        fprintf(dumpfile,"\n\n");
		}
		*/

	}
	else if ((result==1)&&(current->isLeaf==0) ) //else if partially visible 
		for (i=0; i<8; i++)
			testVolume(current->child[i]);


		//else the volume is not visible at all -do nothing
}







static void CALLBACK display(void)
{
   GLint viewport[4];
   GLdouble mvmatrix[16];
   GLdouble projmatrix[16];


   GLdouble A1x, A1y, A1z, A2x, A2y, A2z;
   int testResult;

   int x=1, y=1;
   float clocks_per;

   //code to automatically move a bit to calculate average FPS etc..

   if (toggle2)
   {
     rotateRight(&viewAngle);  
   }


   if (toggle3)
   {
	 if (flip)
	 {
	   rotateRight(&viewAngle);
	   flip=GL_FALSE;
	 }
	 else 
	 {
	   rotateLeft(&viewAngle);
	   flip=GL_TRUE;
	 }
   }


   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   

   glLoadIdentity();

   x2=eyex+cos(viewAngle);
   y2=eyey + vertAngle;
   z2=eyez+sin(viewAngle);





   //hack.. where to put gluLookAt?  Remember to ditch glLoadIdent
   gluLookAt(eyex,eyey,eyez,x2,y2,z2,x3,y3,z3);
 

   leafCountOld = leafCount;
   leafCount=0;


   	
   //fprintf(dumpfile,"Count %d",dumpcount);
   //dumpcount++;
   timer1=clock();
   if (toggle==0) 
	   drawAll(root);
   else 
       testVolume(root);


   if(dump_coord)
   {

	   fprintf(dumpfile,"Count %d",dumpcount);
   dumpcount++;
	dump_coord=0;
   }

   timer2=clock();
     clocks_per = (float)(timer2-timer1);
 //  clocks_per = ((float)(timer2-timer1))/(float)CLOCKS_PER_SEC;
  

	 //calculate performance
   if(toggle_average)
   {
      num_iterations++;
	  avgLeafCount+=leafCount;
      avgFPS+=clocks_per;

   }
   else if(toggle_average==2)
   {
      avgLeafCount/=num_iterations;
	  avgPolyCount=(avgLeafCount*NUM_POLYS)/num_iterations;
      avgFPS/=num_iterations;
	  fprintf(dumpfile,"Screen size: width %d height %d\n", D_WIDTH, D_HEIGHT);
	  fprintf(dumpfile,"Number Movements: %d, Average LeafCount: %3.1lf Average PolyCount %3.1lf\n\n",num_iterations, avgLeafCount, avgPolyCount);
      
	  //reset data for next taking of averages
	  avgLeafCount=0;
	  num_iterations=0;
	  avgFPS=0;
	  avgPolyCount=0;
	  toggle_average=0;
   } 


  glColor3f(1.0, 0.0, 1.0);

   glBegin(GL_TRIANGLES);
     glVertex3f(0.0f, 1.0f, 0.0f);
     glVertex3f(-1.0f, 0.0f,0.0f);
     glVertex3f( 1.0f, 0.0f, 0.0f);
	 glColor3f(0.0,1.0,1.0);
	 glVertex3f(0.0,1.0,0.0);
	 glVertex3f(0.0,0.0,-1.0);
	 glVertex3f(0.0,0.0,1.0);
	 glColor3f(1.0,0.0,1.0);
	 glVertex3f(0.0f,-.2f,1.0f);
	 glVertex3f(1.0f,-.2f,0.0f);
	 glVertex3f(-1.0f,-.2f,0.0f);
/*
     glColor3f(0.0f, 0.0f, 1.0f);
     glVertex3f(eyex-1.5, -1.0, eyez);
     glVertex3f(eyex+1.5, -1.0, eyez);
     glVertex3f(x2, y2, z2);
*/
   glEnd();
  
  
   glGetIntegerv(GL_VIEWPORT, viewport);
   glGetDoublev(GL_MODELVIEW_MATRIX, mvmatrix);
   glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
   testResult=gluProject(0.0, 0.0, 0.0, mvmatrix, projmatrix, viewport, &screenx, &screeny, &screenz);  


   vectorLine(eyex, eyey, eyez, objx, objy, objz, &A1x, &A1y, &A1z);
   vectorLine(eyex, eyey, eyez, 0.0, 0.0, 0.0, &A2x, &A2y, &A2z);
   
//   sprintf(timer_string,"%1.3f, x %1.2lf y %1.2lf z %1.2lf screen coord (%2.5lf, %2.5lf)", clocks_per, eyex, eyey, eyez, screenx, screeny);  
   
//   sprintf(timer_string, "intersect: %d (0,0,0) maps to (%1.3f,%1.3f) leaves: %d  sec per frame: %1.3f", testResult, screenx, screeny, leafCountOld, clocks_per);

   if((A1x*A2x)+(A1y*A2y)+(A1z*A2z)>=0)
   {
   //sprintf(timer_string, "(0,0,0) maps to (%1.3f, %1.3f) leaves: %d  sec per frame: %1.3f", screenx, screeny, leafCountOld, clocks_per);
     sprintf(timer_string, "t %d spf: %1.3f lvs: %d",toggle_average, clocks_per, leafCountOld);
    
   }
   else
	   //sprintf(timer_string, "(0,0,0) does not map to screen leaves: %d  sec per frame: %1.3f", leafCountOld, clocks_per);
       sprintf(timer_string, "t %d spf: %1.3f lvs: %d", toggle_average, clocks_per,leafCountOld);

   glFlush();
}




//Select the pixel format for a given device context
void SetDCPixelFormat(HDC hDC)
{
	int nPixelFormat;

	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),	//size of this structure
			1,							//Version of this structure
			PFD_DRAW_TO_WINDOW |		//draw to window(not bitmap)
			PFD_SUPPORT_OPENGL |		//Support Opengl calls
			PFD_DOUBLEBUFFER,			//Double buffer mode
			PFD_TYPE_RGBA,				//RGBA Color mode
			24,							//Want 24 bit color
			0, 0, 0, 0, 0, 0,			//Not used to select mode
			0, 0,						//Not used to select mode
			0, 0, 0, 0 ,0,
			32,							//Size of depth buffer
			0,
			0,
			PFD_MAIN_PLANE,				//Draw in the main plane
			0,
			0, 0, 0 };

		//Choose a pixel format that best matches that describes in pfd
		nPixelFormat = ChoosePixelFormat(hDC, &pfd);

		//Set the pixel format for the device context
		SetPixelFormat(hDC, nPixelFormat, &pfd);
}

void CALLBACK ChangeSize(GLsizei w, GLsizei h)
{
	//Prevent a divide by zero, when window is too short
	//(you can't make a window of zero width)
	if(h==0)
		h=1;
	//Set the viewport to be the entire window
	glViewport(0, 0, w, h);


	glMatrixMode(GL_PROJECTION);

	//Reset the coordinate system before modifiying
	glLoadIdentity();

	windowHeight=(float)h;
	windowWidth=(float)w;

	//Keep the square square, this time, save calculated
	//width and height for later use
/*	
	if(w<=h)
	{
		windowHeight = 250.0f*h/w;
		windowWidth = 250.0f;
	}
	else
	{
		windowWidth =250.0f*w/h;
		windowHeight = 250.0f;
	}
	*/

	gluPerspective(30., w/(double)h, 0.1, 240.);
	glMatrixMode(GL_MODELVIEW);

}


void CALLBACK RenderScene(void)
{
}


//Window procedure, handels all messages for this program
LRESULT CALLBACK WndProc(	HWND hWnd,
						 UINT message,
						 WPARAM wParam,
						 LPARAM lParam)
{
	static HGLRC hRC;	//Permanent Rendering context
	static HDC hDC;		//Private GDI Device context
    static PAINTSTRUCT ps;
    static RECT rect;

	switch (message)
	{
		//Window creation, setup for OpenGL
	case WM_CREATE:



		//store the device context
		hDC=GetDC(hWnd);

		//Select the pixel format
		SetDCPixelFormat(hDC);

		//Create the rendering context and make itw current
		hRC = wglCreateContext(hDC);
		wglMakeCurrent(hDC, hRC);

		//Create a timer that fires every millisecond
		SetTimer(hWnd, 101, 1, NULL);
		
		init();
		break;

		//Window is being destroyed, cleanup
	case WM_DESTROY:
		//Kill the timer we created
		KillTimer(hWnd, 101);
        fclose(dumpfile);
		//Deselect the current rendering context and delete it
		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);

		//Tell the application to terminate after the window
		//is gone
		PostQuitMessage(0);
		break;

		//Window is resized
	case WM_SIZE:
		//Call ourfunction which modifies the clipping
		//volume and viewport
		ChangeSize(LOWORD(lParam), HIWORD(lParam));

		break;
		//Timer, moves and bounces the rectangle, simply calls 
		//our previous OnIdle function, then invalidates the 
		//window so it will be redrawn.
	case WM_TIMER:
		{
			//IdleFunction();
			InvalidateRect(hWnd, NULL, FALSE);
		}
		break;
		//The painting function. This message sent by windows
		//whenever the screeen needs updating
	case WM_PAINT:
		{
			//Call OpenGL drawing code
		//	RenderScene();
            
			display();
            hDC = BeginPaint(hWnd, &ps);
		
			GetClientRect(hWnd,&rect);
//			DrawText(hDC,"PRINTME",-1,&rect,DT_SINGLELINE | DT_CENTER | DT_VCENTER);
			

			//Call function to swap the buffers
			SwapBuffers(hDC);
            
            DrawText(hDC,intersection_string,-1,&rect,DT_SINGLELINE | DT_LEFT | DT_BOTTOM);
			//Validate the newly painted client area
			ValidateRect(hWnd, NULL);
		    EndPaint(hWnd, &ps);
		}
		break;
		
		// A menu command
	case WM_COMMAND:
			{
			switch(LOWORD(wParam))
				{
				// Exit the program
				case ID_FILE_EXIT:
					DestroyWindow(hWnd);
					break;

				// Display the about box
				case ID_HELP_ABOUT:
					DialogBox (hInstance,
						MAKEINTRESOURCE(IDD_DIALOG_ABOUT),
						hWnd,
						AboutDlgProc);
					break;
				}
			}
			break;
	case WM_CHAR:
		{
			if(wParam == 'w')
				moveForward(&eyex, &eyez, &viewAngle);

			if (wParam=='W')
					runForward(&eyex, &eyez, &viewAngle);
	
			if(wParam == 's')
				moveBack(&eyex, &eyez, &viewAngle);

			if(wParam == 'a')
				rotateLeft(&viewAngle);

			if(wParam == 'q')
				lookUp(&vertAngle);

			if(wParam == 'e')
				lookDown(&vertAngle);


			if(wParam == 'd')
				rotateRight(&viewAngle);  

			if(wParam == 't')
				toggle = (toggle+1)%2;

			if(wParam == 'f')
			    dump_coord=1;


			if (wParam == '1')
				toggle2 = (toggle2+1)%2;

			if (wParam == '2')
				toggle3 = (toggle3+1)%2;

			if (wParam == 'z')
				dump_to_file = (dump_to_file+1)%2;

			if (wParam == 'x')
				toggle_average = toggle_average++;

			//result=intersectionPlaneLine(0.0, 0.0, 1.0, 0.0, eyex, eyey, eyez, -0.5, -0.5, -200, &intersectx,
		    //  &intersecty, &intersectz); 

            result=intersectionPlaneLine(1.0, 0.0, 0.0, 0.0, eyex, eyey, eyez, x2-eyex, y2-eyey, z2-eyez, &intersectx,
		      &intersecty, &intersectz); 
/*
            if (result==1)
		      sprintf(intersection_string, "%s intersection at (%2.3f, %2.3f, %2.3f)", timer_string, intersectx, intersecty, 
		        intersectz);
		    else if (result==0)
			  sprintf(intersection_string, "%s line in same plane", timer_string);
			else
				sprintf(intersection_string, "%s No intersection", timer_string);
*/
			sprintf(intersection_string,"%s %d  eye(%1.3f,%1.3f,%1.3f) eye2(%1.3f,%1.3f,%1.3f)",timer_string, toggle,
				eyex, eyey, eyez, eye2x, eye2y, eye2z);

            //glMatrixMode(GL_MODELVIEW);
            //glLoadIdentity();
			gluLookAt(eyex,eyey,eyez,x2,y2,z2,0.,1.,0.);
		}
	    	break;

 

	default:		//Passes it on if unprocessed
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}

	return(0L);
}



int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine,
					 int nCmdShow)
					 
{

	static char lpszAppName[] = "Demo" ;

	MSG msg;		//Windows message structure
	WNDCLASS wc;	//Windows class structure
	HWND hWnd;		//Storage for windows handle

	//Register the windows style
	wc.style		=CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc	=(WNDPROC) WndProc;
	wc.cbClsExtra	=0;
	wc.cbWndExtra	=0;

	wc.hInstance	=hInstance;
	wc.hIcon		=NULL;
	wc.hCursor		=LoadCursor(NULL, IDC_ARROW);

	//No need for background brush for openGL window
	wc.hbrBackground	=NULL;

	wc.lpszMenuName		= MAKEINTRESOURCE(IDR_MENU);
//	wc.lpszMenuName	=NULL;

	wc.lpszClassName	=lpszAppName;

	//Register the window class
	if(RegisterClass(&wc)==0)
		return FALSE;

	//Create the main application window
	hWnd = CreateWindow(
		lpszAppName,
		lpszAppName,

		//OpenGl requires WS_CLIPCHILDREN and WS_CLIPSIBLINGS
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,

		//Window position and size
		100, 100,
		D_WIDTH, D_HEIGHT,

		NULL,
		NULL,
		hInstance,
		NULL);

	//If the window is not created then quit
	if(hWnd==NULL)
		return FALSE;

//	init(); moved to WM_CREATE

	//Display the window
	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);



	//Process application messages until the application cloases
	while(GetMessage(&msg, NULL, 0, 0))
		{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}

// Dialog procedure.
BOOL APIENTRY AboutDlgProc (HWND hDlg, UINT message, UINT wParam, LONG lParam)
	{
	
    switch (message)
    	{
		// Initialize the dialog box
	    case WM_INITDIALOG:
			{
			int i;
			GLenum glError;

			// glGetString demo
			SetDlgItemText(hDlg,IDC_OPENGL_VENDOR,glGetString(GL_VENDOR));
			SetDlgItemText(hDlg,IDC_OPENGL_RENDERER,glGetString(GL_RENDERER));
			SetDlgItemText(hDlg,IDC_OPENGL_VERSION,glGetString(GL_VERSION));
			SetDlgItemText(hDlg,IDC_OPENGL_EXTENSIONS,glGetString(GL_EXTENSIONS));

			// gluGetString demo
			SetDlgItemText(hDlg,IDC_GLU_VERSION,gluGetString(GLU_VERSION));
			SetDlgItemText(hDlg,IDC_GLU_EXTENSIONS,gluGetString(GLU_EXTENSIONS));


			// Display any recent error messages
			i = 0;
			do {
				glError = glGetError();
				SetDlgItemText(hDlg,IDC_ERROR1+i,gluErrorString(glError));
				i++;
				}
			while(i < 6 && glError != GL_NO_ERROR);


			return (TRUE);
			}
			break;

		// Process command messages
	    case WM_COMMAND:      
			{
			// Validate and Make the changes
			if(LOWORD(wParam) == IDOK)
				EndDialog(hDlg,TRUE);
		    }
			break;

		// Closed from sysbox
		case WM_CLOSE:
			EndDialog(hDlg,TRUE);
			break;
		}

	return FALSE;
	}

	