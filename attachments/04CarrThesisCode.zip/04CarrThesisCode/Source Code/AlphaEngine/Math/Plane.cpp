#include "AlphaEngine/Math/Plane.h"
#include "AlphaEngine/AlphaConstants.h"

int CPlane::classifyPoint(const CVector3 &vert)
{
	float val = normal.dot(vert) + d;

	if (val < -epsilon)
		return ALPHA_BEHIND;
	else if (val > epsilon)
		return ALPHA_INFRONT;
	else
		return ALPHA_COINCIDING;
}

CPlane::CPlane()
{
	normal = CVector3(0,1,0);
	d = 0;
	epsilon = 0.05f;
}

CPlane::CPlane(CVector3 normal, float d)
{
	this->normal = normal;
	this->d = d;
	epsilon = 0.05f;
}

CPlane::~CPlane()
{
}

float CPlane::getDistanceToPlane(const CVector3 &vertex)
{
	return normal.dot(vertex) - d;
}

bool CPlane::rayIntersect(const CVector3 &ro, const CVector3 &rd, CVector3 &ip, float &t)
{
	float vd = normal.dot(rd);
	// check if parallel to plane
	if (vd == 0)
		return false;

	float vo = -(normal.dot(ro) + d);
	
	t = vo / vd;

	if (t < 0)
		return false;

	/*
	FIX THIS!!!
	*/
	ip.points[0] = ro.points[0] + (t * rd.points[0]);
	ip.points[1] = ro.points[1] + (t * rd.points[1]);
	ip.points[2] = ro.points[2] + (t * rd.points[2]);

	return true;
}

bool CPlane::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&d, sizeof(float), 1, filePtr);
		fwrite(&epsilon, sizeof(float), 1, filePtr);
	}
	else
	{
		fread(&d, sizeof(float), 1, filePtr);
		fwrite(&epsilon, sizeof(float), 1, filePtr);
	}
	
	return normal.serialize(filePtr, isStoring);
}

bool CPlane::operator!= (const CPlane &rPlane)
{
	return ((d != rPlane.d) || (normal != rPlane.normal) || (epsilon != rPlane.epsilon));
}

bool CPlane::operator== (const CPlane &rPlane)
{
	return ((d == rPlane.d) && (normal == rPlane.normal) && (epsilon == rPlane.epsilon));
}

CPlane& CPlane::operator= (const CPlane &rPlane)
{
	d = rPlane.d;
	normal = rPlane.normal;
	epsilon = rPlane.epsilon;
	return *this;
}
