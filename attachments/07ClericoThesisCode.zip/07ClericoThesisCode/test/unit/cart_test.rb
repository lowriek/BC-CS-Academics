require File.dirname(__FILE__) + '/../test_helper'

class CartTest < Test::Unit::TestCase
  fixtures :carts

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
