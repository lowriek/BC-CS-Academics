#ifndef _FACE_H_
#define _FACE_H_

#include <stdio.h>
#include <string>
#include "AlphaEngine/Math/Vector2.h"
#include "AlphaEngine/Math/Vector3.h"

using namespace std;

class CFace
{
public:

	CFace();
	virtual ~CFace();

	bool			isTransparent;
	float			transparencyValue;
	
	float			baseOffsetS;
	float			baseOffsetT;
	float			baseScaleS;
	float			baseScaleT;

	float			decalOffsetS;
	float			decalOffsetT;
	float			decalScaleS;
	float			decalScaleT;

	unsigned int	bTxId;
	unsigned int	dTxId;
	unsigned int	lTxId;
	unsigned int	numVert;
	CVector2 *		pBTxCoord;
	CVector2 *		pDTxCoord;
	CVector2 *		pLTxCoord;
	unsigned int *	pVertIndex;
	CVector3		surfaceNormal;

	virtual bool	allocate(int numVertice);
	virtual void	reset();
	void			reverseVertexOrder();
	virtual bool	serialize(FILE * filePtr, bool isStoring);
	CFace&			operator=(const CFace& rFace);

};

#endif
