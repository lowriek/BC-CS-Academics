

char *getSpc(int num)
{



  switch(num)
  {
    case 1:
      return "comer";    
      break;
    case 2:
      return "correr";
      break;
    case 3:
      return "dormir";
      break;
    case 4:
      return "estudiar";
      break;
    case 5:
      return "mirar";
      break;
  }


}
