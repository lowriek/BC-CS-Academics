function [] = getFaces()
% function [] = getFaces()
% Uses facialpoints.txt, created by facialPoints.m, to create cropped
% images for each face in the picture

a = dlmread('facialpoints.txt');
index=0;

for I=1:100
    [q,numfaces] = size(find(a((3*I)-1,:)~=0));
    numfaces=numfaces/3;
    filename = [ int2str(I) , '.jpg' ];
    im = rgb2gray(double(imread(filename))/255);
    im = padarray(im,[200 200], 0, 'both');
    for J=1:numfaces
        index = index+1;
        fid = fopen('index.html','a');
        xs=a(3*I-1,(3*J)-2:(3*J));
        ys=a(3*I,(3*J)-2:(3*J));
        xs = xs + 200;
        ys = ys + 200;
        points = [ xs ; ys ];   %The 3 points are now in points, for the face we have
        dist = sqrt((points(1,1)-points(1,2))^2 + (points(2,1) - points(2,2))^2);
        midpoint = [ mean([points(1,1) points(1,2)]) mean([points(2,1) points(2,2)]) ];
        
        %Now we'll find the angle
            angle = atan2(points(2,2)-points(2,1),points(1,2)-points(1,1));
            angle = angle * (180/pi);
            angles(index)=angle;        
            width = round(1 * dist);
            width = width + (1-mod(width,2));
            height = round(1.5 * dist);
            height = height + (1-mod(height,2));
            RECT = [ midpoint(1)-width midpoint(2)-height width*2 height*2 ];
            cropped = imcrop(im,RECT);
            [y,x] = size(cropped); midpt = [ x/2 y/2 ];
        
        %Now we'll rotate
        cropped = imrotate(cropped,angle,'bicubic', 'crop');
        cropped = imcrop(cropped, [ midpt(1)-width/2 midpt(2)-height/3 width height ]);
        
        cropped = imresize(cropped,[120 80], 'bicubic');
        figure(1);clf;imagesc(cropped);colormap gray;axis image;truesize;
        croppedname = [ 'crop', int2str(I) , '_' , int2str(J), '.jpg' ];
        %print('-djpeg',croppedname);
        %nor = cropped - min( cropped(:));
        %normalized = nor / max( nor(:));
        imwrite(cropped,croppedname,'jpeg');
        fprintf(fid, '<img src="');fprintf(fid,'%s_%s',int2str(I),int2str(J));fprintf(fid,'">\n');
        fclose(fid);
    end
end