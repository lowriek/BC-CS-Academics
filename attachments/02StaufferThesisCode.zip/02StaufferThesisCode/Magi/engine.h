#ifndef	ENGINE_H
#define ENGINE_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENGINE.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "timeKeeper.h"
#include "camera.h"
#include "Model.h"
#include "MilkShapeModel.h"
#include "Entity.h"
#include "environs.h"
#include "terrain.h"
#include "matrix.h"
#include "thread.h"
#include "avatar.h"
#include "sound.h"



class MEngine : public Entity
{
	
	

		protected:
		HGLRC		hRC;
		HDC			hDC;
		HWND		hWnd;
		HINSTANCE	hInstance;
		
		bool		active;
		bool		fullscreen;
		MCamera		* myCamera;
		bool		running;
		double		frameRate[3];
		TimeKeeper	 * MasterClock;
		SoundManager	* MasterSound;
		Entity *	editorInsert;
		FILE * demo;
		
		public:

		MEngine();
		~MEngine();
		bool	SpawnWindow(char * title, int width, int height, int bits, bool fullscreenflag);
		void	ReSizeWindow(int width, int height);
		bool	InitWindow(void);
		void	Kill();
		void	Draw();
		void	Intro(bool start);
		int		DrawScene(void);
		void	InitScene();
		friend LRESULT CALLBACK WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
		friend BOOL CALLBACK DlgProc(HWND dlg, UINT msg, WPARAM wParam, LPARAM lParam);



};




#endif