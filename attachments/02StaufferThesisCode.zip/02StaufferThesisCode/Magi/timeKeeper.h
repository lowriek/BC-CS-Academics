#ifndef	TIMEKEEPER_H
#define TIMEKEEPER_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENGINE.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "Entity.h"

#define TIME_SECONDS_IN_DAY 86400

class TimeKeeper : public Entity
{
	
		protected:
		long masterTime;	
		
		public:
			TimeKeeper(){Entity();masterTime = 0;};
			long GetTime(){return masterTime;};
			float GetAngle(){return (double)masterTime/240;};
			void	Draw(){masterTime = (masterTime + 1) % 86400;};
			ResetClock(){masterTime = 0;};
			AdvanceHour(){masterTime = (masterTime +3600) % 86400;};
			ReverseHour(){masterTime = masterTime -3600;if(masterTime<0)masterTime=86400 - (-1)*masterTime;};


};




#endif