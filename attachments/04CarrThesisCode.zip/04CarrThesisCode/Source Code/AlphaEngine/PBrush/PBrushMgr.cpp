#include "AlphaEngine/PBrush/PBrushMgr.h"
#include "AlphaEngine/Math/Math.h"
#include "AlphaEngine/PBrush/Shape.h"
#include "AlphaEngine/PBrush/CSG.h"

bool CPBrushMgr::brushesSelected()
{
	if (pBuilder)
		return true;
	if (!listSelPBrush.empty())
		return true;
	if (!listSelPBrushPoly.empty())
		return true;

	return false;
}

void CPBrushMgr::brushScale(CVector3 p1, CVector3 p2)
{
	// SCALE EACH BRUSH IN THE GROUP, ALONG WITH THE PBUILDER, IF IT EXISTS
	scaleBrush(pBuilder, p1, p2);

	list<PBRUSHID>::iterator iter;
	if (listSelPBrush.empty())
		return;
	for (iter = listSelPBrush.begin(); iter != listSelPBrush.end(); ++iter)
	{
		CPBrush* pBrush = mapId2PBrush[*iter];
		scaleBrush(pBrush, p1, p2);
	}
}

CPBrushMgr::CPBrushMgr()
{
	pBuilder = 0;
	listSelPBrush.clear();
	listSelPBrushPoly.clear();
	mapId2PBrush.clear();
	nextId = 1;
}

CPBrushMgr::~CPBrushMgr()
{
	map<PBRUSHID, CPBrush*>::iterator iter;
	for (iter = mapId2PBrush.begin(); iter != mapId2PBrush.end(); ++iter)
		delete iter->second;

	listSelPBrush.clear();
	listSelPBrushPoly.clear();
	mapId2PBrush.clear();
	deleteBuilder();
}

void CPBrushMgr::createBrush(int brushType, CVector3 axis, CVector3 p1, CVector3 p2, float depth)
{
	deleteBuilder();
	if (p1 == p2)
		return;

	bool xyAxis = false;
	bool xzAxis = false;
	bool yzAxis = false;
	CVector3 a, b;
	// convert p1, p2 into a, b in the xy axis such that a.x < b.x, a.y > b.y
	if (axis[0] == 1 && axis[1] == 1 && axis[2] == 0)
	{
		a[0] = CMath::Min(p1[0], p2[0]);
		a[1] = CMath::Min(p1[1], p2[1]);
		b[0] = CMath::Max(p1[0], p2[0]);
		b[1] = CMath::Max(p1[1], p2[1]);
		xyAxis = true;
	}
	else if (axis[0] == 1 && axis[1] == 0 && axis[2] == 1)
	{
		a[0] = CMath::Min(p1[2], p2[2]);
		a[1] = CMath::Min(p1[0], p2[0]);
		b[0] = CMath::Max(p1[2], p2[2]);
		b[1] = CMath::Max(p1[0], p2[0]);
		xzAxis = true;
	}
	else if (axis[0] == 0 && axis[1] == 1 && axis[2] == 1)
	{
		a[0] = CMath::Min(p1[2], p2[2]);
		a[1] = CMath::Min(p1[1], p2[1]);
		b[0] = CMath::Max(p1[2], p2[2]);
		b[1] = CMath::Max(p1[1], p2[1]);
		yzAxis = true;
	}
	if (!xyAxis && !xzAxis && !yzAxis)
		return;

	// translate the brush to the origin
	CMatrix44 rotMatrix;
	rotMatrix.identity();
	if (yzAxis)
		rotMatrix.rotateY(-CMath::HALF_PI);
	else if (xzAxis)
	{
		CMatrix44 tmat;
		tmat.rotateZ(CMath::HALF_PI);
		rotMatrix.rotateX(CMath::HALF_PI);
		rotMatrix = tmat * rotMatrix;
	}

	pBuilder = 0;
	float lenx = b.points[0] - a.points[0];
	float leny = b.points[1] - a.points[1];

	switch(brushType)
	{
	case ALPHA_BOX:
		pBuilder = CShape::createBox(lenx, leny, depth);
		break;
	case ALPHA_SPHERE:
		pBuilder = CShape::createSphere(CMath::Max(lenx, leny), 10,10);
		break;
	default:
		return;
	};
	if (!pBuilder)
		return;

	pBuilder->transform(rotMatrix);
	pBuilder->setNormals();
	// translate the brush to correct space
	CMatrix44 translate;
	translate.translate((p1 + p2) / 2.0f);
	pBuilder->transform(translate);
	return;
}

void CPBrushMgr::csgAdd()
{
	if (!pBuilder)
		return;

	CPBrush* pBrush = pBuilder->clone();
	pBrush->brushId = getNextId();
	pBrush->setPickColor();
	pBrush->setPolygonPickColor();
	pBrush->opType = ALPHA_ADD;
	add(pBrush);
}

void CPBrushMgr::csgSub()
{
	if (!pBuilder)
		return;

	CPBrush* pBrush = pBuilder->clone();
	pBrush->brushId = getNextId();
	pBrush->setPickColor();
	pBrush->setPolygonPickColor();
	pBrush->opType = ALPHA_SUB;
	add(pBrush);
}

void CPBrushMgr::deleteBuilder()
{
	if (pBuilder)
		delete pBuilder;

	pBuilder = 0;
}

void CPBrushMgr::deletePBrush()
{
	CPBrush * pBrush = 0;
	list<PBRUSHID>::iterator iter;
	for (iter = listSelPBrush.begin(); iter != listSelPBrush.end(); ++iter)
	{
		map<PBRUSHID, CPBrush*>::iterator iterMap;
		unsigned int val = *iter;
		iterMap = mapId2PBrush.find(val);
		if (iterMap != mapId2PBrush.end())
		{
			delete iterMap->second;
			mapId2PBrush.erase(iterMap);
		}
	}
	deselectPBrush();
	deselectPBrushPoly();	
}

void CPBrushMgr::deselectPBrush()
{
	listSelPBrush.clear();
}

void CPBrushMgr::deselectPBrushPoly()
{
	listSelPBrushPoly.clear();
}

unsigned int CPBrushMgr::getNextId()
{
	unsigned int id = nextId;
	nextId++;
	return id;
}

CPolygon* CPBrushMgr::getPolygons()
{
	map<PBRUSHID, CPBrush*>::iterator iter;
	map<PBRUSHID, CPBrush*>::iterator iter2;

	CPolygon * pPolygons = 0;
	for (iter = mapId2PBrush.begin(); iter != mapId2PBrush.end(); ++iter)
	{
		CPBrush* pBrush = iter->second;
		if (pPolygons)
		{
			if (pBrush->opType == ALPHA_ADD)
			{
				CPolygon* pAdd = CSG::add(pPolygons, pBrush->getPolygonList());
				pPolygons = pAdd;
			}
			else if (pBrush->opType = ALPHA_SUB)
			{
				CPolygon* pSub = CSG::subtract(pPolygons, pBrush->getPolygonList());
				pPolygons = pSub;
			}
		}
		else
		{
			pPolygons = pBrush->getPolygonList();
		}
	}
	return pPolygons;

	/*
	unsigned int numBrushes = mapId2PBrush.size();
	unsigned int index = 0;
	CPolygon** pBrushFaces = new CPolygon*[numBrushes];
	CPolygon* pPolygons = 0;
	iter = mapId2PBrush.begin();
	for (unsigned int i = 0; i < numBrushes; i++)
	{
		CPBrush* pBrush = iter->second;
		pBrushFaces[i] = 0;
		if (pBrush->opType != ALPHA_SUB)
		{
			pBrushFaces[i] = pBrush->getPolygonList();
			iter2 = mapId2PBrush.begin();
			for (unsigned int j=0; j < i; j++)
			{
				CPBrush* pBrushLess = iter2->second;
				if (pBrushLess->opType == ALPHA_ADD)
					pBrushFaces[i] = CSG::leftOpAdd(pBrushFaces[i], pBrushLess->getPolygonList());
				
				iter2++;
			}
			iter2++;
			for (unsigned int k=i+1; k < numBrushes; k++)
			{
				CPBrush* pBrushGreat = iter2->second;
				if (pBrushGreat->opType == ALPHA_ADD)
					pBrushFaces[i] = CSG::leftOpAdd(pBrushFaces[i], pBrushGreat->getPolygonList());
				else if (pBrushGreat->opType == ALPHA_SUB)
					pBrushFaces[i] = CSG::subtract(pBrushFaces[i], pBrushGreat->getPolygonList());
			
				iter2++;
			}
			if (pPolygons)
				pPolygons->add(pBrushFaces[i]);
			else
				pPolygons = pBrushFaces[i];
		}
		iter++;
	}
	
	delete [] pBrushFaces;
	return pPolygons;
	*/
}

void CPBrushMgr::pickPBrush(const int &mode, int x, int y)
{
	map<PBRUSHID, CPBrush*>::iterator iter;
	glDisable(GL_DITHER);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glClearColor(0.0f,0.0f,0.0f,0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_CULL_FACE);
	glLineWidth(4);

	for (iter = mapId2PBrush.begin(); iter != mapId2PBrush.end(); ++iter)
		iter->second->pickBrush(mode);

	GLubyte pixel[3];
	GLint viewport[4];
	glGetIntegerv(GL_VIEWPORT,viewport);
	glReadPixels(viewport[0] + x, viewport[1] + y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE,(void *)pixel);
	CColor4 pixelColor(pixel[0], pixel[1], pixel[2]);
	PBRUSHID brushId = CPBrush::pickColor2BrushId(pixelColor);
	glDisable(GL_DEPTH_TEST);
	glLineWidth(1);
	glEnable(GL_DITHER);
	glDisable(GL_CULL_FACE);
	selectPBrush(brushId);
}

void CPBrushMgr::pickPBrushPoly(const int &mode, int x, int y)
{
	if (mode != ALPHA_FILL)
		return;

	map<PBRUSHID, CPBrush*>::iterator iter;
	CPBrush* pBrush = 0;
	GLubyte pixel[3];
	GLint viewport[4];

	glDisable(GL_DITHER);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glClearColor(0,0,0,0);
	glEnable(GL_CULL_FACE);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	for (iter = mapId2PBrush.begin(); iter != mapId2PBrush.end(); ++iter)
	{
		pBrush = iter->second;
	
		if (pBrush->opType == ALPHA_ADD)
			glCullFace(GL_BACK);
		else if (pBrush->opType == ALPHA_SUB)
			glCullFace(GL_FRONT);
		
		pBrush->pickBrush(mode);
	}

	glGetIntegerv(GL_VIEWPORT,viewport);
	glReadPixels(viewport[0] + x, viewport[1] + y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE,(void *)pixel);
	CColor4 brushColor(pixel[0], pixel[1], pixel[2]);
	PBRUSHID brushId = CPBrush::pickColor2BrushId(brushColor);

	if (brushId == 0)
		return;

	// check if that brushId exists
	iter = mapId2PBrush.find(brushId);
	if (iter == mapId2PBrush.end())
		return;
	
	// render each face of specified brush
	pBrush = iter->second;

	if (pBrush->opType == ALPHA_ADD)
		glCullFace(GL_BACK);
	else if (pBrush->opType == ALPHA_SUB)
		glCullFace(GL_FRONT);

	unsigned int i, j;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	for (i = 0; i < pBrush->numPolygon; i++)
	{
		glBegin(GL_POLYGON);
			glColor3ub(pBrush->pPolygonPickColor[i].r, pBrush->pPolygonPickColor[i].g, pBrush->pPolygonPickColor[i].b);
			for (j = 0; j < pBrush->pPolygon[i].numVert; j++)
				glVertex3fv(pBrush->pPolygon[i].pVert[j].points);
		glEnd();
	}

	glGetIntegerv(GL_VIEWPORT,viewport);
	glReadPixels(viewport[0] + x, viewport[1] + y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE,(void *)pixel);
	
	unsigned int polyId = pixel[0] + pixel[1] + pixel[2] - 1;
	if (polyId < 0 || polyId > pBrush->numPolygon)
		return;

	PBRUSHID2POLYID b2p;
	b2p.brushId = brushId;
	b2p.polyId = polyId;
	selectPBrushPoly(b2p);
	glDisable(GL_CULL_FACE);
	glEnable(GL_DITHER);
	glDisable(GL_DEPTH_TEST);
}

void CPBrushMgr::render(int flags)
{
	map<PBRUSHID, CPBrush*>::iterator	mapIter;
	list<PBRUSHID>::iterator			selBrushIter;
	list<PBRUSHID2POLYID>::iterator		polyIter;

	CPBrush* pBrush = 0;

	for (mapIter = mapId2PBrush.begin(); mapIter != mapId2PBrush.end(); ++mapIter)
	{
		pBrush = mapIter->second;
		if (pBrush->opType == ALPHA_ADD)
			glColor3f(0,0,1);
		else if (pBrush->opType == ALPHA_SUB)
			glColor3f(1, 0.5f, 0);
		else
			glColor3f(1, 0, 0);

		pBrush->render(ALPHA_WIREFRAME);
	}
	// draw selected brushes in bold wireframe
	glLineWidth(3);
	if (!listSelPBrush.empty())
	{
		for (selBrushIter=listSelPBrush.begin(); selBrushIter != listSelPBrush.end(); ++selBrushIter)
		{
			pBrush = mapId2PBrush[*selBrushIter];
			if (pBrush->opType == ALPHA_ADD)
				glColor3f(0,0,1);
			else if (pBrush->opType == ALPHA_SUB)
				glColor3f(1, 0.5f, 0);
			else
				glColor3f(1, 0, 0);

			pBrush->render(ALPHA_WIREFRAME);			
		}
	}
	glLineWidth(1);

	// draw filled in brushes if needed
	glColor3f(0.8f, 0.8f, 0.8f);
	if ( ALPHA_FILL == (flags & ALPHA_FILL))
	{
		for (mapIter = mapId2PBrush.begin(); mapIter != mapId2PBrush.end(); ++mapIter)
		{
			pBrush = mapIter->second;
			pBrush->render(flags);
		}
		// draw selected faces in red
		for (polyIter = listSelPBrushPoly.begin(); polyIter != listSelPBrushPoly.end(); ++polyIter)
		{
			unsigned int brushId = (*polyIter).brushId;
			unsigned int polyId =  (*polyIter).polyId;
			pBrush = mapId2PBrush[brushId];
			glColor3ub(255, 0, 0);
			pBrush->pPolygon[polyId].render(flags);
			glColor3ub(255, 255, 255);
		}
	}

	// ALWAYS DRAW IN WIREFRAME
	if (pBuilder)
	{
		glColor3f(1, 0, 0);
		pBuilder->render(ALPHA_WIREFRAME);
	}
}

void CPBrushMgr::selectPBrush(PBRUSHID brushId)
{
	map<PBRUSHID, CPBrush*>::iterator iter;
	list<PBRUSHID>::iterator iterList;

	iter = mapId2PBrush.find(brushId);
	if (iter == mapId2PBrush.end())
		return;
	
	// if the id is already selected, deselect it
	for (iterList = listSelPBrush.begin(); iterList != listSelPBrush.end();)
	{
		if (*iterList == brushId)
		{
			iterList = listSelPBrush.erase(iterList);
			return;
		}
		else
			++iterList;
	}

	listSelPBrush.push_back(brushId);
}

void CPBrushMgr::selectPBrushPoly(PBRUSHID2POLYID &brushId2PolyId)
{
	list<PBRUSHID2POLYID>::iterator iter;
	for (iter = listSelPBrushPoly.begin(); iter != listSelPBrushPoly.end();)
	{
		if (brushId2PolyId.brushId == (*iter).brushId && brushId2PolyId.polyId == (*iter).polyId)
		{
			iter = listSelPBrushPoly.erase(iter);
			return;
		}
		else
			++iter;
	}
	listSelPBrushPoly.push_back(brushId2PolyId);
}

bool CPBrushMgr::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	map<PBRUSHID, CPBrush*>::iterator iter;
	CPBrush* pBrush = 0;
	unsigned int numBrush;
	if (isStoring)
	{
		numBrush = mapId2PBrush.size();
		fwrite(&nextId, sizeof(unsigned int), 1, filePtr);
		fwrite(&numBrush, sizeof(unsigned int), 1, filePtr);
		for (iter = mapId2PBrush.begin(); iter != mapId2PBrush.end(); ++iter)
		{
			pBrush = iter->second;
			if (!pBrush->serialize(filePtr, isStoring)) return false;
		}
	}
	else
	{
		fread(&nextId, sizeof(unsigned int), 1, filePtr);
		fread(&numBrush, sizeof(unsigned int), 1, filePtr);	
		for (unsigned int i = 0; i < numBrush; i++)
		{
			pBrush = new CPBrush();
			if (!pBrush->serialize(filePtr, isStoring))
			{
				delete pBrush;
				return false;
			}
			add(pBrush);
		}
	}
	return true;
}

void CPBrushMgr::setBaseTx(unsigned int txId)
{
	list<PBRUSHID>::iterator iter;
	list<PBRUSHID2POLYID>::iterator iter1;
	unsigned int i;
	for (iter = listSelPBrush.begin(); iter != listSelPBrush.end(); ++iter)
	{
		CPBrush * pBrush = mapId2PBrush[*iter];
		for (i=0; i < pBrush->numPolygon; i++)
			pBrush->pPolygon[i].bTxId = txId;
	}
	for (iter1 = listSelPBrushPoly.begin(); iter1 != listSelPBrushPoly.end(); ++iter1)
	{
		CPBrush * pBrush = mapId2PBrush[(*iter1).brushId];
		pBrush->pPolygon[(*iter1).polyId].bTxId = txId;
	}
	if (pBuilder)
		for (i=0; i < pBuilder->numPolygon; i++)
			pBuilder->pPolygon[i].bTxId = txId;

}

void CPBrushMgr::setDecalTx(unsigned int txId)
{
	list<PBRUSHID>::iterator iter;
	list<PBRUSHID2POLYID>::iterator iter1;
	unsigned int i;
	for (iter = listSelPBrush.begin(); iter != listSelPBrush.end(); ++iter)
	{
		CPBrush * pBrush = mapId2PBrush[*iter];
		for (i=0; i < pBrush->numPolygon; i++)
			pBrush->pPolygon[i].dTxId = txId;
	}
	for (iter1 = listSelPBrushPoly.begin(); iter1 != listSelPBrushPoly.end(); ++iter1)
	{
		CPBrush * pBrush = mapId2PBrush[(*iter1).brushId];
		pBrush->pPolygon[(*iter1).polyId].dTxId = txId;
	}
	if (pBuilder)
		for (i=0; i < pBuilder->numPolygon; i++)
			pBuilder->pPolygon[i].dTxId = txId;
}

void CPBrushMgr::setPolygonProp(const PolygonProp &polygonProp)
{
	list<PBRUSHID>::iterator iter;
	list<PBRUSHID2POLYID>::iterator iter1;
	unsigned int i;
	
	for (iter = listSelPBrush.begin(); iter != listSelPBrush.end(); ++iter)
	{
		CPBrush * pBrush = mapId2PBrush[*iter];
		for (i=0; i < pBrush->numPolygon; i++)
		{
			pBrush->pPolygon[i].alpha = polygonProp.transparencyValue;
		}

	}
	
	for (iter1 = listSelPBrushPoly.begin(); iter1 != listSelPBrushPoly.end(); ++iter1)
	{
		CPBrush * pBrush = mapId2PBrush[(*iter1).brushId];
		int polyId = (*iter1).polyId;
		pBrush->pPolygon[polyId].alpha = polygonProp.transparencyValue;
	}
	if (pBuilder)
		for (i=0; i < pBuilder->numPolygon; i++)
			pBuilder->pPolygon[i].alpha = polygonProp.transparencyValue;
}

void CPBrushMgr::transform(const CMatrix44 &matrix)
{
	if (pBuilder)
		pBuilder->transform(matrix);

	list<PBRUSHID>::iterator iter;
	for (iter = listSelPBrush.begin(); iter!= listSelPBrush.end(); ++iter)
	{
		CPBrush * pBrush = mapId2PBrush[*iter];
		pBrush->transform(matrix);
	}

}

void CPBrushMgr::add(CPBrush* pBrush)
{
	if (pBrush == NULL)
		return;

	mapId2PBrush.insert(map<PBRUSHID,CPBrush*>::value_type(pBrush->brushId, pBrush));
}

void CPBrushMgr::scaleBrush(CPBrush *pBrush, CVector3 p1, CVector3 p2)
{
	if (!pBrush)
		return;
	
	unsigned int i, j;
	float dx = p1[0] - p2[0];
	float dy = p1[1] - p2[1];
	float dz = p1[2] - p2[2];
	float minx, maxx, miny, maxy, minz, maxz;

	minx = pBrush->pPolygon[0].pVert[0].points[0];
	miny = pBrush->pPolygon[0].pVert[0].points[1];
	minz = pBrush->pPolygon[0].pVert[0].points[2];
	maxx = minx; maxy = miny; maxz=minz;
	for (i=0; i<pBrush->numPolygon; i++)
		for (j=0; j<pBrush->pPolygon[j].numVert; j++)
		{
			minx = CMath::Min(minx, pBrush->pPolygon[i].pVert[j].points[0]);
			miny = CMath::Min(miny, pBrush->pPolygon[i].pVert[j].points[1]);
			minz = CMath::Min(minz, pBrush->pPolygon[i].pVert[j].points[2]);
			maxx = CMath::Max(maxx, pBrush->pPolygon[i].pVert[j].points[0]);
			maxy = CMath::Max(maxy, pBrush->pPolygon[i].pVert[j].points[1]);
			maxz = CMath::Max(maxz, pBrush->pPolygon[i].pVert[j].points[2]);
		}
	
	if (dx != 0)
	{
		float length = maxx - minx;
		if (length != 0)
		{
			float lengthPrime = dx + length;
			float scale = lengthPrime / length;
			if (scale != 0 && lengthPrime >= 1)
			{
				CMatrix44 mscale;
				mscale.scale(CVector3(scale, 1, 1));
				pBrush->transform(mscale);
				CMatrix44 translate;
				translate.translate(CVector3(dx / 2.0f, 0, 0));
				pBrush->transform(translate);
			}
		}
	}
	if (dy != 0)
	{
		float length = maxy - miny;
		if (length != 0)
		{
			float lengthPrime = dy + length;
			float scale = lengthPrime / length;
			if (scale != 0 && lengthPrime >= 1)
			{
				CMatrix44 mscale;
				mscale.scale(CVector3(1, scale, 1));
				pBrush->transform(mscale);
				CMatrix44 translate;
				translate.translate(CVector3(0, dy/2.0f, 0));
				pBrush->transform(translate);
			}
		}
	}
	if (dz != 0)
	{
		float length = maxz - minz;
		if (length != 0)
		{
			float lengthPrime = dz + length;
			float scale = lengthPrime / length;
			if (scale != 0 && lengthPrime >= 1)
			{
				CMatrix44 mscale;
				mscale.scale(CVector3(1, 1, scale));
				pBrush->transform(mscale);
				CMatrix44 translate;
				translate.translate(CVector3(0, 0, dz/2.0f));
				pBrush->transform(translate);
			}
		}
	}
}
