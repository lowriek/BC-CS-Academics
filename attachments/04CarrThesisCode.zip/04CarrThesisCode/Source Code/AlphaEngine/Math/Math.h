#ifndef _CMATH_H_
#define _CMATH_H_

#include <math.h>
#include <stdlib.h>

class CMath  
{
public:
	// return -1 if negative, 0 on 0, +1 on positive
	static int Sign(int value);
	static float Sign(float value);
	
	// computes value * value
	static float Sqr(float value);

	// return random number x, 0 <= x < 1
	static float UnitRandom(float seed = 0.0f);

	// return a random number x, -1 <= x < 1
	static float SymmetricRandom(float seed = 0.0f);
	
	// return a random number x, min <= x < max
	static float IntervalRandom(float min, float max, float seed = 0.0f);

	// value must be -1 <= value <= 1
	static float ACos(float value);
	static float ASin(float value);

	static float InvSqrt(float value);

	static float ATan(float value);
	static float ATan2(float y, float x);
	static float Ceil(float value);
	static float Cos(float value);
	static float Exp(float value);
	static float FAbs(float value);
	static float Floor(float value);
	static float Log(float value);
	static float Pow(float base, float exponent);
	static float Sin(float value);
	static float Sqrt(float value);
	static float Tan(float value);
	static float Min(float a, float b);
	static float Max(float a, float b);

	// constants
	static const float INFINITY;
	static const float PI;
	static const float TWO_PI;
	static const float HALF_PI;
	static const float INV_TWO_PI;
	static const float DEG_TO_RAD;
	static const float RAD_TO_DEG;			
};

#endif 
