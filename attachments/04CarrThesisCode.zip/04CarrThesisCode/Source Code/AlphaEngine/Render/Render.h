#ifndef _RENDER_H_
#define _RENDER_H_

#include <windows.h>
#include <gl/gl.h>
#include <gl/glext.h>

class Render {
public:
	
	static bool init();
	static void shutdown();

	static PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
	static PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;
	static PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;
	static int								maxTextureUnits;

private:
	static bool inString(char *searchStr, char *str);
};

#endif