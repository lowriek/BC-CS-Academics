/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						FONT.H								   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	November 10, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "font.h"


Font::Font(HDC h)
{

	HFONT	font;										// Windows Font ID

	base = glGenLists(96);								// Storage For 96 Characters

	font = CreateFont(	-10,							// Height Of Font
						0,								// Width Of Font
						0,								// Angle Of Escapement
						0,								// Orientation Angle
						FW_NORMAL,						// Font Weight
						FALSE,							// Italic
						FALSE,							// Underline
						FALSE,							// Strikeout
						ANSI_CHARSET,					// Character Set Identifier
						OUT_TT_PRECIS,					// Output Precision
						CLIP_DEFAULT_PRECIS,			// Clipping Precision
						ANTIALIASED_QUALITY,			// Output Quality
						FF_DONTCARE|DEFAULT_PITCH,		// Family And Pitch
						"Book Antiqua");				// Font Name

	SelectObject(h, font);							// Selects The Font We Want

	wglUseFontBitmaps(h, 32, 96, base);				// Builds 96 Characters Starting At Character 32
	pulse = 0;
	height = .7;
	width = -1.0;
	count = 0;

}

Font::Font(HDC hc, int h, int w, int ang, int oang, int fw, BYTE ital, BYTE ul, BYTE so, BYTE csi,
		   BYTE op, BYTE cp, BYTE oq, BYTE fp, LPCTSTR fn)

{

	HFONT	font;										// Windows Font ID

	base = glGenLists(96);								// Storage For 96 Characters

	font = CreateFont(	h,						     	// Height Of Font
						w,								// Width Of Font
						ang,							// Angle Of Escapement
						oang,							// Orientation Angle
						fw,					        	// Font Weight
						ital,							// Italic
						ul,						    	// Underline
						so,						    	// Strikeout
						csi,					        // Character Set Identifier
						op,								// Output Precision
						cp,								// Clipping Precision
						oq,								// Output Quality
						fp,								// Family And Pitch
						fn);							// Font Name

	SelectObject(hc, font);							// Selects The Font We Want

	wglUseFontBitmaps(hc, 32, 96, base);				// Builds 96 Characters Starting At Character 32
	height = .7;
	width = -1.0;
	count = 0;

}

Font::DestroyFont()
{
	glDeleteLists(base, 96);							// Delete All 96 Characters
}

void Font::FontPrint(const char *fmt, ...)
{
				char		text[256];								// Holds Our String
	va_list		ap;										// Pointer To List Of Arguments

	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing

	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);											// Results Are Stored In Text
	
	for(int i = 0; i<256; i++)
		message[count][i] = text[i];
	count++;
}

	Font::FontFlush()
{
	glPushMatrix();
	glLoadIdentity();
	glDisable(GL_DEPTH_TEST);
	//glDisable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glTranslatef(0.0,0.0,-3.2);
	glColor4f(1.0,.1,.1, .4);

	int i=0;

	while(i < count)
	{
	glRasterPos2f(width,height);
	glPushAttrib(GL_LIST_BIT);										// Pushes The Display List Bits
	glListBase(base - 32);											// Sets The Base Character to 32
	glCallLists(strlen(message[i]), GL_UNSIGNED_BYTE, message[i]);	// Draws The Display List Text
	glPopAttrib();													// Pops The Display List Bits

	height = height - .04;
	if (height < -.7)
		{
			height = .7;
			width = width + .4;
		}
	i++;
	}

	glColor3f(1.0,1.0,1.0);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glPopMatrix();
	count = 0;
	height = .7;
	width = -1.0;
}
