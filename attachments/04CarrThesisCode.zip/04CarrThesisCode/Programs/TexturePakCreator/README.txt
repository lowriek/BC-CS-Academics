Creates a packed file of textures.

Only supports bitmaps.

Outputs a output.txp file

Modify default.txt to remove or add files.

Must have number of textures as parameter at top of file.