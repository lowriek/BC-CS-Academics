#ifndef _TRACER_H
#define _TRACER_H

//Necessary stuct Typedefs
struct color{
	float r,g,b;
};

struct point3d{
    float x,y,z;
};


struct ray{
	point3d p0;
	point3d p1;
	float rIndex;
};


struct avector{
	float x,y,z;
};


//Tracer object super-class definition
class Tracer{
	protected:
		//all objects will use at least one of the vars below
		color color1, color2;
		int mirror1, mirror2;
		double finalT;
		
		//any objects using texture mapping use the vars below
		unsigned char *imageBuffer;
		int isTextured;
		int TXRes, TYRes;
		int imageHeight, imageWidth;
		
		//Other optional surface parameters
		float reflectAmt1;
		float refractIndex1;
		float transAmt1;
		float reflectAmt2;
		float refractIndex2;
		float transAmt2;
		int horizontalChecks;
		int verticalChecks;
		
		//all objects store ray intersection point
		point3d intersection;
		point3d translatedIntersection;		
		ray inRay;
		ray transRay;
	
		//variables for the new matrix-define orientation system
		float object_rotation[4][4];
		float world_rotation[4][4];
		float translation[4][4];
		float scale[4][4];
		float compositeMatrix[4][4];
		float inverseCompositeMatrix[4][4];
		int didInverse;
		int didComposite;
		int didNormal;
					
	public:
		Tracer();							//Standard constructor
		Tracer(color c1, int m1);			//Alternate constructor
		
		//mutators
		void setColor1(color c1);			//sets primary object color
		void setColor2(color c2);			//sets secondary object color
		void setMirror1(int m1);			//sets primary mirror value
		void setMirror2(int m2);			//sets secondary mirror value
		void setReflectAmt1(float ra);		//sets reflection amount of object
		void setRefractIndex1(float ri);		//sets refraction amount of object
		void setTransAmt1(float ta);			//sets transparency value of object
		void setReflectAmt2(float ra);		//sets reflection amount of object
		void setRefractIndex2(float ri);		//sets refraction amount of object
		void setTransAmt2(float ta);			//sets transparency value of object
		void setTXRes(int txr);				//sets X-resolution of textures
		void setTyRes(int tyr);				//sets Y-resolution of textures
		void setHorizontalChecks(int i);
		void setVerticalChecks(int i);
		//matrix stuff
		void setWorldRotationMatrix(point3d inM);
		void setObjectRotationMatrix(point3d inM);
		void setTranslationMatrix(point3d inM);
		void setScaleMatrix(point3d inM);
		void setCompositeMatrix(float inM[4][4]);
		void setInverseCompositeMatrix(float inM[4][4]);
		void setTranslatedIntersection(point3d ti);
		void setDidInverse(int i);
		void setDidComposite(int i);
		void setDidNormal(int i);
		void computeCompositeMatrix();
		void computeInverseCompositeMatrix(float from[4][4], float to[4][4]);	
		int getDidInverse();
		int getDidCompositeMatrix();
		int getDidNormal();
		point3d applyMatrixToPoint(point3d p, float mat[4][4]);
		avector applyMatrixToVector(avector v, float mat[4][4]);
		point3d getTranslatedIntersection();
		
		//accessors
		color getColor1();					//returns primary object color
		color getColor2();					//returns secondary object color
		int getMirror1();					//returns primary mirror value
		int getMirror2();					//returns secondary mirror value
		float getReflectAmt1();				//returns reflection amount of object
		float getRefractIndex1();			//returns refraction amount of object
		float getTransAmt1();				//returns transparency value of object
		float getReflectAmt2();				//returns reflection amount of object
		float getRefractIndex2();			//returns refraction amount of object
		float getTransAmt2();				//returns transparency value of object
		int getTXRes();						//returns X-resolution of textures
		int getTYRes();						//returns Y-resolution of textures
		int getHorizontalChecks();
		int getVerticalChecks();
		avector normalizeVector(avector v);
		color getIlluminatedColor(point3d light);
			
		//functions that must be defined in sub-class objects
		virtual float getIntersection(ray r)=0;
		//other functions subclasses must have for use in the general get Illuminated color method
		virtual color whichColor()=0;
		virtual int	whichMirror()=0;
		virtual float getLongitude()=0;
		virtual float getLatitude()=0;
		virtual avector getNormal()=0;
		virtual color getTexturePixel()=0;
		virtual int inShadow(point3d l)=0;

};

//Tracer Control Block Prototype
struct TCB{
	Tracer * obj;
	TCB * next;
};

//Some Required Variables
extern TCB *top;
extern TCB *current;
extern TCB *current2;


#endif
