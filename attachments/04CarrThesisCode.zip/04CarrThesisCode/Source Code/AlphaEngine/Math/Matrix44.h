#ifndef _CMATRIX44_H_
#define _CMATRIX44_H_

#include "AlphaEngine/Math/Vector3.h"

class CMatrix44  
{
public:
	CMatrix44();
    CMatrix44(const float matrix[4][4]);
    CMatrix44(const CMatrix44& matrix);
    CMatrix44(	float fEntry00, float fEntry01, float fEntry02, float fEntry03,
				float fEntry10, float fEntry11, float fEntry12, float fEntry13,
				float fEntry20, float fEntry21, float fEntry22, float fEntry23,
				float fEntry30, float fEntry31, float fEntry32, float fEntry33);

	float*		operator[] (int row) const;
    
    CMatrix44&	operator= (const CMatrix44& matrix);
    bool		operator== (const CMatrix44& matrix) const;
    bool		operator!= (const CMatrix44& matrix) const;

    CMatrix44	operator+ (const CMatrix44& matrix) const;
    CMatrix44	operator- (const CMatrix44& matrix) const;
    CMatrix44	operator* (const CMatrix44& matrix) const;
    CMatrix44	operator- () const;
    CVector3	operator* (const CVector3& rkVector) const;
	CMatrix44	operator* (float fScalar) const;
	
	void		identity();
	void		scale(CVector3 scalar);
	void		rotateX(float radAngle);
	void		rotateY(float radAngle);
	void		rotateZ(float radAngle);
	void		translate(CVector3 delta);
	void		zero();

	virtual ~CMatrix44();
protected:
	float m_matrix[4][4];
	static const CMatrix44 ZERO;
};

#endif
