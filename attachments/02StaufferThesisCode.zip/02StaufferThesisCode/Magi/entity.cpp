/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENTITY.CPP							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 29, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */




#include "entity.h"

//PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
//PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;

Font * Entity::messenger;
bool   Entity::debugOut;
long   Entity::vPoint[3];
bool   Entity::keys[256];
int		Entity::drawMode;
float * Entity::frustum;


Entity::Entity()
{
	child = NULL;
	next = NULL;
	prev = NULL;
	parent = NULL;
	testSight = true;
	
	

}


Entity::Entity(float a, float b, float c)
{
	x = a; y = b; z = c;
	Entity();
}

void Entity::Draw()
{

}

void Entity::Kill()
{
	if(next != NULL)
		next->Kill();
	if(child != NULL)
		child->Kill();

}

Entity::AddChild(Entity * e)
{
	Entity * temp;
	temp = child;
	if(temp != NULL)
	{
		while(temp->next != NULL)
			temp = temp->next;
	temp->next = e;	
	e->prev = temp;
	e->next = NULL;
	e->parent = this;
	}
	else
	{
	child = e;
	e->prev = NULL;
	e->next = NULL;
	e->parent = this;
	}
	
}




float Entity::GetHeight(float xPos, float zPos)
{
	
	
	if(parent == NULL)
		return 0;
	else
	return parent->GetHeight(xPos,zPos);
	
	//return 1;
  }

float Entity::IsVisible()
{
	int p;
	float d = 0;
	float closestWall = 0;

   for( p = 0; p < 6; p++ )
   {
	  d = frustum[4*p+0] * x + frustum[4*p+1] * y + frustum[4*p+2] * z + frustum[4*p+3];
      if( (d <= -boundingRadius))
         return 0;
   }
	  return d;
}

// Modified version originally explained by Mark Morley www.markmorley.com	
float Entity::IsVisible(long a, long b, long c, long rd)
{
	int p;
	float d = 0;
	float closestWall = 99999999999;

   for( p = 0; p < 6; p++ )
   {
	  d = frustum[4*p+0] * a + frustum[4*p+1] * b + frustum[4*p+2] * c + frustum[4*p+3];
      if( (d <= -rd))
         return 0;
   }
	  return (sqrt(abs(int(a-vPoint[0]))*abs(int(a-vPoint[0])) + abs(int(b-vPoint[1]))*abs(int(b-vPoint[1])) + abs(int(c-vPoint[2]))*abs(int(c-vPoint[2]))) - rd);
}



float * Entity::MakeFrustum()
{
	float	proj[16];
	float	modl[16];
	float	clip[16];
	float	t;
	float * frustum;

	frustum = (float *)malloc(sizeof(float)*24);



	glGetFloatv(GL_PROJECTION_MATRIX, proj);
	glGetFloatv(GL_MODELVIEW_MATRIX, modl);



/* Combine the two matrices (multiply projection by modelview) */
   clip[ 0] = modl[ 0] * proj[ 0] + modl[ 1] * proj[ 4] + modl[ 2] * proj[ 8] + modl[ 3] * proj[12];
   clip[ 1] = modl[ 0] * proj[ 1] + modl[ 1] * proj[ 5] + modl[ 2] * proj[ 9] + modl[ 3] * proj[13];
   clip[ 2] = modl[ 0] * proj[ 2] + modl[ 1] * proj[ 6] + modl[ 2] * proj[10] + modl[ 3] * proj[14];
   clip[ 3] = modl[ 0] * proj[ 3] + modl[ 1] * proj[ 7] + modl[ 2] * proj[11] + modl[ 3] * proj[15];

   clip[ 8] = modl[ 8] * proj[ 0] + modl[ 9] * proj[ 4] + modl[10] * proj[ 8] + modl[11] * proj[12];
   clip[ 9] = modl[ 8] * proj[ 1] + modl[ 9] * proj[ 5] + modl[10] * proj[ 9] + modl[11] * proj[13];
   clip[10] = modl[ 8] * proj[ 2] + modl[ 9] * proj[ 6] + modl[10] * proj[10] + modl[11] * proj[14];
   clip[11] = modl[ 8] * proj[ 3] + modl[ 9] * proj[ 7] + modl[10] * proj[11] + modl[11] * proj[15];

   clip[ 4] = modl[ 4] * proj[ 0] + modl[ 5] * proj[ 4] + modl[ 6] * proj[ 8] + modl[ 7] * proj[12];
   clip[ 5] = modl[ 4] * proj[ 1] + modl[ 5] * proj[ 5] + modl[ 6] * proj[ 9] + modl[ 7] * proj[13];
   clip[ 6] = modl[ 4] * proj[ 2] + modl[ 5] * proj[ 6] + modl[ 6] * proj[10] + modl[ 7] * proj[14];
   clip[ 7] = modl[ 4] * proj[ 3] + modl[ 5] * proj[ 7] + modl[ 6] * proj[11] + modl[ 7] * proj[15];

   clip[12] = modl[12] * proj[ 0] + modl[13] * proj[ 4] + modl[14] * proj[ 8] + modl[15] * proj[12];
   clip[13] = modl[12] * proj[ 1] + modl[13] * proj[ 5] + modl[14] * proj[ 9] + modl[15] * proj[13];
   clip[14] = modl[12] * proj[ 2] + modl[13] * proj[ 6] + modl[14] * proj[10] + modl[15] * proj[14];
   clip[15] = modl[12] * proj[ 3] + modl[13] * proj[ 7] + modl[14] * proj[11] + modl[15] * proj[15];

   
     

   /* Extract the numbers for the RIGHT plane */
   frustum[0] = clip[ 3] - clip[ 0];
   frustum[1] = clip[ 7] - clip[ 4];
   frustum[2] = clip[11] - clip[ 8];
   frustum[3] = clip[15] - clip[12];

   /* Normalize the result */
   t = sqrt( frustum[0] * frustum[0] + frustum[1] * frustum[1] + frustum[2] * frustum[2] );
   frustum[0] /= t;
   frustum[1] /= t;
   frustum[2] /= t;
   frustum[3] /= t;

   /* Extract the numbers for the LEFT plane */
   frustum[4] = clip[ 3] + clip[ 0];
   frustum[5] = clip[ 7] + clip[ 4];
   frustum[6] = clip[11] + clip[ 8];
   frustum[7] = clip[15] + clip[12];

   /* Normalize the result */
   t = sqrt( frustum[4] * frustum[4] + frustum[5] * frustum[5] + frustum[6] * frustum[6] );
   frustum[4] /= t;
   frustum[5] /= t;
   frustum[6] /= t;
   frustum[7] /= t;

   /* Extract the BOTTOM plane */
   frustum[8] = clip[ 3] + clip[ 1];
   frustum[9] = clip[ 7] + clip[ 5];
   frustum[10] = clip[11] + clip[ 9];
   frustum[11] = clip[15] + clip[13];

   /* Normalize the result */
   t = sqrt( frustum[8] * frustum[8] + frustum[9] * frustum[9] + frustum[10] * frustum[10] );
   frustum[8] /= t;
   frustum[9] /= t;
   frustum[10] /= t;
   frustum[11] /= t;

   /* Extract the TOP plane */
   frustum[12] = clip[ 3] - clip[ 1];
   frustum[13] = clip[ 7] - clip[ 5];
   frustum[14] = clip[11] - clip[ 9];
   frustum[15] = clip[15] - clip[13];

   /* Normalize the result */
   t = sqrt( frustum[12] * frustum[12] + frustum[13] * frustum[13] + frustum[14] * frustum[14] );
   frustum[12] /= t;
   frustum[13] /= t;
   frustum[14] /= t;
   frustum[15] /= t;
   /* Extract the FAR plane */
   frustum[16] = clip[ 3] - clip[ 2];
   frustum[17] = clip[ 7] - clip[ 6];
   frustum[18] = clip[11] - clip[10];
   frustum[19] = clip[15] - clip[14];

   /* Normalize the result */
   t = sqrt( frustum[16] * frustum[16] + frustum[17] * frustum[17] + frustum[18] * frustum[18] );
   frustum[16] /= t;
   frustum[17] /= t;
   frustum[18] /= t;
   frustum[19] /= t;

   /* Extract the NEAR plane */
   frustum[20] = clip[ 3] + clip[ 2];
   frustum[21] = clip[ 7] + clip[ 6];
   frustum[22] = clip[11] + clip[10];
   frustum[23] = clip[15] + clip[14];

   /* Normalize the result */
   t = sqrt( frustum[20] * frustum[20] + frustum[21] * frustum[21] + frustum[22] * frustum[22] );
   frustum[20] /= t;
   frustum[21] /= t;
   frustum[22] /= t;
   frustum[23] /= t;

   return frustum;
}

unsigned int LoadTGA(const char * filename, float envType)				            // Loads A TGA File Into Memory
{    
	GLubyte		TGAheader[12]={0,0,2,0,0,0,0,0,0,0,0,0};		// Uncompressed TGA Header
	GLubyte		TGAcompare[12];									// Used To Compare TGA Header
	GLubyte		header[6];										// First 6 Useful Bytes From The Header
	GLuint		bytesPerPixel;									// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint		imageSize;										// Used To Store The Image Size When Setting Aside Ram
	GLuint		temp;											// Temporary Variable
	GLuint		type=GL_RGBA;									// Set The Default GL Mode To RBGA (32 BPP)
	int	width, height, bpp;
    unsigned char *imageData;
	unsigned int texID;

	FILE *file = fopen(filename, "rb");							// Open The TGA File

	if(	file==NULL ||											// Does File Even Exist?
		fread(TGAcompare,1,sizeof(TGAcompare),file)!=sizeof(TGAcompare) ||	// Are There 12 Bytes To Read?
		memcmp(TGAheader,TGAcompare,sizeof(TGAheader))!=0				||	// Does The Header Match What We Want?
		fread(header,1,sizeof(header),file)!=sizeof(header))				// If So Read Next 6 Header Bytes
	{
		if (file == NULL)										// Did The File Even Exist? *Added Jim Strong*
			return 0;										// Return False
		else													// Otherwise
		{
			fclose(file);										// If Anything Failed, Close The File
			return 0;										// Return False
		}
	}

	width  = header[1] * 256 + header[0];				// Determine The TGA Width	(highbyte*256+lowbyte)
	height = header[3] * 256 + header[2];				// Determine The TGA Height	(highbyte*256+lowbyte)
    
 	if(	width	<=0	||									// Is The Width Less Than Or Equal To Zero
		height	<=0	||									// Is The Height Less Than Or Equal To Zero
		(header[4]!=24 && header[4]!=32))						// Is The TGA 24 or 32 Bit?
	{
		fclose(file);											// If Anything Failed, Close The File
		return 0;											// Return False
	}

	bpp	= header[4];		           						// Grab The TGA's Bits Per Pixel (24 or 32)
	bytesPerPixel	= bpp/8;			    				// Divide By 8 To Get The Bytes Per Pixel
	imageSize		= width*height*bytesPerPixel;       	// Calculate The Memory Required For The TGA Data

	imageData = (GLubyte *)malloc(sizeof(unsigned char)*imageSize);   // Reserve Memory To Hold The TGA Data

	if(	imageData==NULL ||								    // Does The Storage Memory Exist?
		fread(imageData, 1, imageSize, file)!=imageSize)	// Does The Image Size Match The Memory Reserved?
	{
		if(imageData!=NULL)							// Was Image Data Loaded
			free(imageData);							// If So, Release The Image Data

		fclose(file);											// Close The File
		return 0;											// Return False
	}

	for(GLuint i=0; i<int(imageSize); i+=bytesPerPixel)			// Loop Through The Image Data
	{															// Swaps The 1st And 3rd Bytes ('R'ed and 'B'lue)
		temp=imageData[i];								// Temporarily Store The Value At Image Data 'i'
		imageData[i] = imageData[i + 2];		// Set The 1st Byte To The Value Of The 3rd Byte
		imageData[i + 2] = temp;						// Set The 3rd Byte To The Value In 'temp' (1st Byte Value)
	}

	fclose (file);												// Close The File

		if (bpp==24)										// Was The TGA 24 Bits
	{
		type=GL_RGB;											// If So Set The 'type' To GL_RGB
	}

	if(bpp == 32)
	{
		type = GL_RGBA;
	}
	// Build A Texture From The Data
	glGenTextures(1, &texID);				            		// Generate OpenGL texture IDs

	glBindTexture(GL_TEXTURE_2D, texID);				        // Bind Our Texture

	gluBuild2DMipmaps(GL_TEXTURE_2D, (int)(bpp/8), width, height, type, GL_UNSIGNED_BYTE, imageData);
	//glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_DECAL);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);	// Linear Filtered
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);	// Linear Filtered
	


	glTexImage2D(GL_TEXTURE_2D, 0 , (int)bpp/8, width, height, 0, type, GL_UNSIGNED_BYTE, imageData);

	free(imageData);
	return texID;												// Texture Building Went Ok, Return True
}

