#if !defined(AFX_VIEWPORTCONTAINER_H__65674514_08E6_4FFE_AEDE_32755EDC1A83__INCLUDED_)
#define AFX_VIEWPORTCONTAINER_H__65674514_08E6_4FFE_AEDE_32755EDC1A83__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OpenGLView.h"
#include "Viewport.h"

#include <list>

class CViewportContainer : public COpenGLView
{
protected:
	CViewportContainer();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewportContainer)

// Attributes
public:


	list<CViewport *> listViewports;
// Operations
public:
	void			AddViewport(CViewport * viewport);
	CPoint			AdjustPoint(CViewport * viewport, CPoint point);
	CViewport *		GetViewport(CPoint point);
	void			CreateView(float perX, float perY, float perWidth, float perHeight);
	virtual BOOL	InitOpenGL();
	virtual void	Render();
	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewportContainer)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewportContainer();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CViewportContainer)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWPORTCONTAINER_H__65674514_08E6_4FFE_AEDE_32755EDC1A83__INCLUDED_)
