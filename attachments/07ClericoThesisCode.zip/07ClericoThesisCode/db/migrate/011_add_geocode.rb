class AddGeocode < ActiveRecord::Migration
  def self.up
  	add_column :profiles, :longitude, :decimal, :precision => 9, :scale=> 6
  	add_column :profiles, :latitude, :decimal, :precision => 9, :scale=> 6
  end

  def self.down
  	remove_column :profiles, :longitude
  	remove_column :profiles, :latitude  	
  end
end
