# import_nascar_stats.rb

require 'rubygems'
require 'hpricot'

statfile = 'nascar_statfile.list'

doc = Hpricot(open(statfile))
race = (doc/'nascarstats/race').attr('name')
# create the game
Game.create :name => race

(doc/'nascarstats/race/stat').each { |s|
	player = s.get_attribute('name')
	carnum = s.get_attribute('carnum')
	make = s.get_attribute('make')
	laps = s.get_attribute('laps')
	money = s.get_attribute('money')
	startpos = s.get_attribute('startpos')
	finalpos = s.get_attribute('finalpos')
	lapsled = s.get_attribute('lapsled')
	points = s.get_attribute('points')
	bonus = s.get_attribute('bonus')
	penalty = s.get_attribute('penalty')
	
	Team.create :name => player.gsub(/ /,''), :sport_id => Sport.find_by_name('nascar').id
	Rosterspot.create :team_id => Team.find_by_name(player.gsub(/ /,'')).id, :player_id => Player.find_by_name(player).id
	GameTeam.create :game_id => Game.find_by_name(race).id, :team_id => Team.find_by_name(player.gsub(/ /,'')).id

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('laps').id, :value => laps

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('money').id, :value => money

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('laps_led').id, :value => lapsled

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('points').id, :value => points

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('bonus').id, :value => bonus

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('penalty').id, :value => penalty

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('start_pos').id, :value => startpos

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('final_pos').id, :value => finalpos

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('carnumber').id, :value => carnum

	Stat.create :game_id => Game.find_by_name(race).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name('carmake').id, :value => make
}
