#ifndef _PLANE_H
#define _PLANE_H

#include "server.h"


//Plane Class Definition
class Plane:Tracer{
	private:
		point3d location;
		float d;
		avector sVector, tVector;
		int WHICHCM;
		
	public:
		Plane();
		Plane(color c1, color c2, point3d l, float x);
		
		//Mutator Methods
		void setLocation(point3d l);
		void setD(float x);
		void setSCoordVector(point3d sv);
		void setTCoordVector(point3d tv);
		
		//Accessor Methods
		point3d getLocation();
		float getD();
		avector getSCoordVector();
		avector getTCoordVector();
		
		//Required Methods for use by the getIlluminatedColor Method
		float getIntersection(ray r);
		color whichColor();
		int whichMirror();
		float getLongitude();
		float getLatitude();
		color getTexturePixel();
		avector getNormal();
		int inShadow(point3d light);
};

#endif
