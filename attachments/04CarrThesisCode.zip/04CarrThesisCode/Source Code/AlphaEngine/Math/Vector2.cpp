#include "Vector2.h"

CVector2::CVector2(float x, float y)
{
	this->x = x;
	this->y = y;
}

CVector2::CVector2()
{
	x = y = 0;
}

CVector2::~CVector2()
{

}

CVector2& CVector2::operator= (const CVector2& rVector)
{
	x = rVector.x;
	y = rVector.y;
    return *this;
}

bool CVector2::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&x, sizeof(float), 1, filePtr);
		fwrite(&y, sizeof(float), 1, filePtr);
	}
	else
	{
		fread(&x, sizeof(float), 1, filePtr);
		fread(&y, sizeof(float), 1, filePtr);
	}

	return true;
}