#include "Matrix44.h"
#include <math.h>
#include <string.h>

const CMatrix44 CMatrix44::ZERO(0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f);
CMatrix44::CMatrix44()
{

}
CMatrix44::CMatrix44(const CMatrix44 &matrix)
{
	memcpy(m_matrix, matrix.m_matrix, 16*sizeof(float));
}
CMatrix44::CMatrix44(const float matrix[4][4])
{
    memcpy(m_matrix, matrix,16*sizeof(float));
}
CMatrix44::CMatrix44(	float fEntry00, float fEntry01, float fEntry02, float fEntry03,
						float fEntry10, float fEntry11, float fEntry12, float fEntry13,
						float fEntry20, float fEntry21, float fEntry22, float fEntry23,
						float fEntry30, float fEntry31, float fEntry32, float fEntry33)
{
	m_matrix[0][0] = fEntry00; m_matrix[0][1] = fEntry01; m_matrix[0][2] = fEntry02; m_matrix[0][3] = fEntry03;
	m_matrix[1][0] = fEntry10; m_matrix[1][1] = fEntry11; m_matrix[1][2] = fEntry12; m_matrix[1][3] = fEntry13;
	m_matrix[2][0] = fEntry20; m_matrix[2][1] = fEntry21; m_matrix[2][2] = fEntry22; m_matrix[2][3] = fEntry23;
	m_matrix[3][0] = fEntry30; m_matrix[3][1] = fEntry31; m_matrix[3][2] = fEntry32; m_matrix[3][3] = fEntry33;
}

void CMatrix44::identity()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (i==j)
				m_matrix[i][j] = 1.0f;
			else
				m_matrix[i][j] = 0.0f;
		}
	}
}

CMatrix44::~CMatrix44()
{

}

bool CMatrix44::operator!= (const CMatrix44& matrix) const
{
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			if (m_matrix[x][y] != matrix.m_matrix[x][y])
				return true;

	return false;
}

CVector3 CMatrix44::operator* (const CVector3& rkPoint) const
{
	/*
		TODO: OPTIMIZE THIS!
	*/
	float answer[4][1];
	float temp[4][1];
	float sum = 0;
	temp[0][0] = rkPoint[0];
	temp[1][0] = rkPoint[1];
	temp[2][0] = rkPoint[2];
	temp[3][0] = 1;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j<1; j++)
		{
			sum = 0;
			for (int k = 0; k < 4; k++)
			{
				sum += m_matrix[i][k] * temp[k][j];
			}
			answer[i][j] = sum;
		}
	}
	CVector3 result(answer[0][0], answer[1][0], answer[2][0]);
	return result;
}

CMatrix44 CMatrix44::operator* (float fScalar) const
{
	CMatrix44 product;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
            product[i][j] = fScalar* m_matrix[i][j];
    }
    return product;
}

CMatrix44 CMatrix44::operator* (const CMatrix44& matrix) const
{
    CMatrix44 product;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
			product.m_matrix[i][j] = 
				m_matrix[i][0] * matrix.m_matrix[0][j] +
				m_matrix[i][1] * matrix.m_matrix[1][j] +
				m_matrix[i][2] * matrix.m_matrix[2][j] +
				m_matrix[i][3] * matrix.m_matrix[3][j];
        }
    }
    return product;
}

CMatrix44 CMatrix44::operator+ (const CMatrix44& matrix) const
{
	CMatrix44 sum;
	for (int i = 0; i < 4; i++) 
	{
		for (int j = 0; j < 4; j++)
		{
			sum.m_matrix[i][j] = m_matrix[i][j] + matrix.m_matrix[i][j];
		}
	}
	return sum;
}

CMatrix44 CMatrix44::operator- () const
{
    CMatrix44 neg;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
            neg[i][j] = -m_matrix[i][j];
    }
    return neg;	
}

CMatrix44 CMatrix44::operator- (const CMatrix44& matrix) const
{
	CMatrix44 sub;
	for (int i = 0; i < 4; i++) 
	{
		for (int j = 0; j < 4; j++)
		{
			sub.m_matrix[i][j] = m_matrix[i][j] - matrix.m_matrix[i][j];
		}
	}
	return sub;
}

CMatrix44& CMatrix44::operator= (const CMatrix44& matrix)
{
    memcpy(m_matrix, matrix.m_matrix,16*sizeof(float));
    return *this;
}

bool CMatrix44::operator== (const CMatrix44& matrix) const
{
	for (int i = 0; i < 4; i++) 
	{
		for (int j = 0; j < 4; j++)
		{
			if (m_matrix[i][j] != matrix.m_matrix[i][j])
				return false;
		}
	}
	return true;
}

float* CMatrix44::operator[] (int row) const
{
    return (float*)&m_matrix[row][0];
}

void CMatrix44::rotateX(float radAngle)
{
	identity();

	float c =(float)cos((double) radAngle);
	float s =(float)sin((double) radAngle);
	
	m_matrix[0][0] = 1.0f;
	m_matrix[1][1] = c;
	m_matrix[1][2] = -s;
	m_matrix[2][1] = s;
	m_matrix[2][2] = c;
	m_matrix[3][3] = 1.0f;
}

void CMatrix44::rotateY(float radAngle)
{
	identity();

	float c =(float)cos((double) radAngle);
	float s =(float)sin((double) radAngle);

	m_matrix[0][0] = c;
	m_matrix[0][2] = s;
	m_matrix[1][1] = 1.0f;
	m_matrix[2][0] = -s;
	m_matrix[2][2] = c;
	m_matrix[3][3] = 1.0f;
}

void CMatrix44::rotateZ(float radAngle)
{
	identity();

	float c =(float)cos((double) radAngle);
	float s =(float)sin((double) radAngle);

	m_matrix[0][0] = c;
	m_matrix[0][1] = -s;
	m_matrix[1][0] = s;
	m_matrix[1][1] = c;
	m_matrix[2][2] = 1.0f;
	m_matrix[3][3] = 1.0f;
}

void CMatrix44::scale(CVector3 scalar)
{
	identity();
	m_matrix[0][0] = scalar[0];
	m_matrix[1][1] = scalar[1];
	m_matrix[2][2] = scalar[2];	
}

void CMatrix44::translate(CVector3 delta)
{
	identity();
	m_matrix[0][3] = delta[0];
	m_matrix[1][3] = delta[1];
	m_matrix[2][3] = delta[2];
}

void CMatrix44::zero()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			m_matrix[i][j] = 0.0f;
		}
	}
}