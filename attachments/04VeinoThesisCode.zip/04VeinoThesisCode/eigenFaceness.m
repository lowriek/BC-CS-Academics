function mymatrix = eigenFaceness(im, eigFaces,meanFace,width,height);
%function mymatrix = eigenFaceness(im, eigFaces,meanFace,width,height);
%INPUT
%    im : a grayscale image
%    eigFaces: the eigenFaces from PCA
%    meanFace: the meanFace from PCA
%    width,height: the width and height of the box to use
%OUTPUT
%    mymatrix : A matrix of the "faceness" of each pixel

[m,n] = size(im);
counter=0;counter2=1;
h = fspecial('gaussian',31,4);
im = imfilter(im,h); mymin = 9999;  mymax = -9999;

   counter=counter+1;
   topleft = [(height/2)+1 (width/2)+1];
   bottomright = [m-(height/2) n-(width/2)];
   matrix = zeros(m-height,n-width);
   
   for I= topleft(1):bottomright(1)
       for J= topleft(2):bottomright(2)
           RECT = [J-(width/2) I-(height/2) width-1 height-1];
           thispic = imcrop(im,RECT);
           [matrix(I-(height/2),J-(width/2)),recreatedFace] = faceVal(thispic,eigFaces,meanFace,width,height,counter,I,J);
       end
       I
   end
   
   if counter == 1
       mymatrix = matrix;
   end
   writepic=1-normalize(matrix);
   
   %********Uncomment the next line if you're making a movie
   %movie2avi(M,['facemovie.avi'],'fps',10);
   
   imwrite(normalize(writepic),['faceness' int2str(counter) '.jpg'],'jpeg');
   fid = fopen('faceness.htm','a');
   fprintf(fid, '<img src="');fprintf(fid,'%s',['faceness' int2str(counter) '.jpg']);
   fprintf(fid,'"><br>'); 
   fclose(fid);
   im=imresize(im,size(im)/sqrt(2),'bilinear');
   [m,n]=size(im);
   %end


function [val,recreatedFace] = faceVal(im,eigFaces,meanFace,width,height,counter,I,J);
%
%
%
imbefore = im;
im  = im / sum(abs(im(:)));
im = reshape(im,1,width*height);

%subtract the mean face
im2 = double(im) - meanFace;
%Take the dot product to determine the weights
myWeights = im2 * eigFaces';
%Now recreate the face by multiplying the weights and eigenfaces and adding
%to the meanFace
recreatedFace = meanFace + myWeights*eigFaces;
val = std(imbefore(:))/(sum(abs(im - recreatedFace))+eps);