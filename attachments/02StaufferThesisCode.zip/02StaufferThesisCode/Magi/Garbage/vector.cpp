/* ----------------------------------------------
   -											-
   -	PROJECT:		Hourglass				-
   -	FILE:			vector.cpp				-	
   -	CREATED:		07/20/01				-
   -	MODIFIED:		07/20/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */

#include "vector.h"

Vector3D::Vector3D()
{
	x = 0;
	y = 0;
	z = 0;
}

Vector3D::Vector3D(float a, float b, float c)
{
	x = a;
	y = b;
	z = c;
}

Vector3D::~Vector3D()
{

}


Vector3D Vector3D::operator +(const Vector3D & v) const
{
	return(Vector3D(x + v.x, y + v.y, z + v.z));
}

Vector3D Vector3D::operator -(const Vector3D & v) const
{
	return(Vector3D(x - v.x, y - v.y, z - v.z));
}

Vector3D Vector3D::operator *(const float f) const
{
	return(Vector3D(x * f, y * f, z * f));
}

float	 Vector3D::operator *(const Vector3D & v) const
{
	return(x * v.x + y * v.y + z * v.z);
}






