#include "AlphaEngine/PVS/Sector.h"

void CSector::addPolygon(CPolygon* pPolygon)
{
	if (this->pPolygon)
		this->pPolygon->add(pPolygon);
	else
		this->pPolygon = pPolygon;
}

void CSector::addPortal(CPortal* pPortal)
{
	portalList.add(pPortal);
}

CSector::CSector()
{
	pPolygon = 0;
	beingVisited = false;
}

CSector::~CSector()
{
	if (pPolygon)
		delete pPolygon;

	portalList.clear();
}

bool CSector::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	unsigned int i = 0;
	unsigned int numPolygon = 0;
	unsigned int numPortal = portalList.size();
	CPolygon* pRoot = 0;
	
	if (pPolygon)
	{
		pRoot = pPolygon;	
		while (pRoot != 0)
		{
			numPolygon++;
			pRoot = pRoot->pNext;
		}
	}

	if (isStoring)
	{
		// save polygons
		fwrite(&numPolygon, sizeof(unsigned int), 1, filePtr);
		if (numPolygon > 0)
		{
			pRoot = pPolygon;
			while (pRoot != 0)
			{
				pRoot->serialize(filePtr, isStoring);
				pRoot = pRoot->pNext;
			}
		}
		// save portals
		fwrite(&numPortal, sizeof(unsigned int), 1, filePtr);
		for (i = 0; i < numPortal; i++)
		{
			CPortal* pPortal = portalList.get(i);
			pPortal->serialize(filePtr, isStoring);
		}
	}
	else
	{
		fread(&numPolygon, sizeof(unsigned int), 1, filePtr);
		for (i = 0; i < numPolygon; i++)
		{
			CPolygon* pTemp = new CPolygon();
			pTemp->serialize(filePtr, isStoring);
			if (pPolygon)
				pPolygon->add(pTemp);
			else
				pPolygon = pTemp;
		}
		fread(&numPortal, sizeof(unsigned int), 1, filePtr);
		portalList.clear();
		for (i = 0; i < numPortal; i++)
		{
			CPortal* pPortal = new CPortal();
			pPortal->serialize(filePtr, isStoring);
			portalList.add(pPortal);
		}
	}
	return true;
}





