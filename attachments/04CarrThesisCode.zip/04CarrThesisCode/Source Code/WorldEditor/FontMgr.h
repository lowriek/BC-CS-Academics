// FontMgr.h: interface for the CFontMgr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FONTMGR_H__71D37624_043F_49FB_B496_17557FE5900C__INCLUDED_)
#define AFX_FONTMGR_H__71D37624_043F_49FB_B496_17557FE5900C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFontMgr  
{
public:
	CFontMgr();
	virtual ~CFontMgr();
	virtual bool CreateBitmapFont(HDC hDC, char *font, int fontSize);
	virtual void PrintString(char *str, float x, float y, float z);
private:
	int base;
};

#endif // !defined(AFX_FONTMGR_H__71D37624_043F_49FB_B496_17557FE5900C__INCLUDED_)
