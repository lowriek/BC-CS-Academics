
#include "world.h"
#include <math.h>
#include <gl\gl.h>			//OpenGL Library
#include <gl\glu.h>			// GLU library
#include <stdio.h>

#define CUBEOFFSET 0.2

#define BOUNDRY 100 //how many units in axis direction from origin we can move

int placeCounter=0;

extern void mallocTree(octnode *root, int levels)
{
  int x, temp=levels;
  
  if (levels == 0)
  {  
    //set all leaves to NULL 
    for (x=0;x<8;x++)
	{
	  root->child[x] = NULL;
	}
  }
  else
  {
	//it's not a leaf.  Malloc the leaves and recurse into them.

    for (x=0;x<8;x++)
    { 
      levels = temp;
      root->child[x] = (octnode *)malloc(sizeof(octnode));
      levels--;
      mallocTree(root->child[x],levels);
    }
  }
}

//for debugging purposes--dumps tree structure with values into an ASCII file
extern void dumpTree(octnode *current, int levels)
{   
	static FILE *dumpfile;
    int x;
    static int first = 1;

	if (first) {
		first = 0;
		dumpfile = fopen("dump.txt", "w");
	}
	
	fprintf(dumpfile,"\n");
	fprintf(dumpfile,"isLeaf: %d   dl is: %d   Levels is %d\n", current->isLeaf, current->dl, levels);
 
	for (x=0;x<8;x++)
	  fprintf(dumpfile,"Point %d is %d %d %d\n",x,current->bb[x].x, current->bb[x].y,current->bb[x].z);

	
	if (levels!=0)
	{
		for (x=0;x<8;x++)
		  dumpTree(current->child[x], levels-1);
	}

	//hack.. should be same as LEVELS defined in wiggle.c
    if (levels == LEVELS)
		fclose(dumpfile);

}


extern void drawTriangles(float val, point center)
{

	val/=2;


    glBegin(GL_TRIANGLES);
	/*
	glColor3f(0.0,0,1.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y+val, center.z);
	glColor3f(1.0,1.0,1.0);
	glVertex3f(center.x+val, center.y+val, center.z);

	glColor3f(0.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y-val, center.z);
    glColor3f(.5,1.0,1.0);
	glVertex3f(center.x+val, center.y-val, center.z);
 
	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y, center.z-val);
    glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y, center.z-val);

    glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y, center.z+val);
    glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y, center.z+val);
    
	*/
    //24 triangles in total.. fun looking
	//top four diags
    glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y+val, center.z);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x, center.y+val, center.z-val);

	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x, center.y+val, center.z-val);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y+val, center.z);


    glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y+val, center.z);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x, center.y+val, center.z+val);

	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x, center.y+val, center.z+val);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y+val, center.z);
	
    //bottom 4 diags
	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y-val, center.z);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x, center.y-val, center.z-val);

	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x, center.y-val, center.z-val);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y-val, center.z);


    glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-val, center.y-val, center.z);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x, center.y-val, center.z+val);

	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x, center.y-val, center.z+val);
	glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+val, center.y-val, center.z);


		
    //stickin' out left 
	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val, center.y+val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val, center.y+val/2, center.z-val/2);

    glColor3f(0.0f,0.0f,0.0f);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val, center.y-val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val, center.y-val/2, center.z-val/2);


	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val, center.y+val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val, center.y-val/2, center.z+val/2);

    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val, center.y-val/2, center.z-val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val, center.y+val/2, center.z-val/2);

    //stickin' out right 
	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val, center.y+val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val, center.y+val/2, center.z-val/2);

    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val, center.y-val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val, center.y-val/2, center.z-val/2);


	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val, center.y+val/2, center.z+val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val, center.y-val/2, center.z+val/2);

    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val, center.y-val/2, center.z-val/2);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val, center.y+val/2, center.z-val/2);


	
    //stickin' out back 
	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y+val/2, center.z+val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y+val/2, center.z+val);

  	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y-val/2, center.z+val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y-val/2, center.z+val);


	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y+val/2, center.z+val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val/2, center.y-val/2, center.z+val);

    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val/2, center.y-val/2, center.z+val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y+val/2, center.z+val);

    //
    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y+val/2, center.z-val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y+val/2, center.z-val);

  	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y-val/2, center.z-val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y-val/2, center.z-val);


	glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x-val/2, center.y+val/2, center.z-val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x-val/2, center.y-val/2, center.z-val);

    glColor3f(0.0,0.0,0.0);
    glVertex3f(center.x, center.y, center.z); 
    glColor3f(1.0f,.6f,.2f);
	glVertex3f(center.x+val/2, center.y-val/2, center.z-val);
	glColor3f(1.0f,1.0f,.8f);
	glVertex3f(center.x+val/2, center.y+val/2, center.z-val);

	glEnd();
}

/**
  *fillCoords fills in ALL nodes of the tree with world-coordinates
  *It is called in init() from the main file (wiggle.c)
  *All eight vertices of every node, including leaves, are filled out
  */

extern void fillCoords(octnode *current, int value, int levels, point center)
{
  int x=0, y=0,  temp=levels; 
  int tempvalue = value;
  float half_value = (float)(value / 2);
  
  point p;

  int listIndex;
  float tempVal;


  placeCounter++;

  tempVal=(float)(value*.9);
 // tempVal=value-1;  //value is 1/2 side of cube

  if (levels == 0)  //if it is a leaf
  { 
    
	  current->isLeaf=1; //mark it as a leaf


	 // current->dl=0; //no display list
	  

/***********************   place triangles according to a fixed divisor ***********************/
//  The following code places a triangle at every third volume 
//  and rectangles to show appx. cube boundaries



  if(TRUE)
  {

    listIndex=glGenLists(1);
	glNewList(listIndex, GL_COMPILE);

	drawTriangles(tempVal, center);

    glBegin(GL_TRIANGLES);
	
	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-tempVal, center.y+tempVal, center.z);
    glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+tempVal, center.y+tempVal, center.z);


	glColor3f(1.0,0,0.0);
    glVertex3f(center.x, center.y, center.z); //first vertex at center of volume
    glColor3f(0.0,1.0,0.0);
	glVertex3f(center.x-tempVal, center.y-tempVal, center.z);
    glColor3f(0.0,0.0,1.0);
	glVertex3f(center.x+tempVal, center.y-tempVal, center.z);



    glEnd();
    glColor3f(1.0,.5,.5);
	drawCubes((float)value, center);
	glEndList();
    current->dl=listIndex; //assign display list index to structure
	//insert code for six rectangles.. along edges of cube.. remember to move endlist down
  }
  else
  {
	listIndex = glGenLists(1);
	glNewList(listIndex, GL_COMPILE);
    glColor3f(1.0, 1.0, .5);
	drawCubes(half_value, center);
	glEndList();
	current->dl=listIndex; 
  }

/**********************  place rectangles to show cube dividers in world ********************/


    setCoords(current, center, value);
  }
  else
  {
   
	  current->isLeaf=0; //mark it as not a leaf
	  current->dl=0; //display lists only at a leaf

    setCoords(current, center, value);  
	tempvalue = (int)(value/2);


	/**
	  * set values for eight vertices of nodes based on 
	  * center point and "value"--a number representing
	  * the width of the current cube at the depth of LEVELS
	  */

    for (x=0;x<8;x++)
    { 
      p.x = center.x; p.y = center.y;  p.z = center.z;
	  if (levels!=0)
	  {	   
	    switch(x)
	    {
     
	    case (0):
      	  p.x = p.x + (int)(tempvalue);
		  p.y = p.y + (int)(tempvalue);
		  p.z = p.z + (int)(tempvalue);
		 
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (1):
		  p.x = p.x - (int)(tempvalue);
		  p.y = p.y + (int)(tempvalue);
		  p.z = p.z + (int)(tempvalue);
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (2):
	        p.x = p.x - (int)(tempvalue);
		  p.y = p.y + (int)(tempvalue);
		  p.z = p.z - (int)(tempvalue);
	
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (3):
		  p.x = p.x + (int)(tempvalue);
		  p.y = p.y + (int)(tempvalue);
		  p.z = p.z - (int)(tempvalue);
		
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (4):
		  p.x = p.x + (int)(tempvalue);
		  p.y = p.y - (int)(tempvalue);
		  p.z = p.z + (int)(tempvalue);
		 
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (5):
		  p.x = p.x - (int)(tempvalue);
		  p.y = p.y - (int)(tempvalue);
		  p.z = p.z + (int)(tempvalue);
		
		  fillCoords(current->child[x],tempvalue, levels-1, p);
   	          break;
	    case (6):
		  p.x = p.x - (int)(tempvalue);
		  p.y = p.y - (int)(tempvalue);
		  p.z = p.z - (int)(tempvalue);
		  
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    case (7):
		  p.x = p.x + (int)(tempvalue);
		  p.y = p.y - (int)(tempvalue);
		  p.z = p.z - (int)(tempvalue);
		
		  fillCoords(current->child[x],tempvalue, levels-1, p);
	          break;
	    }

	  }
	 
    }
  }

}


/**
  * setCoords takes current node and fills in values for 
  * eight vertices based on center point and value
  */

extern void setCoords(octnode *node, point p, int value)
{

  
  node->bb[0].x = p.x + value;
  node->bb[0].y = p.y + value;
  node->bb[0].z = p.z - value;


  node->bb[1].x = p.x - value;
  node->bb[1].y = p.y + value;
  node->bb[1].z = p.z - value;

 
  node->bb[2].x = p.x - value;
  node->bb[2].y = p.y + value;
  node->bb[2].z = p.z + value;

 
  node->bb[3].x = p.x + value;
  node->bb[3].y = p.y + value;
  node->bb[3].z = p.z + value;

  
  node->bb[4].x = p.x + value;
  node->bb[4].y = p.y - value;
  node->bb[4].z = p.z - value;

  node->bb[5].x = p.x - value;
  node->bb[5].y = p.y - value;
  node->bb[5].z = p.z - value;

 
  node->bb[6].x = p.x - value;
  node->bb[6].y = p.y - value;
  node->bb[6].z = p.z + value;

  node->bb[7].x = p.x + value;
  node->bb[7].y = p.y - value;
  node->bb[7].z = p.z + value;

 
}

//self explanatory movement functions
extern void rotateLeft(float *viewAngle)
{
   *viewAngle = *viewAngle - .05f;
}


extern void rotateRight(float *viewAngle)
{
   *viewAngle = *viewAngle + .05f;
}

//not correct, not implemented
extern void moveRight(GLdouble *eyex, GLdouble *eyez, float *viewAngle)
{
   *eyez= *eyez - (float)(cos(*viewAngle)*stepsize);
   *eyex= *eyex - (float)(sin(*viewAngle)*stepsize);
}

//not correct, not implemented
extern void moveLeft(GLdouble *eyex, GLdouble *eyez, float *viewAngle)
{
   *eyez = *eyez + cos(*viewAngle)*stepsize;
   *eyex = *eyex + sin(*viewAngle)*stepsize;
}

extern void moveForward(GLdouble *eyex, GLdouble *eyez, float *viewAngle)
{
   *eyex= *eyex + (cos(*viewAngle)*stepsize);
   *eyez= *eyez + (sin(*viewAngle)*stepsize); // -sin??

   if (*eyex>BOUNDRY)  *eyex=BOUNDRY;
   if (*eyex<-BOUNDRY) *eyex=-BOUNDRY;
   if (*eyez>BOUNDRY)  *eyez=BOUNDRY;
   if (*eyez<-BOUNDRY) *eyez=-BOUNDRY;
}
extern void runForward(GLdouble *eyex, GLdouble *eyez, float *viewAngle)
{
   *eyex= *eyex + (cos(*viewAngle)*stepsize*3);
   *eyez= *eyez + (sin(*viewAngle)*stepsize*3); // -sin??

   if (*eyex>BOUNDRY)  *eyex=BOUNDRY;
   if (*eyex<-BOUNDRY) *eyex=-BOUNDRY;
   if (*eyez>BOUNDRY)  *eyez=BOUNDRY;
   if (*eyez<-BOUNDRY) *eyez=-BOUNDRY;
}

extern void moveBack(GLdouble *eyex, GLdouble *eyez, float *viewAngle)
{
   *eyex= *eyex - (cos(*viewAngle)*stepsize);
   *eyez= *eyez - (sin(*viewAngle)*stepsize); // +sin??
   if (*eyex>BOUNDRY)  *eyex=BOUNDRY;
   if (*eyex<-BOUNDRY) *eyex=-BOUNDRY;
   if (*eyez>BOUNDRY)  *eyez=BOUNDRY;
   if (*eyez<-BOUNDRY) *eyez=-BOUNDRY;
}


extern void lookUp  (GLdouble *vertAngle)
{
    *vertAngle = *vertAngle +.15f;
}

extern void lookDown(GLdouble *vertAngle)
{
    *vertAngle = *vertAngle -.15f;
}



extern void drawCubes(float half_value, point center)
{
    /**
	  * drawCubes roughly displays the bounding boxes of each leaf
	  * In total, this is twenty-four rectangles per leaf
	  */

	glBegin(GL_QUADS);
	
	//back
	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .3), (float)(center.z + half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .3), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
    
	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .3), (float)(center.z + half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .3), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .3), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
    
	glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x - half_value - .3), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	
	//front
	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .3), (float)(center.z - half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
    
	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .3), (float)(center.z - half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
    glColor3f(0.0,1.0,1.0);
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .3), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .3), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	//left side
	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .3));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .3));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));


	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .3), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .3), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	//right side
	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));


	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .3), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .3), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .3), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	//top
	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .3), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .3), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .3), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));


	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .3));
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y + half_value - .2), (float)(center.z - half_value - .2));

	//bottom
	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .3), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x - half_value - .3), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x + half_value - .3), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .3), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));


	glColor3f(1.0,1.0,0.0);
    glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z + half_value - .2));

	glColor3f(1.0,1.0,0.0);
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
	glVertex3f((float)(center.x - half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .3));
	glColor3f(0.0,1.0,1.0);
    glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .3));
	glVertex3f((float)(center.x + half_value - .2), (float)(center.y - half_value - .2), (float)(center.z - half_value - .2));
glEnd();



}

