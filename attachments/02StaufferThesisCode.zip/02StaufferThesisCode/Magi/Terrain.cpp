/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --																			   	  --
   --						TERRAIN.CPP								    	--
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	OCTOBER 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "terrain.h"
#include "MilkshapeModel.h"

//extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
//extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;

GLuint LoadGLTexture( const char *filename );



float *			 Terrain::terrainData;
float *			 Terrain::normalList[10];
unsigned int Terrain::terrainTextures[10];
float   *		 Terrain::terrainMatrix;
char*			Terrain::roughMatrix;
float *			 Terrain::colorTerrain;


Terrain::Terrain(int sH, int xS, int zS, int a, int b, int c, int rad)
{ 
	scaleHeight = sH; xStep = xS; zStep = zS; boundingRadius = rad;
	x = a; y = b; z = c; Entity();
	for(int i = 0; i<10; i++)
		normalList[i] = NULL;
}

int Terrain::TerrainLoad(char * fn)
{

	FILE * tFile;
	unsigned char ucGarb[5];
	short int siGarb[5];
	int total;
	unsigned char * temp;
	unsigned char type;
	unsigned char pixDepth;
	char tmpName[30];
	

	tFile = fopen(fn, "rb");
	if(tFile == NULL)
		{	
			
			MessageBox(NULL,"Can't Open File For Terrain","ERROR",MB_OK|MB_ICONEXCLAMATION);
			
			return 0;
		}

	// Begin reading in header information

	fread(&ucGarb, sizeof(unsigned char), 2, tFile);
	fread(&type, sizeof(unsigned char), 1, tFile);
	fread(&siGarb, sizeof(short int),2, tFile);
	fread(&ucGarb, sizeof(unsigned char), 1, tFile);
	fread(&siGarb, sizeof(short int), 2, tFile);
	
	// Read in Fields we want
	fread(&width, sizeof(short int), 1, tFile);
	fread(&height, sizeof(short int), 1, tFile);
	fread(&pixDepth, sizeof(unsigned char), 1, tFile);
	
	fread(&ucGarb, sizeof(unsigned char), 1, tFile);
	total = (height * width * (pixDepth / 8));
	temp = (unsigned char *) malloc (sizeof(unsigned char) * total);
	terrainData = (float *) malloc (sizeof(float) * total);

	fread(temp, sizeof(unsigned char), total, tFile);

	if(temp == NULL)
	{
	
		
	    MessageBox(NULL,"Can't Copy terrain data","ERROR",MB_OK|MB_ICONEXCLAMATION);
		fclose(tFile);
		return 0;
	}

	for(int j = 0; j< width * height; j++)	
		terrainData[j] = (((float)temp[j]) / 256) * scaleHeight;

		
		free(temp);

	fclose(tFile);

	/* Open Color Data in BMP of Same File Name */
	int tmpNum = 0;
	strcpy(tmpName,fn);
	while(fn[tmpNum] != '.')
		tmpName[tmpNum] = fn[tmpNum++];
											// Change the name of the file to open the bmp
	tmpName[tmpNum + 1] = 'b';
	tmpName[tmpNum + 2] = 'm';
	tmpName[tmpNum + 3] = 'p';

	AUX_RGBImageRec * colorFile = LoadBMP(tmpName);
	if(colorFile == NULL)
	{
		MessageBox(NULL,"Can't Copy terrain Color from File data","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return 0;
	}

	colorTerrain  = (float * ) malloc(sizeof(float) * 3 * colorFile->sizeX * colorFile->sizeY);

	for(int i = 0; i < colorFile->sizeY * colorFile->sizeX * 3; i++)
	{
		colorTerrain[i] = ((float)colorFile->data[i]) / 256.0;
	//	colorTerrain[i] = 255;
	
	}		
	free(colorFile->data);
	free(colorFile);

	terrainMatrix = (float *)malloc(sizeof(float)*total);
	
	roughMatrix = (char *)malloc(sizeof(char)*total);
	MakeNormals();
	terrainTextures[1] = LoadTGA("Data/newgrass2.tga", GL_DECAL);
	terrainTextures[0] = LoadTGA("Data/rockgrassgrey.tga", GL_DECAL);
	terrainTextures[2] = LoadTGA("Data/water.tga", GL_DECAL);
	terrainTextures[3] = LoadTGA("Data/ripple.tga",GL_DECAL);
	boundingRadius = sqrt((double)(width *width*xStep*xStep + height * height*zStep*zStep));
	boundingRadius = boundingRadius / 2;
	depth = 0;

	quadWidth = width - 1;
	
	

	return 1;

}

void Terrain::Draw()
{
	
}



void Terrain::BlendNormal(float * middle, float * base1, float * base2, float blend)
{
middle[0] = middle[0] * (1.0 - blend) + (base1[0] + base2[0])/2 * blend;
middle[1] = middle[1] * (1.0 - blend) + (base1[1] + base2[1])/2 * blend;
middle[2] = middle[2] * (1.0 - blend) + (base1[2] + base2[2])/2 * blend;	

}

void Terrain::BlendColorCenter(long centerPos,float * center, float * c1, float * c2, float * c3, float * c4,float * nwC, float * neC, float * swC, float * seC, float bld)
{
	center[0] = (1.0-bld) * colorTerrain[3*centerPos] + bld * ((c1[0] + c2[0] + c3[0] + c4[0] +
					nwC[0] + neC[0] + swC[0] + seC[0])/8);
	center[1] = (1.0-bld) * colorTerrain[3*centerPos + 1] + bld * ((c1[1] + c2[1] + c3[1] + c4[1] +
					nwC[1] + neC[1] + swC[1] + seC[1])/8);
	center[2] = (1.0-bld) * colorTerrain[3*centerPos + 2] + bld * ((c1[2] + c2[2] + c3[2] + c4[2] +
					nwC[2] + neC[2] + swC[2] + seC[2])/8);
}


void Terrain::BlendColorSide(float * mid, float * crn1, float * crn2, float bld)
{
	mid[0] = mid[0] * (1.0-bld) + bld * ((crn1[0] + crn2[0])/2);	
	mid[1] = mid[1] * (1.0-bld) + bld * ((crn1[1] + crn2[1])/2);
	mid[2] = mid[2] * (1.0-bld) + bld * ((crn1[2] + crn2[2])/2);
}

void Terrain::Render(int xTrue, int zTrue, int qW, int corner)
{
	int qR = qW >> 1;
	int nNode = xTrue + qR + (qR + zTrue) * width;		// Center Node



	// Check if the Node has children, if so, recurse and forget about drawing at this level

	if(terrainMatrix[nNode] == -1)
	{
		Render(xTrue, zTrue, qR, 1);
		Render(xTrue + qR, zTrue, qR, 2);
		Render(xTrue + qR,zTrue + qR, qR, 3);
		Render(xTrue, zTrue + qR, qR, 4);
		return;
	}

	if(terrainMatrix[nNode] == 0)				// If quad is not visible return
	return;


	long neighborNorth = nNode - qW * width;
	long neighborSouth = nNode + qW * width;
	long neighborEast = nNode + qW;
	long neighborWest = nNode - qW;

	//Handle Possibly Blending the four directions

	//North

	long nwCorner = xTrue + zTrue * width;
	long neCorner = nwCorner + qW;
	long seCorner = neCorner + qW * width;
	long swCorner = seCorner - qW;
	long	nCorner = nwCorner + qR;
	long	sCorner = swCorner + qR;
	long	wCorner = nNode - qR;
	long	eCorner = nNode + qR;


	float trueNorth = terrainData[nCorner];
	float trueSouth = terrainData[sCorner];
	float trueEast = terrainData[eCorner];
	float trueWest = terrainData[wCorner];

	float eastNorm[3], westNorm[3], northNorm[3], southNorm[3], nwNorm[3], neNorm[3], seNorm[3], swNorm[3];
	float centerNorm[3], centerColorAve[3], northColorAve[3], southColorAve[3], eastColorAve[3], westColorAve[3], nwColorAve[3],
			neColorAve[3], seColorAve[3], swColorAve[3];

	float nwHeight = terrainData[nwCorner];
	float neHeight = terrainData[neCorner];
	float swHeight = terrainData[swCorner];
	float seHeight = terrainData[seCorner];


	float blendVal;

	





	
	centerColorAve[0] = colorTerrain[3 * nNode]; centerColorAve[1] = colorTerrain[3*nNode + 1]; 
	centerColorAve[2] = colorTerrain[3 * nNode + 2];
	northColorAve[0] = colorTerrain[3 * nCorner]; northColorAve[1] = colorTerrain[3*nCorner + 1]; 
	northColorAve[2] = colorTerrain[3 * nCorner + 2];
	southColorAve[0] = colorTerrain[3 * sCorner]; southColorAve[1] = colorTerrain[3*sCorner + 1]; 
	southColorAve[2] = colorTerrain[3 * sCorner + 2];
	westColorAve[0] = colorTerrain[3 * wCorner]; westColorAve[1] = colorTerrain[3*wCorner + 1]; 
	westColorAve[2] = colorTerrain[3 * wCorner + 2];
	eastColorAve[0] = colorTerrain[3 * eCorner]; eastColorAve[1] = colorTerrain[3*eCorner + 1]; 
	eastColorAve[2] = colorTerrain[3 * eCorner + 2];
	nwColorAve[0] = colorTerrain[3 * nwCorner]; nwColorAve[1] = colorTerrain[3*nwCorner + 1]; 
	nwColorAve[2] = colorTerrain[3 * nwCorner + 2];
	neColorAve[0] = colorTerrain[3 * neCorner]; neColorAve[1] = colorTerrain[3*neCorner + 1]; 
	neColorAve[2] = colorTerrain[3 * neCorner + 2];
	swColorAve[0] = colorTerrain[3 * swCorner]; swColorAve[1] = colorTerrain[3*swCorner + 1]; 
	swColorAve[2] = colorTerrain[3 * swCorner + 2];
	seColorAve[0] = colorTerrain[3 * seCorner]; seColorAve[1] = colorTerrain[3*seCorner + 1]; 
	seColorAve[2] = colorTerrain[3 * seCorner + 2];
	

	int tempCount1 = 2, tempCount2 = 0, tempCount3 = width-1;

	while(tempCount1 != qW)
	{
		tempCount1 *= 2;
		tempCount2++;
		tempCount3 /= 2;
	}

	float * normals = normalList[tempCount2];
	tempCount3 += 1;	
	int localWidth = qW + 1;
	int	LODdiv = qW / 2;
	int tempNormZ = (zTrue + LODdiv) / LODdiv;
	int tempNormX = (xTrue + LODdiv) / LODdiv;
	long	lnNode = 3*(tempNormZ * tempCount3 + tempNormX);
	

	

	eastNorm[0] = normals[(lnNode + 3)]; eastNorm[1] = normals[(lnNode + 3) + 1]; 
	eastNorm[2] = normals[(lnNode + 3) + 2];

	westNorm[0] = normals[(lnNode - 3)]; westNorm[1] = normals[(lnNode - 3) + 1]; 
	westNorm[2] = normals[(lnNode - 3) + 2];

	northNorm[0] = normals[(lnNode - 3*tempCount3)]; northNorm[1] = normals[(lnNode - 3*tempCount3)+1]; 
	northNorm[2] = normals[(lnNode - 3*tempCount3) + 2];

	southNorm[0] = normals[(lnNode + 3*tempCount3)]; southNorm[1] = normals[(lnNode + 3*tempCount3)+1]; 
	southNorm[2] = normals[(lnNode + 3*tempCount3)+2];

	seNorm[0] = normals[(lnNode + 3*tempCount3 + 3)]; seNorm[1] = normals[(lnNode + 3*tempCount3 + 3) + 1]; 
	seNorm[2] = normals[(lnNode + 3*tempCount3 + 3) + 2];

	swNorm[0] = normals[(lnNode + 3*tempCount3 - 3)]; swNorm[1] = normals[(lnNode + 3*tempCount3 - 3) + 1]; 
	swNorm[2] = normals[(lnNode + 3*tempCount3 - 3) + 2];

	neNorm[0] = normals[(lnNode - 3*tempCount3 + 3)]; neNorm[1] = normals[(lnNode - 3*tempCount3 + 3) + 1]; 
	neNorm[2] = normals[(lnNode - 3*tempCount3 + 3) + 2];

	nwNorm[0] = normals[(lnNode - 3*tempCount3 - 3)]; nwNorm[1] = normals[(lnNode - 3*tempCount3 - 3) + 1]; 
	nwNorm[2] = normals[(lnNode - 3*tempCount3 - 3) + 2];

	centerNorm[0]=normals[lnNode]; centerNorm[1] = normals[lnNode + 1];
	centerNorm[2]= normals[lnNode + 2];
	


	long x1Global =	xTrue * xStep;
	long x2Global = (xTrue + qR) * xStep;
	long x3Global = (xTrue + qW) * xStep;
	long z1Global = zTrue * zStep;
	long z2Global = (zTrue + qR) * zStep;
	long z3Global = (zTrue + qW) * zStep;

	float nVal, sVal, eVal, wVal;	
	

  long tempParent;
	float tempColor[3];

	if(zTrue != 0)
	{
		if(corner == 1 || corner == 2)
		{
			if(corner == 1)
				tempParent = neCorner - qW * width;
			if(corner == 2)
				tempParent = nwCorner - qW * width;
			if(terrainMatrix[tempParent] > 0)
			{

				if(corner == 1)
				{
					tempColor[0] = colorTerrain[3*(neCorner + qW)]; tempColor[1] = colorTerrain[3*(neCorner + qW) + 1]; 
					tempColor[2] = colorTerrain[3*(neCorner + qW) + 2];
			
						neHeight = (nwHeight + terrainData[neCorner + qW])/2 * (terrainMatrix[tempParent]-1) + neHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(neColorAve, nwColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}
				if(corner == 2)
				{
					tempColor[0] = colorTerrain[3*(nwCorner - qW)]; tempColor[1] = colorTerrain[3*(nwCorner - qW) + 1]; 
					tempColor[2] = colorTerrain[3*(nwCorner - qW) + 2];
					BlendColorSide(nwColorAve, neColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
			
					nwHeight = (neHeight + terrainData[nwCorner - qW])/2 * (terrainMatrix[tempParent]-1) + nwHeight * (1-(terrainMatrix[tempParent]-1));
				}
			}
		}
	}


	if(zTrue + qW + 1 != width)
	{
		if(corner == 3 || corner == 4)
		{
			if(corner == 3)
			
				tempParent = swCorner + qW * width;
				
			
				if(corner == 4)
				tempParent = seCorner + qW * width;
			if(terrainMatrix[tempParent] > 0)
			{
				if(corner == 3)
				{
					tempColor[0] = colorTerrain[3*(swCorner - qW)]; tempColor[1] = colorTerrain[3*(swCorner - qW) + 1]; 
					tempColor[2] = colorTerrain[3*(swCorner - qW) + 2];
		
					swHeight = (seHeight + terrainData[swCorner - qW])/2 * (terrainMatrix[tempParent]-1) + swHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(swColorAve, seColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}
					if(corner == 4)
					{
						tempColor[0] = colorTerrain[3*(seCorner + qW)]; tempColor[1] = colorTerrain[3*(seCorner + qW) + 1]; 
					    tempColor[2] = colorTerrain[3*(seCorner + qW) + 2];
					
						seHeight = (swHeight + terrainData[seCorner + qW])/2 * (terrainMatrix[tempParent]-1) + seHeight * (1-(terrainMatrix[tempParent]-1));
						BlendColorSide(seColorAve, swColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
					}
				}
		}
	}


		if(xTrue != 0)
	{
			if(corner == 1 || corner == 4)
		{
			if(corner == 1)
				tempParent = swCorner - qW;
			if(corner == 4)
				tempParent = nwCorner - qW;
			if(terrainMatrix[tempParent] > 0)
			{
				if(corner == 1)
				{
					tempColor[0] = colorTerrain[3*(swCorner + qW * height)]; tempColor[1] = colorTerrain[3*(swCorner + qW * height) + 1]; 
					tempColor[2] = colorTerrain[3*(swCorner + qW * height) + 2];
				
					swHeight = (nwHeight + terrainData[swCorner + qW * width])/2 * (terrainMatrix[tempParent]-1) + swHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(swColorAve, nwColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}
				if(corner == 4)
				{
					tempColor[0] = colorTerrain[3*(nwCorner - qW * width)]; tempColor[1] = colorTerrain[3*(nwCorner - qW * width) + 1]; 
					tempColor[2] = colorTerrain[3*(nwCorner + qW * width) + 2];
				
					nwHeight = (swHeight + terrainData[nwCorner - qW * width])/2 * (terrainMatrix[tempParent]-1) + nwHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(nwColorAve, swColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}
			}
		}
	}

	if(xTrue + qW + 1 != width)
	{

			if(corner == 2 || corner == 3)
		{
			if(corner == 2)
				tempParent = seCorner + qW;
			if(corner == 3)
				tempParent = neCorner + qW ;
			if(terrainMatrix[tempParent] > 0)
			{
				if(corner == 2)
				{
					tempColor[0] = colorTerrain[3*(seCorner + qW * width)]; tempColor[1] = colorTerrain[3*(seCorner + qW * width) + 1]; 
					tempColor[2] = colorTerrain[3*(seCorner + qW * width) + 2];
				
					seHeight = (neHeight + terrainData[seCorner + qW * width])/2 * (terrainMatrix[tempParent]-1) + seHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(seColorAve, neColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}
				if(corner == 3)
				{
					tempColor[0] = colorTerrain[3*(neCorner - qW * width)]; tempColor[1] = colorTerrain[3*(neCorner - qW * width) + 1]; 
					tempColor[2] = colorTerrain[3*(neCorner - qW * width) + 2];
			
					neHeight = (seHeight + terrainData[neCorner - qW * width])/2 * (terrainMatrix[tempParent]-1) + neHeight * (1-(terrainMatrix[tempParent]-1));
					BlendColorSide(neColorAve, seColorAve, tempColor,terrainMatrix[tempParent] - 1.0);
				}

			}
		}
	}


	

	if(zTrue != 0)
	{
	
		if(terrainMatrix[neighborNorth] != 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborNorth]) - 1.0);	
			BlendColorSide(northColorAve,nwColorAve,neColorAve,blendVal);
		
			trueNorth = (nwHeight + neHeight) / 2 * blendVal + 
							trueNorth * (1.0 - blendVal);
//			BlendNormal(northNorm,nwNorm, neNorm, blendVal);

			
		}
		else
			BlendColorSide(northColorAve,nwColorAve,neColorAve,1.0);
		
	nVal = terrainMatrix[neighborNorth];
	}
		
	if(zTrue + qW + 1 != width)
	{
	
		if(terrainMatrix[neighborSouth] != 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborSouth]) - 1.0);

			trueSouth = (swHeight + seHeight) / 2 * blendVal +
							trueSouth * (1.0 - blendVal);
				BlendColorSide(southColorAve,swColorAve,seColorAve, blendVal);
//			BlendNormal(southNorm, swNorm, seNorm, blendVal);
		}
		else
			BlendColorSide(southColorAve,swColorAve,seColorAve, 1.0);

	sVal = terrainMatrix[neighborSouth];
	}
	
	
	if(xTrue != 0)
	{
		

		if(terrainMatrix[neighborWest] != 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborWest]) - 1.0);
		
			trueWest = (nwHeight + swHeight) / 2 * (blendVal) +
								trueWest * (1.0 - blendVal);
			BlendColorSide(westColorAve,nwColorAve,swColorAve, blendVal);
//			BlendNormal(westNorm,nwNorm, swNorm, blendVal);
		}
		else
		BlendColorSide(westColorAve,nwColorAve,swColorAve, 1.0);
	
		wVal = terrainMatrix[neighborWest];
	
	}
		if(xTrue + qW + 1 != width)
		{

			

		if(terrainMatrix[neighborEast] != 0)
			{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborEast]) - 1.0);
		
			trueEast = (neHeight + seHeight) / 2 * blendVal +
								trueEast * (1.0 - blendVal);
					BlendColorSide(eastColorAve,neColorAve,seColorAve, blendVal);
//				BlendNormal(eastNorm,neNorm, seNorm, blendVal);
			}
		else
			BlendColorSide(eastColorAve,neColorAve,seColorAve, 1.0);
		eVal = terrainMatrix[neighborEast];
		}

if(corner == 1 || corner == 3)
{
BlendColorSide(centerColorAve,nwColorAve,seColorAve, terrainMatrix[nNode] - 1.0);
//BlendNormal(centerNorm,nwNorm,seNorm,terrainMatrix[nNode]-1.0);
}


if(corner == 2 || corner == 4)
{
	BlendColorSide(centerColorAve,neColorAve,swColorAve, terrainMatrix[nNode] - 1.0);
	//BlendNormal(centerNorm,neNorm,swNorm,terrainMatrix[nNode] - 1.0);
}
//	Draw Triangle Fan

float texMap = 1.0;
float halfTexMap =.5;

if(qW != 2)
{
	texMap = qW/2;
	halfTexMap = texMap /2;
}


//float trueCenter = 0;



float trueCenter;
if(corner == 1 || corner == 3) 
	trueCenter=(nwHeight + seHeight) / 2 * (terrainMatrix[nNode] - 1.0) + 
								terrainData[nNode] * (1.0-(terrainMatrix[nNode] - 1.0));

if(corner == 2 || corner == 4) 
	trueCenter=(neHeight + swHeight) / 2 * (terrainMatrix[nNode] - 1.0) + 
								terrainData[nNode] * (1.0-(terrainMatrix[nNode] - 1.0));


//texMap = 1.0;
//halfTexMap = texMap/2;

				
glEnable(GL_TEXTURE_2D);
glEnable(GL_CULL_FACE);
glEnable(GL_DEPTH_TEST);

glEnable(GL_BLEND);
glEnable(GL_ALPHA_TEST);
glAlphaFunc(GL_GREATER, 0.0);
glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

if(drawMode & RENDER_LIGHTING)
	glEnable(GL_LIGHTING);
else
	glDisable(GL_LIGHTING);

glEnable(GL_FOG);

if(drawMode & RENDER_TEXTURE)
{
	glPolygonMode(GL_FRONT,GL_FILL);
	glEnable(GL_TEXTURE_2D);
}
else
{
	glPolygonMode(GL_FRONT, GL_LINE);
	glLineWidth(1);	
}




glBindTexture(GL_TEXTURE_2D,  terrainTextures[1]);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_DECAL);
glColor4f(1.0,1.0,1.0,1.0);

  glBegin(GL_TRIANGLE_FAN);
			
				// Center Point
glNormal3fv(centerNorm);//normals[3 * nNode],normals[3 * nNode + 1],normals[3 * nNode + 2]);

glTexCoord2f( halfTexMap, halfTexMap);

glColor3fv(centerColorAve);
glVertex3f(x2Global, trueCenter, z2Global);


 // North Point

if(nVal != 0)
{
	
	glNormal3fv(northNorm);//normals[3 * nCorner],normals[3 * nCorner + 1],normals[3 * nCorner + 2]);
	
	glTexCoord2f( halfTexMap, 0);
	
	glColor3fv(northColorAve);
	glVertex3f(x2Global, trueNorth, z1Global);
}
	//NW point

	numTriangles++;
	glNormal3fv(nwNorm);
	glTexCoord2f( 0, 0);
   
	glColor3fv(nwColorAve);
	glVertex3f(x1Global, nwHeight, z1Global);

	//W point

if(wVal != 0)
{
	
		numTriangles++;
	glNormal3fv(westNorm);//normals[3 * wCorner],normals[3 * wCorner + 1],normals[3 * wCorner + 2]);
	
	glTexCoord2f( 0, halfTexMap);
    
	glColor3fv(westColorAve);
	glVertex3f(x1Global, trueWest, z2Global);
}

	//SW point

		numTriangles++;
	glNormal3fv(swNorm);
	glTexCoord2f(0, texMap);
	glTexCoord2f( 0,texMap);
    
	glColor3fv(swColorAve);
	glVertex3f(x1Global, swHeight, z3Global);

	//S point

if(sVal != 0)
{
	
		numTriangles++;
	glNormal3fv(southNorm);//normals[3 * sCorner],normals[3 * sCorner + 1],normals[3 * sCorner + 2]);
	glTexCoord2f( halfTexMap, texMap);
    
	glColor3fv(southColorAve);
	glVertex3f(x2Global, trueSouth, z3Global);
}

	//SE point

		numTriangles++;
	glNormal3fv(seNorm);
	glTexCoord2f( texMap, texMap);
    
	glColor3fv(seColorAve);
	glVertex3f(x3Global, seHeight, z3Global);

	//E point
	
if(eVal != 0)
{
		numTriangles++;
	glNormal3fv(eastNorm);//normals[3 * eCorner],normals[3 * eCorner + 1],normals[3 * eCorner + 2]);
	glTexCoord2f( texMap, halfTexMap);
    
	glColor3fv(eastColorAve);
	glVertex3f(x3Global, trueEast, z2Global);
}

	//NE point
	glNormal3fv(neNorm);
	glTexCoord2f(texMap, 0);
    	numTriangles++;
	glColor3fv(neColorAve);
	glVertex3f(x3Global, neHeight, z1Global);

if(nVal != 0)
{
	
	glNormal3fv(northNorm);//normals[3 * nCorner],normals[3 * nCorner + 1],normals[3 * nCorner + 2]);
	glTexCoord2f( halfTexMap, 0);
    	numTriangles++;
	glColor3fv(northColorAve);
	glVertex3f(x2Global, trueNorth, z1Global);
}
else
{
	
	glNormal3fv(nwNorm);
	glTexCoord2f( 0, 0);
		numTriangles++;
	glColor3fv(nwColorAve);
	glVertex3f(x1Global, nwHeight, z1Global);


}

//cnt += .0001;

glEnd();

glDisable(GL_LIGHTING);
glDisable(GL_BLEND);
	//glDisable(GL_ALPHA_TEST);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glDisable(GL_FOG);
	
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);

}

void Terrain::Kill()
{
		if(next != NULL)
		next->Kill();
	if(child != NULL)
		child->Kill();

	for(int i = 0; i<10; i++)
		if(normalList[i] != NULL)
			delete[] normalList[i];
	delete[] terrainData;
	delete[]  terrainMatrix;
	delete[] roughMatrix;
	delete[] colorTerrain;

}




void TerrainNormalize(float *v) {

	double d;
	
	d = sqrt((v[0]*v[0]) + (v[1]*v[1]) + (v[2]*v[2]));

	v[0] = v[0] / d;
	v[1] = v[1] / d;
	v[2] = v[2] / d;
}

void Terrain::TerrainCrossProduct(float * v1, float * v2, float * result) 
{
		result[0] = v1[1] * v2[2] - v1[2] * v2[1];
		
		result[1] = v1[2] * v2[0] - v1[0] * v2[2];
		
		result[2] = v1[0] * v2[1] - v1[1] * v2[0];


}


void TerrainAddVector(float *a, float *b) {

	a[0] += b[0];
	a[1] += b[1];
	a[2] += b[2];
}

void TerrainSubVector(float * final, float * a, float * b)
{
	final[0] = a[0] - b[0];
	final[1] = a[1] - b[1];
	final[2] = a[2] - b[2];
}


float * Terrain::MakeNormalMap(int qWidth)
{
	int tmp = qWidth/2;
	float * tempList;
	tempList = (float *)malloc(sizeof(float) * 3 * (1024/tmp + 1) * (1024/tmp + 1));
	int qRad = qWidth / 2;
	int tempX = 0, tempZ = 0;
	long count = 0;
	long cnt = 0;

	
	while(tempZ <= width - 1)
	{
		while(tempX<= height - 1)
		{
			MakeVertexNormal(qWidth, tempX, tempZ, tempList, cnt);
			cnt = cnt + 3;
			tempX += qRad;
			
		}
			tempZ += qRad;
			tempX = 0;

	}

	

	return tempList;
}

void Terrain::MakeVertexNormal(int qWidth, int tempX, int tempZ, float * loc, long cnt)
{
	float  nP[3],  nwP[3],  wP[3], swP[3],  sP[3],  seP[3],  eP[3],  neP[3], cP[3];
	int qRad = qWidth / 2;

	cP[0] = tempX; cP[1] = terrainData[tempX + tempZ * width]; cP[2] = tempZ;

	int xLimit = width -1;
	int zLimit = width -1;
	//Calculate N point
	nP[0] = cP[0];
	nP[2] = cP[2] - qRad;

	if(tempZ == 0)
		nP[1] = cP[1]; 
	else
		nP[1] = terrainData[long(nP[0] + nP[2] * width)];

	//Calculate NW point
	nwP[0] = cP[0] - qRad;
	nwP[2] = cP[2] - qRad;

	if(tempZ == 0 || tempX == 0)
		nwP[1] = cP[1]; 
	else
		nwP[1] = terrainData[long(nwP[0] + nwP[2] * width)];

	//Calculate W point
	wP[0] = cP[0] - qRad;
	wP[2] = cP[2];

	if(tempX == 0)
		wP[1] = cP[1]; 
	else
		wP[1] = terrainData[long(wP[0] + wP[2] * width)];

	//Calculate SW point
	swP[0] = cP[0] -qRad;
	swP[2] = cP[2] + qRad;

	if(tempZ == zLimit || tempX == 0)
		swP[1] = cP[1]; 
	else
		swP[1] = terrainData[long(swP[0] + swP[2] * width)];

	//Calculate S point
	sP[0] = cP[0];
	sP[2] = cP[2] + qRad;

	if(tempZ == zLimit)
		sP[1] = cP[1]; 
	else
		sP[1] = terrainData[long(sP[0] + sP[2] * width)];

	//Calculate SE point
	seP[0] = cP[0] + qRad;
	seP[2] = cP[2] + qRad;

	if(tempZ == zLimit || tempX == xLimit)
		seP[1] = cP[1]; 
	else
		seP[1] = terrainData[long(seP[0] + seP[2] * width)];

	//Calculate E point
	eP[0] = cP[0] + qRad;
	eP[2] = cP[2];

	if(tempX == xLimit)
		eP[1] = cP[1]; 
	else
		eP[1] = terrainData[long(eP[0] + eP[2] * width)];

	//Calculate NE point
	neP[0] = cP[0] + qRad;
	neP[2] = cP[2] - qRad;

	if(tempZ == 0 || tempX == xLimit)
		neP[1] = cP[1]; 
	else
		neP[1] = terrainData[long(neP[0] + neP[2] * width)];

	float totalNormal[] = {0,0,0};
	float tempN[3];

	CalculateFaceNormal(nP,nwP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);
	

	CalculateFaceNormal(nwP,wP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(wP,swP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(swP,sP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(sP,seP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(seP,eP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(eP,neP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);

	CalculateFaceNormal(neP,nP,cP, tempN);
	//TerrainNormalize(tempN);
	TerrainAddVector(totalNormal,tempN);
	totalNormal[0] /= 8;
	totalNormal[1] /= 8;
	totalNormal[2] /= 8;

	TerrainNormalize(totalNormal);

	loc[cnt] = totalNormal[0]; loc[cnt + 1] = totalNormal[1]; loc[cnt + 2] = totalNormal[2];
	//loc[cnt] = 0; loc[cnt+1] = 1; loc[cnt + 2] = 0;


}

void Terrain::CalculateFaceNormal(float * p1, float * p2, float * p3, float * final)
{
	float v1[3];
	float v2[3];
//p1[0] = p1[0] * xStep; p1[2] = p1[2] * xStep;
//	p2[0] = p2[0] * xStep; p2[2] = p2[2] * xStep;
//	p3[0] = p3[0] * xStep; p3[2] = p3[2] * xStep;

	TerrainSubVector(v1,p2,p1);
	TerrainSubVector(v2,p3,p1);
	TerrainNormalize(v1);
	TerrainNormalize(v2);
	TerrainCrossProduct(v1,v2,final);
	TerrainNormalize(final);

}



void Terrain::MakeNormals()
{
	int qWidth = 2;
	int cnt = 0;
float * temp;
	
while(qWidth < 1025)
	{
	normalList[cnt] = MakeNormalMap(qWidth);

	cnt++;
	qWidth *=2;
	
	}
}


	




float Terrain::GetHeight(float xPos, float zPos)
{
	float xRemainder,xAve,zAve,hAve;
	float zRemainder;
	long x1 = xPos / xStep;
	long z1 = zPos / zStep;
	xRemainder = xPos/xStep - x1;
	zRemainder = zPos/zStep - z1;
	float p1, p2, p3;

	if((x1 % 2 == 0 && z1 % 2 == 0) || (x1 %  2 == 1 && z1 % 2 == 1))
	{
		p1 = terrainData[x1 + z1 * width];
		p2 = terrainData[x1 + 1 + (z1 + 1) * width];

		if(zRemainder <= xRemainder)
		{
			p3 = terrainData[x1 + 1 + z1 * width];
			p3 = ((p1 * (1.0-xRemainder) + p3 * xRemainder) * (1.0 - zRemainder) + p2 * zRemainder);
			return MAX(p3,48);
		}
		else
		{
			p3 = terrainData[x1 + (z1 + 1) * width];
			p3 = ((p2 * (1.0-xRemainder) + p3 * xRemainder) * (zRemainder) + p1 * (1.0-zRemainder));
			return MAX(p3,48);
		}
	}

	if((x1 % 2 == 0 && z1 % 2 == 1) || (x1 %  2 == 1 && z1 % 2 == 0))
	{
		p1 = terrainData[x1+ 1 + z1 * width];
		p2 = terrainData[x1 + (z1 + 1) * width];

		if(zRemainder + xRemainder <= 1.0)
		{
			p3 = terrainData[x1 +  z1 * width];
			p3 = ((p3 * (1.0-xRemainder) + p1 * xRemainder) * (1.0 - zRemainder) + p2 * zRemainder);
			return MAX(p3,48);
		}
		else
		{
			p3 = terrainData[x1 + 1 + (z1 + 1) * width];
			p3 = ((p2 * (1.0-xRemainder) + p3 * xRemainder) * (zRemainder) + p1 * (1.0-zRemainder));
			return MAX(p3,48);
		}
	}
}

void MasterTerrain::Draw()
{

	Tessellate();
	Render(0,0,quadWidth, -1);

	Entity * e = child;
	
while(e != NULL)
	{
		e->Draw();
	    e = e->next;
	}
//glDisable(GL_DEPTH_TEST);
//glEnable(GL_TEXTURE_2D);
//glBindTexture(GL_TEXTURE_2D,  terrainTextures[3]);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
glEnable(GL_BLEND);
glEnable(GL_DEPTH_TEST);
glAlphaFunc(GL_GREATER, 0.0);
glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
glDisable(GL_LIGHTING);
glDisable(GL_TEXTURE_2D);

glColor4f(0.0,.1,0.7,0.7);

  glBegin(GL_QUADS);
  
  glVertex3f(0, 50, 0);
  
  glVertex3f(0, 50, 40000);
  
   glVertex3f(40000, 50, 40000);
   
  glVertex3f(40000, 50, 0);

  
	
glEnd();
//glEnable(GL_DEPTH_TEST);
glDisable(GL_TEXTURE_2D);
glDisable(GL_LIGHTING);
glDisable(GL_BLEND);
glColor4f(1.0,1.0,1.0,1.0);
messenger->FontPrint("Drawing %ld triangles",numTriangles);
numTriangles = 0;

	


	
}

MasterTerrain::MasterTerrain(int sH, int xS, int zS, int a, int b, int c, int rad)
{ 
	scaleHeight = sH;xStep = xS; zStep = zS; boundingRadius = rad; x = a; y = b; z = c; Entity();
	for(int i = 0; i<10; i++)
		normalList[i] = NULL;
}

void MasterTerrain::Kill()
{
	if(next != NULL)
		next->Kill();
	if(child != NULL)
		child->Kill();

	for(int i = 0; i<10; i++)
		if(normalList[i] != NULL)
			delete[] normalList[i];
	delete[] terrainData;
	delete[]  terrainMatrix;
	delete[] roughMatrix;
	delete[] colorTerrain;	


}


void MasterTerrain::Tessellate()
{

	memset( terrainMatrix, 0, width*width * sizeof(float));
	
	unsigned int nRadius = quadWidth >> 1;
	unsigned nNode = nRadius + nRadius * width;


	terrainMatrix[nNode] = -1;

	RecursiveTessellate( 0,			0,			nRadius );
	RecursiveTessellate( 0,			nRadius,	nRadius );
	RecursiveTessellate( nRadius,	0,			nRadius );
	RecursiveTessellate( nRadius,	nRadius,	nRadius );

}


void MasterTerrain::RecursiveTessellate(int nWx, int nWz, int qWidth)
{

	unsigned int nRadius = qWidth >> 1;
	unsigned nNode = nWx + nRadius + (nWz + nRadius) * width;
	int hT;

	
	float dist = IsVisible((nWx + nRadius) * xStep, terrainData[nNode], (nWz + nRadius) * xStep, nRadius * xStep * 2);
	
		

	if(dist == 0)
	{
		terrainMatrix[nNode] = 0;
		return;
	}
		
	
		// Split Metric determines if more depth is needed	DISTANCE / (XFACTOR * QUADWIDTH * ROUGHNESS)
	
	float splitMetric = (float)dist / (float)((50 * qWidth)*(roughMatrix[nNode]));
	//splitMetric = .5;
	


	if(splitMetric <= 1.0 && qWidth > 3)
	{

	terrainMatrix[nNode] = -1;
	RecursiveTessellate( nWx,					nWz,			nRadius );
	RecursiveTessellate( nWx,					nWz + nRadius,	nRadius );
	RecursiveTessellate( nWx + nRadius,			nWz,			nRadius );
	RecursiveTessellate( nWx + nRadius,			nWz + nRadius,	nRadius );
	}
	else
	{
	//splitMetric = dist / (100 * qWidth) * (((1-(splitMetric - 1)/2) + 1));
	//splitMetric = (float)dist / (float)((50 * qWidth));
	if(splitMetric < 1.0)
		splitMetric = 1.0;
	if(splitMetric > 2.0)
		splitMetric = 2.0;


	if(nWz == 512 && nWx == 512)
		messenger->FontPrint("Location metric, distance: %f - %f", splitMetric, dist);

	terrainMatrix[nNode] = splitMetric;				// Split Metric Value bound between 1.0 - 2.0
	}
	
	return;
}

 int MasterTerrain::ComputeRoughness(long nWx, long nWz, int qWidth)
{
	int qRad = qWidth >> 1;
	long node = nWx + qRad + (nWz + qRad) * width;


	

	if(qWidth < 3)
		return 0.1;					// minimum roughness value

	// These are the certain sides of the triangle fan

	int centerHeight = terrainData[node];
	int nwHeight = terrainData[nWx + nWz * width];
	int neHeight = terrainData[nWx + qWidth + nWz * width];
	int swHeight = terrainData[nWx + (nWz + qWidth) * width];
	int seHeight = terrainData[nWx + qWidth + (nWz + qWidth) * width];

	// Find the potential new points

	int nHeight = terrainData[nWx + qRad + nWz * width];
	int wHeight = terrainData[nWx + (nWz + qRad) * width];
	int sHeight = terrainData[nWx + qRad + (nWz + qWidth) * width];
	int eHeight = terrainData[nWx + qWidth + (nWz + qRad) * width];


	//Calculate the errors on each side with the new point

	int nError = abs(nHeight - ((nwHeight + neHeight) / 2));
	int wError = abs(wHeight - ((nwHeight + swHeight) / 2));
	int sError = abs(sHeight - ((swHeight + seHeight) / 2));
	int eError = abs(eHeight - ((seHeight + neHeight) / 2));
	int cError = abs(centerHeight - ((nwHeight + neHeight + seHeight + swHeight)/4));

	int maxLocalError = 0;

	if(nError > maxLocalError)	maxLocalError = nError;
	if(wError > maxLocalError)	maxLocalError = wError;
	if(sError > maxLocalError)	maxLocalError = sError;
	if(eError > maxLocalError)	maxLocalError = eError;
	if(cError > maxLocalError)	maxLocalError = cError;

	int tempError;
	
	//NW Quad
	tempError = ComputeRoughness(nWx,nWz,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//SW Quad
	tempError = ComputeRoughness(nWx,nWz + qRad,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//NE Quad
	tempError = ComputeRoughness(nWx + qRad,nWz,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//SE Quad
	tempError = ComputeRoughness(nWx + qRad,nWz + qRad,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	maxLocalError = min(1,maxLocalError);
	roughMatrix[node] = maxLocalError;									// Roughness Info stored next to node depth info in Matrix
	roughMatrix[node - qRad/2 - width*(qRad/2)] = maxLocalError;
	roughMatrix[node + qRad/2 - width*(qRad/2)] = maxLocalError;
	roughMatrix[node + qRad/2 + width*(qRad/2)] = maxLocalError;
	roughMatrix[node - qRad/2 + width*(qRad/2)] = maxLocalError;
	return maxLocalError;


}


void MasterTerrain::Init()
{
	ComputeRoughness(0,0,quadWidth);
}

