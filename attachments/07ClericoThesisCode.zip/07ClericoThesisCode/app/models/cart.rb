class Cart < ActiveRecord::Base
	belongs_to :profile

end
