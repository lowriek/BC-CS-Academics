// ControlBox.cpp : implementation file
//

#include "stdafx.h"
#include "WorldEditor.h"
#include "ControlBox.h"
#include "WorldEditorDoc.h"
#include "AlphaEngine/PBrush/PBrushMgr.h"
#include "AlphaEngine/Texture/Texture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TOOLBOX 0
#define GROUPS 1
#define MODELS 2
#define SKY 3
#define CONSOLE 4
#define STATS 5
#define FACE 6
#define TEXTURE 7
/////////////////////////////////////////////////////////////////////////////
// CControlBox

IMPLEMENT_DYNCREATE(CControlBox, CFormView)

CControlBox::CControlBox()
	: CFormView(CControlBox::IDD)
{
	//{{AFX_DATA_INIT(CControlBox)
	m_transparent = FALSE;
	m_transparencyValue = 0.0f;
	m_lstDecalString = _T("");
	m_lstTextureString = _T("");
	//}}AFX_DATA_INIT
	setup = false;
}

CControlBox::~CControlBox()
{
}

void CControlBox::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlBox)
	DDX_Control(pDX, IDC_LIST_TEXTURE, m_lstTexture);
	DDX_Control(pDX, IDC_LIST_DECAL, m_lstDecal);
	DDX_Control(pDX, IDC_BUTTON_DECAL, m_btnDecal);
	DDX_Control(pDX, IDC_BUTTON_NO_DECAL, m_btnNoDecal);
	DDX_Control(pDX, IDC_BUTTON_TEXTURE, m_btnTexture);
	DDX_Control(pDX, IDC_BUTTON_FACE_OK, m_btnFaceOk);
	DDX_Control(pDX, IDC_STATIC_TRANSPARENCY_VALUE, m_staticTransValue);
	DDX_Control(pDX, IDC_SPIN_TRANSPARENCY_VALUE, m_spinTransValue);
	DDX_Control(pDX, IDC_EDIT_TRANSPARENCY_VALUE, m_editTransValue);
	DDX_Control(pDX, IDC_CHECK_TRANSPARENT, m_chkTrans);
	DDX_Control(pDX, IDC_CHECK_SKY, m_chkSky);
	DDX_Control(pDX, IDC_COMBO_EXTENDED, m_cmbExtended);
	DDX_Control(pDX, IDC_COMBO_ENTITY, m_cmbEntity);
	DDX_Control(pDX, IDC_BUTTON_EXTENDED_INSERTOR, m_btnExtendedInsertor);
	DDX_Control(pDX, IDC_BUTTON_ENTITY_INSERT, m_btnEntityInsertor);
	DDX_Control(pDX, IDC_CONTROL_TAB1, m_tab);
	DDX_Check(pDX, IDC_CHECK_TRANSPARENT, m_transparent);
	DDX_Text(pDX, IDC_EDIT_TRANSPARENCY_VALUE, m_transparencyValue);
	DDV_MinMaxFloat(pDX, m_transparencyValue, 0.f, 1.f);
	DDX_LBString(pDX, IDC_LIST_DECAL, m_lstDecalString);
	DDX_LBString(pDX, IDC_LIST_TEXTURE, m_lstTextureString);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CControlBox, CFormView)
	//{{AFX_MSG_MAP(CControlBox)
	ON_NOTIFY(TCN_SELCHANGE, IDC_CONTROL_TAB1, OnSelchangeControlTab1)
	ON_BN_CLICKED(IDC_BUTTON_FACE_OK, OnButtonFaceOk)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_TRANSPARENCY_VALUE, OnDeltaposSpinTransparencyValue)
	ON_BN_CLICKED(IDC_BUTTON_TEXTURE, OnButtonTexture)
	ON_BN_CLICKED(IDC_BUTTON_DECAL, OnButtonDecal)
	ON_BN_CLICKED(IDC_BUTTON_NO_DECAL, OnButtonNoDecal)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlBox diagnostics

#ifdef _DEBUG
void CControlBox::AssertValid() const
{
	CFormView::AssertValid();
}

void CControlBox::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CControlBox message handlers


void CControlBox::OnDraw(CDC* pDC) 
{
	CWorldEditorDoc* pDoc = (CWorldEditorDoc*)GetDocument();

	if (pDoc->UPDATE_LIST)
		PopulateLists();
}

void CControlBox::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	if (!setup) {
		m_tab.InsertItem(TOOLBOX, _T("Toolbox"));
		m_tab.InsertItem(GROUPS, _T("Groups"));
		m_tab.InsertItem(MODELS, _T("Models"));
		m_tab.InsertItem(SKY, _T("Sky"));
		m_tab.InsertItem(CONSOLE, _T("Console"));
		m_tab.InsertItem(STATS, _T("Stats"));
		m_tab.InsertItem(FACE, _T("Face"));
		m_tab.InsertItem(TEXTURE, _T("Texture"));
	}
	
	HideToolbox();
	HideFace();
	HideGroups();
	HideModels();
	HideSky();
	HideConsole();
	HideStats();
	HideTexture();

	switch(m_tab.GetCurFocus())
	{
	case GROUPS:
		SetupGroups();
		break;
	case MODELS:
		SetupModels();
		break;
	case SKY:
		SetupSky();
		break;
	case TOOLBOX:
		SetupToolbox();
		break;
	case CONSOLE:
		SetupConsole();
		break;
	case STATS:
		SetupStats();
		break;
	case FACE:
		SetupFace();
		break;
	case TEXTURE:
		SetupTexture();
		break;
	}

	setup = true;
}

void CControlBox::HideGroups()
{
}

void CControlBox::HideModels()
{
}

void CControlBox::HideSky()
{
}

void CControlBox::HideTexture()
{
	m_btnDecal.EnableWindow(FALSE);
	m_btnTexture.EnableWindow(FALSE);
	m_btnNoDecal.EnableWindow(FALSE);
	m_lstDecal.EnableWindow(FALSE);
	m_lstTexture.EnableWindow(FALSE);

	m_btnDecal.ShowWindow(SW_HIDE);
	m_btnTexture.ShowWindow(SW_HIDE);
	m_btnNoDecal.ShowWindow(SW_HIDE);
	m_lstDecal.ShowWindow(SW_HIDE);
	m_lstTexture.ShowWindow(SW_HIDE);
}

void CControlBox::HideToolbox()
{
	m_btnEntityInsertor.EnableWindow(FALSE);
	m_btnExtendedInsertor.EnableWindow(FALSE);
	m_cmbEntity.EnableWindow(FALSE);
	m_cmbExtended.EnableWindow(FALSE);

	m_btnEntityInsertor.ShowWindow(SW_HIDE);
	m_btnExtendedInsertor.ShowWindow(SW_HIDE);
	m_cmbEntity.ShowWindow(SW_HIDE);
	m_cmbExtended.ShowWindow(SW_HIDE);
}

void CControlBox::SetupGroups()
{
}

void CControlBox::SetupModels()
{
}

void CControlBox::SetupSky()
{
}

void CControlBox::SetupTexture()
{
	m_btnDecal.EnableWindow(TRUE);
	m_btnTexture.EnableWindow(TRUE);
	m_btnNoDecal.EnableWindow(TRUE);
	m_lstDecal.EnableWindow(TRUE);
	m_lstTexture.EnableWindow(TRUE);

	m_btnDecal.ShowWindow(SW_SHOWNORMAL);
	m_btnTexture.ShowWindow(SW_SHOWNORMAL);
	m_btnNoDecal.ShowWindow(SW_SHOWNORMAL);
	m_lstDecal.ShowWindow(SW_SHOWNORMAL);
	m_lstTexture.ShowWindow(SW_SHOWNORMAL);

}

void CControlBox::SetupToolbox()
{
	m_btnEntityInsertor.EnableWindow(TRUE);
	m_btnExtendedInsertor.EnableWindow(TRUE);
	m_cmbEntity.EnableWindow(TRUE);
	m_cmbExtended.EnableWindow(TRUE);

	m_btnEntityInsertor.ShowWindow(SW_SHOWNORMAL);
	m_btnExtendedInsertor.ShowWindow(SW_SHOWNORMAL);
	m_cmbEntity.ShowWindow(SW_SHOWNORMAL);
	m_cmbExtended.ShowWindow(SW_SHOWNORMAL);
}

void CControlBox::SetupStats()
{
}

void CControlBox::PopulateLists()
{
	CWorldEditorDoc * pDoc = (CWorldEditorDoc*)GetDocument();
	CTexture* pTexture = pDoc->GetTextures();

	if (!pTexture)
		return;

	// put all names of textures in the necessary lists
	CListBox* pListBox1 = &m_lstTexture;
	CListBox* pListBox2 = &m_lstDecal;
	pListBox1->ResetContent();
	pListBox2->ResetContent();

	while (pTexture != 0)
	{
		CString str;
		str.Format(pTexture->name);
		int type = pTexture->getTextureType();

		if (type == BASE_TEXTURE)
			pListBox1->AddString(str);	
		else if (type == DECAL_TEXTURE)
			pListBox2->AddString(str);

		pTexture = pTexture->getNext();
	}

	pDoc->UPDATE_LIST = FALSE;
	
}

void CControlBox::SetupConsole()
{
}

void CControlBox::HideStats()
{
}

void CControlBox::HideConsole()
{
}

void CControlBox::HideFace()
{
	m_chkSky.EnableWindow(FALSE);
	m_chkTrans.EnableWindow(FALSE);
	m_editTransValue.EnableWindow(FALSE);
	m_spinTransValue.EnableWindow(FALSE);
	m_staticTransValue.EnableWindow(FALSE);
	m_btnFaceOk.EnableWindow(FALSE);

	m_chkSky.ShowWindow(SW_HIDE);
	m_chkTrans.ShowWindow(SW_HIDE);
	m_editTransValue.ShowWindow(SW_HIDE);
	m_spinTransValue.ShowWindow(SW_HIDE);
	m_staticTransValue.ShowWindow(SW_HIDE);
	m_btnFaceOk.ShowWindow(SW_HIDE);

}

void CControlBox::SetupFace()
{
	m_chkSky.EnableWindow(TRUE);
	m_chkTrans.EnableWindow(TRUE);
	m_editTransValue.EnableWindow(TRUE);
	m_spinTransValue.EnableWindow(TRUE);
	m_staticTransValue.EnableWindow(TRUE);
	m_btnFaceOk.EnableWindow(TRUE);

	m_chkSky.ShowWindow(SW_SHOWNORMAL);
	m_chkTrans.ShowWindow(SW_SHOWNORMAL);
	m_editTransValue.ShowWindow(SW_SHOWNORMAL);
	m_spinTransValue.ShowWindow(SW_SHOWNORMAL);
	m_staticTransValue.ShowWindow(SW_SHOWNORMAL);
	m_btnFaceOk.ShowWindow(SW_SHOWNORMAL);
}

void CControlBox::OnSelchangeControlTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HideFace();
	HideGroups();
	HideModels();
	HideSky();
	HideToolbox();
	HideConsole();
	HideStats();
	HideTexture();

	switch(m_tab.GetCurFocus())
	{
	case GROUPS:
		SetupGroups();
		break;
	case MODELS:
		SetupModels();
		break;
	case SKY:
		SetupSky();
		break;
	case TOOLBOX:
		SetupToolbox();
		break;
	case CONSOLE:
		SetupConsole();
		break;
	case STATS:
		SetupStats();
		break;
	case FACE:
		SetupFace();
		break;
	case TEXTURE:
		SetupTexture();
		break;
	}

	*pResult = 0;
}

void CControlBox::OnButtonFaceOk() 
{
	UpdateData(TRUE);
	CWorldEditorDoc *pDoc = (CWorldEditorDoc *)GetDocument();
	PolygonProp polyProp;
	
	if (m_transparent)
		polyProp.isTransparent = true;
	else
		polyProp.isTransparent = false;

	polyProp.transparencyValue = m_transparencyValue;
	pDoc->SetPolygonProp(polyProp);
}

void CControlBox::OnDeltaposSpinTransparencyValue(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	m_transparencyValue += .05 * -pNMUpDown->iDelta;
	if (m_transparencyValue > 1.0)
		m_transparencyValue = 1.0f;
	if (m_transparencyValue < 0)
		m_transparencyValue = 0.0f;
	UpdateData(FALSE);
	*pResult = 0;
}

void CControlBox::OnButtonTexture() 
{
	UpdateData(TRUE);
	CWorldEditorDoc* pDoc = (CWorldEditorDoc*)GetDocument();
	if (m_lstTextureString != "")
		pDoc->SetBaseTx((const char*)m_lstTextureString);
}

void CControlBox::OnButtonDecal() 
{
	UpdateData(TRUE);
	CWorldEditorDoc* pDoc = (CWorldEditorDoc*)GetDocument();
	if (m_lstDecalString != "")
		pDoc->SetDecalTx((const char*)m_lstDecalString);	
}

void CControlBox::OnButtonNoDecal() 
{
	UpdateData(TRUE);
	CWorldEditorDoc* pDoc = (CWorldEditorDoc*)GetDocument();
	pDoc->SetDecalTx("");
}
