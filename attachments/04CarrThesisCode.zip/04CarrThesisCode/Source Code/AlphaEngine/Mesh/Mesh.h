#ifndef _MESH_H_
#define _MESH_H_

#include "AlphaEngine/Core/BaseObject.h"
#include "AlphaEngine/Math/Vector3.h"
#include "AlphaEngine/Math/Vector2.h"
#include "AlphaEngine/Mesh/Face.h"
#include "AlphaEngine/AlphaConstants.h"
#include <windows.h>
#include <gl/gl.h>
#include <gl/glext.h>

class CMesh : public CBaseObject
{
public:
	CMesh();
	virtual ~CMesh();

	virtual CMesh*	clone();
	virtual void	insert(CMesh * pMesh);
	virtual bool	load(char * meshName);
	virtual bool	rayIntersectTest(CVector3& ro, CVector3& rdir, float rad=0.0f);
	virtual bool	rayIntersect(CVector3& ro, CVector3& rdir, CVector3& ip, float& t, unsigned int &faceId, float rad=0.0f);
	virtual void	render(int flags=30);
	virtual void	reset();
	virtual bool	serialize(FILE * filePtr, bool isStoring);
	unsigned int	numFace;
	unsigned int	numVert;

	CFace *		pFace;
	CVector3 *	pVert;
private:
	void			renderFace(unsigned int x, bool b, bool d, bool l);
};

#endif