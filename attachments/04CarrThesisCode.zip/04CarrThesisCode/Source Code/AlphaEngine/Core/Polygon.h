#ifndef _CPOLYGON_H
#define _CPOLYGON_H

#include "AlphaEngine/Math/Plane.h"
#include "AlphaEngine/Math/Matrix44.h"
#include "AlphaEngine/Math/Vector2.h"
#include "AlphaEngine/AlphaConstants.h"
#include <windows.h>
#include <gl/gl.h>
#include <gl/glext.h>

typedef struct {
	bool isTransparent;
	float transparencyValue;
} PolygonProp;

class CPolygon
{
public:
	CPolygon();
	virtual ~CPolygon();

	float			alpha;
	unsigned int	bTxId;
	unsigned int	dTxId;
	unsigned int	numVert;
	bool			flag;
	CVector3*		pVert;
	CVector2*		pBTxCoord;
	CVector2*		pDTxCoord;
	CPolygon*		pNext;
	CPlane			plane;
	
	void			add(CPolygon* pPolygon);
	bool			allocate(unsigned int numVert);
	void			calculatePlane();
	int				classify(CPlane& planeTest);
	CPolygon*		clone();
	void			deallocate();
	void			flip();
	void			insertVert(CVector3 &v, CVector2 &bTxCoord, CVector2 &dTxCoord);
	bool			rayIntersect(CVector3 &ro, CVector3 &rd, CVector3 &ip, float &t, float rad);
	void			render(int flags);
	bool			serialize(FILE* filePtr, bool isStoring);
	bool			splitPolygon(CPlane &plane, CPolygon *pPosPolygon, CPolygon *pNegPolygon);
	void			transform(const CMatrix44 &matrix);

};
#endif
