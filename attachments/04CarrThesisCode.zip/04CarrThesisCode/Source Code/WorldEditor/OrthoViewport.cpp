// OrthoViewport.cpp: implementation of the COrthoViewport class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldEditor.h"
#include "OrthoViewport.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


COrthoViewport::COrthoViewport()
{
}

COrthoViewport::COrthoViewport(COpenGLView * parent) : CViewport(parent)
{
	m_zoom = 8;
	m_minZoom = 2;
	m_maxZoom = 12;
}

COrthoViewport::~COrthoViewport()
{
}

void COrthoViewport::SetupProjection()
{
	float distance = GetSideLength() / 2.0f;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
//	glOrtho(-distance, distance, -distance, distance, -distance, distance);
	glOrtho(-distance, distance, -distance, distance, -4096, 4096);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void COrthoViewport::ZoomIn()
{
	if (m_minZoom < m_zoom) 
	{
		m_zoom--;
	}
}

void COrthoViewport::ZoomOut()
{
	if (m_maxZoom > m_zoom) 
	{
		m_zoom++;
	}
}

float COrthoViewport::GetSideLength()
{
	return (float)pow(2, m_zoom);
}

void COrthoViewport::Render()
{
	CViewport::Render();
	SetupProjection();
}
