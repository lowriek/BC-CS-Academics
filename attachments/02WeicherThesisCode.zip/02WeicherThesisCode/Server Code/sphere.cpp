#include <iostream.h>
#include <stdio.h>
#include <math.h>
#include "server.h"
#include "sphere.h"

//a obviously necessary contant value for PI
//const double pi=3.14159265359;

//Function definitions for the Sphere class
Sphere::Sphere(double r, point3d cent, color c, int m1, float refamt, float refract, float trans)
{
	radius=r;
	center=cent;
	color1=c;
	color2.r=-1.0; color2.g=-1.0; color2.b=-1.0;
	mirror1 = m1;
	mirror2 = 0;
	reflectAmt1 = refamt;
	refractIndex1 = refract;
	transAmt1 = trans;
	horizontalChecks=1;
	verticalChecks=1;
}


Sphere::Sphere()
{
	int i,j;
	//set Object defaults
	color1.r = 1.0;	color1.g = 1.0;	color1.b = 1.0;
	color2.r = -1.0; color2.g = -1.0; color2.b = -1.0;
	mirror1 = 0; mirror2 = 0;
	isTextured=0;
	reflectAmt1 = 1.0;
	refractIndex1 = 0.0;
	transAmt1 = 0.0;
	reflectAmt2 = 1.0;
	refractIndex2 = 0.0;
	transAmt2 = 0.0;	
	radius = 1.0;
	center.x = 0.0; center.y = 0.0; center.z=0.0;
	horizontalChecks=1;
	verticalChecks=1;
	//Initialize a bunch of other variables...
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			object_rotation[i][j]=0;
			world_rotation[i][j]=0;
			translation[i][j]=0;
			scale[i][j]=0;
			compositeMatrix[i][j]=0;
			inverseCompositeMatrix[i][j]=0;
		}
	object_rotation[0][0]=object_rotation[1][1]=object_rotation[2][2]=object_rotation[3][3]=1;
	world_rotation[0][0]=world_rotation[1][1]=world_rotation[2][2]=world_rotation[3][3]=1;
	translation[0][0]=translation[1][1]=translation[2][2]=translation[3][3]=1;
	scale[0][0]=scale[1][1]=scale[2][2]=scale[3][3]=1;
	compositeMatrix[0][0]=compositeMatrix[1][1]=compositeMatrix[2][2]=compositeMatrix[3][3]=1;
	inverseCompositeMatrix[0][0]=inverseCompositeMatrix[1][1]=inverseCompositeMatrix[2][2]=inverseCompositeMatrix[3][3]=1;	
	didInverse=FALSE;
	didComposite=FALSE;
	didNormal=FALSE;


}


double Sphere::getRadius()
{  
	return radius;
}

void Sphere::setRadius(double r)
{ 
	radius=r;
}

void Sphere::setCenter(point3d p)
{  
	center = p;
}

point3d Sphere::getCenter()
{  
	return center;
}

float Sphere::getIntersection(ray r) // 0=false 1=true
{
	float t1, t2, sqrtamt;
	
	if(didComposite==FALSE)
		computeCompositeMatrix();																/* If not done, compute comp. matrix */
	if(didInverse==FALSE)
		computeInverseCompositeMatrix(compositeMatrix, inverseCompositeMatrix);					/* If not done, compute inv. comp. matrix */
	if(didNormal==FALSE){
		point3d temp;
		temp.x=0; temp.y=0; temp.z=0;
		setCenter(temp);																		/* Set center to <0,0,0>, which is where it */
																								/*  will need to be for most calculations */
		setDidNormal(TRUE);
	}
		
	//store original incoming ray for later use in mirrored objects
	inRay.p0.x=r.p0.x;
	inRay.p0.y=r.p0.y;
	inRay.p0.z=r.p0.z;
	inRay.p1.x=r.p1.x;
	inRay.p1.y=r.p1.y;
	inRay.p1.z=r.p1.z;
	inRay.rIndex = r.rIndex;
	
	//MODIFICATIONS ON JAN. 10, 2001
	r.p0 = applyMatrixToPoint(inRay.p0, inverseCompositeMatrix);								/* Reverse Transform the ray points */
	r.p1 = applyMatrixToPoint(inRay.p1, inverseCompositeMatrix);								/* so they are relative to the unit sphere */
	
	sqrtamt = 4*pow((center.x-r.p0.x)*(r.p0.x-r.p1.x)+(center.y-r.p0.y)*						/* Check for non-neg within the square-root */
		(r.p0.y-r.p1.y)+(center.z-r.p0.z)*(r.p0.z-r.p1.z),2)-4*(pow(center.x,2)-
		pow(radius,2)-2*center.x*r.p0.x + pow(r.p0.x,2)+pow(center.y-r.p0.y,2)+
		pow(center.z-r.p0.z,2))*(pow(r.p0.x-r.p1.x,2)+pow(r.p0.y-r.p1.y,2)+
		pow(r.p0.z-r.p1.z,2));
	if(sqrtamt<0)
		return -1;

	// if non-negative checks out proceed with calculation of two solutions
	else{
		
		t1=-(sqrt(sqrtamt) + 2*((center.x-r.p0.x)*(r.p0.x-r.p1.x)+(center.y-r.p0.y)*(r.p0.y-r.p1.y)+(center.z-r.p0.z)*
			(r.p0.z-r.p1.z)))/(2.0*(pow(r.p0.x-r.p1.x,2)+pow(r.p0.y-r.p1.y,2)+
			pow(r.p0.z-r.p1.z,2)));
		t2=(sqrt(sqrtamt) - 2*((center.x-r.p0.x)*(r.p0.x-r.p1.x)+(center.y-r.p0.y)*(r.p0.y-r.p1.y)+(center.z-r.p0.z)*
			(r.p0.z-r.p1.z)))/(2.0*(pow(r.p0.x-r.p1.x,2)+pow(r.p0.y-r.p1.y,2)+
			pow(r.p0.z-r.p1.z,2)));		

		if (t1<=0.001 && t2<=0.001){												/* If both solutions <= zero they are ignored */
			finalT = -1;
			return -1;
		}		
		else if(t1<=0.001 && t2>0.001){												/* If t1 is less than zero, t2 greater than zero */
			intersection.x = r.p0.x + t2*(r.p1.x-r.p0.x);
			intersection.y = r.p0.y + t2*(r.p1.y-r.p0.y);
			intersection.z = r.p0.z + t2*(r.p1.z-r.p0.z);
			finalT= t2;
			intersection = applyMatrixToPoint(intersection, compositeMatrix);		/* Transform point back out to real location */
			return t2;
		}
		else if(t2<=0.001 && t1>0.001){												/* If t2 less than zero, t2 greater than zero */
			intersection.x = r.p0.x + t1*(r.p1.x-r.p0.x);
			intersection.y = r.p0.y + t1*(r.p1.y-r.p0.y);
			intersection.z = r.p0.z + t1*(r.p1.z-r.p0.z);
			finalT = t1;
			intersection = applyMatrixToPoint(intersection, compositeMatrix);		/* Transform point back out to real location */
			return t1;
		}
		else if(t1<t2){																/* Both greater than zero, t1 is closer solution */
			intersection.x = r.p0.x + t1*(r.p1.x-r.p0.x);
			intersection.y = r.p0.y + t1*(r.p1.y-r.p0.y);
			intersection.z = r.p0.z + t1*(r.p1.z-r.p0.z);
			finalT = t1;
			intersection = applyMatrixToPoint(intersection, compositeMatrix);		/* Transform point back out to real location */
			return t1;
		}
		else if(t2<t1){																/* Both greater than zero, t2 is closer solution */
			intersection.x = r.p0.x + t2*(r.p1.x-r.p0.x);
			intersection.y = r.p0.y + t2*(r.p1.y-r.p0.y);
			intersection.z = r.p0.z + t2*(r.p1.z-r.p0.z);
			finalT = t2;
			intersection = applyMatrixToPoint(intersection, compositeMatrix);		/* Transform point back out to real location */
			return t2;
		}
		else if(t1==t2){															/* Both solutions are the same */
			intersection.x = r.p0.x + t1*(r.p1.x-r.p0.x);
			intersection.y = r.p0.y + t1*(r.p1.y-r.p0.y);
			intersection.z = r.p0.z + t1*(r.p1.z-r.p0.z);
			finalT = t1;
			intersection = applyMatrixToPoint(intersection, compositeMatrix);		/* Transform point back out to real location */
			return t1;
		}
	}
}


/*  Below are functions that are required for use in the getIlluminatedColor() method
	  which this class inherits from the Tracer parent class
*/
avector Sphere::getNormal()
{
	avector snormal;
	point3d vp1, vp2;

	vp1 = applyMatrixToPoint(intersection, inverseCompositeMatrix);
	vp2.x = vp1.x + (vp1.x - center.x);												/* Add original snormal vector components to get */
	vp2.y = vp1.y + (vp1.y - center.y);												/*  A second point in the vector OUTSIDE the sphere */
	vp2.z = vp1.z + (vp1.z - center.z);
	vp1 = applyMatrixToPoint(vp1, compositeMatrix);									/* Transform these points */
	vp2 = applyMatrixToPoint(vp2, compositeMatrix);
	snormal.x = vp2.x - vp1.x;														/* Construct new snormal from these transformed points */
	snormal.y = vp2.y - vp1.y;
	snormal.z = vp2.z - vp1.z;
	snormal = normalizeVector(snormal);												/* Normalize the vector */
	
	return snormal;
}

int Sphere::inShadow(point3d light)
{
	ray aray;
	avector v;
	
	v.x = light.x - intersection.x;													/* No transforms necessary, the intersecion is already */
	v.y = light.y - intersection.y;													/*  at its real location */
	v.z = light.z - intersection.z;
	
	
	v = normalizeVector(v);

	aray.p0.x = intersection.x;														/* Create a new ray */
	aray.p0.y = intersection.y;
	aray.p0.z = intersection.z;
	aray.p1.x = aray.p0.x + v.x;
	aray.p1.y = aray.p0.y + v.y;
	aray.p1.z = aray.p0.z + v.z;
	
	return fireShadowRay(aray, light);
}

color Sphere::whichColor(){
	point3d realIntersection; 
	
	if(color2.r==-1 || color2.g == -1 || color2.b==-1)										/* Check if color2 was even assigned */
		return color1;
	else{
		float lon, lat, dist, vAngle, halfCircum;
		int hCheck, vCheck;

		lon=getLongitude();	
																							/* Get the relative long. of the intersection */
		hCheck = (int)((lon*getHorizontalChecks())/360.);									/* Determine which "check" it falls into */

		realIntersection.x = intersection.x;												/* Translate intersection back relative to  */
		realIntersection.y = intersection.y;												/*   the origin for these calcs             */
		realIntersection.z = intersection.z;
		intersection = applyMatrixToPoint(intersection, inverseCompositeMatrix);				
																								
		
		dist = 2*getRadius();
		vCheck = (int)((getVerticalChecks()*(intersection.y - (center.y-getRadius())))/dist);
	
		intersection.x = realIntersection.x;												/* Restore intersection back to real location */							
		intersection.y = realIntersection.y;
		intersection.z = realIntersection.z;
	
		if(hCheck==0 && vCheck==0)
			return color1;
		else if(hCheck%2==1 && vCheck%2==1)
			return color1;
		else if(hCheck%2==0 && vCheck%2==0)
			return color1;
		else
			return color2;
	}
}

int Sphere::whichMirror(){
	point3d realIntersection; 
	
	if(mirror1==mirror2)																	/* Check both are the same, just return one */
		return mirror1;
		
	else{
		float lon, lat, dist, vAngle, halfCircum;
		int hCheck, vCheck;

		lon=getLongitude();	
																							/* Get the relative long. of the intersection */
		hCheck = (int)((lon*getHorizontalChecks())/360.);									/* Determine which "check" it falls into */

		realIntersection.x = intersection.x;												/* Translate intersection back relative to  */
		realIntersection.y = intersection.y;												/*   the origin for these calcs             */
		realIntersection.z = intersection.z;
		intersection = applyMatrixToPoint(intersection, inverseCompositeMatrix);				
																								
		
		dist = 2*getRadius();
		vCheck = (int)((getVerticalChecks()*(intersection.y - (center.y-getRadius())))/dist);		/* Center of sphere already at <0, 0, 0>  */
	
		intersection.x = realIntersection.x;												/* Restore intersection back to real location */							
		intersection.y = realIntersection.y;
		intersection.z = realIntersection.z;
	
		if(hCheck==0 && vCheck==0)
			return mirror1;
		else if(hCheck%2==1 && vCheck%2==1)
			return mirror1;
		else if(hCheck%2==0 && vCheck%2==0)
			return mirror1;
		else
			return mirror2;
	}
	
}

float Sphere::getLongitude(){
	float rads, x, z, degs;
	point3d realIntersection;
	
	realIntersection.x = intersection.x;													/* Save real intersection location */
	realIntersection.y = intersection.y;
	realIntersection.z = intersection.z;

	intersection = applyMatrixToPoint(intersection, inverseCompositeMatrix);				/* Translate intersection back to be */
																							/*  relative to origin  */
																							/* Center is already at <0,0,0>  */
	
	x = intersection.x-center.x;															// Determine difference in the x components
	z = intersection.z-center.z;															// Determine difference in the z components
	z = -z;																					// Reverse sign because the relative axis
																							//  is different from standard cartesian
	
	rads = atan2f(z,x);																		// Compute the number of radians around the sphere
	if(rads < 0)
		rads = (pi + (pi+rads)); 
				
	degs = (rads*360.)/(2.*pi);																// Convert radians to degrees for ease of use

	intersection.x = realIntersection.x;													/* Restore intersection back to real location */
	intersection.y = realIntersection.y;
	intersection.z = realIntersection.z;
	
	return degs;	
																							/* Return the number of degrees around the */
																							/*  sphere starting at z-most point   */
}																							/*  around via the y-most point  */

float Sphere::getLatitude(){
	float rads, y, x, degs;
	point3d realIntersection;
	
	realIntersection.x = intersection.x;													/* Save real intersection location  */
	realIntersection.y = intersection.y;
	realIntersection.z = intersection.z;
	
	intersection = applyMatrixToPoint(intersection, inverseCompositeMatrix);				/* Translate intersection to be origin relative */
			
	
	y = intersection.y-center.y;															/* Center already at <0, 0, 0>  */
	x = intersection.x-center.x;
	
	rads = atanf(y/x);																		/* Compute the number of radians around the 
																							/*  sphere starting at the x-most point */
																							/*  around via the y-most point */
	
	degs = (rads*360.)/(2.*pi);																/* Conv to degrees around sphere from x-most pt. */

	intersection.x = realIntersection.x;													/* Restore intersection to real location */
	intersection.y = realIntersection.y;
	intersection.z = realIntersection.z;

	return degs;
}

color Sphere::getTexturePixel(){
	color blah;
	blah.r = 1.0; blah.g=1.0; blah.b=1.0;
	return blah;
}
