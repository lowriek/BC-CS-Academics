class Rosterspot < ActiveRecord::Base
	belongs_to :team
	belongs_to :player
	validates_presence_of :player_id
	validates_presence_of :team_id

	validates_uniqueness_of :player_id, :scope => [:team_id]
end
