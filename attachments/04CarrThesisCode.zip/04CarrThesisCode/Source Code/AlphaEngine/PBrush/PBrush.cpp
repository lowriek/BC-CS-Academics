#include "PBrush.h"
#include <windows.h>
#include <gl/gl.h>

void CPBrush::allocate(unsigned int numPoly)
{
	numPolygon = numPoly;
	pPolygon = new CPolygon[numPolygon];
	pPolygonPickColor = new CColor4[numPolygon];
}

CColor4 CPBrush::brushId2PickColor(PBRUSHID brushId)
{
	CColor4 retColor;
	unsigned int rval = 0;
	unsigned int gval = 0;
	unsigned int bval = 0;
	unsigned int x = brushId;
	if (x == 0)
		return retColor;
	while (rval < 255 && x > 0)
	{
		while (gval < 255 && x > 0)
		{
			while (bval < 255 && x > 0)
			{
				if (x <= 255)
				{
					bval = x;
					x = 0;
				} else
				{
					bval = 255;
					x -= 255;
				}
			}
			if (x > 0)
			{
				gval++;
				bval = 0;
				x--;
			}
		}
		if (x > 0)
		{
			rval++;
			gval = 0;
			x--;
		}
	}
	retColor.r = rval;
	retColor.g = gval;
	retColor.b = bval;
	return retColor;
}

CPBrush* CPBrush::clone()
{
	CPBrush* pBrush = new CPBrush();
	pBrush->allocate(numPolygon);
	for (unsigned int x = 0; x < numPolygon; x++)
	{
		pBrush->pPolygon[x].allocate(pPolygon[x].numVert);
		pBrush->pPolygon[x].alpha = pPolygon[x].alpha;
		pBrush->pPolygon[x].bTxId = pPolygon[x].bTxId;
		pBrush->pPolygon[x].dTxId = pPolygon[x].dTxId;
		pBrush->pPolygon[x].plane = pPolygon[x].plane;

		for (unsigned int y = 0; y < pPolygon[x].numVert; y++)
		{
			pBrush->pPolygon[x].pVert[y] = pPolygon[x].pVert[y];
			pBrush->pPolygon[x].pBTxCoord[y] = pPolygon[x].pBTxCoord[y];
			pBrush->pPolygon[x].pDTxCoord[y] = pPolygon[x].pDTxCoord[y];
		}
	}
	return pBrush;
}

CPBrush::CPBrush()
{
	brushId = 0;
	numPolygon = 0;
	pickColor = CColor4(0,0,0,0);
	pPolygonPickColor = 0;
	pPolygon = 0;
}

CPBrush::~CPBrush()
{
	if (pPolygon)
		delete [] pPolygon;
	if (pPolygonPickColor)
		delete [] pPolygonPickColor;
}

CPolygon* CPBrush::getPolygonList()
{
	// return a linked list of polygons for this brush
	if (!pPolygon)
		return 0;
	
	CPolygon* pRoot = pPolygon[0].clone();
	for (unsigned int x = 1; x < numPolygon; x++)
		pRoot->add(pPolygon[x].clone());

	return pRoot;
}

CPBrush* CPBrush::intrudePolygon(PBRUSHID polygonId, float distance)
{
	if (polygonId >= numPolygon || distance == 0.0f || !pPolygon)
		return NULL;

	CPBrush * pBrush = new CPBrush();
	pBrush->allocate(pPolygon[polygonId].numVert+2);
	// create back poly (copy of original poly) and front poly
	for (int x=0; x < 2; x++)
	{
		pBrush->pPolygon[x].allocate(pPolygon[polygonId].numVert);
		pBrush->pPolygon[x].plane = pPolygon[polygonId].plane;
		for (unsigned int y=0; y < pBrush->pPolygon[x].numVert; y++)
		{
			pBrush->pPolygon[x].pVert[y] = pPolygon[polygonId].pVert[y];
			pBrush->pPolygon[x].pBTxCoord[y] = pPolygon[polygonId].pBTxCoord[y];
			pBrush->pPolygon[x].pDTxCoord[y] = pPolygon[polygonId].pDTxCoord[y];
		}
		pBrush->pPolygon[x].bTxId = pPolygon[polygonId].bTxId;
		pBrush->pPolygon[x].dTxId = pPolygon[polygonId].dTxId;
	}
	// modify front poly
	CMatrix44 transform;
	CVector3 intrudeDistance = pBrush->pPolygon[0].plane.normal * distance;
	transform.translate(intrudeDistance);
	pBrush->pPolygon[1].transform(transform);
	// create side polygons
	int sides = pBrush->numPolygon-2;
	for (int j = 0; j < sides; j++)
	{
		int index = j+2;
		int vA = j;
		int vB = (j+1)%sides;
	
		pBrush->pPolygon[index].allocate(4);

		pBrush->pPolygon[index].pBTxCoord[0] = CVector2(0,1);
		pBrush->pPolygon[index].pDTxCoord[0] = CVector2(0,1);
		pBrush->pPolygon[index].pBTxCoord[1] = CVector2(0,0);
		pBrush->pPolygon[index].pDTxCoord[1] = CVector2(0,0);
		pBrush->pPolygon[index].pBTxCoord[2] = CVector2(1,0);
		pBrush->pPolygon[index].pDTxCoord[2] = CVector2(1,0);
		pBrush->pPolygon[index].pBTxCoord[3] = CVector2(1,1);
		pBrush->pPolygon[index].pDTxCoord[3] = CVector2(1,1);


		pBrush->pPolygon[index].pVert[0] = pBrush->pPolygon[0].pVert[vB];
		pBrush->pPolygon[index].pVert[1] = pBrush->pPolygon[0].pVert[vA];
		pBrush->pPolygon[index].pVert[2] = pBrush->pPolygon[1].pVert[vA];
		pBrush->pPolygon[index].pVert[3] = pBrush->pPolygon[1].pVert[vB];

		pBrush->pPolygon[index].bTxId = pBrush->pPolygon[0].bTxId;
		pBrush->pPolygon[index].dTxId = pBrush->pPolygon[0].dTxId;
	}

	pBrush->pPolygon[1].flip();

	pBrush->setNormals();
	pBrush->setPolygonPickColor();
	return pBrush;
}

void CPBrush::pickBrush(const int &mode)
{
	unsigned int x;
	int t1 = mode & ALPHA_WIREFRAME;
	int t2 = mode & ALPHA_FILL;

	glColor3ub(pickColor.r, pickColor.g, pickColor.b);
	if (t1 == ALPHA_WIREFRAME)
	{
		for (x=0; x<numPolygon; x++)
			pPolygon[x].render(ALPHA_WIREFRAME);

		return;
	}
	else if (t2 == ALPHA_FILL)
	{
		for (x = 0; x < numPolygon; x++)
		{
			if (opType == ALPHA_ADD)
				glCullFace(GL_BACK);
			else if (opType == ALPHA_SUB)
				glCullFace(GL_FRONT);

			pPolygon[x].render(ALPHA_FILL);
		}
	}
}

PBRUSHID CPBrush::pickColor2BrushId(CColor4 &pickColor)
{
	PBRUSHID retval = 0;
	unsigned int rval = 0;
	unsigned int gval = 0;
	unsigned int bval = 0;
	if (pickColor.r == 0 && (pickColor.g == 0 && pickColor.b == 0))
		return 0;

	while (rval < 255)
	{
		while (gval < 255)
		{
			while (bval < 255)
			{
				bval++;
				retval++;
				if (pickColor.r == rval && (pickColor.g == gval && pickColor.b == bval))
					return retval;
			}
			gval++;
			retval++;
			bval = 0;
			if (pickColor.r == rval && (pickColor.g == gval && pickColor.b == bval))
				return retval;
		}
		rval++;
		retval++;
		gval = 0;
		if (pickColor.r == rval && (pickColor.g == gval && pickColor.b == bval))
			return retval;
	}
	return 0;
}

void CPBrush::render(int flags)
{
	if (!pPolygon)
		return;

	for (unsigned int x=0; x < numPolygon; x++)
	{
		if (opType == ALPHA_ADD)
			glCullFace(GL_BACK);
		else if (opType == ALPHA_SUB)
			glCullFace(GL_FRONT);

		pPolygon[x].render(flags);
	}
}

bool CPBrush::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;
	
	unsigned int x;

	if (isStoring)
	{
		fwrite(&brushId, sizeof(PBRUSHID), 1, filePtr);
		fwrite(&numPolygon, sizeof(unsigned int), 1, filePtr);
		fwrite(&opType, sizeof(int), 1, filePtr);
	}
	else
	{
		fread(&brushId, sizeof(PBRUSHID), 1, filePtr);
		fread(&numPolygon, sizeof(unsigned int), 1, filePtr);
		fread(&opType, sizeof(int), 1, filePtr);
		allocate(numPolygon);
	}

	for (x=0; x < numPolygon; x++)
	{
		if (!pPolygon[x].serialize(filePtr, isStoring)) return false;
		if (!pPolygonPickColor[x].serialize(filePtr, isStoring)) return false;
	}
	
	return pickColor.serialize(filePtr, isStoring);
}

void CPBrush::setNormals()
{
	if (!pPolygon)
		return;

	for (unsigned int x=0; x< numPolygon; x++)
		pPolygon[x].calculatePlane();
}

void CPBrush::setPickColor()
{
	pickColor = CPBrush::brushId2PickColor(brushId);
}

void CPBrush::setPolygonPickColor()
{
	if (numPolygon == 0)
		return;
	
	if (!pPolygon)
		return;

	if (pPolygonPickColor)
		delete [] pPolygonPickColor;

	pPolygonPickColor = new CColor4[numPolygon];

	for (unsigned int x = 0; x < numPolygon; x++)
	{
		// TODO: SUPPORT MORE THAN 254 sided faces.
		pPolygonPickColor[x].a = 255;
		pPolygonPickColor[x].r = x+1;
		pPolygonPickColor[x].g = 0;
		pPolygonPickColor[x].b = 0;
	}
}

void CPBrush::transform(const CMatrix44 &matrix)
{
	if (!pPolygon)
		return;

	unsigned int x, y;
	unsigned int numVert = 0;
	CVector3 midpt;

	for (x = 0; x < numPolygon; x++)
		for (y=0; y < pPolygon[x].numVert; y++)
		{
			midpt += pPolygon[x].pVert[y];
			numVert++;
		}

	midpt /= (float)numVert;

	CMatrix44 toOrigin, fromOrigin, composite;
	toOrigin.translate(-midpt);
	fromOrigin.translate(midpt);
	composite =  fromOrigin * matrix * toOrigin;

	for (x = 0; x < numPolygon; x++)
		pPolygon[x].transform(composite);

	// might change if rotated
	setNormals();
}