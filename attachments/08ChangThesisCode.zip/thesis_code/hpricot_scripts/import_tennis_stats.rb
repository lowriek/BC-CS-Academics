require 'rubygems'
require 'hpricot'
require 'open-uri'

statfile = 'tennis_statfile.list'

doc = Hpricot(open(statfile))

(doc/'game').each { |g|
	gamename = g.get_attribute('name')
	Game.create :name => gamename
	
	# get rid of spaces in names
	t1p1=(g/'team1').attr('p1').gsub(/ /,'')
	t1p1s=(g/'team1').attr('p1')
	t1p2=(g/'team1').attr('p2').gsub(/ /,'')
	t1p2s=(g/'team1').attr('p2')
	t2p1=(g/'team2').attr('p1').gsub(/ /,'')
	t2p1s=(g/'team2').attr('p1')
	t2p2=(g/'team2').attr('p2').gsub(/ /,'')
	t2p2s=(g/'team2').attr('p2')

	if (t1p2 == '')
		Team.create :name => t1p1, :sport_id => Sport.find_by_name('tennis').id
		team1name = t1p1
		Rosterspot.create :team_id => Team.find_by_name(team1name).id,:player_id => Player.find_by_name(t1p1s).id
	else
		if (t1p1<t1p2)
			Team.create :name => t1p1+'_'+t1p2, :sport_id => Sport.find_by_name('tennis').id
			team1name = t1p1+'_'+t1p2
		else
			Team.create :name => t1p2+'_'+t1p1, :sport_id => Sport.find_by_name('tennis').id
			team1name = t1p2+'_'+t1p1
		end
		Rosterspot.create :team_id => Team.find_by_name(team1name).id,:player_id => Player.find_by_name(t1p1s).id
		Rosterspot.create :team_id => Team.find_by_name(team1name).id,:player_id => Player.find_by_name(t1p2s).id
	end
	if (t2p2 == '')
		Team.create :name => t2p1, :sport_id => Sport.find_by_name('tennis').id
		team2name = t2p1
		Rosterspot.create :team_id => Team.find_by_name(team2name).id,:player_id => Player.find_by_name(t2p1s).id
	else
		if (t2p1<t2p2)
			Team.create :name => t2p1+'_'+t2p2, :sport_id => Sport.find_by_name('tennis').id
			team2name = t2p1+'_'+t2p2
		else
			Team.create :name => t2p2+'_'+t2p1, :sport_id => Sport.find_by_name('tennis').id
			team2name = t2p2+'_'+t2p1
		end
		Rosterspot.create :team_id => Team.find_by_name(team2name).id,:player_id => Player.find_by_name(t2p1s).id
		Rosterspot.create :team_id => Team.find_by_name(team2name).id,:player_id => Player.find_by_name(t2p2s).id
	end

	GameTeam.create :game_id => Game.find_by_name(gamename).id ,:team_id => Team.find_by_name(team1name).id
	GameTeam.create :game_id => Game.find_by_name(gamename).id ,:team_id => Team.find_by_name(team2name).id

	(g/'stat').each { |s|
		val = s.get_attribute('value')
		game = s.get_attribute('gamename')
		sc = s.get_attribute('statconcept')
		player = s.get_attribute('pname')
		if (player == '')
			player = 'unknown'
		end
		Stat.create :value => val, :game_id => Game.find_by_name(game).id, :player_id => Player.find_by_name(player).id, :statconcept_id => Statconcept.find_by_name(sc).id

		
	}
}
