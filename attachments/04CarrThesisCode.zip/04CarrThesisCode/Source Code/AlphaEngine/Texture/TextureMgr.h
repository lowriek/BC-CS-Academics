#ifndef _TEXTUREMGR_H_
#define _TEXTUREMGR_H_

#pragma warning (disable:4786)

#include "AlphaEngine/Texture/Texture.h"
#include <gl/gl.h>
#include <list>
#include <map>

using namespace std;

typedef map<unsigned int, CTexture*> INT2TEXTURE;

class CTextureMgr  
{
public:
	CTextureMgr();
	virtual ~CTextureMgr();
	
	CTexture*		getTextures();
	bool			loadTexturePak(const char* filename);
	unsigned int	getTextureId(const char* textureName);

private:
	bool			createGLTexture(CTexture* pTexture);
	CTexture*		pTexture;
};

#endif 
