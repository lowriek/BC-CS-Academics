#include "AlphaEngine/Core/Camera.h"
#include "AlphaEngine/Math/Matrix44.h"

CCamera::CCamera()
{
	position = CVector3(0,0,0);
	view = CVector3(1,0,0);
	strafe = CVector3(0,1,0);
	up = CVector3(0,0,1);

	pFrustum = new CFrustum();
}

CCamera::~CCamera()
{
	if (pFrustum)
	{
		delete pFrustum;
	}
}

CFrustum * CCamera::getFrustum()
{
	return pFrustum;
}

void CCamera::Lift(float distance)
{
	// Make sure the up vector is the unit vector
	position += up * distance;
}

void CCamera::Look()
{

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(	position[0],			position[1],			position[2],
				position[0] + view[0],	position[1] + view[1],	position[2] + view[2],
				up[0],					up[1],					up[2] );

	pFrustum->update();
}

void CCamera::Move(float distance)
{
	view.unitize();

	position += view * distance;
}

void CCamera::Render()
{
	glPushAttrib(GL_LINE_BIT);
	glLineWidth(2);
	glPushMatrix();
		glTranslatef(position[0], position[1], position[2]);
		glPushMatrix();
			glScalef(8,8,8);
			glColor3f(0.0f,0.0f,0.0f);
			glBegin(GL_LINE_LOOP);
				glVertex3f( 1.0f, 1.0f,-1.0f);
				glVertex3f(-1.0f, 1.0f,-1.0f);
				glVertex3f(-1.0f, 1.0f, 1.0f);
				glVertex3f( 1.0f, 1.0f, 1.0f);
			glEnd();
			glBegin(GL_LINE_LOOP);
				glVertex3f( 1.0f,-1.0f, 1.0f);
				glVertex3f(-1.0f,-1.0f, 1.0f);
				glVertex3f(-1.0f,-1.0f,-1.0f);
				glVertex3f( 1.0f,-1.0f,-1.0f);
			glEnd();
			glBegin(GL_LINE_LOOP);
				glVertex3f( 1.0f, 1.0f, 1.0f);
				glVertex3f(-1.0f, 1.0f, 1.0f);
				glVertex3f(-1.0f,-1.0f, 1.0f);
				glVertex3f( 1.0f,-1.0f, 1.0f);
			glEnd();
			glBegin(GL_LINE_LOOP);
				glVertex3f( 1.0f,-1.0f,-1.0f);
				glVertex3f(-1.0f,-1.0f,-1.0f);
				glVertex3f(-1.0f, 1.0f,-1.0f);
				glVertex3f( 1.0f, 1.0f,-1.0f);			
			glEnd();
			glBegin(GL_LINE_LOOP);
				glVertex3f(-1.0f, 1.0f, 1.0f);
				glVertex3f(-1.0f, 1.0f,-1.0f);
				glVertex3f(-1.0f,-1.0f,-1.0f);
				glVertex3f(-1.0f,-1.0f, 1.0f);	
			glEnd();
			glBegin(GL_LINE_LOOP);
				glVertex3f( 1.0f, 1.0f,-1.0f);
				glVertex3f( 1.0f, 1.0f, 1.0f);
				glVertex3f( 1.0f,-1.0f, 1.0f);
				glVertex3f( 1.0f,-1.0f,-1.0f);			
			glEnd();
			
			glColor3f(1,0,0);
			glBegin(GL_LINES);
				glVertex3f(0,0,0);
				glVertex3fv(view.points);
			glEnd();
			
		glPopMatrix();
	glPopMatrix();	
	
	glPopAttrib();
}

void CCamera::RotateView(float angle, float x, float y, float z)
{
	CMatrix44 matrix;
	if (x == 1)
	{
		matrix.rotateX(angle);
	}
	else if (y == 1)
	{
		matrix.rotateY(angle);
	} else if (z == 1)
	{
		matrix.rotateZ(angle);
	}

	view = matrix * view;
	up = matrix * up;
	strafe = matrix * strafe;

	view.unitize();
	up.unitize();
	strafe.unitize();
}

void CCamera::Strafe(float distance)
{
	CVector3 delta = strafe * distance;
	position += delta;
	
}
void CCamera::Update()
{

}