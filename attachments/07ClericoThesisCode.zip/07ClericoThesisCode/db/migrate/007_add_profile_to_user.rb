class AddProfileToUser < ActiveRecord::Migration
  def self.up
  	add_column :users, :profileid, :integer
  end

  def self.down
	  remove_column :users, :profileid
  end
end
