// WorldEditorDoc.h : interface of the CWorldEditorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WORLDEDITORDOC_H__27450C3C_6167_4B80_A1EB_9A30296FF979__INCLUDED_)
#define AFX_WORLDEDITORDOC_H__27450C3C_6167_4B80_A1EB_9A30296FF979__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AlphaEngine/AlphaEngine.h"
#include "AlphaEngine/Math/Rect3d.h"
#include "AlphaEngine/PBrush/PBrush.h"
#include "AlphaEngine/PBrush/PBrushMgr.h"
#include "AlphaEngine/Core/Camera.h"
#include "AlphaEngine/Texture/Texture.h"

#define TRANSLATE 0
#define ROTATE 1
#define SCALE 2

class CWorldEditorDoc : public CDocument
{
protected: // create from serialization only
	CWorldEditorDoc();
	DECLARE_DYNCREATE(CWorldEditorDoc)
	
	BOOL	InitDocument();

public:

	bool	BrushesSelected();
	void	BrushScale(CVector3 p1, CVector3 p2);
	void	CSGAdd();
	void	CSGSub();
	void	CreateBox(CVector3 axis, CVector3 p1, CVector3 p2);
	void	CreateSphere(CVector3 axis, CVector3 p1, CVector3 p2);
	void	CreateBsp();
	void	CreatePvs();
	void	DeselectPBrush();
	void	DeleteBuilder();
	void	DeletePBrush();
	CTexture* GetTextures();
	void	PickPBrush(int displayMode, int x, int y);
	void	PickPoly(int displayMode, int x, int y);
	void	Render(int mode);
	void	SetBaseTx(const char *textureName);
	void	SetDecalTx(const char *textureName);
	void	SetPolygonProp(const PolygonProp &polygonProp);
	void	SetRenderBrush();
	void	SetRenderCSG();
	void	SetRenderFinal();
	void	TransformBrushes(const CMatrix44& matrix);

	short int	BRUSH_MANIP_MODE;
	short int	RENDER_MODE;
	BOOL		UPDATE_LIST;

	CAlphaEngine* pAlphaEngine;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWorldEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWorldEditorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWorldEditorDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORLDEDITORDOC_H__27450C3C_6167_4B80_A1EB_9A30296FF979__INCLUDED_)
