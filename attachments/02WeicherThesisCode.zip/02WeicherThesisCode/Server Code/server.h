#ifndef _SERVER_H
#define _SERVER_H

#include "tracer.h"  

#define MYPORT 2000
#define MAXFD 20
#define BACKLOG 10
#define MAX_OBJECTS 10
#define RINDEX_AIR 1.0
#define NO 0
#define YES 1
#define FALSE 0
#define TRUE 1

//Globals 
const double pi=3.14159265359;		//Geometric Constant
extern float AMBIENT;	        	//Ambient scene light level
extern int NUM_OBJECTS;			    //Number of objects in scene
extern int ANTI_ALIAS;				//0=no, 1=yes
extern int CAST_SHADOWS;			//0=no, 1=yes
extern int ENABLE_FOG;				//0=no, 1=yes
extern float fog_min_dist;			//distance at which fogging effects become initially apparent
extern float fog_max_dist;		        //distance at which scene is in full fog
extern float SHADOW_FACTOR;			//amount to affect base color if in shadow

/*Other, typedef and class dependant variables and functions
	-must therefore be defined after the above.   */
	
extern int currentLine;
extern color fog_color, light_color;
extern point3d eye, screen, light;
extern ray theray;




//Raytracing functions
void initSceneVars();
int traceScene(int xmin, int xmax, int xstep, int ymin, int ymax, int ystep);
int fireShadowRay(ray r, point3d light);
color fireRay(ray r);
void rayIncrementY();
void rayIncrementX();
void receiveDataRequest(int sock);
void sendPixelData(int sock, int numfloats);

//prototypes for various inline power functions
float Power(float a, int b);
float Power(float a, float b);
float Power(float a, double b);

float Power(int a, int b);
float Power(int a, float b);
float Power(int a, double b);

float Power(double a, int b);
float Power(double a, float b);
float Power(double a, double b);

float SQRT(float a);


//Server Functions
void receiveParamString(char * buf, int sock);
void sendFileRequest(int sock);
void sendParamsRequest(int sock);
void receiveFile(FILE * iFile, int sock);
void bailOut(int aSignal);
int child_server(int new_fd, int mynum);
int parseParams(char * params, int * xmin, int * xmax, int * xstep, int * ymin, int * ymax, int * ystep);




#endif
