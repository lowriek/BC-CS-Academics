/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						WINMAIN.CPP							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */
#define WIN32_MEAN_AND_LEAN
#define WIN32_EXTRA_LEAN
#include "engine.h"
#include "thread.h"
/*
class TestMEngine : public MEngine
{
public:
	initTestEngine();

};

TestMEngine::initTestEngine()
{

}*/
/* Global Engine */

MEngine	* GblEngine;


WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow)
{
	
		GblEngine = new MEngine();
		GblEngine->Draw();
		return -1;

}

