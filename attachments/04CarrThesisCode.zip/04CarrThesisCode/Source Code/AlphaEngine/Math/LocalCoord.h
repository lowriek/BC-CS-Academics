#ifndef _LOCALCOORD_H_
#define _LOCALCOORD_H_

#include "AlphaEngine/Math/Vector3.h"

class CLocalCoord {
public:
	CLocalCoord();
	virtual ~CLocalCoord();

	virtual bool serialize(FILE * filePtr, bool isStoring);

	CVector3	position;
	CVector3	right;
	CVector3	up;
	CVector3	view;

};
#endif