class Profile < ActiveRecord::Base

	#attr_reader :id

	def self.find_available
		find_all_by_available(true)
	end	

	validates_presence_of :first_name, :last_name, :phone_number, :email, :street_address
	validates_format_of :email,
		:with => %r{.+@.+\..+}i,
		:message => "must be of the form name@domain.suffix."
	validates_format_of :phone_number,
		:with => %r{...-...-....}i,
		:message => "must be of the form xxx-xxx-xxxx."
	validates_format_of :street_address,
		:with => %r{.+,.+,.+}i,
		:message => "must be a proper address of the form: Street, City, State"

end
