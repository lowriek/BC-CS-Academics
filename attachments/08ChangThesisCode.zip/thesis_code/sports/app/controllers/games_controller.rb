class GamesController < ApplicationController
	layout 'standard'
	def index
		@games = Game.find(:all)
	end

	def show
		@game = Game.find(params[:id])
		@teams = Array.new
		@players = Array.new
		GameTeam.find_all_by_game_id(@game.id).each { |gt|
			@teams << Team.find_by_id(gt.team_id)
		}
		@stats = Stat.find_all_by_game_id(@game.id)

		sc = Statconcept.find(@stats[0].statconcept_id)
		sp = Sport.find_by_id(sc.sport_id)
		if (sp.name == 'tennis')
			render :action => 'show_tennis'
		elsif (sp.name == 'nascar')
			@finalpos_stats = Stat.find(:all, :conditions =>{ :game_id => @game.id, :statconcept_id => Statconcept.find_by_name('final_pos').id}, :order => :value)
			@startpos_stats = Stat.find(:all, :conditions =>{ :game_id => @game.id, :statconcept_id => Statconcept.find_by_name('start_pos').id})
			render :action => 'show_nascar'
		elsif (sp.name == 'basketball')
			render :action => 'show_basketball'
		end
	end

	def show_tennis
		
	end
	def show_basketball

	end
	def show_nascar

	end

end
