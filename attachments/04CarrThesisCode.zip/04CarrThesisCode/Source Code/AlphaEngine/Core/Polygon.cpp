#include "AlphaEngine/Core/Polygon.h"
#include "AlphaEngine/Render/Render.h"
#include "AlphaEngine/Math/Math.h"

void CPolygon::add(CPolygon* pPolygon)
{
	if (pPolygon == 0)
		return;

	if (pNext)
		pNext->add(pPolygon);
	else
		pNext = pPolygon;
}

bool CPolygon::allocate(unsigned int numVert)
{
	if (numVert == 0)
		return false;

	this->numVert = numVert;
	pVert = new CVector3[numVert];
	pBTxCoord = new CVector2[numVert];
	pDTxCoord = new CVector2[numVert];

	return true;
}

void CPolygon::calculatePlane()
{
	if (numVert > 2)
	{
		CVector3 v1 = pVert[2] - pVert[1];
		CVector3 v2 = pVert[0] - pVert[1];

		v1.unitize();
		v2.unitize();
		plane.normal = v1.unitCross(v2);
		plane.d = -plane.normal.dot(pVert[0]);
	}
}

int CPolygon::classify(CPlane& planeTest)
{
	int numPos = 0;
	int numNeg = 0;
	int numCo = 0;
	for (unsigned int i=0; i < numVert; i++)
	{
		int retval = planeTest.classifyPoint(pVert[i]);
		switch(retval)
		{
		case ALPHA_INFRONT:
			numPos++;
			break;
		case ALPHA_BEHIND:
			numNeg++;
			break;
		case ALPHA_COINCIDING:
			numCo++;
			break;
		}
	}

	if (numPos > 0 && numNeg == 0)
		return ALPHA_INFRONT;
	if (numNeg > 0 && numPos == 0)
		return ALPHA_BEHIND;
	if (numPos == 0 && numNeg == 0)
		return ALPHA_COINCIDING;

	return ALPHA_SPANNING;
}

CPolygon* CPolygon::clone()
{
	CPolygon* pPolygon = new CPolygon();
	pPolygon->allocate(numVert);
	pPolygon->alpha = alpha;
	pPolygon->bTxId = bTxId;
	pPolygon->dTxId = dTxId;
	pPolygon->plane = plane;
	pPolygon->flag = flag;
	for (unsigned int x = 0; x < numVert; x++)
	{
		pPolygon->pBTxCoord[x] = pBTxCoord[x];
		pPolygon->pDTxCoord[x] = pDTxCoord[x];
		pPolygon->pVert[x] = pVert[x];
	}
	return pPolygon;
}

CPolygon::CPolygon()
{
	numVert = 0;
	alpha = 1.0f;
	bTxId = 0;
	dTxId = 0;
	pVert = 0;
	pBTxCoord = 0;
	pDTxCoord = 0;
	pNext = 0;
	flag = false;
}

CPolygon::~CPolygon()
{
	if (pNext)
		delete pNext;

	pNext = 0;
	deallocate();
}

void CPolygon::deallocate()
{
	if (pVert)
		delete [] pVert;
	if (pBTxCoord)
		delete [] pBTxCoord;
	if (pDTxCoord)
		delete [] pDTxCoord;
	
	pVert = 0;
	pBTxCoord = 0;
	pDTxCoord = 0;
	numVert = 0;
}

void CPolygon::flip()
{
	if (numVert == 0 || !pVert)
		return;
	
	CVector3 tV;
	CVector2 tT;
	for (int k = 0; k < (int)CMath::Floor(numVert / 2.0f); k++)
	{
		int index = numVert - 1 - k;
		tV = pVert[index];
		pVert[index] = pVert[k];
		pVert[k] = tV;

		tT = pBTxCoord[index];
		pBTxCoord[index] = pBTxCoord[k];
		pBTxCoord[k] = tT;

		tT = pDTxCoord[index];
		pDTxCoord[index] = pDTxCoord[k];
		pDTxCoord[k] = tT;
	}
	calculatePlane();
}

void CPolygon::insertVert(CVector3 &v, CVector2 &bTxCoord, CVector2 &dTxCoord)
{
	unsigned int oldNumVert = numVert;
	unsigned int newNumVert = oldNumVert + 1;
	unsigned int x;
	
	CVector3* pNewVert = new CVector3[newNumVert];
	CVector2* pNewBTx = new CVector2[newNumVert];
	CVector2* pNewDTx = new CVector2[newNumVert];

	for (x = 0; x < oldNumVert; x++)
	{
		pNewVert[x] = pVert[x];
		pNewBTx[x] = pBTxCoord[x];
		pNewDTx[x] = pDTxCoord[x];
	}

	pNewVert[oldNumVert] = v;
	pNewBTx[oldNumVert] = bTxCoord;
	pNewDTx[oldNumVert] = dTxCoord;

	if (pVert)
		delete [] pVert;
	if (pBTxCoord)
		delete [] pBTxCoord;
	if (pDTxCoord)
		delete [] pDTxCoord;

	numVert = newNumVert;
	pVert = pNewVert;
	pBTxCoord = pNewBTx;
	pDTxCoord = pNewDTx;

	calculatePlane();
}

bool CPolygon::rayIntersect(CVector3 &ro, CVector3 &rd, CVector3 &ip, float &t, float rad)
{
	if (numVert == 0)
		return false;

	if (plane.rayIntersect(ro, rd, ip, t))
	{
		unsigned int x;
		unsigned int indexA, indexB;
		CVector3 v1, v2, norm;
		float d;
		for (x = 0; x < numVert; x++)
		{
			indexA = x;
			indexB = (x+1) % numVert;
			v1 = pVert[indexA] - ip;
			v2 = pVert[indexB] - ip;
			norm = v1.unitCross(v2);
			d = plane.normal.dot(-ro);
			if ((ip.dot(norm) + d) < rad)
				return false;
		}
		return true;
	}
	else
		return false;
}

void CPolygon::render(int flags)
{
	unsigned int x;
	if ( (flags & ALPHA_WIREFRAME) == ALPHA_WIREFRAME)
	{
		glBegin(GL_LINE_LOOP);

		for (x = 0; x < numVert; x++)
			glVertex3fv(pVert[x].points);

		glEnd();
	}

	if ((flags & ALPHA_FILL) != ALPHA_FILL)
		return;

	if (Render::glActiveTextureARB == 0 || Render::glMultiTexCoord2fARB == 0)
		return;

	bool bTex = (flags & ALPHA_B_TX) == ALPHA_B_TX;
	bool dTex = (flags & ALPHA_D_TX) == ALPHA_D_TX;

	if (alpha != 1.0f)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glColor4f(1,1,1,alpha);
	}

	Render::glActiveTextureARB(GL_TEXTURE0_ARB);
	if (bTex && bTxId != 0)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, bTxId);
	}

	Render::glActiveTextureARB(GL_TEXTURE1_ARB);
	if (dTex && dTxId != 0)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, dTxId);
	}

	glBegin(GL_POLYGON);
	for (x = 0; x < numVert; x++)
	{
		Render::glMultiTexCoord2fARB(GL_TEXTURE0_ARB, pBTxCoord[x].x, pBTxCoord[x].y);
		Render::glMultiTexCoord2fARB(GL_TEXTURE1_ARB, pDTxCoord[x].x, pDTxCoord[x].y);
		glVertex3fv(pVert[x].points);
	}
	glEnd();

	if (alpha != 1.0f)
	{
		glDisable(GL_BLEND);
		glColor4f(1,1,1,1);
	}

	Render::glActiveTextureARB(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);
	Render::glActiveTextureARB(GL_TEXTURE0_ARB);
	glDisable(GL_TEXTURE_2D);	
}

bool CPolygon::serialize(FILE* filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	unsigned int x;

	if (isStoring)
	{
		fwrite(&alpha, sizeof(float), 1, filePtr);
		fwrite(&bTxId, sizeof(unsigned int), 1, filePtr);
		fwrite(&dTxId, sizeof(unsigned int), 1, filePtr);
		fwrite(&numVert, sizeof(unsigned int), 1, filePtr);
	}
	else
	{
		fread(&alpha, sizeof(float), 1, filePtr);
		fread(&bTxId, sizeof(unsigned int), 1, filePtr);
		fread(&dTxId, sizeof(unsigned int), 1, filePtr);
		fread(&numVert, sizeof(unsigned int), 1, filePtr);
		allocate(numVert);
	}

	for (x=0; x < numVert; x++)
	{
		if (!pVert[x].serialize(filePtr, isStoring)) return false;
		if (!pBTxCoord[x].serialize(filePtr, isStoring)) return false;
		if (!pDTxCoord[x].serialize(filePtr, isStoring)) return false;
	}

	if (!plane.serialize(filePtr, isStoring)) return false;

	return true;	
}

bool CPolygon::splitPolygon(CPlane &plane, CPolygon *pPosPolygon, CPolygon *pNegPolygon)
{
	if (numVert == 0 || !pVert)
		return false;

	if (!pPosPolygon || !pNegPolygon)
		return false;

	pPosPolygon->alpha = alpha;
	pPosPolygon->bTxId = bTxId;
	pPosPolygon->dTxId = dTxId;
	pPosPolygon->plane = plane;

	pNegPolygon->alpha = alpha;
	pNegPolygon->bTxId = bTxId;
	pNegPolygon->dTxId = dTxId;
	pNegPolygon->plane = plane;

	CVector3 ptA, ptB;
	int sideA, sideB;
	unsigned int lastIndex = numVert-1;
	ptA = pVert[lastIndex];
	sideA = plane.classifyPoint(ptA);

	for (unsigned int i = 0; i < numVert; i++)
	{
		ptB = pVert[i];
		sideB = plane.classifyPoint(ptB);
		if (sideB == ALPHA_INFRONT)
		{
			if (sideA == ALPHA_BEHIND)
			{
				CVector3 ip, ro, rd;
				CVector2 bTxCoord, dTxCoord;
				float t;
				ro = ptA;
				rd = ptB - ptA;
				plane.rayIntersect(ro, rd, ip, t);
				bTxCoord.x = t * (pBTxCoord[i].x - pBTxCoord[lastIndex].x) + pBTxCoord[lastIndex].x;
				bTxCoord.y = t * (pBTxCoord[i].y - pBTxCoord[lastIndex].y) + pBTxCoord[lastIndex].y;
				dTxCoord.x = t * (pDTxCoord[i].x - pDTxCoord[lastIndex].x) + pDTxCoord[lastIndex].x;
				dTxCoord.y = t * (pDTxCoord[i].y - pDTxCoord[lastIndex].y) + pDTxCoord[lastIndex].y;
				pPosPolygon->insertVert(ip, bTxCoord, dTxCoord);
				pNegPolygon->insertVert(ip, bTxCoord, dTxCoord);
			}
			pPosPolygon->insertVert(ptB, pBTxCoord[i], pDTxCoord[i]);
		}
		else if (sideB == ALPHA_BEHIND)
		{
			if (sideA == ALPHA_INFRONT)
			{
				CVector3 ip, ro, rd;
				CVector2 bTxCoord, dTxCoord;
				float t;
				ro = ptA;
				rd = ptB - ptA;
				plane.rayIntersect(ro, rd, ip, t);
				bTxCoord.x = t * (pBTxCoord[i].x - pBTxCoord[lastIndex].x) + pBTxCoord[lastIndex].x;
				bTxCoord.y = t * (pBTxCoord[i].y - pBTxCoord[lastIndex].y) + pBTxCoord[lastIndex].y;
				dTxCoord.x = t * (pDTxCoord[i].x - pDTxCoord[lastIndex].x) + pDTxCoord[lastIndex].x;
				dTxCoord.y = t * (pDTxCoord[i].y - pDTxCoord[lastIndex].y) + pDTxCoord[lastIndex].y;
				pPosPolygon->insertVert(ip, bTxCoord, dTxCoord);
				pNegPolygon->insertVert(ip, bTxCoord, dTxCoord);
			}
			pNegPolygon->insertVert(ptB, pBTxCoord[i], pDTxCoord[i]);			
		}
		else
		{
			pPosPolygon->insertVert(ptB, pBTxCoord[i], pDTxCoord[i]);
			pNegPolygon->insertVert(ptB, pBTxCoord[i], pDTxCoord[i]);
		}
		ptA = ptB;
		sideA = sideB;
		lastIndex = i;
	}
	return true;
}

void CPolygon::transform(const CMatrix44 &matrix)
{
	if (!pVert)
		return;

	for (unsigned int x=0; x < numVert; x++)
	{
		pVert[x] = matrix * pVert[x];
	}
	
	calculatePlane();
}


