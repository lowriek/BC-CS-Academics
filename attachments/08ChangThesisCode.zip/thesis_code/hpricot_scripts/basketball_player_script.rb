require 'rubygems'
require 'hpricot'
require 'open-uri'

#	basketball_player_script.rb

if ( (url = ARGV[0]) == nil)
  puts "usage: basketball_stat_script.rb url_of_player player_name\n"
  exit
end

name = ARGV[1]

file = 'basketball_player_info.list'

doc = Hpricot(open(url))

#	FORMAT:
#	<profiles>
#		<playerprofile name=x birthday=y birthplace=z height=a />
#		etc
#	</profiles>

# name = (doc/'div.content/div.col-left/div.pcCont/img').attr('alt')
birthday = (doc/'div.content/div.col-left/div.pcCont/table/tr/td[1]/table[1]/tr[1]/td[2]').inner_html
birthplace = (doc/'div.content/div.col-left/div.pcCont/table/tr/td[1]/table[1]/tr[2]/td[2]').inner_html
height = (doc/'div.content/div.col-left/div.pcCont/table/tr/td[1]/table[1]/tr[3]/td[2]').inner_html
pictureurl = (doc/'div.pcCont/img').attr('src')

s = 'name="'+name+'" bday="'+birthday+'" bplace="'+birthplace+'" height="'+height+'" pictureurl="'+pictureurl+'"'
system("echo '<playerprofile "+s+" />' >> "+file)

