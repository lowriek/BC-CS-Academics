//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WorldEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_CONTROL_BOX                 101
#define IDD_FORMVIEW                    102
#define IDD_FORMVIEW1                   103
#define IDR_MAINFRAME                   128
#define IDR_WORLDETYPE                  129
#define IDR_MENU1                       132
#define IDC_BUTTON2                     1002
#define IDC_BUTTON_EXTENDED_INSERTOR    1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON_FACE_OK              1003
#define IDC_BUTTON_DECAL                1004
#define IDC_BUTTON4                     1005
#define IDC_BUTTON_NO_DECAL             1005
#define IDC_BUTTON5                     1006
#define IDC_CONTROL_TAB1                1012
#define IDC_COMBO_ENTITY                1015
#define IDC_BUTTON_ENTITY_INSERT        1016
#define IDC_COMBO_EXTENDED              1017
#define IDC_CHECK_TRANSPARENT           1027
#define IDC_CHECK_SKY                   1031
#define IDC_EDIT_TRANSPARENCY_VALUE     1050
#define IDC_SPIN_TRANSPARENCY_VALUE     1051
#define IDC_STATIC_TRANSPARENCY_VALUE   1067
#define IDC_BUTTON_TEXTURE              1076
#define IDC_LIST_TEXTURE                1077
#define IDC_LIST_DECAL                  1078
#define IDC_CHECK2                      1080
#define IDC_CHECK3                      1081
#define IDC_CHECK5                      1083
#define IDC_CHECK6                      1084
#define IDC_CHECK7                      1085
#define IDC_CHECK8                      1086
#define IDC_COMBO1                      1087
#define IDC_COMBO2                      1088
#define IDC_COMBO3                      1089
#define IDC_COMBO4                      1090
#define IDC_COMBO5                      1091
#define IDC_COMBO6                      1092
#define IDC_RADIO1                      1093
#define IDC_RADIO2                      1094
#define IDC_RADIO3                      1095
#define IDC_COMBO7                      1096
#define IDC_EDIT1                       1098
#define ID_GRID_1X1                     32781
#define ID_GRID_2X2                     32782
#define ID_GRID_4X4                     32783
#define ID_GRID_8X8                     32784
#define ID_GRID_16X16                   32785
#define ID_GRID_32X32                   32786
#define ID_GRID_64X64                   32787
#define ID_GRID_128X128                 32788
#define ID_GRID_256X256                 32789
#define ID_VIEW_ZOOMIN                  32790
#define ID_VIEW_ZOOMOUT                 32791
#define ID_BRUSH_3SIDED                 32793
#define ID_BRUSH_4SIDED                 32794
#define ID_BRUSH_5SIDED                 32795
#define ID_BRUSH_6SIDED                 32796
#define ID_BRUSH_7SIDED                 32797
#define ID_BRUSH_8SIDED                 32798
#define ID_BRUSH_9SIDED                 32799
#define ID_BRUSH_NSIDED                 32800
#define ID_BRUSH_PRIMITIVE_CONE         32801
#define ID_BRUSH_PRIMITIVE_SPHERE       32802
#define ID_LIGHT_INSERT                 32803
#define ID_MODEL_INSERT                 32804
#define ID_BUTTON_MAKE_HOLLOW           32806
#define ID_BUTTON_DELETE                32811
#define ID_SELECTION_PICKEDIT           32812
#define ID_SELECTION_PICKALL            32813
#define ID_DISPLAY_WIREFRAME            32814
#define ID_DISPLAY_FILLEDNOTEXTURE      32815
#define ID_DISPLAY_FILLEDBASETEXTURE    32816
#define ID_DISPLAY_FILLED               32817
#define ID_BUTTON_TRANSLATE             32818
#define ID_BUTTON_ROTATE                32819
#define ID_BUTTON_SCALE                 32820
#define ID_BUTTON_TEXTURE               32821
#define ID_BUTTON_DECAL                 32822
#define ID_BUTTON_NO_BASE               32825
#define ID_BUTTON_NO_DECAL              32826
#define ID_COMPUTE_PVS                  32832
#define ID_COMPUTE_LIGHTING             32835
#define ID_BUTTON_XLOCK                 32836
#define ID_BUTTON_YLOCK                 32837
#define ID_BUTTON_ZLOCK                 32838
#define ID_BUTTON_CSG_SUB               32839
#define ID_COMPUTE_BSP                  32840
#define ID_VIEW_FILLED                  32841
#define ID_VIEW_BRUSHMODE               32842
#define ID_VIEW_CSGMODE                 32843
#define ID_BUTTON_BOX                   32844
#define ID_BUTTON_SPHERE                32845
#define ID_BUTTON32846                  32846
#define ID_BUTTON_CSG_ADD               32847
#define ID_BUTTON_DELETE_BUILDER        32848
#define IDC_VIEW_FINALMODE              32849
#define ID_INDICATOR_MOUSE              59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32850
#define _APS_NEXT_CONTROL_VALUE         1103
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
