Application:  WorldEditor
Author: Derek W. Carr
Purpose:

	This application allows users to create 3D environments.

	Environments are created using CSG modelling techniques.  The
	application can automatically create a Portal-Sector representation
	of the environment that can be used for efficient rendering.

Instructions:

	The screen is divided into two portions.

	On the left side, a canvas is divided into 4 regions.
	
	The top-left region is a XY view of space.
	The top-right region is a XZ view of space.
	The bottom-left region is a YZ view of space.
	The bottom-right region is a Perspective view of space.

	Each region is presented as a graph that can be zoomed in and out
	using the mouse wheel over each region.

	By default, there is a box in the center of the region.  This
	represents the camera.  The red line is the view vector of the
	camera.

	The right side of the screen is a toolbox.  The Texture tab
	and a portion of the Faces tab	are implemented.

	The Texture tab allows users to assign a decal or base texture to
	the selected faces.

	The Face tab allows users to specify if a selected face is transparent
	or not, and what the opacity is for that face.

	The toolbar has standard New Document / Open Document / Save Document
	buttons.

	Pressing the T toolbar icon sets the Brush Manipulation mode to
	Translate.

	Pressing the R toolbar icon sets the Brush Manipulatin mode to Rotate.
	
	Pressing the S toolbar icon sets the Brush Manipulation mode to Scale.

	Each brush is manipulated by dragging the mouse in the XY, XZ, YZ 	regions.

	The toolbar icon next to S deletes the current builder brush.

	The Box button creates a box builder brush based on the selected 		area.

	The Sphere button creates a sphere builder brush based on the size and
	location of the selected area.

	The + and - peform CSG add / subtract for current builder brush.

	The x deletes all selected brushes.

	If no brushes are actively selected, and there is no template brush,
	then to create a template brush, an area must first be selected
	by depressing the mouse button and dragging.

	In order to scroll in each region.  Ctrl-Right Click on a piece of the
	graph.  The panel will scroll.

	To control the camera use following keys:
	Scroll left	- a
	Scroll right	- d
	Forward		- w
	Backward	- s
	Up		- q
	Down		- e

	To toggle the perspective view in and out of fullscreen - f

	To select a brush, Ctrl-Left click on a brush in either of the
	4 views.

	To select a face, Shift-Left Click on a face in the Perspective view.

	To deselect all faces and brushes, press Escape.

	There are three different viewing modes:
	Brush Mode -	Shows brushes before CSG operations.  
			Full manipulation of brushes allowed.

	CSG Mode -	View CSG result.  Must compute a BSP first.
			Uses BSP rendering technique.

	Final Mode -	View using portal-sector algorithm.  Must compute
			PVS first to create data structure.  Renders using
			portal algorithm.
	Flags for all modes:
	Wireframe - 	Displays polygons in wireframe.
	Full	  -	Displays textured polygons.

	
		
	
	