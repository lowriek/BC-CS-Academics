/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						AVATAR.CPP							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	December 29, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "avatar.h"





Avatar::Avatar(MCamera * cam, TimeKeeper * clk)
{
	x = cam->GetX(); y = cam->GetY(); z = cam->GetZ(); dec = cam->GetDec(); 
	dir = cam->GetDir(); camera = cam; Entity(); beginControl = true;localClock=clk;
	Model * weapon = new MilkshapeModel(3000,-1,3000,30,1,1,1,false);									// Memory To Hold The Model
	if ( weapon->loadModelData( "data/staff.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model staff.ms3d", "Error", MB_OK | MB_ICONERROR );
		weapon = NULL;
	}
	else
		AddChild(weapon);
	
}

float Avatar::GetHeight(float xPos, float zPos)
{
	return z;
}

void Avatar::Kill()
{
	if(child != NULL)
		child->Kill();
}

void Avatar::Draw()
{
	static float cnt = 0;
	

	glPushMatrix();
	
	glTranslatef(x,y,z);
	
	glRotatef(-dir,0,1,0);
	glTranslatef(-7,0,-15);
	
	glRotatef(-50,1,0,0);
	if(child != NULL)
	{
		messenger->FontPrint(" Avatar is using weapon: %d  z: %d",(int)x,(int)z);
		child->SetCoordinates(0,0,0, false);
		child->Draw();
	}
		
	glPopMatrix();

	if(!camera->MainCameraControl())
		{
		if(debugOut)
					messenger->FontPrint(" Avatar is drawn on square x: %d  z: %d",(int)x,(int)z);

			if(beginControl)
			{
				
				camera->MutDec(dec);
				camera->MutDir(dir);
				camera->MutX(x);
				camera->MutY(parent->GetHeight(x,z) + 8);
				camera->MutZ(z);
				beginControl = false;
			}
				
			if	(keys[VK_LEFT])
			{
				dir -=3;
				camera->MutDir(dir);
			}
			if	(keys[VK_RIGHT])
			{
				dir +=3;
				camera->MutDir(dir);
			}
			if	(keys[VK_F2])
			{
				dec += 3;
				camera->MutDec(dec);
			}
			if	(keys[VK_F3])
			{
				dec -= 3;
				camera->MutDec(dec);
			}
			if	(keys[VK_F4])
			{
				camera->ToggleCameraControl();
				keys[VK_F4] = false;
			}

			if	(keys[VK_UP])
			{
				x = x + 2*sin(dir * 3.14/180.0) * cos(dec * 3.14/180.0);
				z = z - 2*cos(dir * 3.14/180.0) * cos(dec * 3.14/180.0);
				y = parent->GetHeight(x, z) + 7;
				camera->MutX(x);
		        camera->MutZ(z);
				camera->MutY(y);
			}
			if	(keys[VK_DOWN])
			{
				x = x - 2*sin(dir * 3.14/180.0) * cos(dec * 3.14/180.0);
				z = z + 2*cos(dir * 3.14/180.0) * cos(dec * 3.14/180.0);
				y = parent->GetHeight(x, z) + 7;
				camera->MutX(x);
		        camera->MutZ(z);
				camera->MutY(y);
			}
				if	(keys[VK_F5])
			{
				localClock->AdvanceHour();
				keys[VK_F5] = false;
			}

			if	(keys[VK_F6])
			{
				localClock->ReverseHour();
				keys[VK_F6] = false;
			}

			
		}
	else
		beginControl = true;

}


