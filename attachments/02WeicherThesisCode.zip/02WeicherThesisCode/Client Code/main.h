#ifndef _MAIN_H
#define _MAIN_H

#include "tracer.h"
	
#define MAX_OBJECTS 10
#define RINDEX_AIR 1.0
#define NO 0
#define YES 1
#define FALSE 0
#define TRUE 1

//Globals 
const double pi=3.14159265359;				//Geometric Constant
extern float AMBIENT;				 			//Ambient scene light level
extern int NUM_OBJECTS;							//Number of objects in scene
extern int ANTI_ALIAS;				     			//0=no, 1=yes
extern int CAST_SHADOWS;			       			//0=no, 1=yes
extern int ENABLE_FOG;				       			//0=no, 1=yes
extern float fog_min_dist;			       			//distance at which fogging effects become initially apparent
extern float fog_max_dist;							//distance at which scene is in full fog
extern float SHADOW_FACTOR;						//amount to affect base color if in shadow



/*Other, typedef and class dependant variables and functions
	-must therefore be defined after the above.   */
	
extern int currentLine;
extern color fog_color, light_color;
extern point3d eye, screen, light;
extern ray theray;

typedef struct serverInfo{
  char * ip;
  int first;
  int last;
  char * fname;
  int threadNum;
};


//functions
int checkServers(int numServers, char * argv[]);
void initializeLocks();
void dispatchServers(int sCount, char * ips[], char * sourcef);
int fireShadowRay(ray r, point3d light);
color fireRay(ray r);

//thread functions
void doManualRefresh();
void receiveFileRequest(int sock, int * error);
void sendSourceFile(FILE * fp, int sock, int * error);
void receiveParamRequest(int sock, int * error);
void sendParamString(int sock, int first, int last, int * error);
void sendDataRequest(int sock, int * error);
int receiveNumFloats(int sock, int * error);
void receivePixelData(int sock, float * dataBuf, int nf, int * error);
void transferPixelsToBuffer(int numfloats, float * dataBuf, int * error);

//prototypes for various inline power functions
float Power(float a, int b);
float Power(float a, float b);
float Power(float a, double b);

float Power(int a, int b);
float Power(int a, float b);
float Power(int a, double b);

float Power(double a, int b);
float Power(double a, float b);
float Power(double a, double b);

float SQRT(float a);

#endif













