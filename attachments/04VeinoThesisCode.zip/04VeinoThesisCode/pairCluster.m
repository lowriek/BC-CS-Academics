function [index,loc] = pairCluster(S,k,clusters)
%
%
%
%

[u,s,v] = svd(S);
[m,n] = size(u);
eigvect = zeros(k,m);
for I=1:k
    eigvect(I,:) = u(:,I)';
end


[index,loc] = kmeans(eigvect',clusters,'Replicates',20, 'EmptyAction','singleton','Display','iter');
