function [] = facialPoints()
% [] = facialPoints()
% Reads in files 1.jpg -> 100.jpg for purposes of locating faces
% Click the left eye, then the right eye, then the nose.  Press enter when
% finished choosing all the points in an image

for I=1:100
    fid = fopen('facialpoints.txt','a');
    fprintf(fid,'%d\n',I);
    fclose(fid);
    im = rgb2gray(imread([int2str(I), '.jpg']));
    figure(1);clf;imagesc(im);truesize;axis image;colormap gray;
    [a,b] = ginput;
    fid = fopen('facialpoints.txt','a');
    fprintf(fid,'%5d',a);fprintf(fid,'\n');fprintf(fid,'%5d',b);fprintf(fid,'\n');
    fclose(fid);
end