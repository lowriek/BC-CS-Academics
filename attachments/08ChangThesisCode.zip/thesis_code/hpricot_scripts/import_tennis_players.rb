require 'rubygems'
require 'hpricot'
require 'open-uri'

playerfile = 'tennis_players.list'

data = Hpricot(open(playerfile))
(data/'player').each { |p|
	
	if (Player.find_by_name(p.get_attribute('name')) == nil)
		# player doesn't exist, create
		Player.create :name => p.get_attribute('name'), :birthday => p.get_attribute('bday'), :birthplace => p.get_attribute('country')
	else
		# player exists, update data
		@player = Player.find_by_name(p.get_attribute('name'))
		@player.birthday = p.get_attribute('bday')
		@player.birthplace = p.get_attribute('country')
	end
}
