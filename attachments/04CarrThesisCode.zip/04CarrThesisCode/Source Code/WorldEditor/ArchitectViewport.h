#if !defined(AFX_ARCHITECTVIEWPORT_H__5DA2DE89_7FB4_4544_A65C_3FB5070CC05D__INCLUDED_)
#define AFX_ARCHITECTVIEWPORT_H__5DA2DE89_7FB4_4544_A65C_3FB5070CC05D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OrthoViewport.h"
#include "AlphaEngine/Math/Vector3.h"
#include "AlphaEngine/Math/Vector2.h"
#include "FontMgr.h"

#define	NO_INTERACTION -1
#define REGION_SELECTED 0
#define REGION_SELECTING 1
#define TRANSLATE_BRUSH 2
#define ROTATE_BRUSH 3
#define SCALE_BRUSH 4

class CArchitectViewport : public COrthoViewport  
{

protected:
	CArchitectViewport();

public:
	CArchitectViewport(COpenGLView * parent);
	~CArchitectViewport();

	void			CheckGridSize();
	void			DecreaseGridSize();
	void			DrawGridLines();
	void			DrawGridLabels();
	void			DrawSelectedRegion();
	void			IncreaseGridSize();
	void			OnButtonBox();
	void			OnButtonSphere();
	CVector3		ScreenToWorld(CVector2 pt);
	void			SetGridSize(int n);
	CVector3		SnapToGrid(CVector3 pt);
	virtual void	Render();
	virtual void	PrepareToRender();
	
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnLButtonUp(UINT nFlags, CPoint point);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	virtual void OnRButtonDown(UINT nFlags, CPoint point);
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	CVector3	m_axis;
	CVector3	m_midPt;
	CRect3d 	selectedRegion;
	CVector2	lastMousePt;
	CFontMgr	fontMgr;
	float		m_maxDistance;
	int			m_nGridSize;
	int			USER_MODE;

// Operations
protected:
/*
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
*/
};

#endif // !defined(AFX_ARCHITECTVIEWPORT_H__5DA2DE89_7FB4_4544_A65C_3FB5070CC05D__INCLUDED_)
