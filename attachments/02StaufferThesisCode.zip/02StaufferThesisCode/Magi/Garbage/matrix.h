/* ----------------------------------------------
   -											-
   -	PROJECT:		Hourglass				-
   -	FILE:			matrix.h				-	
   -	CREATED:		07/20/01				-
   -	MODIFIED:		07/20/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */

#ifndef _MATRIX_H
#define _MATRIX_H

#include <stdio.h>
#include <windows.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include "vector.h"

class Matrix4D{
	
	public:
	float a[16];
	
	~Matrix4D();
	Matrix4D();
	Matrix4D(float a00, float a01, float a02, float a03,
			       float a10, float a11, float a12, float a13,
			       float a20, float a21, float a22, float a23);
	Matrix4D(float a00, float a01, float a02, float a03,
			       float a10, float a11, float a12, float a13,
			       float a20, float a21, float a22, float a23,
				   float a30, float a31, float a32, float a33);
	inline float * GetMatrix(){return a;};
	Matrix4D inverse(const Matrix4D & m) const;
	Vector3D operator *(const Vector3D & v) const;
    Matrix4D operator *(const Matrix4D & m) const;
	

				};

#endif // _MATRIX_H


