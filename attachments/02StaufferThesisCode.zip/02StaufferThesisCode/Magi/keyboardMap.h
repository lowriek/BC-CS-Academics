#ifndef	KEYMAP_H
#define KEYMAP_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						KeyboardMap.h							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	April 17, 2002					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#define	RENDER_TEXTURE	    0x0001
#define RENDER_LIGHTING		0x0002
#define RENDER_MODELS	   0x0004
#define RENDER_EFFECTS     0x0008





#endif