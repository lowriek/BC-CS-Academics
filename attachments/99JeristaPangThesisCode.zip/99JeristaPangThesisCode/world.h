
//#include <math.h>
#include <windows.h>		//Standard Windows include
#include <gl\gl.h>			//OpenGL Library
#include <gl\glu.h>			// GLU library

#define stepsize 0.2
//number represents smallest partition size
//right now only 2 levels deep (64 nodes..) value==60
//so world is 60*4 (240) units wide
#define VALUE 20
#define LEVELS 3   //how deep?  8^LEVELS =  appx number of cubes in space

typedef struct points{
  short x,y,z;
} point;

typedef struct octnodes {
  struct points bb[8];
  struct octnodes *child[8];
  unsigned int dl;
  int isLeaf;
} octnode;

extern void mallocTree (octnode *root,    int levels);
extern void setCoords (octnode *node, point p, int value);
extern void fillCoords(octnode *current, int value, int levels, point p);
extern void rotateLeft (float   *viewAngle);
extern void rotateRight(float   *viewAngle);
extern void moveRight  (GLdouble  *eyex,    GLdouble *eyez, float *viewAngle);
extern void moveLeft   (GLdouble   *eyex,    GLdouble *eyez, float *viewAngle);
extern void moveForward(GLdouble   *eyex,    GLdouble *eyez, float *viewAngle);
extern void runForward(GLdouble *eyex, GLdouble *eyez, float *viewAngle);
extern void moveBack   (GLdouble   *eyex,    GLdouble *eyez, float *viewAngle);
extern void lookUp     (GLdouble *vertAngle);
extern void lookDown   (GLdouble *vertAngle);



extern void dumpTree(octnode *current, int levels);
extern void drawCubes(float half_value, point center);
extern void drawTriangles(float val, point center);

 