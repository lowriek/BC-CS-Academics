#ifndef _PORTAL_H_
#define _PORTAL_H_

#include <stdio.h>
#include "AlphaEngine/Core/Polygon.h"

class CPortal : public CPolygon
{
public:
	CPortal();
	virtual ~CPortal();

	CPortal*	clone();
	void		render(int flags);
	bool		serialize(FILE* filePtr, bool isStoring);

	unsigned int id;
	unsigned int partitionId;
	unsigned int fromSectorId;
	unsigned int toSectorId;
	bool isMirror;
};


class CPortalList
{
public:
	CPortalList();
	~CPortalList();

	void		add(CPortal* pPortal);
	void		clear();
	CPortal*	get(unsigned int index);
	void		remove(unsigned int index);
	unsigned int	size();

private:
	void		increaseCapacity();

	CPortal**	pPortalList;
	unsigned int capacity;
	unsigned int listSize;		// number of elements in the pPortalList
};

#endif 