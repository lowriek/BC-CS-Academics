require 'rubygems'
require 'hpricot'
require 'open-uri'

# url (day)
#url = 'http://scores.espn.go.com/nba/scoreboard?date=20080307'
if ( (url = ARGV[0]) == nil)
  puts "usage: games_script.rb url -note:url is like /nba/scoreboard?date=20080325\n"
  exit
end
doc = Hpricot(open("http://scores.espn.go.com"+url))

newfn = 'new_game.list'
oldfn = 'old_game.list'	

(doc/'div#gameLinks/div/a[1]').each { |g|
  #puts Hpricot::Elements[g].attr('href')
  current = Hpricot::Elements[g].attr('href')
  system("ruby -ne 'print if/"+current.gsub("/nba/boxscore?","")+"/' "+oldfn+" > temp")
  lines = File.readlines("temp")
  if (lines.length == 0)
    system("echo "+current+" >> "+newfn)
  end
}

