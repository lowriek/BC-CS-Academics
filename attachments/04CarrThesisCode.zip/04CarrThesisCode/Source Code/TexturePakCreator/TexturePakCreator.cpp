#include <fstream>	// file loading
#include <conio.h>	// kbhit
#include <iostream>	// cout
#include <string.h>	// string manipulation functions
#include <string>
#include "Tokenizer.h"

#include "AlphaEngine/Texture/Texture.h"

// for cout
using namespace std;

char * ReadTextFile(char * filename, int &bufferLen);
void PrintInstructions();
int Wait();

void PrintInstructions()
{
	cout << "Error!" << endl;
	cout << "TexturePakCreator filename?" << endl;
	cout << "filename - optional .txt file.  List of requested package contents." << endl;
	cout << "\tIf not specifed, attempt to load 'default.txt' in current directory." << endl;
	cout << "Sample descriptor file: " << endl;
	cout << "\t#images" << endl;
	cout << "\t$file(1)\t$type" << endl;
	cout << "\t...\t\t..." << endl;
	cout << "\t$file(#images)\t$type" << endl;
	cout << "$file - image file location." << endl;
	cout << "$type - 'B': Basic, 'D': decal, 'L': lightmap" << endl;
	cout << endl;
}

int Wait() { while (!kbhit()); return 0; }

char * ReadTextFile(char * filename, int &bufferLen)
{
	FILE * filePtr = NULL;
	bufferLen = 0;
	
	filePtr = fopen(filename, "rb");
	
	if (!filePtr)
	{
		return NULL;
	}

	// FIND THE LENGTH OF THE FILE
	fseek(filePtr, 0, SEEK_END);
	bufferLen = ftell(filePtr);
	fseek(filePtr, 0, SEEK_SET);

	// ALLOCATE A BUFFER TO HOLD THE TEXT AND A NULL TERMINATOR
	char * contents = new char[bufferLen+1];
	if (contents == NULL)
	{
		fclose(filePtr);
		return NULL;
	}
	
	// READ THE CONTENTS INTO THE BUFFER
	fread(contents, sizeof(char), bufferLen, filePtr);
	
	// NULL TERMINATE THE STRING
	contents[bufferLen] = '\0';

	// CLOSE THE FILE
	fclose(filePtr);


	return contents;
}
int main(int argc, char* argv[])
{
	FILE * filePtr = NULL;
	string buffer = "";
	int bufferLen = 0;
	int numFiles = 0;
	if (argc < 2)
		buffer = ReadTextFile("default.txt", bufferLen);
	else
		buffer = ReadTextFile(argv[1], bufferLen);
	CTokenizer tokenizer(buffer.c_str(), " \n\t");
	char * strNumFiles = tokenizer.NextToken();
	if (strNumFiles == 0)
	{
		PrintInstructions();
		return Wait();
	}
	numFiles = atoi(strNumFiles);
	if (numFiles <= 0)
	{
		PrintInstructions();
		return Wait();
	}
	cout << numFiles << endl;

	delete [] strNumFiles;

	CTexture * texture = new CTexture[numFiles];
	int numLoaded = 0;

	for (int x = 0; x < numFiles; x++)
	{
		char* txt_name = tokenizer.NextToken();
		char* filename = tokenizer.NextToken();
		char* type = tokenizer.NextToken();
		
		if (filename == 0 || type == 0)
		{
			cout << "Error while loading file!" << endl;
			PrintInstructions();
			return Wait();
		}

		int textureType = INVALID_TEXTURE;
		
		if (type[0] == 'B')
		{
			textureType = BASE_TEXTURE;
		}
		else if (type[0] == 'D')
		{
			textureType = DECAL_TEXTURE;
		}
		
		cout << "Loading: " << txt_name << "at " << filename << "...";
		
		if (texture[numLoaded].load(filename, txt_name, textureType))
		{
			numLoaded++;
			cout << "\tCompleted." << endl;
		}
		else
			cout << "\tError!" << endl;

		delete [] filename;
		delete [] type;
		delete [] txt_name;
	}
	filePtr = fopen("output.txp", "wb");
	if (filePtr == NULL)
	{
		cout << "Unable to create output file." << endl;
		delete [] texture;
		return Wait();
	}
	fwrite(&numLoaded, sizeof(int), 1, filePtr);
	for (int y = 0; y < numLoaded; y++)
		texture[y].serialize(filePtr, true);
	fclose(filePtr);
	delete [] texture;
	cout << "Done." << endl;
	return Wait();
}

