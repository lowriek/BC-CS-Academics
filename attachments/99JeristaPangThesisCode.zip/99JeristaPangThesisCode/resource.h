//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDR_MENU                        101
#define IDD_DIALOG_ABOUT                102
#define IDC_OPENGL_VENDOR               1000
#define IDC_OPENGL_RENDERER             1001
#define IDC_OPENGL_VERSION              1002
#define IDC_OPENGL_EXTENSIONS           1003
#define IDC_GLU_VERSION                 1005
#define IDC_GLU_EXTENSIONS              1006
#define IDC_ERROR1                      1007
#define IDC_ERROR2                      1008
#define IDC_ERROR3                      1009
#define IDC_ERROR4                      1010
#define IDC_ERROR5                      1011
#define IDC_ERROR6                      1012
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUT                   40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
