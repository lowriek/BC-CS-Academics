class AddSkills < ActiveRecord::Migration
  def self.up
  	add_column :profiles, :introtodisasterservices, :boolean, :default=> false
  	add_column :profiles, :onthescene, :boolean, :default=> false
 	add_column :profiles, :cpraed, :boolean, :default=> false
   	add_column :profiles, :firstaid, :boolean, :default=> false
  	add_column :profiles, :masscare, :boolean, :default=> false
 	add_column :profiles, :shelterops, :boolean, :default=> false
   	add_column :profiles, :driver, :boolean, :default=> false
  	add_column :profiles, :teamleadership, :boolean, :default=> false
 	add_column :profiles, :wmd, :boolean, :default=> false
  end

  def self.down
  	remove_column :profiles, :introtodisasterservices
  	remove_column :profiles, :onthescene
 	remove_column :profiles, :cpraed
   	remove_column :profiles, :firstaid
  	remove_column :profiles, :masscare
 	remove_column :profiles, :shelterops
   	remove_column :profiles, :driver
  	remove_column :profiles, :teamleadership
 	remove_column :profiles, :wmd	
  end
end
