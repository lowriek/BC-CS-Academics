/*		sound.cpp					  */
/*		Magi Game Engine		 */
/*		Interface for DirectSound */
/*		Created: April 4, 2002	   */
/*      Cris Stauffer					*/
/*		Code Based off of Trent Polack */


#include "sound.h"


/*		SoundObject Methods   */                


void SoundObject::Set3DPos(float x, float y, float z)
	{	ds3DBuffer->SetPosition(x, y, -z, DS3D_IMMEDIATE);	}

void SoundObject::Set3DDistances(float minDistance, float maxDistance)
	{
	DS3DBUFFER dsBufferParams;
	dsBufferParams.flMinDistance= minDistance;
	dsBufferParams.flMaxDistance= maxDistance;

	if(ds3DBuffer)
		ds3DBuffer->SetAllParameters(&dsBufferParams, DS3D_IMMEDIATE);
	}

bool SoundObject::SetVolume(float percent)
{
	
	if(ds3DBuffer)
		if(DS_OK != ds3DBuffer->SetConeOutsideVolume((int)( DSBVOLUME_MIN + (-1)*DSBVOLUME_MIN *percent)
																				,DS3D_IMMEDIATE));
									
			return false;

	return true;
}


void SoundObject::Shutdown()
	{
	if(dmSegment!=NULL)
		{
		dmSegment->Release();
		dmSegment= NULL;
		}

	if(ds3DBuffer!=NULL)
		{
		ds3DBuffer->Release(); 
		ds3DBuffer= NULL;
		}
	}



/*	SoundManager Methods  */         

bool SoundManager::Init(void)
	{
	HRESULT hr;
	WCHAR wcharStr[MAX_PATH];
	char pathStr[MAX_PATH];

	CoInitialize(NULL);
	hr= CoCreateInstance(	CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC,
			IID_IDirectMusicLoader8, (void**)&loader);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create main DirectAudio file loader", "ERROR", MB_OK);
		return false;
		}

	hr= CoCreateInstance(	CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC,
			IID_IDirectMusicPerformance8, (void**)&performance);

		if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create main DirectAudio performance object", "ERROR", MB_OK);
		Shutdown();
		return false;
		}


	performance->InitAudio(	NULL, NULL, hwnd, DMUS_APATH_SHARED_STEREOPLUSREVERB, 
				64, DMUS_AUDIOF_ALL, NULL);

	hr= performance->CreateStandardAudioPath(	DMUS_APATH_DYNAMIC_3D,
				                64, TRUE, &audioPath3);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create the DirectAudio audio path", "ERROR", MB_OK);
		Shutdown();
		return false;
		}
	
	hr= audioPath3->GetObjectInPath(	0, DMUS_PATH_PRIMARY_BUFFER, 0, GUID_NULL, 0,  
 				        IID_IDirectSound3DListener8, (void**)&listener3);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to recieve listener from audio path", "ERROR", MB_OK);
		Shutdown();
		return false;
		}

	listParams.dwSize= sizeof(DS3DLISTENER);
	listener3->GetAllParameters(&listParams);

	listParams.vPosition.x= 0.0f;
	listParams.vPosition.y= 0.0f;
	listParams.vPosition.z= 0.0f;
	listener3->SetAllParameters(&listParams, DS3D_IMMEDIATE);

	GetCurrentDirectory(MAX_PATH, pathStr);
	MultiByteToWideChar(CP_ACP, 0, pathStr, -1, wcharStr, MAX_PATH);

	loader->SetSearchDirectory(GUID_DirectMusicAllTypes, wcharStr, FALSE);

	return true;
	}

void SoundManager::Shutdown()
	{
	//Shut down the direct music performance information
	if(performance!=NULL)
		{
		performance->Stop(NULL, NULL, 0, 0);
		performance->CloseDown();
		performance->Release();
		}

	//Shut down the direct sound listener(player) information
//	if(listener3 != NULL)
//		listener3->Release();

	//Shut down the direct music audiopath
	if(audioPath3 != NULL)
		audioPath3->Release();

	
	//Shut down the direct music loader
	if(loader != NULL)
		loader->Release();

	//Uninitialize COM (*MUST* be done, or you're asking for trouble)
	CoUninitialize();

	
	}

void  SoundManager::Kill()
{
	
	
	for(int i = 0; i < 10; i++)
	{
		if(objList[i] != NULL)
		{
			//Stop(objList[i]);
			objList[i]->Shutdown();
		}
	}

	Shutdown();
}

bool SoundManager::Create(SoundObject * audio, char* filename, bool is3DSound)
	{
	DS3DBUFFER dsBufferParams; 
	HRESULT hr;
	WCHAR wcharStr[MAX_PATH];

	for(int i = 0; i<10; i++)
		if(objList[i] == NULL)
		{
			objList[i] = audio;
			break;
		}

	//Convert the file name to the string that DirectAudio needs
	MultiByteToWideChar(CP_ACP, 0, filename, -1, wcharStr, MAX_PATH);

	//Load the audio segment from a file
	hr= loader->LoadObjectFromFile(CLSID_DirectMusicSegment,
									 IID_IDirectMusicSegment8,
									 wcharStr,
									 (void**)&audio->dmSegment);
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to Load sound from file", "ERROR", MB_OK);
		return false;
		}

	//Do code specific for 3D sounds
//	if(is3DSound)
	if(true)
		{
		//Get the 3D buffer, and audio path
		hr= audioPath3->GetObjectInPath(DMUS_PCHANNEL_ALL, DMUS_PATH_BUFFER, 0, 
										   GUID_NULL, 0, IID_IDirectSound3DBuffer,
										   (void**)&audio->ds3DBuffer);
		if(FAILED(hr))
			{
			MessageBox(hwnd, "Unable to get 0bject in path", "ERROR", MB_OK);
			return false;
			}

		//Get the 3D buffer paramters
		dsBufferParams.dwSize= sizeof(DS3DBUFFER);
		audio->ds3DBuffer->GetAllParameters(&dsBufferParams);

		//Set some new parameters
		dsBufferParams.dwMode= DS3DMODE_DISABLE;    // relative to the listener
		audio->ds3DBuffer->SetAllParameters(&dsBufferParams, DS3D_IMMEDIATE);

		//Set the 3D sound flag to true
		audio->is3DSound = true;
		}
	//Do code specific to non-3D sounds (background music)
	else
		{
		//Set the 3D buffer to null since we don't need it
		audio->ds3DBuffer= NULL;
		//Set the 3D sound flag to false, since we don't need it either
		audio->is3DSound= false;
		}

	return true;
	}

void SoundManager::Play(SoundObject * audio, DWORD numRepeats)
	{
	//Set the number of repeats that we want for the specific sound
	audio->dmSegment->SetRepeats(numRepeats);

	if(audio->is3DSound)
		{
		audio->dmSegment->Download(audioPath3);

		//Play the segment using the 3D audio path
		performance->PlaySegmentEx(audio->dmSegment, NULL, NULL, 
									 DMUS_SEGF_SECONDARY, 0,
									 NULL, NULL, audioPath3);
		}
	else
		{
		//Download the segment's performance object
		audio->dmSegment->Download(performance);
		//Play the non-3D sound segment
		performance->PlaySegmentEx(audio->dmSegment, NULL, NULL, 
									 DMUS_SEGF_DEFAULT, 0,
									 NULL, NULL, NULL);
		}
	}

void SoundManager::Stop(SoundObject * audio)
	{	performance->StopEx(audio->dmSegment, 0, 0);	}

//------------------------------------------------------------------//
//- void SHININGAUDIO::SetListenerPos(float, float, float) ---------//
//------------------------------------------------------------------//
//- Set the listener's (player's) position in 3D space.			   -//
//------------------------------------------------------------------//
void SoundManager::SetListenerPos(float x, float y, float z)
	{
	//Get the listener parameters
	listParams.dwSize= sizeof(DS3DLISTENER);
	listener3->GetAllParameters(&listParams);

	//Set the listener's position in 3D space
	listParams.vPosition.x=  x;
	listParams.vPosition.y=  y;
	listParams.vPosition.z= -z;

	//Set all of the new parameters
	listener3->SetAllParameters(&listParams, DS3D_IMMEDIATE);
	}

void SoundManager::SetListenerOrientation(float forwardX, float forwardY, float forwardZ,
																float topX, float topY, float topZ)
	{
	listener3->SetOrientation(forwardX, forwardY, -forwardZ, 
								 topX, topY, topZ, DS3D_IMMEDIATE);
	}
	