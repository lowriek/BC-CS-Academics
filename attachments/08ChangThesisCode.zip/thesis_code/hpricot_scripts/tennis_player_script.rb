# tennis_player_script.rb

require 'rubygems'
require 'hpricot'
require 'open-uri'

url = 'http://sports.espn.go.com/sports/tennis/players'
playerfile = 'tennis_players.list'
system('echo -n > '+playerfile)
# not really necessary, we can do with just temp files
espnprefix = 'http://sports.espn.go.com/sports/tennis/'

counter= 0;
doc = Hpricot(open(url))
# system('echo "<tennisplayers>" > '+playerfile)
(doc/'div.content/div.sp-col1/div.sp-col1-inner/table[2]/tr.evenrow').each { |p|
	counter+=1
	puts counter
	sleeptime = (60*rand)
	puts 'sleeping for '+sleeptime.to_s+'seconds'
	sleep sleeptime
	name = (p/'td/a').inner_html.gsub(/[\'\"\n]/, '').gsub(/[&]/,'and').gsub(/[\r\n]/,'')
	url = (p/'td/a').attr('href').gsub(/[\'\"\n]/, '')
	country = (p/'td[2]').inner_html.gsub(/[\'\"\n]/, '').gsub(/[&]/,'and').gsub(/[\r\n]/,'')
	playerpage = Hpricot(open(espnprefix+url))
	bday = (playerpage/'div.sp-col1-inner/table/tr/td[2]/div[1]').inner_html
	bday = bday.gsub(/<.*>/,'').gsub(/[\'\"\n]/, '')
	#hand = (playerpage/'div.sp-col1-inner/table/tr/td[2]/div[2]').inner_html
	#hand = hand.gsub(/<.*>:./,'')
	rank = (playerpage/'div.sp-col1-inner/div.tablemed').inner_html
	rank = rank.gsub(/\n<.*>./,'').gsub(/[\'\"\n]/, '')
	# format is string ("$100,000")
	careermoney = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[2]')[0].inner_html.gsub(/[\'\"\n]/, '')
	singlestitles = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[3]')[0].inner_html.gsub(/[\'\"\n]/, '')
	doublestitles = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[4]')[0].inner_html.gsub(/[\'\"\n]/, '')
	singlesrecord = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[5]')[0].inner_html.gsub(/[\'\"\n]/, '')
	input = '<player name="'+name+'" country="'+country+'" bday="'+bday+'" rank="'+rank+'" cmoney="'+careermoney+'" cstitles="'+singlestitles+'" cdtitles="'+doublestitles+'" csrecord="'+singlesrecord+'" />'
	puts input
	system("echo '"+input+"' >> "+playerfile)
}

(doc/'div.content/div.sp-col1/div.sp-col1-inner/table[2]/tr.oddrow').each { |p|
	counter+=1
	puts counter
	sleeptime = (60*rand)
	puts 'sleeping for '+sleeptime.to_s+'seconds'
	sleep sleeptime
	name = (p/'td/a').inner_html.gsub(/[\'\"\n]/, '').gsub(/[&]/,'and').gsub(/[\r\n]/,'')
	url = (p/'td/a').attr('href').gsub(/[\'\"\n]/, '')
	country = (p/'td[2]').inner_html.gsub(/[\'\"\n]/, '').gsub(/[&]/,'and').gsub(/[\r\n]/,'')
	playerpage = Hpricot(open(espnprefix+url))
	bday = (playerpage/'div.sp-col1-inner/table/tr/td[2]/div[1]').inner_html
	bday = bday.gsub(/<.*>/,'').gsub(/[\'\"\n]/, '')
	# inconsistent data after birthday
	# hand = (playerpage/'div.sp-col1-inner/table/tr/td[2]/div[2]').inner_html
	# hand = hand.gsub(/<.*>:./,'')
	rank = (playerpage/'div.sp-col1-inner/div.tablemed').inner_html
	rank = rank.gsub(/\n<.*>./,'').gsub(/[\'\"\n]/, '')
	# format is string ("$100,000")
	careermoney = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[2]')[0].inner_html.gsub(/[\'\"\n]/, '')
	singlestitles = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[3]')[0].inner_html.gsub(/[\'\"\n]/, '')
	doublestitles = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[4]')[0].inner_html.gsub(/[\'\"\n]/, '')
	singlesrecord = (playerpage/'div.sp-col1-inner/table.tablehead/tr[4]/td[5]')[0].inner_html.gsub(/[\'\"\n]/, '')
	input = '<player name="'+name+'" country="'+country+'" bday="'+bday+'" rank="'+rank+'" cmoney="'+careermoney+'" cstitles="'+singlestitles+'" cdtitles="'+doublestitles+'" csrecord="'+singlesrecord+'" />'
	puts input
	system("echo '"+input+"' >> "+playerfile)
}

system("cat "+playerfile+" | sort | uniq > temp")
system("cat temp > "+playerfile)

system("echo '<tennisplayers>' > temp")
system("cat "+playerfile+" >> temp")
system("cat temp > "+playerfile)
system("echo '</tennisplayers>' >> "+playerfile)


# system('echo "</tennisplayers>" >> '+playerfile)
=begin
data = Hpricot(open(playerfile))
(data/'player').each { |p|
	
	if (Player.find_by_name(p.get_attribute('name')) == nil)
		# player doesn't exist, create
		Player.create :name => p.get_attribute('name'), :birthday => p.get_attribute('bday'), :birthplace => p.get_attribute('country')
	else
		# player exists, update data
		@player = Player.find_by_name(p.get_attribute('name'))
		@player.birthday = p.get_attribute('bday')
		@player.birthplace = p.get_attribute('country')
	end
}
=end
