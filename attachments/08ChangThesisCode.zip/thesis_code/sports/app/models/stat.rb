class Stat < ActiveRecord::Base
	has_one :statconcepts
	has_one :players
	has_one :games

	validates_presence_of :player_id
	validates_presence_of :game_id
	validates_presence_of :statconcept_id
	validates_presence_of :value

	validates_uniqueness_of :statconcept_id, :scope => [:player_id, :game_id]
end
