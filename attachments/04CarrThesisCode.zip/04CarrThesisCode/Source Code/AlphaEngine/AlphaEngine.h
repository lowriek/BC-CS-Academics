#ifndef _ALPHAENGINE_H_
#define _ALPHAENGINE_H_

#include "AlphaEngine/Bsp/BspNode.h"
#include "AlphaEngine/Core/BaseObjectMgr.h"
#include "AlphaEngine/Math/Vector3.h"
#include "AlphaEngine/PBrush/PBrushMgr.h"
#include "AlphaEngine/Render/Render.h"
#include "AlphaEngine/Texture/TextureMgr.h"
#include "AlphaEngine/PVS/SectorMgr.h"

class CAlphaEngine
{
public:
	CAlphaEngine();
	virtual ~CAlphaEngine();

	bool	createBsp();
	bool	createPvs();
	bool	init();
	void	render(int flag1, int flag2);
	bool	serialize(FILE * filePtr, bool isStoring);
	void	shutdown();

	CPBrushMgr*		pBrushMgr;
	CBspNode*		pBspRoot;
	CCamera*		pCamera;
	CTextureMgr*	pTextureMgr;
	CSectorMgr*		pSectorMgr;

	unsigned int	numBspNode;
	unsigned int	numBspFace;
};

#endif

