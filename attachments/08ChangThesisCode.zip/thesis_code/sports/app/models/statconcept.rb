class Statconcept < ActiveRecord::Base
	validates_presence_of :sport_id
	validates_presence_of :unit_id
end
