#ifndef _PBRUSHMGR_H_
#define _PBRUSHMGR_H_

#pragma warning (disable:4786)

#include <windows.h>
#include <gl/gl.h>
#include <gl/glext.h>

#include "AlphaEngine/PBrush/PBrush.h"

typedef struct
{
	PBRUSHID brushId;
	unsigned int polyId;
} PBRUSHID2POLYID;

#include <map>
#include <list>

using namespace std;

class CPBrushMgr
{
public:
	CPBrushMgr();
	~CPBrushMgr();

	bool		brushesSelected();
	void		brushScale(CVector3 p1, CVector3 p2);
	void		createBrush(int brushType, CVector3 axis, CVector3 p1, CVector3 p2, float depth);
	void		csgAdd();
	void		csgSub();
	void		deleteBuilder();
	void		deletePBrush();
	void		deselectPBrush();
	void		deselectPBrushPoly();
	CPolygon*	getPolygons();
	unsigned int getNextId();
	void		pickPBrush(const int &mode, int x, int y);
	void		pickPBrushPoly(const int &mode, int x, int y);	
	void		render(int flags);
	bool		serialize(FILE* filePtr, bool isStoring);
	void		selectPBrush(PBRUSHID brushId);
	void		selectPBrushPoly(PBRUSHID2POLYID &brushId2PolyId);
	void		setBaseTx(unsigned int txId);
	void		setDecalTx(unsigned int txId);
	void		setPolygonProp(const PolygonProp &polygonProp);
	void		transform(const CMatrix44 &matrix);

	CPBrush*				pBuilder;
	unsigned int			nextId;
	map<PBRUSHID, CPBrush*> mapId2PBrush;
	list<PBRUSHID>			listSelPBrush;
	list<PBRUSHID2POLYID>	listSelPBrushPoly;

private:
	void		add(CPBrush* pBrush);
	void		scaleBrush(CPBrush* pBrush, CVector3 p1, CVector3 p2);
};

#endif 
