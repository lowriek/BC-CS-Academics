function [eigenfaces,facespace,meanFace] = PCA(numeigs,A);
%function [eigenfaces,facespace,meanFace] = PCA(numeigs,A);
%INPUTS
%   numeigs : The number of eigenfaces to return
%   A : An m x n matrix where the rows correspond to one face image and n
%   is the number of faces
%OUTPUTS
%   eigenfaces: the eigenFaces returned from svd
%   facespace: the weights for each of the faces
%   meanFace: the average face


meanFace = mean(A);
[m,n] = size(A);
%figure(1);clf;imagesc(reshape(meanFace',120,80));axis image;truesize;colormap gray;
% norm = meanFace - min ( meanFace(:) ); normmean = norm / max ( norm(:) );
% imwrite(normmean,'meanFace.jpg','jpeg');
% 
% 
% fid = fopen('eigfaceindex.html','a'); fprintf(fid,'<img src="meanFace.jpg">'); fclose(fid);

for I=1:m
    A(I,:) = A(I,:) - meanFace;
end

%Find the eigenvectors of A
[u,s,v] = svd(A',0);
[a,b] = size(u);

%************The following commented out code creates jpg files of the
%eigenfaces*****************************
% for I=1:b
%     eigface = reshape(u(:,I),120,80);
%     norm = eigface - min ( eigface(:) ); normface = norm / max ( norm(:) );
%     figure(2);clf;imagesc(eigface);axis image;truesize;colormap gray;
%     eigfacename = [ 'eigface' , int2str(I) , '.jpg' ];
%     imwrite(normface,eigfacename,'jpeg');
%     fid = fopen('eigfaceindex.html','a');
%     fprintf(fid, '<img src="eigface');fprintf(fid,'%s',int2str(I));fprintf(fid,'.jpg">\n');
%     fclose(fid);
% end

%*********The following code creates a cumulative sum of the eigenfaces,
%showing that using about 20 brings back most the data****************
% [x,y] = size(s);
% eigvals = s*s; sum = trace(eigvals);
% for I=1:x
%     eigvals(I,I) = eigvals(I,I) / sum;
% end
% diagonal = diag(eigvals);
% cumul = cumsum(diagonal);
% figure(1);hold on;
% for I=1:numeigs
%     plot(I,cumul(I),'rx');
% end

eigenfaces = zeros(numeigs,n);
for I=1:numeigs
    eigenfaces(I,:) = u(:,I)';
end

facespace = zeros(m,numeigs);
for I=1:m
    for J=1:numeigs
        facespace(I,J) = dot(A(I,:),eigenfaces(J,:));
    end
end