#ifndef _SPHERE_H
#define _SPHERE_H

#include "server.h"


// Sphere class definition
class Sphere:Tracer{
	private:
		point3d center;
		double radius;
	
	public:
		Sphere();
		Sphere(double r, point3d cent, color c1, int m1, float refamt, float refract, float trans);
		void setCenter(point3d c);
		void setRadius(double r);
		void setFT(double ft);
		point3d getCenter();
		double getRadius();
		double getFT();


		//required abstract methods
		float getIntersection(ray r);
		color whichColor();
		int	whichMirror();
		float getLongitude();
		float getLatitude();
		avector getNormal();
		color getTexturePixel();
		int inShadow(point3d l);
			
};
	
#endif

