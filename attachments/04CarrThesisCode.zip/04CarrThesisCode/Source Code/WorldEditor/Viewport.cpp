// Viewport.cpp: implementation of the CViewport class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldEditor.h"
#include "Viewport.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CViewport::CViewport()
{
}

CViewport::CViewport(COpenGLView * parent)
{
	this->parent = parent;
}

CViewport::~CViewport()
{

}

COpenGLView* CViewport::GetParent() 
{
	return parent;
}

void CViewport::OnSize(UINT nType, int cx, int cy)
{

}
void CViewport::OnLButtonDown(UINT nFlags, CPoint point)
{

}
void CViewport::OnLButtonUp(UINT nFlags, CPoint point)
{

}
void CViewport::OnMouseMove(UINT nFlags, CPoint point)
{

}
void CViewport::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	
}
void CViewport::OnRButtonDown(UINT nFlags, CPoint point)
{
}
void CViewport::OnRButtonUp(UINT nFlags, CPoint point)
{
}

void CViewport::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void CViewport::SetupViewport(float perX, float perY, float perWidth, float perHeight)
{
	this->perX = perX;
	this->perY = perY;
	this->perWidth = perWidth;
	this->perHeight = perHeight;
}