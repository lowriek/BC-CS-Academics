#if !defined(AFX_CONTROLBOX_H__517D7A01_E0D0_4B57_A5E3_D67C147C4B12__INCLUDED_)
#define AFX_CONTROLBOX_H__517D7A01_E0D0_4B57_A5E3_D67C147C4B12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ControlBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CControlBox form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CControlBox : public CFormView
{
protected:
	CControlBox();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CControlBox)

// Form Data
public:
	//{{AFX_DATA(CControlBox)
	enum { IDD = IDD_CONTROL_BOX };
	CListBox	m_lstTexture;
	CListBox	m_lstDecal;
	CButton	m_btnDecal;
	CButton	m_btnNoDecal;
	CButton	m_btnTexture;
	CButton	m_btnFaceOk;
	CStatic	m_staticTransValue;
	CSpinButtonCtrl	m_spinTransValue;
	CEdit	m_editTransValue;
	CButton	m_chkTrans;
	CButton	m_chkSky;
	CComboBox	m_cmbExtended;
	CComboBox	m_cmbEntity;
	CButton	m_btnExtendedInsertor;
	CButton	m_btnEntityInsertor;
	CTabCtrl	m_tab;
	BOOL	m_transparent;
	float	m_transparencyValue;
	CString	m_lstDecalString;
	CString	m_lstTextureString;
	//}}AFX_DATA

// Attributes
public:
	bool setup;
// Operations
public:
	void HideToolbox();
	void HideFace();
	void HideGroups();
	void HideModels();
	void HideSky();
	void HideConsole();
	void HideStats();
	void HideTexture();

	void PopulateLists();

	void SetupToolbox();
	void SetupFace();
	void SetupGroups();
	void SetupModels();
	void SetupSky();
	void SetupConsole();
	void SetupStats();
	void SetupTexture();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlBox)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CControlBox();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CControlBox)
	afx_msg void OnSelchangeControlTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonFaceOk();
	afx_msg void OnDeltaposSpinTransparencyValue(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonTexture();
	afx_msg void OnButtonDecal();
	afx_msg void OnButtonNoDecal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLBOX_H__517D7A01_E0D0_4B57_A5E3_D67C147C4B12__INCLUDED_)
