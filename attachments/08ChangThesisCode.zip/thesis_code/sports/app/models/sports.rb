class Sports < ActiveRecord::Base
end
