class Player < ActiveRecord::Base
	has_many :rosterspots
	has_many :teams, :through => :rosterspots

	validates_uniqueness_of :name
end
