// Tokenizer.h: interface for the CTokenizer class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CTOKENIZER_H_
#define _CTOKENIZER_H_

class CTokenizer  
{
public:

	CTokenizer(const char * tokenString, const char * delim);
	virtual ~CTokenizer();

	char *	NextToken();

private:
	int		GetStringLength(const char * buffer);

	char *	tokenString;
	char *	delim;

	int		lengthTokenString;
	int		lengthDelimString;
	int		curIndexToken;
};

#endif // #define _CTOKENIZER_H_
