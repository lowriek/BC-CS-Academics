#include "Color4.h"

CColor4::CColor4(const CColor4 &rColor)
{
	operator=(rColor);
}

CColor4::CColor4(unsigned int r, unsigned int g, unsigned int b, unsigned int a)
{
	this->r = r;
	this->g = g;
	this->b = b;
	this->a = a;
}

CColor4::CColor4(unsigned int r, unsigned int g, unsigned int b)
{
	this->r = r;
	this->g = g;
	this->b = b;
	a = 255;
}

CColor4::CColor4()
{
	r = g = b = a = 255;
}

CColor4::~CColor4()
{

}

CColor4& CColor4::operator=(const CColor4 &rColor)
{
	r = rColor.r;
	g = rColor.g;
	b = rColor.b;
	a = rColor.a;
	return *this;
}

bool CColor4::operator ==(const CColor4 &rColor)
{
	return (r == rColor.r && g == rColor.g && b == rColor.b && a == rColor.a);
}

bool CColor4::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&a, sizeof(unsigned int), 1, filePtr);
		fwrite(&b, sizeof(unsigned int), 1, filePtr);
		fwrite(&g, sizeof(unsigned int), 1, filePtr);
		fwrite(&r, sizeof(unsigned int), 1, filePtr);
	}
	else
	{
		fread(&a, sizeof(unsigned int), 1, filePtr);
		fread(&b, sizeof(unsigned int), 1, filePtr);
		fread(&g, sizeof(unsigned int), 1, filePtr);
		fread(&r, sizeof(unsigned int), 1, filePtr);		
	}

	return true;
}