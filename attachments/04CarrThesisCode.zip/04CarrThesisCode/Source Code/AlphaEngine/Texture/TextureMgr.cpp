#include "TextureMgr.h"
#include <string>

bool CTextureMgr::createGLTexture(CTexture* pTexture)
{
	if (!pTexture)
		return false;

	if (pTexture->getTextureType() == INVALID_TEXTURE)
		return false;

	if (!pTexture->getData())
		return false;
	
	if (pTexture->getHeight() == 0 || pTexture->getWidth() == 0)
		return false;

	GLint param = GL_REPLACE;

	if (pTexture->getTextureType() == DECAL_TEXTURE)
		param = GL_DECAL;

	if (pTexture->getTextureType() == LIGHTMAP_TEXTURE)
		param = GL_MODULATE;
	
	glGenTextures(1, &pTexture->texId);
	glBindTexture(GL_TEXTURE_2D, pTexture->texId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, param);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, pTexture->getWidth(), pTexture->getHeight(), 0, GL_RGB, GL_UNSIGNED_BYTE, pTexture->getData());
	return true;
}

CTextureMgr::CTextureMgr()
{
	pTexture = 0;
}

CTextureMgr::~CTextureMgr()
{
	CTexture* pTemp = pTexture;

	while (pTemp != 0)
	{
		glDeleteTextures(1, &pTexture->texId);
		pTemp = pTemp->getNext();
	}

	if (pTexture)
		delete pTexture;
}

CTexture* CTextureMgr::getTextures()
{
	return pTexture;
}

unsigned int CTextureMgr::getTextureId(const char* textureName)
{
	unsigned int result = 0;
	CTexture* pTemp = pTexture;
	while (pTemp != 0)
	{
		if (strcmp(textureName, pTemp->name) == 0)
		{
			result = pTemp->texId;
			pTemp = 0;
		}
		else
		{
			pTemp = pTemp->getNext();
		}
	}

	return result;
}

bool CTextureMgr::loadTexturePak(const char* filename)
{
	FILE * filePtr;
	filePtr = fopen(filename, "rb");
	if (!filePtr)
		return false;

	int numTextures = 0;
	fread(&numTextures, sizeof(int), 1, filePtr);
	if (numTextures <= 0) return false;

	for (int x = 0; x < numTextures; x++)
	{
		CTexture* texture = new CTexture();
		if (!texture->serialize(filePtr, false))
		{
			delete texture;
			return false;
		}

		if (!createGLTexture(texture))
		{
			delete texture;
			return false;
		}
		else
		{
			if (pTexture)
				pTexture->add(texture);
			else
				pTexture = texture;
		}
	}
	return true;
}

