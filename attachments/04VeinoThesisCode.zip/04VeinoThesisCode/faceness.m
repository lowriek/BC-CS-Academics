function mymatrix = faceness(im, eigFaces,meanFace,width,height);
%function mymatrix = faceness(im, eigFaces,meanFace,width,height);
%INPUT
%    im : a grayscale image
%    eigFaces: the eigenFaces from PCA
%    meanFace: the meanFace from PCA
%    width,height: the width and height of the box to use
%OUTPUT
%    mymatrix : A matrix of the "faceness" of each pixel

[m,n] = size(im);
counter=0;counter2=1;
h = fspecial('gaussian',31,4);
im = imfilter(im,h); mymin = 9999;  mymax = -9999;
map = rgb2gray(double(imread('151facemap.jpg'))/255);

%meanFace = meanFace / sum(abs(meanFace(:)));
%while m>height && n>width
   counter=counter+1;
   topleft = [(height/2)+1 (width/2)+1];
   bottomright = [m-(height/2) n-(width/2)];
   matrix = zeros(m-height,n-width);
   
   %Uncomment this line if you're going to plot the dist vs variation
   figure(1);hold on;set(1,'DoubleBuffer','on');axis([0,.35,0,.7]);
   
   for I= topleft(1):bottomright(1)
       for J= topleft(2):bottomright(2)
           RECT = [J-(width/2) I-(height/2) width-1 height-1];
           thispic = imcrop(im,RECT);
                
           %figure(1);clf;imagesc(thispic);axis image;truesize;
           [matrix(I-(height/2),J-(width/2)),recreatedFace] = faceVal(thispic,eigFaces,meanFace,width,height,counter,I,J,map);

           
%********The following code finds the min and max value, used for
%normalizing**********
%            thispic = thispic / sum(abs(thispic(:)));
%            if (min(thispic(:))<mymin)
%                 mymin=min(thispic(:));
% 			end
% 			if (max(thispic(:))>mymax)
%                 mymax=max(thispic(:));
% 			end
% 			if (min(recreatedFace(:))<mymin)
%                 mymin=min(recreatedFace(:));
% 			end
% 			if (max(recreatedFace(:))>mymax)
%                 mymax=max(recreatedFace(:));
% 			end

%********The following code is used to make a movie of the original image
%and recreated image****************
%            if mod(I,50) == 0 && mod(J,3)==0
%                figure(1);clf;imagesc(reshape(thispic,height,width));axis image;truesize;
%                figure(2);clf;imagesc(reshape(recreatedFace,height,width));axis image;truesize;
%                a = getframe(1); a2 = getframe(2); a.cdata = [a.cdata a2.cdata];
%                M(counter2) = a;
%                counter2=counter2+1;
% %                if J >bottomright(2)-3
% %                   movie2avi(M,['facemovie' int2str(I) '.avi'],'fps',10);
% %                   clear M;
% %                   counter2=1;
% %                end    
%            end
                           
       end
       
      I
   end
   
   %Uncomment this line if you're plotting
   %drawnow;
   
   %figure(1);clf;imagesc(matrix);axis image;truesize;
   %print -djpeg figure
   if counter == 1
       mymatrix = matrix;
   end
   writepic=1-normalize(matrix);
   
   %********Uncomment the next line if you're making a movie
   %movie2avi(M,['facemovie.avi'],'fps',10);
   
   imwrite(normalize(writepic),['faceness' int2str(counter) '.jpg'],'jpeg');
   fid = fopen('faceness.htm','a');
   fprintf(fid, '<img src="');fprintf(fid,'%s',['faceness' int2str(counter) '.jpg']);
   fprintf(fid,'"><br>'); 
   fclose(fid);
   im=imresize(im,size(im)/sqrt(2),'bilinear');
   [m,n]=size(im);
   %end


function [val,recreatedFace,minim,maxim] = faceVal(im,eigFaces,meanFace,width,height,counter,I,J,map);
%
%
%
imbefore = im;
im  = im / sum(abs(im(:)));
im = reshape(im,1,width*height);

%subtract the mean face
im2 = double(im) - meanFace;

%im2 = im2 / sum(abs(im2(:)));
%myWeights = zeros(1,size(eigFaces,1));
%  for I=1:10
%      myWeights(1,I) = dot(im2(1,:),eigFaces(I,:));
% end


%Take the dot product to determine the weights
myWeights = im2 * eigFaces';
%Now recreate the face by multiplying the weights and eigenfaces and adding
%to the meanFace
recreatedFace = meanFace + myWeights*eigFaces;

%*******The following is for debugging purposes*******
%recreatedFace = recreatedFace / sum(abs(recreatedFace(:)));
% figure(1);clf;imagesc(reshape(im,height,width));axis image;truesize;
% figure(2);clf;imagesc(reshape(recreatedFace,height,width));axis image;truesize;
%val = sqrt( sum((im(1:end)-recreatedFace(1:end)).^2) );
%b = [sum(abs(im(:))) sum(abs(recreatedFace(:)))]




val = std(imbefore(:))/(sum(abs(im - recreatedFace))+eps);

%********The following is to plot the standard deviation vs the difference
%between the images*******
% dev = std(imbefore(:));
% val = sum(abs(im-recreatedFace));
% if (round(map(I,J)) == 1)
%     %plot(dev,val,'g.');
%     1;
% else
%     plot(dev,val,'r.');
% end

%********The following creates jpg images of the box before normalization,
%after normalization, and after recreation************
% if mod(I,5) == 0 && mod(J,10) == 0
% normim = (reshape(im,height,width) - (-3.1720e-004)) / (.0017-(-3.1720e-004));
% normrec = (reshape(recreatedFace,height,width) - (-3.1720e-004)) / (.0017-(-3.1720e-004));
% normim = min(1,max(0,normim)); normrec = min(1,max(0,normrec)); 
%    imwrite(imbefore,['orig' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg'],'jpeg');
%    imwrite(normim,['norm' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg'],'jpeg');
%    imwrite(normrec,['recreate' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg'],'jpeg');
% 
%    fid = fopen('index.html','a');
%    fprintf(fid, '<img src="');fprintf(fid,'%s',['orig' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg']);
%    fprintf(fid,'">');
%    fprintf(fid, '<img src="');fprintf(fid,'%s',['norm' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg']);
%    fprintf(fid,'">');
%    fprintf(fid, '<img src="');fprintf(fid,'%s',['recreate' int2str(counter) '-' int2str(I) '-' int2str(J) '.jpg']);
%    fprintf(fid,'">');
%    fprintf(fid,'%s',[num2str(val) '___' num2str(sum(imbefore(:))) '___' num2str(std(imbefore(:)))]); fprintf(fid,'<br>');
%    fclose(fid);
% end