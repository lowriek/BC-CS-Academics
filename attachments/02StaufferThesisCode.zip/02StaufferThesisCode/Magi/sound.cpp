/*		sound.cpp					  */
/*		Magi Game Engine		 */
/*		Interface for DirectSound */
/*		Created: April 4, 2002	   */
/*      Cris Stauffer					*/
/*		Code Based off of Trent Polack */


#include "sound.h"


/*		SoundObject Methods   */                


void SoundObject::Shutdown()
	{
	if(dmSegment!=NULL)
		{
		dmSegment->Release();
		dmSegment= NULL;
		}

	if(dsBuffer!=NULL)
		{
		dsBuffer->Release(); 
		dsBuffer= NULL;
		}
	}



/*	SoundManager Methods  */         


bool SoundObject::SetVolume(float percent)
{
	
		if(DS_OK !=dsBuffer->SetVolume(0))
			return false;
			
return true;
}

bool SoundManager::Init(void)
	{
	HRESULT hr;
	WCHAR wcharStr[MAX_PATH];
	char pathStr[MAX_PATH];

	CoInitialize(NULL);
	hr= CoCreateInstance(	CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC,
			IID_IDirectMusicLoader8, (void**)&loader);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create main DirectAudio file loader", "ERROR", MB_OK);
		return false;
		}

	hr= CoCreateInstance(	CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC,
			IID_IDirectMusicPerformance8, (void**)&performance);

		if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create main DirectAudio performance object", "ERROR", MB_OK);
		Shutdown();
		return false;
		}


	performance->InitAudio(	NULL, NULL, hwnd, DMUS_APATH_SHARED_STEREOPLUSREVERB, 
				64, DMUS_AUDIOF_ALL, NULL);

	hr=performance->GetDefaultAudioPath(&audioPath);
	
	//hr= performance->CreateStandardAudioPath(	DMUS_APATH_SHARED_STEREOPLUSREVERB, 64, TRUE, &audioPath);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to create the DirectAudio audio path", "ERROR", MB_OK);
		Shutdown();
		return false;
		}
	
	GetCurrentDirectory(MAX_PATH, pathStr);
	MultiByteToWideChar(CP_ACP, 0, pathStr, -1, wcharStr, MAX_PATH);

	loader->SetSearchDirectory(GUID_DirectMusicAllTypes, wcharStr, FALSE);

	return true;
	}


bool SoundManager::SetVolume(float percent)
{
	
		if(S_OK != audioPath->SetVolume(-9000 + 9000*percent,1))
			MessageBox(hwnd, "Unable to set volume through audio path", "ERROR", MB_OK);

			
return true;
}
void SoundManager::Shutdown()
	{
	//Shut down the direct music performance information
	if(performance!=NULL)
		{
		performance->Stop(NULL, NULL, 0, 0);
		performance->CloseDown();
		performance->Release();
		}

	//Shut down the direct sound listener(player) information
//	if(listener3 != NULL)
//		listener3->Release();

	//Shut down the direct music audiopath
	if(audioPath != NULL)
		audioPath->Release();

	
	//Shut down the direct music loader
	if(loader != NULL)
		loader->Release();

	//Uninitialize COM (*MUST* be done, or you're asking for trouble)
	CoUninitialize();

	
	}

void  SoundManager::Kill()
{
	
	
	for(int i = 0; i < 10; i++)
	{
		if(objList[i] != NULL)
		{
			//Stop(objList[i]);
			objList[i]->Shutdown();
		}
	}

	Shutdown();
}

bool SoundManager::Create(SoundObject * audio, char* filename, bool is3DSound)
	{
	HRESULT hr;
	WCHAR wcharStr[MAX_PATH];

	for(int i = 0; i<10; i++)
		if(objList[i] == NULL)
		{
			objList[i] = audio;
			if(objList[i] = NULL)
				MessageBox(hwnd, "Unable to Save Audio Object", "ERROR", MB_OK);
			break;
		}

	//Convert the file name to the string that DirectAudio needs
	MultiByteToWideChar(CP_ACP, 0, filename, -1, wcharStr, MAX_PATH);

	//Load the audio segment from a file
	hr= loader->LoadObjectFromFile(CLSID_DirectMusicSegment,
									 IID_IDirectMusicSegment8,
									 wcharStr,
									 (void**)&audio->dmSegment);
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to Load sound from file", "ERROR", MB_OK);
		return false;
		}

	hr = audioPath->GetObjectInPath(DMUS_PCHANNEL_ALL, DMUS_PATH_BUFFER, 0, 
										   GUID_NULL, 0, IID_IDirectSoundBuffer,
										   (void**)&audio->dsBuffer);

	if(FAILED(hr))
		{
		MessageBox(hwnd, "Unable to retrieve path buffer", "ERROR", MB_OK);
		return false;
		}


	return true;
	}

void SoundManager::Play(SoundObject * audio, DWORD numRepeats)
	{
	//Set the number of repeats that we want for the specific sound
	audio->dmSegment->SetRepeats(numRepeats);

		audio->dmSegment->Download(performance);
		//Play the non-3D sound segment

		performance->PlaySegmentEx(audio->dmSegment, NULL, NULL, 
									 DMUS_SEGF_DEFAULT, 0,
									 NULL, NULL, NULL);
	}
	

void SoundManager::Stop(SoundObject * audio)
	{	performance->StopEx(audio->dmSegment, 0, 0);	}

