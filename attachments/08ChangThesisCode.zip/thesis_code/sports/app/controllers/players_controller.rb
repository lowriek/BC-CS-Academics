class PlayersController < ApplicationController
	layout 'standard'	
	def index
		@players = Player.find(:all)
	end

	def show
		@player = Player.find(params[:id])
		@teams = @player.teams
		@stats = Stat.find_all_by_player_id(@player.id)
	end

end
