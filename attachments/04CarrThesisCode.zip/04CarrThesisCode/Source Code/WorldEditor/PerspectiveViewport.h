// PerspectiveViewport.h: interface for the CPerspectiveViewport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PERSPECTIVEVIEWPORT_H__8169C8A3_64BB_4811_A8CB_41AF1CD45E6D__INCLUDED_)
#define AFX_PERSPECTIVEVIEWPORT_H__8169C8A3_64BB_4811_A8CB_41AF1CD45E6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Viewport.h"

class CPerspectiveViewport : public CViewport  
{
private:
	CPerspectiveViewport();
public:
	CPerspectiveViewport(COpenGLView * parent);
	virtual ~CPerspectiveViewport();
	virtual void Render();
	virtual void SetupProjection();
	virtual void OnLButtonDown(UINT nFlags, CPoint point);

	short int RENDER_MODE;
};

#endif // !defined(AFX_PERSPECTIVEVIEWPORT_H__8169C8A3_64BB_4811_A8CB_41AF1CD45E6D__INCLUDED_)
