//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDD_MODELFORM                   101
#define IDC_TREE1                       1000
#define IDC_MODEL_CREATE                1001
#define IDC_MODEL_CANCEL                1002
#define IDC_MODEL_FILENAME              1003
#define IDC_MODEL_X                     1004
#define IDC_MODEL_Y                     1005
#define IDC_MODEL_Z                     1006
#define IDC_MODEL_RADIUS                1009
#define ID_QUIT                         40001
#define ID_FILE                         40002
#define ID_M_EXIT                       40004
#define ID_M_GRAPHIC_TEXTURE            40005
#define ID_M_GRAPHIC_LIGHTING           40006
#define ID_M_GRAPHIC_ENVIRON            40008
#define ID_MENU_ABOUT                   40009
#define ID_M_MUSIC_SONG                 40010
#define ID_M_MUSIC_SEFFECT              40011
#define ID_M_MODEL_CREATE               40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
