#ifndef _CVECTOR3_H_
#define _CVECTOR3_H_

#include <stdio.h>

class CVector3  
{
public:
    // constructors
    CVector3 ();
    CVector3 (float t_x, float t_y, float t_z);
    CVector3 (float points[3]);
    CVector3 (const CVector3 &rVector);
	// data
	float points[3];

	// access functions
	// CVector3 v;
	// v[0] is v.x; etc;
	float& operator[] (int i) const;

	// assignment
    CVector3& operator= (const CVector3& rVector);

    // comparison
    bool operator== (const CVector3& rVector) const;
    bool operator!= (const CVector3& rVector) const;	
    // arithmetic operations
    CVector3 operator+ (const CVector3& rVector) const;
    CVector3 operator- (const CVector3& rVector) const;
    CVector3 operator* (float fScalar) const;
    CVector3 operator/ (float fScalar) const;
    CVector3 operator- () const;

	// arithmetic updates
    CVector3& operator+= (const CVector3& rVector);
    CVector3& operator-= (const CVector3& rVector);
    CVector3& operator*= (float fScalar);
    CVector3& operator/= (float fScalar);
    // vector operations
    float length () const;
    float squaredLength () const;
    float dot (const CVector3& rVector) const;
    float unitize (float fTolerance = 1e-06f);
    CVector3 cross (const CVector3& rVector) const;
    CVector3 unitCross (const CVector3& rVector) const;

	bool	serialize(FILE * filePtr, bool isStoring);
    // Gram-Schmidt orthonormalization.
        // special points
    static const CVector3 ZERO;
    static const CVector3 UNIT_X;
    static const CVector3 UNIT_Y;
    static const CVector3 UNIT_Z;
    static float FUZZ;
private:
};

#endif
