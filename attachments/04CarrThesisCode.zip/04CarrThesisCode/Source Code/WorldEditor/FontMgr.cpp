// FontMgr.cpp: implementation of the CFontMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldEditor.h"
#include "FontMgr.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFontMgr::CFontMgr()
{
	base = -1;
}

CFontMgr::~CFontMgr()
{
	if (base != -1) 
	{
		glDeleteLists(base, 96);
	}
}

bool CFontMgr::CreateBitmapFont(HDC hDC, char *font, int fontSize)
{

	HFONT hFont;
	HFONT oldFont;

	if (stricmp(font, "symbol") == 0)
	{
		hFont = CreateFont(	fontSize, 0,0,0, FW_BOLD, FALSE, FALSE, FALSE,
							SYMBOL_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
							ANTIALIASED_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
							font);
	}
	else
	{
		hFont = CreateFont(	fontSize, 0,0,0, FW_BOLD, FALSE, FALSE, FALSE,
							ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
							ANTIALIASED_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
							font);
	}

	if (!hFont)
		return false;

	base = glGenLists(96);
	oldFont = (HFONT)::SelectObject(hDC, hFont);
	wglUseFontBitmaps(hDC, 32, 96, base);
	::SelectObject(hDC, oldFont);
	DeleteObject(hFont);

	return true;
}

void CFontMgr::PrintString(char *str, float x, float y, float z)
{
	
	if (base <= 0 || str == NULL)
		return;

	glRasterPos3f(x,y, z);
	glPushAttrib(GL_LIST_BIT);
		glListBase(base - 32);
		glCallLists(strlen(str), GL_UNSIGNED_BYTE, str);
	glPopAttrib();	
}

