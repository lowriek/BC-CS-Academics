/* ----------------------------------------------
   -											-
   -	PROJECT:		Hourglass				-
   -	FILE:			primitive.h				-	
   -	CREATED:		07/24/01				-
   -	MODIFIED:		07/24/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */


#ifndef _PRIMITIVE_H
#define _PRIMITIVE_H

	//	Mesh
		struct Mesh
		{
			int m_materialIndex;
			int m_numTriangles;
			int *m_pTriangleIndices;
		};

		//	Material properties
		struct Material
		{
			float m_ambient[4], m_diffuse[4], m_specular[4], m_emissive[4];
			float m_shininess;
			GLuint m_texture;
			char *m_pTextureFilename;
		};

		//	Triangle structure
		struct Triangle
		{
			float m_vertexNormals[3][3];
			float m_s[3], m_t[3];
			int m_vertexIndices[3];
		};

		//	Vertex structure
		struct Vertex
		{
			char m_boneID;	// for skeletal animation
			float m_location[3];
		};

#endif						//_PRIMITIVE_H