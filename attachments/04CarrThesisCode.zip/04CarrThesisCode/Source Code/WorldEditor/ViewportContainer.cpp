// ViewportContainer.cpp : implementation file
//

#include "stdafx.h"
#include "WorldEditor.h"
#include "ViewportContainer.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewportContainer

IMPLEMENT_DYNCREATE(CViewportContainer, COpenGLView)

void CViewportContainer::AddViewport(CViewport * viewport)
{
	if (viewport != NULL)
		listViewports.push_back(viewport);
}

CPoint CViewportContainer::AdjustPoint(CViewport * viewport, CPoint point)
{
	CRect cr;
	GetClientRect(&cr);
	winHeight = cr.Height();
	winWidth = cr.Width();
	// convert from Window coordinates to OpenGL coordinates
	int x = point.x;
	int y = winHeight - point.y;

	// bottom left coordinate of this viewport
	int windowX = viewport->perX * winWidth;
	int windowY = viewport->perY * winHeight;

	// create the point to be returned in terms of OpenGL coordinate system
	CPoint pt;
	pt.x = x - windowX;
	pt.y = y - windowY;
	return pt;
}

#ifdef _DEBUG
void CViewportContainer::AssertValid() const
{
	COpenGLView::AssertValid();
}
#endif //_DEBUG

void CViewportContainer::CreateView(float perX, float perY, float perWidth, float perHeight)
{
	CRect cr;
	GetClientRect(&cr);
	winHeight = cr.Height();
	winWidth = cr.Width();

	int x = perX * winWidth;
	int y = perY * winHeight;
	int width = perWidth * winWidth;
	int height = perHeight * winHeight;
	glScissor(x, y, width, height);
	glEnable(GL_SCISSOR_TEST);
	glViewport(x, y, width, height);
}

CViewportContainer::CViewportContainer()
{
}

CViewportContainer::~CViewportContainer()
{
	list<CViewport *>::iterator iter;
	for (iter = listViewports.begin(); iter != listViewports.end(); ++iter)
	{
		delete (*iter);
	}
	listViewports.clear();
}

#ifdef _DEBUG
void CViewportContainer::Dump(CDumpContext& dc) const
{
	COpenGLView::Dump(dc);
}
#endif //_DEBUG

CViewport * CViewportContainer::GetViewport(CPoint point)
{
	if (listViewports.empty())
		return NULL;

	CRect cr;
	GetClientRect(&cr);
	winHeight = cr.Height();
	winWidth = cr.Width();

	// find a viewport that contains this point...
	int x = point.x;
	int y = winHeight - point.y;

	// lower left point of window
	int windowX1 = 0;
	int windowY1 = 0;
	// upper right point of window
	int windowX2 = winWidth;
	int windowY2 = winHeight;

	list<CViewport *>::iterator iter;

	for (iter = listViewports.begin(); iter != listViewports.end(); ++iter)
	{
		CViewport * viewport = *iter;
		// bottom left coordinate of this viewport
		windowX1 = viewport->perX * (float)winWidth;
		windowY1 = viewport->perY * (float)winHeight;
		// upper right coordinate of this viewport
		windowX2 = windowX1 + (viewport->perWidth * winWidth);
		windowY2 = windowY1 + (viewport->perHeight * winHeight);
		// check if (x, y) is in between this rect.  if so return
		if (x >= windowX1 && x <= windowX2)
		{
			if (y >= windowY1 && y <= windowY2)
			{
				return viewport;
			}
		}
	}

	// no valid viewport was found
	return NULL;
}

BOOL CViewportContainer::InitOpenGL()
{
	if (!COpenGLView::InitOpenGL())
	{
		return FALSE;
	}
	
	glClearColor(0,0,0,0);
	return TRUE;
}

void CViewportContainer::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CViewport * viewport = GetViewport(point);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnLButtonDown(nFlags, AdjustPoint(viewport, point));
	}

	COpenGLView::OnLButtonDown(nFlags, point);
}

void CViewportContainer::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CViewport * viewport = GetViewport(point);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnLButtonUp(nFlags, AdjustPoint(viewport, point));
	}

	COpenGLView::OnLButtonUp(nFlags, point);
}

void CViewportContainer::OnMouseMove(UINT nFlags, CPoint point) 
{
	CViewport * viewport = GetViewport(point);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnMouseMove(nFlags, AdjustPoint(viewport, point));
	}
	COpenGLView::OnMouseMove(nFlags, point);
}

BOOL CViewportContainer::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	CViewport * viewport = GetViewport(pt);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnMouseWheel(nFlags, zDelta, AdjustPoint(viewport, pt));
	}

	return COpenGLView::OnMouseWheel(nFlags, zDelta, pt);
}

void CViewportContainer::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CViewport * viewport = GetViewport(point);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnRButtonDown(nFlags, AdjustPoint(viewport, point));
	}

	COpenGLView::OnRButtonDown(nFlags, point);
}

void CViewportContainer::OnRButtonUp(UINT nFlags, CPoint point) 
{
	CViewport * viewport = GetViewport(point);
	if (viewport != NULL)
	{
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->OnRButtonUp(nFlags, AdjustPoint(viewport, point));
	}

	COpenGLView::OnRButtonUp(nFlags, point);
}

void CViewportContainer::OnSize(UINT nType, int cx, int cy) 
{
	COpenGLView::OnSize(nType, cx, cy);
	
	if (0 >= cx || 0>=cy || nType == SIZE_MINIMIZED)
		return;

	winHeight = cy;
	winWidth = cx;
	
	SetContext();
	Render();
	SwapGLBuffers();

}

void CViewportContainer::Render()
{
	// Get access to the full screen and clear it
	CreateView(0.0,0.0,1.0,1.0);
	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	list<CViewport *>::iterator iter;
	
	// iterate through the vieports and display
	for (iter = listViewports.begin(); iter != listViewports.end(); ++iter)
	{
		CViewport * viewport = *iter;
		CreateView(viewport->perX, viewport->perY, viewport->perWidth, viewport->perHeight);
		viewport->Render();
	}
}



BEGIN_MESSAGE_MAP(CViewportContainer, COpenGLView)
	//{{AFX_MSG_MAP(CViewportContainer)
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()