/* Standard Includes */
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <math.h>
#include <string.h>

/* Raytracing Includes */
#include "main.h"


/* Networking Includes */
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

/* Threading Includes */
#include <pthread.h>

#define PORT 2000
#define MAXDATASIZE 180


extern "C" {
#include <GL/glut.h>
}

//Globals 
float AMBIENT;				 	  //Ambient scene light level
int NUM_OBJECTS;				  //Number of objects in scene
int ANTI_ALIAS;				     	  //0=no, 1=yes
int CAST_SHADOWS;			       	  //0=no, 1=yes
int ENABLE_FOG;				       	  //0=no, 1=yes
float fog_min_dist;			       	  //distance at which fogging effects become initially apparent
float fog_max_dist;				  //distance at which scene is in full fog
float SHADOW_FACTOR;				  //amount to affect base color if in shadow
int numServers;


/*Other, typedef and class dependant variables and functions
	-must therefore be defined after the above.   */
	
int currentLine=0;
color fog_color, light_color;
point3d eye, screen, light;
ray theray;


//Some globals for the scene
int IMAGE_DONE=0;
int SCREEN_RES_X=499;
int SCREEN_RES_Y=499;
float WORLD_RES_X=100.0;
float WORLD_RES_Y=100.0;
int XPIXEL, YPIXEL;
float * imageBuf;
int serverCount;
int sDoneCount;
int pixelsDone;
int firstDisplay=0;

pthread_mutex_t bufferMutex;
pthread_mutex_t countMutex;
pthread_mutex_t parentMutex;
pthread_t * servers;


static void checkErrors(void) {
	GLenum errCode;
	const GLubyte *errString;
	if((errCode=glGetError()) != GL_NO_ERROR) {
		errString=gluErrorString(errCode);
		cerr<<"OpenGL Error: "<<errString<<endl;
		}
} 

static void myInit(void) {
	
  glClearColor(1.0, 1.0, 1.0, 1.0);
  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0.0, WORLD_RES_X, 0.0, WORLD_RES_Y);
  glMatrixMode(GL_MODELVIEW);
  
}

static void display(void){
	
  int pIndex;
  int maxIndex;

  if(IMAGE_DONE==0){						
     
    glClear(GL_COLOR_BUFFER_BIT);
    
  }
  else{	
    glClear(GL_COLOR_BUFFER_BIT);                        /* Clear the screen */

    maxIndex = pixelsDone;                                         /* Only for as many pixels as completed, in case some servers */
    pIndex=0;                                                          /*  never returned pixel data */
    color drawcolor;
    
    while(pIndex < maxIndex) {                                         /* Loop through buffer and draw each pixel */
      
	drawcolor.r = imageBuf[pIndex+2];
	drawcolor.g = imageBuf[pIndex+3];
	drawcolor.b = imageBuf[pIndex+4];
	glColor3f(drawcolor.r, drawcolor.g, drawcolor.b);	
	glBegin(GL_POINTS);
	glVertex2f(imageBuf[pIndex], imageBuf[pIndex+1]);
	glEnd();
	pIndex = pIndex + 5;
	
    }
   
    glFlush();
    checkErrors();
  }
  
  
}


void doManualRefresh(){
  
  pthread_mutex_lock(&parentMutex);       //should get blocked on this
  display();
  firstDisplay=1;                         //call the first manual redraw
  pthread_mutex_unlock(&parentMutex);     //unlock this locking
  pthread_mutex_unlock(&parentMutex);     //unlock the previous unlocking
}

//void sThread(struct serverInfo * info){
static void * sThread(void * info2){  
  int sockfd, numbytes, n, numfloats,b, error=0;
  char frame[MAXDATASIZE];  
  char ch;
  char *c;
  FILE * fp;
  struct hostent *he;
  struct sockaddr_in their_addr;
  float * dataBuf;

  struct serverInfo * info;

  info = (struct serverInfo *) info2;

  printf("Thread %d (%s):  Thread Starting...\n", info->threadNum, info->ip);
  if( (fp=fopen(info->fname, "rb"))==NULL){
    printf("Thread %d (%s):  Unable to open local source file '%s'. Aborting.\n", info->threadNum, info->ip, info->fname);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;                                       //update number of servers done and terminate
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }

  if( (he=gethostbyname(info->ip))==NULL){
    printf("Thread %d (%s):  Unable to get host IP address for '%s'.  Aborting.\n", info->threadNum, info->ip, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;                                     //update number of servers done and terminate
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }

  if( (sockfd=socket(AF_INET, SOCK_STREAM, 0)) == -1){
    printf("Thread %d (%s):  Unable to get socket from OS. Aborting.\n", info->threadNum, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }

  their_addr.sin_family =AF_INET;
  their_addr.sin_port = htons(PORT);
  their_addr.sin_addr = *((struct in_addr *)he->h_addr);
  bzero(&(their_addr.sin_zero), 8);
  
  if( connect(sockfd, (struct sockaddr *)&their_addr, sizeof(struct sockaddr)) == -1){
    printf("Thread %d (%s):  Unable to connect to host program. Aborting\n", info->threadNum, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  
  //Now connected to rayserver
  
  receiveFileRequest(sockfd, &error);                                                        /* Receive File request */
  if(error==1){
    printf("Thread %d (%s):  Error receiving file request. Aborting \n", info->threadNum, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  else if (error==2){
    printf("Error 2\n");
    return NULL;
  }
  
  printf("Thread %d (%s):  Received proper file request.\n", info->threadNum, info->ip);                  
  
  sendSourceFile(fp, sockfd, &error);                                                        /* Send server the source file */
  if(error){
    printf("Thread %d (%s):  Error sending source file. Aborting \n", info->threadNum, info->ip); 
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  printf("Thread %d (%s):  Sent source file successfully.\n", info->threadNum, info->ip);

  receiveParamRequest(sockfd, &error);                                                       /* Receive param string request */
  if(error){
    printf("Thread %d (%s):  Error receiving param request. Aborting \n", info->threadNum, info->ip);  
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }                                                      
  printf("Thread %d (%s):  Received proper param request.\n", info->threadNum, info->ip);
  
  sendParamString(sockfd, info->first, info->last, &error);                                  /* Send param string */
  if(error){
    printf("Thread %d (%s):  Error sending param string. Aborting \n", info->threadNum, info->ip);  
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  printf("Thread %d (%s):  Sent param string successfully.\n", info->threadNum, info->ip);           

  sendDataRequest(sockfd, &error);                                                            /* Send data request */
  if(error){
    printf("Thread %d (%s):  Error sending data request. Aborting \n", info->threadNum, info->ip); 
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  printf("Thread %d (%s):  Send data request succesfully.\n", info->threadNum, info->ip);
  printf("Thread %d (%s):  Waiting for pixel data...\n", info->threadNum, info->ip);

  numfloats = receiveNumFloats(sockfd, &error);
  if(error){
    printf("Thread %d (%s):  Error receiving number of floats. Aborting \n", info->threadNum, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  dataBuf = (float *) malloc (numfloats * sizeof(float));

  receivePixelData(sockfd, dataBuf, numfloats, &error);                                                /* Receive pixel data */
  if(error){
    printf("Thread %d (%s):  Error receiving pixel data. Aborting \n", info->threadNum, info->ip);
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL;
  }
  printf("Thread %d (%s):  Received pixel data. \n", info->threadNum, info->ip);

  transferPixelsToBuffer(numfloats, dataBuf, &error);                                          /* Transfer pixels to main buffer */
  if(error){
    printf("Thread %d (%s):  Error putting pixels in buffer. Aborting \n", info->threadNum, info->ip); 
    pthread_mutex_lock(&countMutex);
    sDoneCount++;
    pthread_mutex_unlock(&countMutex);
    return NULL ;
  }
  printf("Thread %d (%s):  Transferred pixel data to main image buffer.\n", info->threadNum, info->ip);
  
  printf("Thread %d (%s):  Finished with workload.  Terminating.\n\n", info->threadNum, info->ip);



  return NULL;

  
} 

void transferPixelsToBuffer(int numfloats, float * dataBuf, int * error)
{
  int i, j;
  
  //Lock all other threads out of count vars and image buffer
  pthread_mutex_lock(&bufferMutex);

  
  
  j = pixelsDone;
  for(i=0; i<numfloats; i++)         //transfer pixels to main buffer
    imageBuf[j++] = dataBuf[i];
  
  pixelsDone = pixelsDone + numfloats;  //update global float count
  
  pthread_mutex_unlock(&bufferMutex);
  
  pthread_mutex_lock(&countMutex);   //lock out count var for numm servers that are done
  sDoneCount++;                     //update the count
  
  if(sDoneCount == serverCount){
    IMAGE_DONE = 1;
    pthread_mutex_unlock(&parentMutex);
  }

  
  pthread_mutex_unlock(&countMutex);

  *error = 0;




}

int receiveNumFloats(int sock, int * error){
  int n, numfloats;

  n = read(sock, &numfloats, sizeof(int));
  if( n < 4 ){
    *error = 1;
    return 0;
  }

  return numfloats;
}

void receivePixelData(int sock, float * dataBuf, int nf, int * error){

  int i,n;
  float f;
  int numfloats, count=0;

  numfloats = nf;
 
  //read floats one at a time
  for(i=0; i<numfloats; i++){
    n = read(sock, &f, sizeof(float));
    if( n <  4){
      *error = 1;
      return;
    }
    else{
      dataBuf[i] = f;
      count++;
    }
  }
  return;
}

void sendDataRequest(int sock, int * error){
  int n;
  char * frame = "SENDPIXELDATA";
  
  n = write(sock, frame, strlen(frame) + 1);
  if( n<=0){
    *error = 1;
    return;
  }

}

void sendParamString(int sock, int first, int last, int * error){

  int n, i;
  char * frame;

  frame = (char *) malloc(100 * sizeof(char));
  
  //assemble param string
  i=0;
  sprintf(frame, "%d", 0);             // xmin
  
  i = strlen(frame);
  frame[i] = '&';                     // delimiter
  i++;
  
  sprintf(&(frame[i]), "%d", 499);    // xmax
 
  i = strlen(frame);         
  frame[i] = '&';                     // delimiter
  i++;
  
  sprintf(&(frame[i]), "%d", 1);      // xstep
  
  i = strlen(frame);
  frame[i] = '&';                     // delimiter
  i++;

  sprintf(&(frame[i]), "%d", first);  // ymin
  
  i = strlen(frame);
  frame[i] = '&';                     // delimiter
  i++;
  
  sprintf(&(frame[i]), "%d", last);   // ymax

  i = strlen(frame);                  // delimiter
  frame[i] = '&';
  i++;

  sprintf(&(frame[i]), "%d", 1);      // ystep

  // '\0' already added by sprintf

  n = write(sock, frame, strlen(frame) +1);
  if (n <= 0){
    *error =1;
    return;
  }

}

void receiveFileRequest(int sock, int * error){

  int n;
  char frame[100];
  
  n = read(sock, frame, sizeof(frame));
  if( n <= 0){
    *error = 1;
    return;
  }

  if( strcmp(frame, "SENDSOURCEFILE") != 0){
    *error = 2;
    return;
  }
}

void receiveParamRequest(int sock, int * error){
  int n;
  char frame[100];
  
  n = read(sock, frame, sizeof(frame));
  if (n<=0){
    *error = 1;
    return;
  }
  
  if (strcmp(frame, "SENDRAYRANGE") != 0 ){
    *error = 1;
    return;
  }
}

void sendSourceFile(FILE * fp, int sock, int * error){
  int i, j, ch;
  char frame[100];

  i=0;
  ch = fgetc(fp);
  i++;
  
  while(ch!= EOF){
    if(i <= 100)
      frame[i-1] = ch;
    else{
      j = write(sock, frame, sizeof(frame));
      if( j <= 0){
	*error = 1;
	return ;
      }
      i=1;
      frame[0] = ch;
    }
    ch = fgetc(fp);
    i++;
  }
  
  if(i > 0){
    frame[i-1] = '\0';
    j = write(sock, frame, strlen(frame) + 1);
    if (j <= 0){
      *error = 1;
      return;
    }
  }

  fclose(fp);

}

int checkServers(int numServers, char * argv[]){
  struct hostent *he;
  int i;
  int error=0;

  printf("\n");

  /* 
     Attempt to get the hostnames for each one and check for errors
     and if error with IP address, effectively remove it from the list.
  */
   
  for(i=2; i<(numServers + 2); i++){
    printf("Client:  Checking IP address for '%s'...  ", argv[i]);
    
    if((he=gethostbyname(argv[i]))==NULL){
      printf("\n         Error:  Unable to resolve Host IP Address for '%s'.\n", argv[i]);
      error++;
    }    
    else
      printf("OK\n");
  }

  if(error==0)
    printf("Client:  All IP Addresses OK.\n");

  return error;

}

void initializeLocks(){

  /* Initialize mutexs */
  pthread_mutex_init(&bufferMutex, NULL);
  pthread_mutex_init(&countMutex, NULL);
  pthread_mutex_init(&parentMutex, NULL);

  /* Lock mutexs until parent says everybody go! */
  pthread_mutex_lock(&bufferMutex);
  pthread_mutex_lock(&countMutex);
  pthread_mutex_lock(&parentMutex);

}



void dispatchServers(int sCount, char * ips[], char * sourcef){
  
  int i;
  int nRows, modVal;
  char * argString;
  struct serverInfo * si;
  
  sDoneCount = 0;
  pixelsDone = 0;

  /* Calculate number of rows for each server */
  nRows = 500 / sCount;
  /* Calculate leftover rows in case of uneven division */
  modVal = 500 % sCount;
  
  printf("\n\n* * * * *    Dispatching Servers    * * * * *\n");
  printf("Client:  Total Servers: %d\n", sCount);
  printf("         Allocating %d rows of pixels to each server.\n", nRows);
  printf("                   (%d extra rows to final server)\n\n", modVal);
  
  printf("Client:  Initializing mutex locks...\n");
  initializeLocks();
  printf("         Initialize done.\n\n");
  
  printf("Client:  Mallocing threads for servers...\n");
  servers = (pthread_t *) malloc( sCount * sizeof(pthread_t));
  printf("         Done mallocing.\n\n");

  printf("Client:  Mallocing image buffer...\n");
  imageBuf = (float *) malloc(500 * 500 * 5 * sizeof(float));
  printf("         Done mallocing.\n\n");

  /* For each server, assemble their arg string, and put them into motion... */
  for(i=0; i<sCount; i++){
    
    si = (struct serverInfo *) malloc(sizeof(struct serverInfo));            /* Malloc struct for server info */

    si->ip = (char *) malloc(strlen(ips[i+2]) + 1);                          /* Malloc and copy ip for this server */
    strcpy(si->ip, ips[i+2]);

    si->fname = (char *) malloc(strlen(sourcef) + 1);                        /* Malloc and copy source file name */
    strcpy(si->fname, sourcef);

    si->first = (nRows * i);                                                 /* Beginning row for this server to start tracing */
    si->last = (nRows * (i+1)) - 1;
    si->threadNum = i;
                                                                             /* Ending for for this server to start tracing */
    if(i==(sCount-1))                                                        /* Last server also does extra rows */
      si->last = si->last + modVal;

    printf("Client:  Thread %d (%s) Information:\n", i, si->ip);
    printf("         IP:   '%s'\n", si->ip);
    printf("         File: '%s'\n", si->fname);
    printf("         Rows:  %d to %d\n", si->first, si->last);

    /* Create the pthread, and put them into motion. */
    if(pthread_create(&(servers[i]), NULL, sThread, si) != 0){
      printf("         Error creating server thread %d.\n", i);
      printf("         Moving on to next thread.\n");
      sDoneCount++;                                                          /* Increment number of servers left to wait for */
    }
    else
      printf("         Created server thread %d succesfully.\n\n", i);
    
  }  //Done creating all the server threads threads

  printf("Client:  All Threads created successfully...\n\n");
  /* Unlock the mutex so that servers can being returning results when ready */
  pthread_mutex_unlock(&bufferMutex);
  pthread_mutex_unlock(&countMutex);

  //Return to main, open window, and call display() to wait for pixel data...
  
}

void main(int argc, char* argv[]){
  int error;
  char * fname;

  if(argc < 3){
    printf("\n\nInvalid execution.\n");
    printf("This raytracer is designed to run in a parallel environment.\n");
    printf("You must supply the name of a valid scene file to raytrace\n");
    printf("as well as the IP address of valid raytracing servers.\n");
    printf("USAGE: raytrace <<sourcefile.ray>> <<IPAddress1>> ... <<IPAddressN>>\n\n");
    exit(0);
    
  }
  else
    serverCount = (argc - 2);
  
  //Check that servers are at least valid IP addresses.
  error = checkServers(serverCount, argv);
  if(error){
    printf("\nClient:  One or more IP addresses you entered are invalid.\n");
    printf("         Tracing cannot continue.\n");
    printf("         Program terminating.\n\n\n");
    exit(1);
  }
  

  
  
  
  //copy command line arguments to new variable before O/S reclaims memory
  fname = (char *) malloc(sizeof(argv[1]));
  strcpy(fname, argv[1]);
    
  dispatchServers(serverCount, argv, fname);
  
  pthread_mutex_lock(&parentMutex);                                   //hold here until last thread clears him...
  printf("\nClient:  Raytracing done. Displaying...\n");

  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
  glutInitWindowSize(SCREEN_RES_X, SCREEN_RES_Y);
  glutInitWindowPosition(50, 50);
  glutCreateWindow("Distributed Raytrace v1.0");
  glutDisplayFunc(display);
  
  myInit();

  glutMainLoop();  
  
  if(IMAGE_DONE==1)
    free(imageBuf);
}


//Various inline power functions
float Power(float a, int b){
	if(b<0)
		return pow(a,b);
	else if(b==0)
		return 1;
	else if(b==1)
		return a;
	else{
		float temp = a * a;
		for(int i=2;i<b;i++)
			temp = temp * a;
		return temp;
	}
}
	
float Power(float a, float b)
{	return pow(a,b);}


float Power(float a, double b)
{	return pow(a,b);}

float Power(int a, float b)
{	return pow(a,b);}

float Power(int a, int b)
{	return Power((float)a,b);}

float Power(int a, double b)
{   return pow(a,b);}

float Power(double a, float b)
{	return pow(a,b);}

float Power(double a, int b)
{	return Power((float)a,b);}

float Power(double a, double b)
{   return pow(a,b);}

float SQRT(float a){
	float r;
	if(a<(-.05))
		return 0;
	else if( a<0 && a>(-.05))
		r=0;
	else
		r = sqrt(a);
	
	return r;
}
















