function [] = makeClusterPage(kmeaned,loc,eigFaces,meanFace,pagename,desc)
% function [] = makeClusterPage(kmeaned,loc,faceSpace,meanFace,pagename,desc)
%   INPUT
%      kmeaned : the index received from kmeans
%      loc : the loc received from kmeans
%      pagename: the name of the output index page (without .htm)
%      desc : a string description of the page

pics = dir('*_*_*.jpg');
[m,n] = size(kmeaned);
fid = fopen([pagename '.htm'],'a');
fprintf(fid,'<font size="+3"<b>');fprintf(fid, desc);fprintf(fid,'</font></b><p>');
fclose(fid);
for I=1:max(kmeaned)
      %recreateFaceIm(loc(I,:),pagename,I);
      recreateFaceK(loc(I,:),pagename,eigFaces,meanFace,I);
      for J=1:m
          if kmeaned(J)==I
              fid = fopen([pagename '.htm'],'a');
              fprintf(fid, '<img src="');fprintf(fid,'%s',pics(J).name);fprintf(fid,'">\n');
              fclose(fid);    
          end
      end
     fid = fopen([pagename '.htm'],'a');
      fprintf(fid,'<p>');
      fclose(fid);
  end
