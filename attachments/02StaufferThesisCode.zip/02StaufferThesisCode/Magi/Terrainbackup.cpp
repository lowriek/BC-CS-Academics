/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --																			   	  --
   --						TERRAIN.CPP								    	--
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	OCTOBER 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "terrain.h"
#include "MilkshapeModel.h"

extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;

GLuint LoadGLTexture( const char *filename );


float colorSwatch[16][3] = 
{
	{ .703, .832,  .184 }, // Green
{ .636, .671, .437 }, // Dk Grn	
	{ .637, .687, .437 }, // Dk Grn
{ .703, .832,  .184 }, // Green
	{ .871, .507,  .183 }, // Dk Sand
	{ .637, .687, .437 }, // Dk Grn
	{ .703, .832,  .184 }, // Green
		{ .644, .468,  .277 }, // Dk Brown
	{ .714, .601, .488 }, // Med Brown
{ .917, .906, .887 }, // Lt Gray
	{ .644, .468,  .277 }, // Dk Brown
	{ .714, .601, .488 }, // Med Brown
		{ .996, .996, .996 },  // White
	{ .917, .906, .887 }, // Lt Gray
	{ .996, .996, .996 }  // White
};

float *		 Terrain::terrainData;
float *		 Terrain::normals;
unsigned int Terrain::terrainTextures[10];
float   *		 Terrain::terrainMatrix;
char*		Terrain::roughMatrix;
float *		  Terrain::colorTerrain;


int Terrain::TerrainLoad(char * fn)
{

	FILE * tFile;
	unsigned char ucGarb[5];
	short int siGarb[5];
	int total;
	unsigned char * temp;
	unsigned char type;
	unsigned char pixDepth;
	char tmpName[30];
	

	tFile = fopen(fn, "rb");
	if(tFile == NULL)
		{	
			
			MessageBox(NULL,"Can't Open File For Terrain","ERROR",MB_OK|MB_ICONEXCLAMATION);
			
			return 0;
		}

	// Begin reading in header information

	fread(&ucGarb, sizeof(unsigned char), 2, tFile);
	fread(&type, sizeof(unsigned char), 1, tFile);
	fread(&siGarb, sizeof(short int),2, tFile);
	fread(&ucGarb, sizeof(unsigned char), 1, tFile);
	fread(&siGarb, sizeof(short int), 2, tFile);
	
	// Read in Fields we want
	fread(&width, sizeof(short int), 1, tFile);
	fread(&height, sizeof(short int), 1, tFile);
	fread(&pixDepth, sizeof(unsigned char), 1, tFile);
	
	fread(&ucGarb, sizeof(unsigned char), 1, tFile);
	total = (height * width * (pixDepth / 8));
	temp = (unsigned char *) malloc (sizeof(unsigned char) * total);
	terrainData = (float *) malloc (sizeof(float) * total);

	fread(temp, sizeof(unsigned char), total, tFile);

	if(temp == NULL)
	{
	
		
	    MessageBox(NULL,"Can't Copy terrain data","ERROR",MB_OK|MB_ICONEXCLAMATION);
		fclose(tFile);
		return 0;
	}

	for(int j = 0; j< width * height; j++)	
		terrainData[j] = (((float)temp[j]) / 256) * scaleHeight;

		
		free(temp);

	fclose(tFile);

	/* Open Color Data in BMP of Same File Name */
	int tmpNum = 0;
	strcpy(tmpName,fn);
	while(fn[tmpNum] != '.')
		tmpName[tmpNum] = fn[tmpNum++];
											// Change the name of the file to open the bmp
	tmpName[tmpNum + 1] = 'b';
	tmpName[tmpNum + 2] = 'm';
	tmpName[tmpNum + 3] = 'p';

	AUX_RGBImageRec * colorFile = LoadBMP(tmpName);
	if(colorFile == NULL)
	{
		MessageBox(NULL,"Can't Copy terrain Color from File data","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return 0;
	}

	colorTerrain  = (float * ) malloc(sizeof(float) * 3 * colorFile->sizeX * colorFile->sizeY);

	for(int i = 0; i < colorFile->sizeY * colorFile->sizeX * 3; i++)
		colorTerrain[i] = ((float)colorFile->data[i]) / 256.0;
			
	free(colorFile->data);
	free(colorFile);


	normals = (float *)malloc(sizeof(float)*total*3);
	terrainMatrix = (float *)malloc(sizeof(float)*total);
	
	roughMatrix = (char *)malloc(sizeof(char)*total);
	MakeNormals();
	terrainTextures[1] = LoadTGA("Data/grass3.tga", GL_DECAL);
	terrainTextures[0] = LoadTGA("Data/rockgrassgrey.tga", GL_DECAL);
	terrainTextures[2] = LoadTGA("Data/water.tga", GL_DECAL);
	boundingRadius = sqrt((double)(width *width*xStep*xStep + height * height*zStep*zStep));
	boundingRadius = boundingRadius / 2;
	depth = 0;

	quadWidth = width - 1;
	
	

	return 1;

}

void Terrain::Draw()
{
	
}

void Terrain::BlendNormal(float * middle, float * base1, float * base2, float blend)
{
middle[0] = middle[0] * (1.0 - blend) + (base1[0] + base2[0])/2 * blend;
middle[1] = middle[1] * (1.0 - blend) + (base1[1] + base2[1])/2 * blend;
middle[2] = middle[2] * (1.0 - blend) + (base1[2] + base2[2])/2 * blend;	

}


void Terrain::Render(int xTrue, int zTrue, int qW)
{
	int qR = qW >> 1;
	int nNode = xTrue + qR + (qR + zTrue) * width;		// Center Node



	// Check if the Node has children, if so, recurse and forget about drawing at this level

	if(terrainMatrix[nNode] == -1)
	{
		Render(xTrue, zTrue, qR);
		Render(xTrue + qR, zTrue, qR);
		Render(xTrue, zTrue + qR, qR);
		Render(xTrue + qR,zTrue + qR, qR);
		return;
	}

	if(terrainMatrix[nNode] == 0)				// If quad is not visible return
	return;


	long neighborNorth = nNode - qW * width;
	long neighborSouth = nNode + qW * width;
	long neighborEast = nNode + qW;
	long neighborWest = nNode - qW;

	//Handle Possibly Blending the four directions

	//North

	long nwCorner = xTrue + zTrue * width;
	long neCorner = nwCorner + qW;
	long seCorner = neCorner + qW * width;
	long swCorner = seCorner - qW;
	long	nCorner = nwCorner + qR;
	long	sCorner = swCorner + qR;
	long	wCorner = nwCorner + qR * width;
	long	eCorner = neCorner + qR * width;

	float blendVal;

	float trueNorth = terrainData[nCorner];
	float trueSouth = terrainData[sCorner];
	float trueEast = terrainData[eCorner];
	float trueWest = terrainData[wCorner];

	float eastNorm[3], westNorm[3], northNorm[3], southNorm[3], nwNorm[3], neNorm[3], seNorm[3], swNorm[3];
	float centerNorm[3];
	
	eastNorm[0] = normals[3 * eCorner]; eastNorm[1] = normals[3 * eCorner + 1]; eastNorm[2] = normals[3 * eCorner + 2];
	westNorm[0] = normals[3 * wCorner]; westNorm[1] = normals[3 * wCorner + 1]; westNorm[2] = normals[3 * wCorner + 2];
	northNorm[0] = normals[3 * nCorner]; northNorm[1] = normals[3 * nCorner + 1]; northNorm[2] = normals[3 * nCorner + 2];
	southNorm[0] = normals[3 * sCorner]; southNorm[1] = normals[3 * sCorner + 1]; southNorm[2] = normals[3 * sCorner + 2];
	seNorm[0] = normals[3 * seCorner]; seNorm[1] = normals[3 * seCorner + 1]; seNorm[2] = normals[3 * seCorner + 2];
	swNorm[0] = normals[3 * swCorner]; swNorm[1] = normals[3 * swCorner + 1]; swNorm[2] = normals[3 * swCorner + 2];
	neNorm[0] = normals[3 * neCorner]; neNorm[1] = normals[3 * neCorner + 1]; neNorm[2] = normals[3 * neCorner + 2];
	nwNorm[0] = normals[3 * nwCorner]; nwNorm[1] = normals[3 * nwCorner + 1]; nwNorm[2] = normals[3 * nwCorner + 2];


	long x1Global =	xTrue * xStep;
	long x2Global = (xTrue + qR) * xStep;
	long x3Global = (xTrue + qW) * xStep;
	long z1Global = zTrue * zStep;
	long z2Global = (zTrue + qR) * zStep;
	long z3Global = (zTrue + qW) * zStep;

	float nVal, sVal, eVal, wVal;	
	
	float trueCenter = (terrainData[nwCorner] + terrainData[neCorner] + terrainData[swCorner] + terrainData[seCorner]) / 4 * (terrainMatrix[nNode] - 1.0) + 
								terrainData[nNode] * (1.0-(terrainMatrix[nNode] - 1.0));

	centerNorm[0] = (seNorm[0] + neNorm[0] + swNorm[0] + nwNorm[0]) / 4 * (terrainMatrix[nNode] - 1.0) + 
							 normals[3 * nNode] * (1.0 - (terrainMatrix[nNode] - 1.0));
	centerNorm[1] = (seNorm[1] + neNorm[1] + swNorm[1] + nwNorm[1]) / 4 * (terrainMatrix[nNode] - 1.0) + 
							 normals[3 * nNode + 1] * (1.0 - (terrainMatrix[nNode] - 1.0));
	centerNorm[2] = (seNorm[2] + neNorm[2] + swNorm[2] + nwNorm[0]) / 4 * (terrainMatrix[nNode] - 1.0) + 
							 normals[3 * nNode + 2] * (1.0 - (terrainMatrix[nNode] - 1.0));

	if(zTrue != 0)
	{
		if(terrainMatrix[neighborNorth] > 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborNorth]) - 1.0);			
			trueNorth = (terrainData[nwCorner] + terrainData[neCorner]) / 2 * blendVal + 
							trueNorth * (1.0 - blendVal);
			BlendNormal(northNorm,nwNorm, neNorm, blendVal);

			
		}
	nVal = terrainMatrix[neighborNorth];
	}
		else
			nVal = -1;
	

	if(zTrue + qW + 1 != width)
	{
		if(terrainMatrix[neighborSouth] > 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborSouth]) - 1.0);
			trueSouth = (terrainData[swCorner] + terrainData[seCorner]) / 2 * blendVal +
							trueSouth * (1.0 - blendVal);
			BlendNormal(southNorm, swNorm, seNorm, blendVal);
		}
		sVal = terrainMatrix[neighborSouth];
	}
	else
		sVal = -1;

	if(xTrue != 0)
	{

		if(terrainMatrix[neighborWest] > 0)
		{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborWest]) - 1.0);
		trueWest = (terrainData[nwCorner] + terrainData[swCorner]) / 2 * (blendVal) +
								trueWest * (1.0 - blendVal);
		BlendNormal(westNorm,nwNorm, swNorm, blendVal);
		}
		wVal = terrainMatrix[neighborWest];
	}
	else
		wVal = -1;
		
		if(xTrue + qW + 1 != width)
		{
		if(terrainMatrix[neighborEast] > 0)
			{
			blendVal = (MAX(terrainMatrix[nNode], terrainMatrix[neighborEast]) - 1.0);
				trueEast = (terrainData[neCorner] + terrainData[seCorner]) / 2 * blendVal +
								trueEast * (1.0 - blendVal);
				BlendNormal(eastNorm,neNorm, seNorm, blendVal);
			}
		eVal = terrainMatrix[neighborEast];
		}
		else
			eVal = -1;
	

//	Draw Triangle Fan

float texMap = 1.0;
float halfTexMap =.5;

if(qW != 2)
{
	texMap = qW/2;
	halfTexMap = texMap /2;
}

//texMap = ((xTrue + 1) % 10) / 10;
//halfTexMap = texMap/2;

				

glEnable(GL_CULL_FACE);
glEnable(GL_DEPTH_TEST);

glEnable(GL_BLEND);
glEnable(GL_ALPHA_TEST);
glAlphaFunc(GL_GREATER, 0);
glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
glEnable(GL_LIGHTING);
//glDisable(GL_LIGHTING);
//glDisable(GL_TEXTURE_2D);

	//glDisable(GL_CULL_FACE);
//glPolygonMode(GL_FRONT, GL_LINE);
//glLineWidth(1);	
	static float cnt = 0.0;


glActiveTextureARB(GL_TEXTURE0_ARB);
glEnable(GL_TEXTURE_2D);
glBindTexture(GL_TEXTURE_2D,  terrainTextures[1]);
//glColor3f(1.0,1.0,1.0);

//glActiveTextureARB(GL_TEXTURE1_ARB);
//glEnable(GL_TEXTURE_2D);
//glBindTexture(GL_TEXTURE_2D,  terrainTextures[0]);

cnt++;
glBegin(GL_TRIANGLE_FAN);
			
				// Center Point
//glColor4f(0.9,0.1,0.1, 1.0);
glNormal3fv(centerNorm);//normals[3 * nNode],normals[3 * nNode + 1],normals[3 * nNode + 2]);

glMultiTexCoord2fARB(GL_TEXTURE0_ARB, halfTexMap, halfTexMap);
//glMultiTexCoord2fARB(GL_TEXTURE1_ARB, halfTexMap , halfTexMap);
glColor4f(colorTerrain[3 * nNode],colorTerrain[3 * nNode + 1],colorTerrain[3 * nNode + 2], 1.0);
glVertex3f(x2Global, trueCenter, z2Global);


 // North Point

if(nVal != 0)
{
	
	glNormal3fv(northNorm);//normals[3 * nCorner],normals[3 * nCorner + 1],normals[3 * nCorner + 2]);
	
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, halfTexMap, 0);
//	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, halfTexMap, 0);
	glColor4f(colorTerrain[3 * nCorner],colorTerrain[3 * nCorner + 1],colorTerrain[3 * nCorner + 2], 1.0);
	glVertex3f(x2Global, trueNorth, z1Global);
}
	//NW point

	
	glNormal3f(normals[3 * nwCorner],normals[3 * nwCorner + 1],normals[3 * nwCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0, 0);
  //  glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0, 0);
	glColor4f(colorTerrain[3 * nwCorner],colorTerrain[3 * nwCorner + 1],colorTerrain[3 * nwCorner + 2], 1.0);
	glVertex3f(x1Global, terrainData[nwCorner], z1Global);

	//W point

if(wVal != 0)
{
	
	
	glNormal3fv(westNorm);//normals[3 * wCorner],normals[3 * wCorner + 1],normals[3 * wCorner + 2]);
	
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0, halfTexMap);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0, halfTexMap);
	glColor4f(colorTerrain[3 * wCorner],colorTerrain[3 * wCorner + 1],colorTerrain[3 * wCorner + 2], 1.0);
	glVertex3f(x1Global, trueWest, z2Global);
}

	//SW point

	
	glNormal3f(normals[3 * swCorner],normals[3 * swCorner + 1],normals[3 * swCorner + 2]);
	glTexCoord2f(0, texMap);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0,texMap);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0,texMap);
	glColor4f(colorTerrain[3 * swCorner],colorTerrain[3 * swCorner + 1],colorTerrain[3 * swCorner + 2], 1.0);
	glVertex3f(x1Global, terrainData[swCorner], z3Global);

	//S point

if(sVal != 0)
{
	

	glNormal3fv(southNorm);//normals[3 * sCorner],normals[3 * sCorner + 1],normals[3 * sCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, halfTexMap, texMap);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, halfTexMap, texMap);
	glColor4f(colorTerrain[3 * sCorner],colorTerrain[3 * sCorner + 1],colorTerrain[3 * sCorner + 2], 1.0);
	glVertex3f(x2Global, trueSouth, z3Global);
}

	//SE point

	
	glNormal3f(normals[3 * seCorner],normals[3 * seCorner + 1],normals[3 * seCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, texMap, texMap);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, texMap, texMap);
	glColor4f(colorTerrain[3 * seCorner],colorTerrain[3 * seCorner + 1],colorTerrain[3 * seCorner + 2], 1.0);
	glVertex3f(x3Global, terrainData[seCorner], z3Global);

	//E point
	
if(eVal != 0)
{
	
	glNormal3fv(eastNorm);//normals[3 * eCorner],normals[3 * eCorner + 1],normals[3 * eCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, texMap, halfTexMap);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, texMap, halfTexMap);
	glColor4f(colorTerrain[3 * eCorner],colorTerrain[3 * eCorner + 1],colorTerrain[3 * eCorner + 2], 1.0);
	glVertex3f(x3Global, trueEast, z2Global);
}

	//NE point
	
	glNormal3f(normals[3 * neCorner],normals[3 * neCorner + 1],normals[3 * neCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, texMap, 0);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, texMap, 0);
	glColor4f(colorTerrain[3 * neCorner],colorTerrain[3 * neCorner + 1],colorTerrain[3 * neCorner + 2], 1.0);
	glVertex3f(x3Global, terrainData[neCorner], z1Global);

if(nVal != 0)
{
	
	glNormal3fv(northNorm);//normals[3 * nCorner],normals[3 * nCorner + 1],normals[3 * nCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, halfTexMap, 0);
    //glMultiTexCoord2fARB(GL_TEXTURE1_ARB, halfTexMap, 0);
	glColor4f(colorTerrain[3 * nCorner],colorTerrain[3 * nCorner + 1],colorTerrain[3 * nCorner + 2], 1.0);
	glVertex3f(x2Global, trueNorth, z1Global);
}
else
{
	
	glNormal3f(normals[3 * nwCorner],normals[3 * nwCorner + 1],normals[3 * nwCorner + 2]);
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0, 0);
	//glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0 , 0);
	glColor4f(colorTerrain[3 * nwCorner],colorTerrain[3 * nwCorner + 1],colorTerrain[3 * nwCorner + 2], 1.0);
	glVertex3f(x1Global, terrainData[nwCorner], z1Global);


}

//cnt += .0001;

glEnd();

glDisable(GL_LIGHTING);
glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
}
/*
void Terrain::Render(int xTrue, int zTrue, int qW)
{

	long xGlob = xTrue * xStep;
	long zGlob = zTrue * zStep;
	int quadRad = qW >> 1;
	int nNode = xTrue + quadRad  + (zTrue + quadRad) * width;

	if(terrainMatrix[nNode] == -1)
	{
			Render(xTrue,zTrue,quadRad);
			Render(xTrue + quadRad, zTrue + quadRad,quadRad);  
			 Render(xTrue, zTrue + quadRad, quadRad);
			 Render(xTrue + quadRad,zTrue,quadRad);
	}
	else
			if(terrainMatrix[nNode] >  0.0)
			{
				//if(debugOut)
					//messenger->FontPrint(" %f, %f  is Drawn with visibility %f with bounding radius %d",x,z,nd,boundingRadius);
				
				glEnable(GL_DEPTH_TEST);
				glDisable(GL_LIGHTING);
				//glDisable(GL_TEXTURE_2D);
				//glDisable(GL_CULL_FACE);
				//glPolygonMode(GL_FRONT, GL_LINE);
				//glLineWidth(1);
				
				
			glBindTexture( GL_TEXTURE_2D, terrainTextures[1]);
			glEnable( GL_TEXTURE_2D );

				long nodeCenter = xTrue + quadRad + (zTrue + quadRad)*width;
				
				long nodeNorth = nodeCenter - qW * width;
				long nodeSouth = nodeCenter + qW * width;
				long nodeEast  = nodeCenter + qW;
				long nodeWest  = nodeCenter - qW;
				long nodeNorthBlend, nodeSouthBlend, nodeEastBlend, nodeWestBlend;
				

				if(zTrue == 0)
					nodeNorthBlend = -1;
				else	
					if( terrainMatrix[nodeNorth] == -1)
						nodeNorthBlend = -1;
					else
					nodeNorthBlend = terrainMatrix[nodeNorth];
				
				if(xTrue == 0 )
					nodeWestBlend = -1;
				else
					if(terrainMatrix[nodeWest] == -1)
						nodeWestBlend = -1;
					else
					nodeWestBlend = terrainMatrix[nodeWest];

				if(xTrue + qW + 1 == width )
					nodeEastBlend = -1;
				else
					if( terrainMatrix[nodeEast] == -1)
						nodeEastBlend = -1;
					else
						nodeEastBlend = terrainMatrix[nodeEast];

				if(zTrue + qW + 1 == width )
					nodeSouthBlend = -1;
				else
				 if(terrainMatrix[nodeSouth] == -1)
					nodeSouthBlend = -1;
				 else
					 nodeSouthBlend = terrainMatrix[nodeSouth];

				
				int	p1 = xGlob + quadRad * xStep;
				int	p2 = xGlob + qW * xStep;
				int	p3 = zGlob + quadRad * zStep;
				int	p4 = zGlob + qW * zStep;
				int	p5 = xTrue + quadRad + (zTrue + quadRad) * width;
				int	p6 = xTrue + quadRad + zTrue * width;
				int	p7 = xTrue + zTrue * width;
				int	p8 = xTrue + (zTrue + quadRad) * width;
				int	p9 = xTrue + (zTrue + qW) * width;
				int	p10 = xTrue + quadRad + (zTrue + qW) * width;
				int	p11 = xTrue + qW + (zTrue + qW) * width;
				int	p12 = xTrue + qW + (zTrue + quadRad) * width;
				int	p13 = xTrue + qW + zTrue * width;

				float blendN = (MAX(terrainMatrix[nodeCenter], nodeNorthBlend) - 1) /254;
				float blendS =(MAX(terrainMatrix[nodeCenter], nodeSouthBlend) - 1)/254;
				float blendE = (MAX(terrainMatrix[nodeCenter], nodeEastBlend) - 1)/254;
				float blendW =(MAX(terrainMatrix[nodeCenter], nodeWestBlend) - 1)/254;
				float blendC = (terrainMatrix[nodeCenter] - 1) / 254;

				
				float	trueNorth = terrainData[p6];
				float	trueSouth = terrainData[p10];
				float	trueWest = terrainData[p8];
				float	trueEast = terrainData[p12];
				float	trueCenter = terrainData[p5];


				
				float centerHeight = terrainData[nodeCenter];
				float nSideAve = (terrainData[p7] + terrainData[p13])/2;
				float eSideAve = (terrainData[p13] +  terrainData[p11])/2;
				float wSideAve = (terrainData[p9] + terrainData[p7])/2;
				float sSideAve = (terrainData[p11] + terrainData[p9])/2 ;
				float centerAve = (terrainData[p7] + terrainData[p13] + terrainData[p9] + terrainData[p11])/4;

				if(xTrue == 512 && zTrue == 512 && qW == 2)
					messenger->FontPrint("blend is: %f -center average is: %f - realCenterHeight: %f",blendC,centerAve, centerHeight);

				if(nodeNorthBlend != -1)
					trueNorth = nSideAve * (blendN) + terrainData[p6] * (1.0 - blendN);
				if(nodeSouthBlend != -1)
					trueSouth = sSideAve * (blendS) + terrainData[p10] * (1.0 - blendS);
				if(nodeWestBlend!= -1)
					trueWest = wSideAve * (blendW) + terrainData[p8] * (1.0 - blendW);
				if(nodeEastBlend != -1)
					trueEast = eSideAve * (blendE) + terrainData[p12] * (1.0 - blendE);
				
				trueCenter = centerAve * (blendC) + terrainData[p5] * (1.0 - blendC);			
			


				int texMapping = 1;//quadWidth/2;
				float halfTexMap = .5;//texMapping/2;

			
				int temp = scaleHeight / 15;

				glBegin(GL_TRIANGLE_FAN);
			
				// Center Point
				glColor3f(colorTerrain[3*p5],colorTerrain[3*p5 + 1],colorTerrain[3*p5 + 2]);
				glNormal3f(normals[3*p5],normals[3*p5 + 1],normals[3*p5 + 2]);
				glTexCoord2f(halfTexMap, halfTexMap);
				glVertex3f(p1, trueCenter, p3); 
				// N  Point
				if(nodeNorthBlend != 0)
				{
						glColor3f(colorTerrain[3*p6],colorTerrain[3*p6 + 1],colorTerrain[3*p6 + 2]);
				glNormal3f(normals[3*p6],normals[3*p6 + 1],normals[3*p6 + 2]);
				glTexCoord2f(halfTexMap,0);
				glVertex3f(p1, trueNorth, zGlob);
				numTriangles++;
				}
				// NW Point
					glColor3f(colorTerrain[3*p7],colorTerrain[3*p7 + 1],colorTerrain[p7* 3 + 2]);
				glNormal3f(normals[3*p7],normals[3*p7 + 1],normals[3*p7 + 2]);
				glTexCoord2f(0,0);
				glVertex3f(xGlob, terrainData[p7], zGlob);
				numTriangles++;
				// W  Point	
				if(nodeWestBlend != 0)
				{
						glColor3f(colorTerrain[3*p8],colorTerrain[3*p8 + 1],colorTerrain[p8* 3 + 2]);
				glNormal3f(normals[3*p8],normals[3*p8 + 1],normals[3*p8 + 2]);
				glTexCoord2f(0,halfTexMap);
				glVertex3f(xGlob, trueWest,p3);	
				numTriangles++;
				}
				// SW Point
						glColor3f(colorTerrain[3*p9],colorTerrain[3*p9 + 1],colorTerrain[p9* 3 + 2]);
				glNormal3f(normals[3*p9],normals[3*p9 + 1],normals[3*p9 + 2]);
				glTexCoord2f(0,texMapping);
				glVertex3f(xGlob, terrainData[p9],p4);
				numTriangles++;
				if(nodeSouthBlend != 0)
				{
				// S  Point
							glColor3f(colorTerrain[3*p10],colorTerrain[3*p10 + 1],colorTerrain[p10* 3 + 2]);
				glNormal3f(normals[3*p10],normals[3*p10 + 1],normals[3*p10 + 2]);
				glTexCoord2f(halfTexMap,texMapping);
				glVertex3f(p1, trueSouth, p4);
				numTriangles++;
				}
				// SE Point
					glColor3f(colorTerrain[3*p11],colorTerrain[3*p11 + 1],colorTerrain[p11* 3 + 2]);
				glNormal3f(normals[3*p11],normals[3*p11 + 1],normals[3*p11 + 2]);
				glTexCoord2f(texMapping,texMapping);
				glVertex3f(p2, terrainData[p11], p4);
				numTriangles++;
				if(nodeEastBlend != 0)
				{
				// E  Point
						glColor3f(colorTerrain[3*p12],colorTerrain[3*p12 + 1],colorTerrain[p12* 3 + 2]);
				glNormal3f(normals[3*p12],normals[3*p12 + 1],normals[3*p12 + 2]);
				glTexCoord2f(texMapping,halfTexMap);
				glVertex3f(p2, trueEast, p3);
				numTriangles++;
				}
				// NE Point
						glColor3f(colorTerrain[3*p13],colorTerrain[3*p13 + 1],colorTerrain[p13* 3 + 2]);
				glNormal3f(normals[3*p13],normals[3*p13 + 1],normals[3*p13 + 2]);
				glTexCoord2f(texMapping,0);
				glVertex3f(p2, terrainData[p13], zGlob);
				numTriangles++;
				if(nodeNorthBlend != 0)
				{
					//N  Point Again
						glColor3f(colorTerrain[3*p6],colorTerrain[3*p6 + 1],colorTerrain[p6* 3 + 2]);
					glNormal3f(normals[3*p6],normals[3*p6 + 1],normals[3*p6 + 2]);
					glTexCoord2f(halfTexMap,0);
					glVertex3f(p1, trueNorth, zGlob);	
					
				}
					else
					{
							glColor3f(colorTerrain[3*p7],colorTerrain[3*p7 + 1],colorTerrain[p7* 3 + 2]);
					glNormal3f(normals[3*p7],normals[3*p7 + 1],normals[3*p7 + 2]);
					glTexCoord2f(0,0);
					glVertex3f(xGlob,terrainData[p7],zGlob);
				
					}
					glEnd();

				}

}
*/
void Terrain::Kill()
{
		if(next != NULL)
		delete next;
	if(child != NULL)
		delete child;

}



float * Terrain::TerrainCrossProduct(int x1,int z1,int x2,int z2,int x3,int z3) {

	float *auxNormal,v1[3],v2[3];
		
	v1[0] = (x2-x1); 
	v1[1] = -terrainData[z1 * width + x1] 
			+ terrainData[z2 * width + x2];
	v1[2] = (z2-z1); 


	v2[0] = (x3-x1); 
	v2[1] = -terrainData[z1 * width + x1] 
			+ terrainData[z3 * width + x3];
	v2[2] = (z3-z1); 

	auxNormal = (float *)malloc(sizeof(float)*3);

	auxNormal[2] = v1[0] * v2[1] - v1[1] * v2[0];
	auxNormal[0] = v1[1] * v2[2] - v1[2] * v2[1];
	auxNormal[1] = v1[2] * v2[0] - v1[0] * v2[2];

	return(auxNormal);
}

void terrainNormalize(float *v) {

	double d;
	
	d = sqrt((v[0]*v[0]) + (v[1]*v[1]) + (v[2]*v[2]));

	v[0] = v[0] / d;
	v[1] = v[1] / d;
	v[2] = v[2] / d;
}

void terrainAddVector(float *a, float *b) {

	a[0] += b[0];
	a[1] += b[1];
	a[2] += b[2];
}

void Terrain::MakeNormals() {

	float *norm1,*norm2,*norm3,*norm4; 
	int i,j,k;
	
	if (normals == NULL)
		return;


	for(i = 0; i < height; i++)
		for(j = 0; j < width; j++) {
			norm1 = NULL;
			norm2 = NULL;
			norm3 = NULL;
			norm4 = NULL;

			/* normals for the four corners */
			if (i == 0 && j == 0) {
				norm1 = TerrainCrossProduct(0,0, 0,1, 1,0);	
				terrainNormalize(norm1);				
			}
			else if (j == width-1 && i == height-1) {
				norm1 = TerrainCrossProduct(j,i, j,i-1, j-1,i);	
				terrainNormalize(norm1);				
			}
			else if (j == 0 && i == height-1) {
				norm1 = TerrainCrossProduct(j,i, j+1,i, j,i-1);	
				terrainNormalize(norm1);				
			}
			else if (j == width-1 && i == 0) {
				norm1 = TerrainCrossProduct(j,i, j-1,i, j,i+1);	
				terrainNormalize(norm1);				
			}

			/* normals for the borders */
			else if (i == 0) {
				norm1 = TerrainCrossProduct(j,0, j-1,0, j,1);
				terrainNormalize(norm1);
				norm2 = TerrainCrossProduct(j,0,j,1,j+1,0);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
			}
			else if (j == 0) {
				norm1 = TerrainCrossProduct(0,i, 1,i, 0,i-1);
				terrainNormalize(norm1);
				norm2 
					= TerrainCrossProduct(0,i, 0,i+1, 1,i);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
			}
			else if (i == height-1) {
				norm1 = TerrainCrossProduct(j,i, j+1,i, j,i-1);
				terrainNormalize(norm1);
				norm2 = TerrainCrossProduct(j,i, j,i-1, j-1,i);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
			}
			else if (j == width-1) {
				norm1 = TerrainCrossProduct(j,i, j,i-1, j-1,i);
				terrainNormalize(norm1);
				norm2 = TerrainCrossProduct(j,i, j-1,i, j,i+1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
			}

			/* normals for the inner vertices using 8 neighbours */
			else {
				norm1 = TerrainCrossProduct(j,i, j-1,i, j-1,i+1);
				terrainNormalize(norm1);
				norm2 = TerrainCrossProduct(j,i, j-1,i+1, j,i+1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j,i+1, j+1,i+1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j+1,i+1, j+1,i);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j+1,i, j+1,i-1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j+1,i-1, j,i-1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j,i-1, j-1,i-1);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
				norm2 = TerrainCrossProduct(j,i, j-1,i-1, j-1,i);
				terrainNormalize(norm2);
				terrainAddVector(norm1,norm2);
				free(norm2);
			}

			terrainNormalize(norm1);
			norm1[2] = - norm1[2];
			for (k = 0; k< 3; k++) 
				normals[3*(i*width + j) + k] = norm1[k];

			free(norm1);
			

		}
}



float Terrain::GetHeight(float xPos, float zPos)
{
	float xRemainder,xAve,zAve,hAve;
	float zRemainder;
	long x1 = xPos / xStep;
	long z1 = zPos / zStep;
	xRemainder = xPos/xStep - x1;
	zRemainder = zPos/zStep - z1;



	if(xRemainder > zRemainder)
	{
		if(xRemainder > .5)
			xAve =	terrainData[x1 + z1 * height] * (1.0-xRemainder) + 	terrainData[x1 + z1 * height + 1] *xRemainder;
		else
			xAve =	terrainData[x1 + z1 * height] * (xRemainder) + 	terrainData[x1 + z1 * height+ 1] *(1.0-xRemainder);	
		
		if(zRemainder > .5)
			zAve =	terrainData[x1 + z1 * height + 1] * (1.0-zRemainder) + 	terrainData[x1 + z1 * height + height + 1] *zRemainder;
		else
			zAve =	terrainData[x1 + z1 * height + 1] * (zRemainder) + 	terrainData[x1 + z1 * height + height + 1] *(1.0-zRemainder);
	
		return((xAve + zAve)/2);
	}	
	else
		{
		if(xRemainder > .5)
			xAve =	terrainData[x1 + z1 * height + height] * (1.0-xRemainder) + 	terrainData[x1 + z1 * height + height + 1] *xRemainder;
		else
			xAve =	terrainData[x1 + z1 * height + height] * (xRemainder) + 	terrainData[x1 + z1 * height+ height+ 1] *(1.0-xRemainder);	

		
		if(zRemainder > .5)
			zAve =	terrainData[x1 + z1 * height] * (1.0-zRemainder) + 	terrainData[x1 + z1 * height + height ] *zRemainder;
		else
			zAve =	terrainData[x1 + z1 * height] * (zRemainder) + 	terrainData[x1 + z1 * height + height ] *(1.0-zRemainder);

	
		return((xAve + zAve)/2);
		}	

}

void MasterTerrain::Draw()
{

	Tessellate();
	Render(0,0,quadWidth);

	messenger->FontPrint("Drawing %ld triangles",numTriangles);
	numTriangles = 0;

	Entity * e = child;
	
	while(e != NULL)
	{
		e->Draw();
	    e = e->next;
	}


	
}

void MasterTerrain::Kill()
{
	if(next != NULL)
		delete next;
	if(child != NULL)
		delete child;

	
	free(terrainData);
	free(terrainMatrix);
	free(normals);

}


void MasterTerrain::Tessellate()
{

	memset( terrainMatrix, 0, width*width * sizeof(float));
	unsigned int nRadius = quadWidth >> 1;
	unsigned nNode = nRadius + nRadius * width;


	terrainMatrix[nNode] = -1;

	RecursiveTessellate( 0,			0,			nRadius );
	RecursiveTessellate( 0,			nRadius,	nRadius );
	RecursiveTessellate( nRadius,	0,			nRadius );
	RecursiveTessellate( nRadius,	nRadius,	nRadius );

}


void MasterTerrain::RecursiveTessellate(int nWx, int nWz, int qWidth)
{

	unsigned int nRadius = qWidth >> 1;
	unsigned nNode = nWx + nRadius + (nWz + nRadius) * width;
	int hT;

	
	float dist = IsVisible((nWx + nRadius) * xStep, terrainData[nNode], (nWz + nRadius) * xStep, nRadius * xStep * 2);
	
	
	if(dist < 0)
	{
		messenger->FontPrint(" Distance is % f",dist);
		//dist = nRadius * xStep * 2 - dist;
	}
		

	if(dist == 0)
	{
		terrainMatrix[nNode] = 0;
		return;
	}
		
	
		// Split Metric determines if more depth is needed	DISTANCE / (XFACTOR * QUADWIDTH * ROUGHNESS)
	
	float splitMetric = (float)dist / (float)((50 * qWidth));//*(1 + roughMatrix[nNode]));

	


	if(splitMetric < 1.0 && qWidth > 3)
	{

	terrainMatrix[nNode] = -1;
	RecursiveTessellate( nWx,					nWz,			nRadius );
	RecursiveTessellate( nWx,					nWz + nRadius,	nRadius );
	RecursiveTessellate( nWx + nRadius,			nWz,			nRadius );
	RecursiveTessellate( nWx + nRadius,			nWz + nRadius,	nRadius );
	}
	else
	{
	if(splitMetric < 1.0)
		splitMetric = 1.0;

	
	terrainMatrix[nNode] = splitMetric;				// Split Metric Value bound between 1.0 - 2.0
	}
	
	return;
}

 int MasterTerrain::ComputeRoughness(long nWx, long nWz, int qWidth)
{
	int qRad = qWidth >> 1;
	long node = nWx + qRad + (nWz + qRad) * width;


	

	if(qWidth < 3)
		return 0.1;					// minimum roughness value

	// These are the certain sides of the triangle fan

	int centerHeight = terrainData[node];
	int nwHeight = terrainData[nWx + nWz * width];
	int neHeight = terrainData[nWx + qWidth + nWz * width];
	int swHeight = terrainData[nWx + (nWz + qWidth) * width];
	int seHeight = terrainData[nWx + qWidth + (nWz + qWidth) * width];

	// Find the potential new points

	int nHeight = terrainData[nWx + qRad + nWz * width];
	int wHeight = terrainData[nWx + (nWz + qRad) * width];
	int sHeight = terrainData[nWx + qRad + (nWz + qWidth) * width];
	int eHeight = terrainData[nWx + qWidth + (nWz + qRad) * width];


	//Calculate the errors on each side with the new point

	int nError = abs(nHeight - ((nwHeight + neHeight) / 2));
	int wError = abs(wHeight - ((nwHeight + swHeight) / 2));
	int sError = abs(sHeight - ((swHeight + seHeight) / 2));
	int eError = abs(eHeight - ((seHeight + neHeight) / 2));
	int cError = abs(centerHeight - ((nwHeight + neHeight + seHeight + swHeight)>>2));

	int maxLocalError = 0;

	if(nError > maxLocalError)	maxLocalError = nError;
	if(wError > maxLocalError)	maxLocalError = wError;
	if(sError > maxLocalError)	maxLocalError = sError;
	if(eError > maxLocalError)	maxLocalError = eError;
	if(cError > maxLocalError)	maxLocalError = cError;

	int tempError;
	
	//NW Quad
	tempError = ComputeRoughness(nWx,nWz,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//SW Quad
	tempError = ComputeRoughness(nWx,nWz + qRad,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//NE Quad
	tempError = ComputeRoughness(nWx + qRad,nWz,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	//SE Quad
	tempError = ComputeRoughness(nWx + qRad,nWz + qRad,qRad);
	if(tempError > maxLocalError)	maxLocalError = tempError;

	roughMatrix[node] = maxLocalError;									// Roughness Info stored next to node depth info in Matrix

	return maxLocalError;


}


void MasterTerrain::Init()
{
	ComputeRoughness(0,0,quadWidth);
}

