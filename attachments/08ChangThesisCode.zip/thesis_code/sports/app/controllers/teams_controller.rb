class TeamsController < ApplicationController
	layout 'standard'	
	def index
		@teams = Team.find(:all)
	end

	def show
		@team = Team.find(params[:id])
		@players = Rosterspot.find_by_team_id(@team.id).player
		@games = Array.new
		GameTeam.find_all_by_team_id(@team.id).each { |gt|
			@games << Game.find_by_id(gt.game_id)
		}
	end
end

