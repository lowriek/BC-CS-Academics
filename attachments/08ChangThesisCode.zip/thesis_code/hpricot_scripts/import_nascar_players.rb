# import_nascar_players.rb

require 'rubygems'
require 'hpricot'

playerfile = 'nascar_players.list'

doc = Hpricot(open(playerfile))

name = (doc/'players/player').attr('name')
birthday = (doc/'players/player').attr('birthday')

@p = Player.find_by_name(name)
if (@p == nil)
	Player.create :name => name, :birthday => birthday
end
