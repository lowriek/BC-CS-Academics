function [S] = similarityMatrix(D)
%  function [S] = similarityMatrix(faceSpace,eigFaces,meanFace)
%   INPUT : 
%       D - Distance matrix received from distanceMatrix.m
%   OUTPUT:
%       S - D after it's pushed through a gaussian to distribute the data

sigma = std(D(:));
S=exp(-D.^2/(2*(sigma^2)));

        