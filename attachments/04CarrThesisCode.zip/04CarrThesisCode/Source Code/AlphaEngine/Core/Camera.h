#ifndef _CAMERA_H_
#define _CAMERA_H_

#include "AlphaEngine/Core/Frustum.h"
#include "AlphaEngine/Math/Vector3.h"

class CCamera
{
public:
	CCamera();
	virtual ~CCamera();

	CFrustum * getFrustum();

	CFrustum* pFrustum;

	void Look();
	void Render();
	void RotateView(float angle, float X, float Y, float Z);
	void Move(float distance);
	void Strafe(float distance);
	void Lift(float distance);

	void Update();

	CVector3 position;

	CVector3 view;
	CVector3 up;
	CVector3 strafe;
};



#endif