/* ----------------------------------------------
   -											-
   -	PROJECT:		Hourglass				-
   -	FILE:			matrix.cpp				-	
   -	CREATED:		07/20/01				-
   -	MODIFIED:		07/20/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */

#include "matrix.h"

Matrix4D::Matrix4D()
{
	a[0] = 1; a[1] = a[2] = a[3] = 0;
	a[4] = 0; a[5] = 1; a[6] = a[7] = 0;
	a[8] = a[9] = 0; a[10] = 1; a[11] = 0;
	a[12] = a[13] = a[14] = 0; a[15] = 1;
}

Matrix4D::Matrix4D(float a00, float a01, float a02, float a03,
			       float a10, float a11, float a12, float a13,
			       float a20, float a21, float a22, float a23)
{
	a[0] = a00; a[1] = a01; a[2] = a02; a[3] = a03;
	a[4] = a10; a[5] = a11; a[6] = a12; a[7] = a13;
	a[8] = a20; a[9] = a21; a[10] = a22; a[11] = a23;
	a[12] = a[13] = a[14] = 0; a[15] = 1; 
}

Matrix4D::Matrix4D(float a00, float a01, float a02, float a03,
			       float a10, float a11, float a12, float a13,
			       float a20, float a21, float a22, float a23,
				   float a30, float a31, float a32, float a33)
{
	a[0] = a00; a[1] = a01; a[2] = a02; a[3] = a03;
	a[4] = a10; a[5] = a11; a[6] = a12; a[7] = a13;
	a[8] = a20; a[9] = a21; a[10] = a22; a[11] = a23;
	a[12] = a30; a[13] = a31; a[14] = a32; a[15] = a33; 
}

Matrix4D::~Matrix4D()
{

}


Vector3D Matrix4D::operator *(const Vector3D & v) const
{
return (Vector3D( a[0] * v.x + a[1] * v.y + a[2] * v.z + a[3],
				 a[4] * v.x + a[5] * v.y + a[6] * v.z + a[7],
				 a[8] * v.x + a[9] * v.y + a[10] * v.z + a[1] ));
}


Matrix4D Matrix4D::operator *(const Matrix4D & m) const
{
return (Matrix4D(a[0] * m.a[0] + a[1] * m.a[4] + 
				 a[2] * m.a[8],
				 a[0] * m.a[1] + a[1] * m.a[5] + 
				 a[2] * m.a[9],
				 a[0] * m.a[2] + a[1] * m.a[6] + 
				 a[2] * m.a[10],
				 a[0] * m.a[3] + a[1] * m.a[7] + 
				 a[2] * m.a[11] + a[3],
				   a[4] * m.a[0] + a[5] * m.a[4] + 
				   a[6] * m.a[8],
				   a[4] * m.a[1] + a[5] * m.a[5] + 
				   a[6] * m.a[9],
				   a[4] * m.a[2] + a[5] * m.a[6] + 
				   a[6] * m.a[10],
				   a[4] * m.a[3] + a[5] * m.a[7] + 
				   a[6] * m.a[11] + a[7],	
				     a[8] * m.a[0] + a[9] * m.a[4] + 
				     a[10] * m.a[8],
					 a[8] * m.a[1] + a[9] * m.a[5] + 
					 a[10] * m.a[9],
					 a[8] * m.a[2] + a[9] * m.a[5] + 
					 a[10] * m.a[10],
					 a[8] * m.a[3] + a[9] * m.a[7] + 
					 a[10] * m.a[11] + a[11]));

}

Matrix4D Matrix4D::inverse(const Matrix4D &m) const
{
   float n00 = m.a[0];
   float n01 = m.a[1];
   float n02 = m.a[2];
   float x = m.a[3];
   float n10 = m.a[4];
   float n11 = m.a[5];
   float n12 = m.a[6];
   float y = m.a[7];
   float n20 = m.a[8];
   float n21 = m.a[9];
   float n22 = m.a[10];
   float z = m.a[11];
   float t = 1.0F / (n00 * (n11 * n22 - n12 * n21) -
      
   n01 * (n10 * n22 - n12 * n20) +
   n02 * (n10 * n21 - n11 * n20));
   return (Matrix4D(
					(n11 * n22 - n12 * n21) * t,
					(n02 * n21 - n01 * n22) * t,
					(n01 * n12 - n02 * n11) * t,
					((n12 * n21 - n11 * n22) * x +
					(n01 * n22 - n02 * n21) * y +
					(n02 * n11 - n01 * n12) * z) * t,
					(n12 * n20 - n10 * n22) * t,
					(n00 * n22 - n02 * n20) * t,
					(n02 * n10 - n00 * n12) * t,
					((n10 * n22 - n12 * n20) * x +
					(n02 * n20 - n00 * n22) * y +
					(n00 * n12 - n02 * n10) * z) * t,
					(n10 * n21 - n11 * n20) * t,
					(n01 * n20 - n00 * n21) * t,
					(n00 * n11 - n01 * n10) * t,
					((n11 * n20 - n10 * n21) * x +
					(n00 * n21 - n01 * n20) * y +
					(n01 * n10 - n00 * n11) * z) * t));

}

