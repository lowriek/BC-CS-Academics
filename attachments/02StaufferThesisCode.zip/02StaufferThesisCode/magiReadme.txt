Here is Everything

The file structure is such

/Data - Models and Images
/Sounds - Sound files
/	- Source Files

When executing program, choose to start up in window mode, fullscreen doesn't work yet


The controls are such

F1- Changes to fullscreen, do not use, as it doesn't work yet. 
F2- Look Up
F3 - Look Down
F4 - Change from Omnicient Viewer to Human View (It follows the path of the ground)
F5 - Toggle Time Forward an hour
F6 - Toggle Time Backward an hour

ToolBar controls- you can use the tool bar controls to:
1. toggle lighting and texturing
2. sound options dont work(sound is always on)
3. use the object creation wizard to add a new object
4. exit