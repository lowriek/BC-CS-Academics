#ifndef THREAD_H
#define	THREAD_H


#include <windows.h>
#include <iostream.h>

class	Thread
{

private:
	HANDLE	hnd;
	LPDWORD id;

public:
	Thread(LPSECURITY_ATTRIBUTES att, DWORD size, LPTHREAD_START_ROUTINE fn,
			LPVOID par, DWORD flags);
	~Thread();

};

class	Semaphore
{
private:
	bool	lock;
	HANDLE  mutex;
public:


Semaphore();
~Semaphore();
Lock();
Unlock();
bool State(){ return lock;};

};


#endif 