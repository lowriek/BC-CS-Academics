#ifndef	AVATAR_H
#define AVATAR_H

/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						AVATAR.H							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	DECEMBER 29, 2001					   --
   --														       --
   --		Notes:	Controls first person controls / view		   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "engine.h"


class Avatar : public Entity
{
	protected:

		MCamera * camera;
		float dec;
		float dir;
		bool  beginControl;
		TimeKeeper * localClock;

	public:
		Avatar(MCamera * cam, TimeKeeper * clk);
		void Draw();
		void Kill();
		float GetHeight(float xPos, float zPos);
		


};



#endif