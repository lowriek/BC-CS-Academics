function [colorfacemap] = colorFaceness(im,p2);
%INPUT
%   im - color image received directly from just imread
%

amin=-60;bmin=-60;
amax=80;bmax=80;
bins=45; sigma = 4;

h = fspecial('gaussian',31,3.5);
im = imfilter(im,h);


[m,n,dontcare] = size(im);
colorfacemap = zeros(m,n);
[L,a,b] = RGB2Lab(im);
for I=1:m
    for J=1:n
        aval = 1+floor(bins*(a(I,J)-(amin))/(amax-(amin)));
        bval = 1+floor(bins*(b(I,J)-(bmin))/(bmax-(bmin)));
        %aval = a(I,J); bval = b(I,J);
        %prob = sqrt((aval-11.5556)^2 + (bval - 8.4444)^2);
        prob = p2(aval,bval);
        colorfacemap(I,J) = prob;%exp(-prob.^2/(2*sigma^2));
    end
end
figure(1);imagesc(colorfacemap);axis image;truesize;title('Faceness of image based on color');