/*	parser.c
	John Weicher
	9-25-01
*/

#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "server.h"
#include "parser.h"
#include "string.h"
#include "error.h"
#include "tracer.h"

TCB *top;
TCB *current;
TCB *current2;


//parser flags
int IS_RAY_FILE=0;
int FILE_READ=0;
int IN_GLOBALS=0;
int IN_CAMERA=0;
int IN_OBJECT_DEFINITION=0;
int GLOBALS_SET=0;
int CAMERA_SET=0;
int OBJECT_TYPE=-1;
int LIGHT_SET=0;
int BLOCK_COMMENT=0;

/************************
   PARSEFILE ROUTINE
*************************/
void parseFile(char * fName)
{
	FILE * infile;
	checkName(fName);  //check that file is a ray-source file
	infile = openFile(fName);  //attempt to open the source file
	
	parseHeader(infile);
	buildScene(infile);
	
	//exit for debugging
	closeFile(infile);
	printf("Returning to raytracing module...\n\n"); 
}

/*************************
   BUILDSCENE ROUTINE
**************************/
void buildScene(FILE * theFile)
{
	int temp;
	char aLine[150];
	
	fgets(aLine, 150, theFile);
	currentLine++;
	
	temp=strlen(aLine);
	aLine[temp-1] = '\0';
	
	
	while(FILE_READ==0){
		
		processLine(aLine);
		if(FILE_READ==0){
			fgets(aLine, 150, theFile);
			currentLine++;
			temp=strlen(aLine);
			aLine[temp-1] = '\0';
		}
	}
	
	//automatically drops off the end of this function, when end of file has been read
	//returns to the ParseFile() function, which then executes the closeFile() function
	//to close the input file, and return control to the main tracing routines. 

		
}


/******************************************************************************************
   PROCESSLINE ROUTINE
******************************************************************************************/
void processLine(char * input)
{
	int i=0;
	//begin cases for possible file input
	

		
	while(input[i]==' ') i++;
	if(strlen(&input[i])==0 || (strlen(&input[i])>1 && input[i]=='/' && input[i+1]=='/' ))
		return;
	
	if(strcmp(input, "#comment")==0){
		BLOCK_COMMENT=1;
		return;
	}
	if(strcmp(input, "#endcomment")==0){
		BLOCK_COMMENT=0;
		return;
	}
		
	if(BLOCK_COMMENT)
		return;
	
	//if a file-header-tag is read
	if(strcmp(input, "[rayfile]")==0){
		if(IS_RAY_FILE==1) //inherently checks other violations with this one
			genError(MULTIPLE_FILE_HEADERS, NULL);
	}
	
	//if a file-end-tag is read
	if(strcmp(input, "[/rayfile]")==0){
		if(IN_GLOBALS==1)
			genError(PREMATURE_FILE_END, NULL);
		else if(GLOBALS_SET==0)
			genError(PREMATURE_FILE_END, NULL);
		else if(IN_OBJECT_DEFINITION==1)
			genError(PREMATURE_FILE_END, NULL);
		else
			FILE_READ=1;
			printf("Finished parsing file\n");
			printf("Total Objects Parsed (excluding Light Sources): %d\n\n", NUM_OBJECTS);
			return;
		
	}	
	
	//if an open-global-group tag is read
	if(strcmp(input, "[GLOBALS]")==0){
		if(GLOBALS_SET==1)
			genError(OBJECT_DEFINITION_EXPECTED, input);
		else if(IN_GLOBALS==1)
			genError(MULTIPLE_GLOBAL_TAGS, input);
		else if(IN_OBJECT_DEFINITION==1)
			genError(OBJECT_DEFINITION_EXPECTED, input);
		else
			IN_GLOBALS=1;
			printf("***** Parsing global parameters section *****\n");
			return;
	}
	
	//if a close-global-group tag is read
	if(strcmp(input, "[/GLOBALS]")==0){
		if(GLOBALS_SET==1)
			genError(OBJECT_DEFINITION_EXPECTED, input);
		else if(IN_GLOBALS==0)
			genError(GLOBAL_DEFINITION_EXPECTED, input);
		else if(IN_OBJECT_DEFINITION==1)
			genError(OBJECT_DEFINITION_EXPECTED, input);
		else{
			IN_GLOBALS=0;
			GLOBALS_SET=1;
			printf("***** Finished parsing global parameters *****\n\n");
			return;
		}
	}
			
	//if an object-definition tag is read	
	if(strcmp(input, "[OBJECT]")==0){
		if(IN_GLOBALS==1)
			genError(GLOBAL_DEFINITION_EXPECTED, input);
		if(IN_OBJECT_DEFINITION==1)
			genError(NESTED_OBJECT_DEFINITION, NULL);
		else
			IN_OBJECT_DEFINITION=1;
			printf("-----  In object definition   -----\n");
			return;
	}	

	//if a close-object-definition tag is read
	if(strcmp(input, "[/OBJECT]")==0){
		if(IN_GLOBALS==1)
			genError(GLOBAL_DEFINITION_EXPECTED, input);
		if(OBJECT_TYPE==-1)
			genError(EMPTY_OBJECT_DEFINITION, NULL);
		if(IN_OBJECT_DEFINITION==1){
			IN_OBJECT_DEFINITION=0;
			
			if(OBJECT_TYPE==0)
				LIGHT_SET=1;
			OBJECT_TYPE=-1;
			
			printf("----- Finished parsing object -----\n\n");
			return;
		}
	}
	

	//All other reads will be treated as object attributes
	//Must not be a tag to get this far
	processAttribute(input);


}


/******************************************************************************************
   PROCESSATTRIBUTE ROUTINE
******************************************************************************************/
void processAttribute(char * input){
	char attrib[50], val[50], ch;
	int i=0,j=0, iValue, eCode;
	float fValue;
	
	while(input[i]==' ') i++;										//advance past leading white spaces before attribute keyword
	
	while( (input[i] != ' ') && (input[i] != '=') && i<49)			//extract attribute keyword character by character
		attrib[j++] = input[i++];
	attrib[j]='\0';													//add string terminator manually
	
	while(input[i]==' ' || input[i]=='=') i++;						//move past white spaces before value
	
	j=0;
	while( (input[i] != '\n') && (input[i] != '\0') && i<49)		//extract value portion of line character by character
		val[j++] = input[i++];
	val[j]='\0';													//add string terminator manually

	if(IN_GLOBALS==1) 												//expecting a global attribute
		setGlobalAttribute(attrib, val);
	else if(strcmp(attrib, "type")==0){    							//must be in a object definition 
		if(OBJECT_TYPE!=-1)											//make sure current object type hasn't already been defined
			genError(OBJECT_TYPE_ALREADY_DEFINED, NULL);			//if so, throw an error
		if(strcmp(val, "light")==0)
			generateLightObject();									//call function to generate light source for scene
		else if(strcmp(val, "sphere")==0)
			generateSphereObject();									//call function to generate an empty sphere object and TCB
		else if(strcmp(val, "plane")==0)
			generatePlaneObject();									//call function to generate an empty plane object and TCB
		else
			genError(INVALID_OBJECT_TYPE, val);						//if attribute was 'type', but unknown type value, throw an error
	}
	else 
		setObjectAttribute(attrib, val);							//if not in globals section, and not a 'type' statement,
																	//  then it must be an object attribute.  This will also 
																	//  catch any invalid attributes, or stray lines outside
}																	//  of the globals section.


/******************************************************************************************
   PARSEHEADER ROUTINE
******************************************************************************************/
void parseHeader(FILE * theFile)									//This function is reponsible for parsing the first line from
{																	//  the input file, and making sure that it is indeed a 
	int temp;														//	scene source file.  It checks to ensure that the first
	char aLine[150];												//  line of the file is [rayfile] header tag.
	
	fgets(aLine, 150,theFile);										//Read first line from the file
	currentLine++;
	
	temp = strlen(aLine);					
	aLine[temp-1]='\0';												//Write a string terminator over the trailing '\n' of the line
	if(strcmp("[rayfile]",aLine)!=0)								//Check to ensure its the [rayfile] tag.
		genError(IMPROPER_FILE_HEADER, aLine);						//If not, throw an error
	
	IS_RAY_FILE=1;													//Otherwise, set parse success flag
	printf("\nFile opened successfully...\n\n");
}

/******************************************************************************************
   OPENFILE ROUTINE
******************************************************************************************/
FILE * openFile(char * fName)										//This function attempts to open the specified input file.
{
	FILE * temp;
	temp = fopen(fName, "r");										//Attempt to open the file
	if(temp==NULL)
		genError(FILE_NOT_FOUND, fName);							//If there is a problem opening(or finding) the file, throw and
	return temp;													//  error, otherwise return the file pointer to the open file.	
}

/******************************************************************************************
   CHECKNAME ROUTINE
******************************************************************************************/
void checkName(char * name)
{
	int sLen;
	char ext[4];

	sLen = strlen(name);
	strcpy(ext, &(name[sLen-4]));
	if(strcmp(ext,".ray")!=0)
		genError(INVALID_SOURCE_FILE, name);
}	

/******************************************************************************************
   CLOSEFILE ROUTINE
******************************************************************************************/
void closeFile(FILE * theFile)
{
	int err;
	err = fclose(theFile);
	if(err!=0)
		genError(IMPROPER_FILE_CLOSING, NULL);
}

/******************************************************************************************
   TRIMSTRING ROUTINE
******************************************************************************************/
char * trimString(char input[150])
{
	int i=0;
	char * output;
	
	output = (char*) malloc(sizeof(input));
	//skip past preceding spaces in the string
	while(input[i]==' ')
		i++;
	//copy input to new string
	strcpy(output, &(input[i]));
	
	//move marker to '\0' at end
	i = strlen(output);
	
	//move marker back until it hits a non-space character
	while(output[i-1]==' ')
		i--;
		
	//if necessary move '\0' in to new spot	
	output[i] = '\0';
	
	return output;
}

/******************************************************************************************
   SETGLOBALATTRIBUTE ROUTINE
******************************************************************************************/
void setGlobalAttribute(char attrib[50], char val[50])
{
	int eCode;
	long int iValue;
	double dValue;
	float fValue;
	
	
	if(strcmp(attrib, "ambient")==0){
		fValue = atof(val);
		AMBIENT = fValue;
		printf("GLOBAL PARAM:  Ambient lighting set to %f\n", AMBIENT);
	}
	else if(strcmp(attrib, "shadowfactor")==0){
		fValue=atof(val);
		if(fValue > 1.0) fValue = 1.0;
		if(fValue < 0.0) fValue = 0.0;
		SHADOW_FACTOR = fValue;
		printf("GLOBAL PARAM:  Shadow factor set to %f\n", SHADOW_FACTOR);
	}
	else if(strcmp(attrib, "shadows")==0){
		iValue = strtol(val, NULL,10);
		if(iValue > 0) CAST_SHADOWS=1;
		else CAST_SHADOWS=0;
		printf("GLOBAL PARAM:  Shadow-casting=");
		if(CAST_SHADOWS==0) printf("off\n");
		else printf("on\n");
			
	}
	else if(strcmp(attrib, "antialias")==0){
		iValue=strtol(val, NULL, 10);
		if(iValue>0) ANTI_ALIAS=1;
		else ANTI_ALIAS=0;
		printf("GLOBAL_PARAM:  Anti-Aliasing:");
		if(ANTI_ALIAS==0) printf(" Off\n");
		else printf(" On\n");
	}
	else if(strcmp(attrib, "fog")==0){
		iValue = strtol(val, NULL,10);
		if(iValue>0)  ENABLE_FOG=1;
		else ENABLE_FOG=0;
		printf("GLOBAL PARAM:  Fogging=");
		if(ENABLE_FOG==0) printf("off\n");
		else printf("on\n");
	}

	else if(strcmp(attrib, "fog_min_dist")==0){
		fValue = atof(val);
		fog_min_dist = fValue;
		printf("GLOBAL PARAM:  Fog Minimum Distance set to %f\n", fog_min_dist);
	}
	else if(strcmp(attrib, "fog_max_dist")==0){
		fValue = atof(val);
		fog_max_dist = fValue;
		printf("GLOBAL PARAM:  Fog Maximum Distance set to %f\n", fog_max_dist);
	}

	else if(strcmp(attrib, "fog.r")==0){
		fValue = atof(val);
		fog_color.r = fValue;
		printf("GLOBAL PARAM:  Fog Color Red component set to %f\n", fog_color.r);
	}

	else if(strcmp(attrib, "fog.g")==0){
		fValue = atof(val);
		fog_color.g = fValue;
		printf("GLOBAL PARAM:  Fog Color Green component set to %f\n", fog_color.g);
	}

	else if(strcmp(attrib, "fog.b")==0){
		fValue = atof(val);
		fog_color.b = fValue;
		printf("GLOBAL PARAM:  Fog Color Blue component set to %f\n", fog_color.b);
	}
	else if(strcmp(attrib, "fog_color")==0){
		float r,g,b;
		eCode=extractThreeComponents(val, &r, &g, &b);
		if(eCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			fog_color.r = r;  fog_color.g = g;  fog_color.b = b;
			if(fog_color.r > 1.0) fog_color.r = 1.0;
			if(fog_color.r < 0.0) fog_color.r = 0.0;
			if(fog_color.g > 1.0) fog_color.g = 1.0;
			if(fog_color.g < 0.0) fog_color.g = 0.0;
			if(fog_color.b > 1.0) fog_color.b = 1.0;
			if(fog_color.b < 0.0) fog_color.b = 0.0;		
			printf("GLOBAL PARAM:  Fog Color set to <%f, %f, %f>\n", fog_color.r, fog_color.g, fog_color.b);
		}
	}
	else if(strcmp(attrib, "shadow_factor")==0){
		fValue = atof(val);	
		if(fValue < 0.0) fValue = 0.0;
		if(fValue > 1.0) fValue = 1.0;
		SHADOW_FACTOR=fValue;
		printf("GLOBAL PARAM:  Shadow factor set to %f\n", SHADOW_FACTOR);
	}
	else
		genError(INVALID_GLOBAL_ATTRIBUTE, attrib);
	
}

/******************************************************************************************
   GENERATEPLANEOBJECT ROUTINE  (right now, this function is very small, but in the future
   									it will be more substantial as support for multiple
   									light sources is added)
******************************************************************************************/
void generateLightObject(){

	OBJECT_TYPE=0;
}

/******************************************************************************************
   GENERATESPHEREOBJECT ROUTINE
******************************************************************************************/
void generateSphereObject(){

	OBJECT_TYPE=1;
	TCB* newTCB;
	
	newTCB = (TCB *) malloc(sizeof(struct TCB));						//Generate a new TCB pointer to add to the linked list

	newTCB->obj = (Tracer *) new Sphere();								//Generate an new Sphere object pointed to by this TCB
												
	if(NUM_OBJECTS==0){													//If this is the first object, make top point to this
		NUM_OBJECTS++;													//   new TCB, and set its next to NULL
		top = newTCB;
		top->next=NULL;
	}
	else{																//If this is not the first object, add him to the front
		NUM_OBJECTS++;													//   of the list, and make it the new top
		newTCB->next = top;
		top = newTCB;
	}
	
	printf("Sphere object created\n");
	
}


/******************************************************************************************
   GENERATEPLANEOBJECT ROUTINE
******************************************************************************************/
void generatePlaneObject(){

	OBJECT_TYPE=2;
	TCB* newTCB;
	
	newTCB = (TCB *) malloc(sizeof(struct TCB));						//Generate a new TCB pointer to add to the linked list
	
	newTCB->obj = (Tracer *) new Plane();								//Generate a new Plane object pointed to by this TCB
		
	if(NUM_OBJECTS==0){													//If this is the first object, make top point to this
		NUM_OBJECTS++;													//   new TCB, and set its next to NULL;
		top = newTCB;
		top->next = NULL;
	}
	else{
		NUM_OBJECTS++;													//If this is not the first object, add him to the front
		newTCB->next = top;												//   of the list, and make it the new top
		top = newTCB;
	}

	printf("Plane object created\n");
}



/******************************************************************************************
   SETOBJECTATTRIBUTE ROUTINE
******************************************************************************************/
void setObjectAttribute(char attrib[50], char val[50]){
	
	if(OBJECT_TYPE==0)
		setLightSourceAttribute(attrib, val);
	else if(OBJECT_TYPE==1)
		setSphereAttribute(attrib, val);
	else if(OBJECT_TYPE==2)
		setPlaneAttribute(attrib, val);
}

/******************************************************************************************
   SETLIGHTSOURCEATTRIBUTE ROUTINE
******************************************************************************************/
void setLightSourceAttribute(char attrib[50], char val[50]){
	int errCode;
	
	if(strcmp(attrib, "location")==0){
		float x,y,z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			light.x = x;  light.y = y; light.z = z;
			printf("Light Source location set to <%f, %f, %f>\n", light.x, light.y, light.z);
		}
	}
	else if(strcmp(attrib, "color")==0){
		float r,g,b;
		errCode = extractThreeComponents(val, &r, &g, &b);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			light_color.r = r; light_color.g = g; light_color.b = b;
			if(light_color.r > 1.0) light_color.r = 1.0;
			if(light_color.r < 0.0) light_color.r = 0.0;
			if(light_color.g > 1.0) light_color.g = 1.0;
			if(light_color.g < 0.0) light_color.g = 0.0;
			if(light_color.b > 1.0) light_color.b = 1.0;
			if(light_color.b < 0.0) light_color.b = 0.0;
			printf("Light Source color set to <%f, %f, %f>\n", light_color.r, light_color.g, light_color.b);
		}
	}
	else
		genError(INVALID_LIGHT_SOURCE_ATTRIBUTE, attrib);
		
		
}


/******************************************************************************************
   SETSPHEREATTRIBUTE ROUTINE
******************************************************************************************/
void setSphereAttribute(char attrib[50], char val[50]){
	int errCode, iValue;
	float fValue;
	double dValue;
	
	if(strcmp(attrib, "world_rotation")==0){													/* Set Sphere's world Rotation Matrix */
		float x,y,z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setWorldRotationMatrix(temp);
			printf("  - World Rotation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "object_rotation")==0){												/* Set Sphere's object rotation matrix */
		float x,y,z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setObjectRotationMatrix(temp);
			printf("  - Object Rotation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "translation")==0){													/* Set Sphere's translation matrix */
		float x, y, z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setTranslationMatrix(temp);
			printf("  - Translation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "scale")==0){														/* Set sphere's scale matrix */
		float x, y, z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setScaleMatrix(temp);
			printf("  - Scale set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
		
		
	else if(strcmp(attrib, "center")==0){														/* Set Sphere's center */
		float x, y, z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x = x; temp.y = y; temp.z = z;
			((Sphere *)(top->obj))->setCenter(temp);
			temp = ((Sphere *)(top->obj))->getCenter();
			printf("  - Center set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	else if(strcmp(attrib, "radius")==0){														/* Set Sphere's Radius */
		dValue = strtod(val, (char**)NULL);
		if(dValue<=0.0) genError(INVALID_ATTRIBUTE_VALUE, val);
		((Sphere *)(top->obj))->setRadius(dValue);
		dValue = ((Sphere *)(top->obj))->getRadius();
		printf("  - Radius set to %f\n", dValue);
	}
	else if(strcmp(attrib, "color1")==0){														/* Set Sphere's primary color */
		float r,g,b;
		errCode=extractThreeComponents(val, &r, &g, &b);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			color temp;
			temp.r = r;  temp.g = g;  temp.b = b;
			if(temp.r > 1.0) temp.r = 1.0;
			if(temp.r < 0.0) temp.r = 0.0;
			if(temp.g > 1.0) temp.g = 1.0;
			if(temp.g < 0.0) temp.g = 0.0;
			if(temp.b > 1.0) temp.b = 1.0;
			if(temp.b < 0.0) temp.b = 0.0;
			top->obj->setColor1(temp);
			temp = top->obj->getColor1();
			printf("  - Color1 set to <%f, %f, %f>\n", temp.r, temp.g, temp.b);
		}
	}
	else if(strcmp(attrib, "color2")==0){														/* Set Sphere's secondary color */
		float r,g,b;
		errCode=extractThreeComponents(val, &r, &g, &b);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			color temp;
			temp.r = r;  temp.g = g;  temp.b = b;
			if(temp.r > 1.0) temp.r = 1.0;
			if(temp.r < 0.0) temp.r = 0.0;
			if(temp.g > 1.0) temp.g = 1.0;
			if(temp.g < 0.0) temp.g = 0.0;
			if(temp.b > 1.0) temp.b = 1.0;
			if(temp.b < 0.0) temp.b = 0.0;
			top->obj->setColor2(temp);
			temp = top->obj->getColor2();
			printf("  - Color2 set to <%f, %f, %f>\n", temp.r, temp.g, temp.b);
		}
	}
	else if(strcmp(attrib, "mirror1")==0){														/* Set Sphere's primary mirror value */
		iValue = atoi(val);
		if(iValue != 1 && iValue !=0)
			genError(INVALID_ATTRIBUTE_VALUE, val);
		fValue = 1.0;
		top->obj->setMirror1(iValue);
		top->obj->setReflectAmt1(fValue);
		iValue = top->obj->getMirror1();
		printf("  - Mirror1 set to %d\n", iValue);
	}
	else if(strcmp(attrib, "mirror2")==0){														/* Set Sphere's secondary mirror value */
		iValue = atoi(val);
		if(iValue != 1 && iValue !=0)
			genError(INVALID_ATTRIBUTE_VALUE, val);
		fValue=1.0;
		top->obj->setMirror2(iValue);
		top->obj->setReflectAmt2(fValue);
		iValue = top->obj->getMirror2();
		printf("  - Mirror2 set to %d\n", iValue);		
	}		
	else if(strcmp(attrib, "reflection1")==0){													/* Set Sphere's reflection factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setReflectAmt1(fValue);
		top->obj->setMirror1(1);
		fValue = top->obj->getReflectAmt1();
		printf("  - Reflection Amount set to %f\n", fValue);
		printf("  - Mirror1 automatically set to 1\n");
	}
	else if(strcmp(attrib, "reflection2")==0){													/* Set Sphere's reflection factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setReflectAmt2(fValue);
		top->obj->setMirror2(1);
		fValue = top->obj->getReflectAmt2();
		printf("  - Reflection Amount set to %f\n", fValue);
		printf("  - Mirror1 automatically set to 1\n");
	}	
	
	else if(strcmp(attrib, "refraction1")==0){													/* Set Sphere's refraction factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setRefractIndex1(fValue);
		fValue = top->obj->getRefractIndex1();
		printf("  - Refraction Index set to %f\n", fValue);
	}
	else if(strcmp(attrib, "refraction2")==0){													/* Set Sphere's refraction factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setRefractIndex2(fValue);
		fValue = top->obj->getRefractIndex2();
		printf("  - Refraction Index set to %f\n", fValue);
	}	
	
	else if(strcmp(attrib, "transparency1")==0){													/* Set Sphere's transparenct factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setTransAmt1(fValue);
		fValue = top->obj->getTransAmt1();
		printf("  - Transparency Amount set to %f\n", fValue);
	}
	else if(strcmp(attrib, "transparency2")==0){													/* Set Sphere's transparenct factor */
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setTransAmt2(fValue);
		fValue = top->obj->getTransAmt2();
		printf("  - Transparency Amount set to %f\n", fValue);
	}	
	
	else if(strcmp(attrib, "horizontalchecks")==0){												/* Set Sphere's horizontal checks */
		iValue = atoi(val);
		if(iValue < 1)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setHorizontalChecks(iValue);
		printf("  - Horizontal Checks set to %d\n", top->obj->getHorizontalChecks());
	}
	else if(strcmp(attrib, "verticalchecks")==0){												/* Set Sphere's vertical checks */
		iValue = atoi(val);
		if(iValue<1)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setVerticalChecks(iValue);
		printf("  - Vertical Checks set to %d \n", top->obj->getVerticalChecks());
	}
	// ADD CASE FOR TEXTURE INBETWEEN HERE
	else
		genError(INVALID_OBJECT_ATTRIBUTE, attrib);
	

}


/******************************************************************************************
   SETPLANEATTRIBUTE ROUTINE
******************************************************************************************/
void setPlaneAttribute(char attrib[50], char val[50]){
int errCode, iValue;
	float fValue;
	double dValue;
	
	if(strcmp(attrib, "location")==0){
		float x,y,z,d;
		errCode=extractFourComponents(val, &x, &y, &z, &d);
		if(errCode==1)
			genError(ERROR_EXTRACTING_FOUR_VALUES, NULL);
		else{
			point3d temp;
			temp.x = x;  temp.y = y; temp.z = z;
			((Plane *)(top->obj))->setLocation(temp);
			((Plane *)(top->obj))->setD(d);
			d = ((Plane *)(top->obj))->getD();
			temp = ((Plane *)(top->obj))->getLocation();
			printf("  - Oriented according to <%f, %f, %f, %f>\n", temp.x, temp.y, temp.z, d);
		}
	}
	
	else if(strcmp(attrib, "world_rotation")==0){													/* Set plane's world Rotation Matrix */
		float x,y,z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setWorldRotationMatrix(temp);
			printf("  - World Rotation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "object_rotation")==0){												/* Set plane's object rotation matrix */
		float x,y,z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setObjectRotationMatrix(temp);
			printf("  - Object Rotation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "translation")==0){													/* Set plane's translation matrix */
		float x, y, z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setTranslationMatrix(temp);
			printf("  - Translation set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}
	
	else if(strcmp(attrib, "scale")==0){														/* Set planes's scale matrix */
		float x, y, z;
		errCode=extractThreeComponents(val, &x, &y, &z);
		x=y=z=1.0;																				/* Automatically override */
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x=x; temp.y=y; temp.z=z;
			top->obj->setScaleMatrix(temp);
			printf("  - Scale set to <%f, %f, %f>\n", temp.x, temp.y, temp.z);
		}
	}	
	
	else if(strcmp(attrib, "scoordvector")==0){
		float x,y,z;
		errCode = extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x = x; temp.y = y; temp.z = z;
			((Plane *)(top->obj))->setSCoordVector(temp);
			avector tempv = ((Plane *)(top->obj))->getSCoordVector();
			printf("  - Generating Texture S-Coords using <%f, %f, %f>\n", tempv.x, tempv.y, tempv.z);
		}
	}
	else if(strcmp(attrib, "tcoordvector")==0){
		float x,y,z;
		errCode = extractThreeComponents(val, &x, &y, &z);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			point3d temp;
			temp.x = x; temp.y = y; temp.z = z;
			((Plane *)(top->obj))->setTCoordVector(temp);
			avector tempv = ((Plane *)(top->obj))->getTCoordVector();
			printf("  - Generating Texture T-Coords using <%f, %f, %f>\n", tempv.x, tempv.y, tempv.z);
		}
	}	
	else if(strcmp(attrib, "color1")==0){
		float r,g,b;
		errCode=extractThreeComponents(val, &r, &g, &b);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			color temp;
			temp.r = r;  temp.g = g;  temp.b = b;
			if(temp.r > 1.0) temp.r = 1.0;
			if(temp.r < 0.0) temp.r = 0.0;
			if(temp.g > 1.0) temp.g = 1.0;
			if(temp.g < 0.0) temp.g = 0.0;
			if(temp.b > 1.0) temp.b = 1.0;
			if(temp.b < 0.0) temp.b = 0.0;
			top->obj->setColor1(temp);
			temp = top->obj->getColor1();
			printf("  - Color1 set to <%f, %f, %f>\n", temp.r, temp.g, temp.b);
		}
	}
	else if(strcmp(attrib, "color2")==0){
		float r,g,b;
		errCode=extractThreeComponents(val, &r, &g, &b);
		if(errCode==1)
			genError(ERROR_EXTRACTING_THREE_VALUES, NULL);
		else{
			color temp;
			temp.r = r;  temp.g = g;  temp.b = b;
			if(temp.r > 1.0) temp.r = 1.0;
			if(temp.r < 0.0) temp.r = 0.0;
			if(temp.g > 1.0) temp.g = 1.0;
			if(temp.g < 0.0) temp.g = 0.0;
			if(temp.b > 1.0) temp.b = 1.0;
			if(temp.b < 0.0) temp.b = 0.0;
			top->obj->setColor2(temp);
			temp = top->obj->getColor2();
			printf("  - Color2 set to <%f, %f, %f>\n", temp.r, temp.g, temp.b);
		}
	}
	else if(strcmp(attrib, "mirror1")==0){
		iValue = atoi(val);
		if(iValue != 1 && iValue !=0)
			genError(INVALID_ATTRIBUTE_VALUE, val);
		fValue=1.0;
		top->obj->setMirror1(iValue);
		top->obj->setReflectAmt1(fValue);
		iValue = top->obj->getMirror1();
		printf("  - Mirror1 set to %d\n", iValue);
	}
	else if(strcmp(attrib, "mirror2")==0){
		iValue = atoi(val);
		if(iValue != 1 && iValue !=0)
			genError(INVALID_ATTRIBUTE_VALUE, val);
		fValue=1.0;
		top->obj->setReflectAmt2(fValue);
		top->obj->setMirror2(iValue);
		iValue = top->obj->getMirror2();
		printf("  - Mirror2 set to %d\n", iValue);
	}		
	else if(strcmp(attrib, "reflection1")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setReflectAmt1(fValue);
		top->obj->setMirror1(1);
		fValue = top->obj->getReflectAmt1();
		printf("  - Reflection Amount set to %f\n", fValue);
		printf("  - Mirror1 automatically set to 1\n");
	}
	else if(strcmp(attrib, "reflection2")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setReflectAmt2(fValue);
		top->obj->setMirror2(1);
		fValue = top->obj->getReflectAmt2();
		printf("  - Reflection Amount set to %f\n", fValue);
		printf("  - Mirror1 automatically set to 1\n");
	}	
	
	
	else if(strcmp(attrib, "refraction1")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setRefractIndex1(fValue);
		fValue = top->obj->getRefractIndex1();
		printf("  - Refraction Index set to %f\n", fValue);
	}
	else if(strcmp(attrib, "refraction2")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setRefractIndex2(fValue);
		fValue = top->obj->getRefractIndex2();
		printf("  - Refraction Index set to %f\n", fValue);
	}	
	
	else if(strcmp(attrib, "transparency1")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setTransAmt1(fValue);
		fValue = top->obj->getTransAmt1();
		printf("  - Transparency Amount set to %f\n", fValue);
	}
	
	else if(strcmp(attrib, "transparency2")==0){
		fValue = atof(val);
		if(fValue <0.0 || fValue > 1.0)
			genError(INVALID_ATTRIBUTE_VALUE, NULL);
		top->obj->setTransAmt2(fValue);
		fValue = top->obj->getTransAmt2();
		printf("  - Transparency Amount set to %f\n", fValue);
	}	
	
	// ADD CASE FOR TEXTURE INBETWEEN HERE
	else
		genError(INVALID_OBJECT_ATTRIBUTE, attrib);
	

}



/******************************************************************************************
   VARIOUS EXTRACTION ROUTINES
******************************************************************************************/
int extractThreeComponents(char input[50], int *comp1, int *comp2, int *comp3){
	int i=0,j=0, len, eCode=0;
	char temp[20];
	
	if(input[0] != '<')													//Check that it starts with the proper format
		return 1;														//If not, throw an error
	
	while(input[i] == '<' || input[i] == ' ') i++;						//Move past leading '<' and whitespaces
	
																		//Extract first component
	while(input[i] != ',' && input[i] != '\0')  						//Second check just in case
		temp[j++] = input[i++];
	
																		//For first component, check that is all digits or
	len = j;															// .'s, if so, convert
	for(j=0; j<len; j++)												//Check each character
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//Must be a numeric digit or '.'
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
		*comp1 = atoi(temp);
	}																	//Store Converted value into variable	
	else
		return 1;														//If invalid value, return error code							

	while(input[i] == ',' || input[i] == ' ') i++;						//Move to start of next component
	j=0;
	
	while(input[i] != ',' && input[i] != '\0')							//Extract second component
		temp[j++] = input[i++];
	
	len=j;
	for(j=0; j<len; j++)												//For second component, check that it is all digits of
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//  .'s, if so, convert
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
	 	*comp2 = atoi(temp);											//Store converted value into variable
	}
	else
		return 1;														//If invalid return error code
	 
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != '>' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract third component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For third component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp3 = atoi(temp);											//Store converted value into variable
	}
	else
		return 1;
		
	return eCode;


}



int extractThreeComponents(char input[50], float *comp1, float *comp2, float *comp3){
	int i=0,j=0, len, eCode=0;
	char temp[20];
	
	if(input[0] != '<')													//Check that it starts with the proper format
		return 1;														//If not, throw an error
	
	while(input[i] == '<' || input[i] == ' ') i++;						//Move past leading '<' and whitespaces
	
																		//Extract first component
	while(input[i] != ',' && input[i] != '\0')  						//Second check just in case
		temp[j++] = input[i++];
	
																		//For first component, check that is all digits or
	len = j;															// .'s, if so, convert
	for(j=0; j<len; j++)												//Check each character
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//Must be a numeric digit or '.'
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
		*comp1 = atof(temp);
	}																	//Store Converted value into variable	
	else
		return 1;														//If invalid value, return error code							

	while(input[i] == ',' || input[i] == ' ') i++;						//Move to start of next component
	j=0;
	
	while(input[i] != ',' && input[i] != '\0')							//Extract second component
		temp[j++] = input[i++];
	
	len=j;
	for(j=0; j<len; j++)												//For second component, check that it is all digits of
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//  .'s, if so, convert
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
	 	*comp2 = atof(temp);											//Store converted value into variable
	}
	else
		return 1;														//If invalid return error code
	 
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != '>' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract third component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For third component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp3 = atof(temp);											//Store converted value into variable
	}
	else
		return 1;
		
	return eCode;




}

//Not really needed as of yet...
int extractFourComponents(char input[50], int *comp1, int *comp2, int *comp3, int * comp4){
	int i=0,j=0, len, eCode=0;
	char temp[20];
	
	if(input[0] != '<')													//Check that it starts with the proper format
		return 1;														//If not, throw an error
	
	while(input[i] == '<' || input[i] == ' ') i++;						//Move past leading '<' and whitespaces
	
																		//Extract first component
	while(input[i] != ',' && input[i] != '\0')  						//Second check just in case
		temp[j++] = input[i++];
	
																		//For first component, check that is all digits or
	len = j;															// .'s, if so, convert
	for(j=0; j<len; j++)												//Check each character
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//Must be a numeric digit or '.'
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
		*comp1 = atoi(temp);
	}																	//Store Converted value into variable	
	else
		return 1;														//If invalid value, return error code							

	while(input[i] == ',' || input[i] == ' ') i++;						//Move to start of next component
	j=0;
	
	while(input[i] != ',' && input[i] != '\0')							//Extract second component
		temp[j++] = input[i++];
	
	len=j;
	for(j=0; j<len; j++)												//For second component, check that it is all digits of
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//  .'s, if so, convert
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
	 	*comp2 = atoi(temp);											//Store converted value into variable
	}
	else
		return 1;														//If invalid return error code
	 
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != ',' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract third component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For third component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp3 = atoi(temp);											//Store converted value into variable
	}
	else
		return 1;
		
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != '>' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract fourth component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For fourth component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp4 = atoi(temp);											//Store converted value into variable
	}
	else
		return 1;


		
	return eCode;

}



int extractFourComponents(char input[50], float *comp1, float *comp2, float *comp3, float *comp4){
	int i=0,j=0, len, eCode=0;
	char temp[20];
	
	if(input[0] != '<')													//Check that it starts with the proper format
		return 1;														//If not, throw an error
	
	while(input[i] == '<' || input[i] == ' ') i++;						//Move past leading '<' and whitespaces
	
																		//Extract first component
	while(input[i] != ',' && input[i] != '\0')  						//Second check just in case
		temp[j++] = input[i++];
	
																		//For first component, check that is all digits or
	len = j;															// .'s, if so, convert
	for(j=0; j<len; j++)												//Check each character
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//Must be a numeric digit or '.'
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
		*comp1 = atof(temp);
	}																	//Store Converted value into variable	
	else
		return 1;														//If invalid value, return error code							

	while(input[i] == ',' || input[i] == ' ') i++;						//Move to start of next component
	j=0;
	
	while(input[i] != ',' && input[i] != '\0')							//Extract second component
		temp[j++] = input[i++];
	
	len=j;
	for(j=0; j<len; j++)												//For second component, check that it is all digits of
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//  .'s, if so, convert
	if(eCode==0){
		temp[len] = '\0';												//Add string terminator
	 	*comp2 = atof(temp);											//Store converted value into variable
	}
	else
		return 1;														//If invalid return error code
	 
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != ',' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract third component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For third component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp3 = atof(temp);											//Store converted value into variable
	}
	else
		return 1;
		
	while(input[i] == ',' || input[i] ==' ') i++;						//Move to start of next component
	j=0;
	 
	while(input[i] != '>' && input[i] != '\0')
		temp[j++] = input[i++];											//Extract fourth component
	 	
	len=j;
	for(j=0; j<len; j++)
		if(isdigit(temp[j])==0 && temp[j] != '.' && temp[j] !='-') eCode=1;				//For fourth component, check that is all digits, or .'s	
	if(eCode==0){ 		
		temp[len] = '\0';												//Add string terminator
		*comp4 = atof(temp);											//Store converted value into variable
	}
	else
		return 1;


		
	return eCode;

}

