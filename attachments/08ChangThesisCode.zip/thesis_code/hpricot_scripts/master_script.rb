# master script

# loop forever
# 1. sleep
# 2. get/remove current_day from new_day list, add to old_day.list
# 3. 	process current_day
#	=> get previous, next day urls, add to new-day.list if new
# 4. 

begin
  newdayfn = 'new_day.list'
  olddayfn = 'old_day.list'
  newgamefn = 'new_game.list'
  oldgamefn = 'old_game.list'
  newplayerfn = "new_player.list"
  oldplayerfn = "old_player.list"
  
  iterations = 0;
  while (true)
    # sleep
    iterations+=1
    puts iterations.to_s+". sleeping for 5 seconds"
    sleep 5 # 5 seconds

    # new day, also run games_script
    newdayf = File.open(newdayfn,"r+")
    if(line = newdayf.readline)
      	newdayurl = line.chomp
      	newdayf.close
      	# process day, get more days
	system("ruby day_script.rb "+newdayurl)

        # process day by getting game urls
  	system("ruby games_script.rb "+"/nba/scoreboard"+newdayurl)
    end
	puts "past new day"

    # new game
    # gets the statistics from this game
    newgamef = File.open(newgamefn,"r+")
    if(line = newgamef.readline)
        newgameurl = line.chomp
 	newgamef.close
	system("ruby basketball_stat_script.rb "+newgameurl)
    end
	puts "past new game"

=begin
    #  new player
    newplayerf = File.open(newplayerfn,"r+")
    if(line = newplayerf.readline)
        newplayerurl = line.chomp
	newplayerf.close

	#process player
        system("ruby basketball_player_script.rb "+newplayerurl)
	
	# run this in separate script, first collect all urls of players,
	# adding them to new list.  then process one by one until done.
	# run this separate script periodically to add new players
    end
=end

  end
rescue EOFError
  puts "error in master"
end
