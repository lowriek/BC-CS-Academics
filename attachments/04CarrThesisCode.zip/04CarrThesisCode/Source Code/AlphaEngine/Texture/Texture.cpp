// Texture.cpp: implementation of the CTexture class.
//
//////////////////////////////////////////////////////////////////////
#include "Texture.h"
#include <string.h>
#include <stdlib.h>
#include <gl\glaux.h>

CTexture::CTexture()
{
	width = 0;
	height = 0;
	imageData = NULL;
	textureType = INVALID_TEXTURE;
	pNext = 0;
}

CTexture::~CTexture()
{
	if (pNext)
		delete pNext;

	clear();
}

void CTexture::add(CTexture* pTexture)
{
	if (getNext())
		getNext()->add(pTexture);
	else
		pNext = pTexture;
}

void CTexture::clear()
{
	if (imageData)
		free(imageData);

	imageData = NULL;
	width = 0;
	height = 0;
}

unsigned char* CTexture::getData()
{
	return imageData;
}

int CTexture::getHeight()
{
	return height;
}

CTexture* CTexture::getNext()
{
	return pNext;
}

int CTexture::getTextureType()
{
	return textureType;
}

int CTexture::getWidth()
{
	return width;
}

bool CTexture::load(const char* filename, const char* textureName, int type)
{
	if (type != BASE_TEXTURE && type != DECAL_TEXTURE && type != LIGHTMAP_TEXTURE)
	{
		return false;
	}
	else
		textureType = type;

	char fullName[100];
	char tokenString[100];
	char seps[]   = ". ";
	char *token;

	strcpy(fullName, filename);
	strcpy(tokenString, filename);
	strcpy(name, textureName);

	// filename 
	token = strtok( tokenString, seps );

	// extension (bmp, jpeg, png, etc.)
	token = strtok( NULL, seps);

	if (token != NULL)
	{
		char* extension = _strupr(token);
		if (strcmp( extension, "BMP" ) == 0)
			return loadBitmapFile(fullName);
	}

	return false;
}

bool CTexture::loadBitmapFile(char* filename)
{
	AUX_RGBImageRec *pBitmap = NULL;
	pBitmap = auxDIBImageLoad(filename);
	if(pBitmap == NULL) 
	{
		return false;
	}
	clear();
	width = pBitmap->sizeX;
	height = pBitmap->sizeY;
	imageData = (unsigned char *)malloc(width * height * 3);
	memcpy(imageData, pBitmap->data, width * height * 3);
	if (pBitmap)			
	{
		if (pBitmap->data)
		{
			free(pBitmap->data);
		}
		free(pBitmap);
	}
	return true;
}

bool CTexture::serialize(FILE * filePtr, bool isStoring)
{
	if (filePtr  == NULL)
		return false;

	short int valid;

	if (isStoring)
	{
		if (height == 0 || width == 0 || imageData == NULL || textureType == INVALID_TEXTURE)
		{
			valid = 0;
			fwrite(&valid, sizeof(short int), 1, filePtr);
		}
		else
		{
			valid = 1;
			fwrite(&valid, sizeof(short int), 1, filePtr);
			fwrite(&textureType, sizeof(short int), 1, filePtr);
			fwrite(&height, sizeof(int), 1, filePtr);
			fwrite(&width, sizeof(int), 1, filePtr);
			fwrite(imageData, 1, width*height*3, filePtr);
			fwrite(name, 1, 14, filePtr);
		}
	}
	else
	{
		clear();
		fread(&valid, sizeof(short int), 1, filePtr);
		if (valid != 0)
		{
			fread(&textureType, sizeof(short int), 1, filePtr);
			fread(&height, sizeof(int), 1, filePtr);
			fread(&width, sizeof(int), 1, filePtr);
			imageData = (unsigned char *)malloc(width * height * 3);
			fread(imageData, 1, width * height * 3, filePtr);
			fread(name, 1, 14, filePtr);
		}
	}
	return true;
}