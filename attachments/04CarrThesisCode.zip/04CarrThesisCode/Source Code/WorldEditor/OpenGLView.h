#if !defined(AFX_OPENGLVIEW_H__BA29CF0A_C6FF_4EEE_8EBD_E38147B5EFB0__INCLUDED_)
#define AFX_OPENGLVIEW_H__BA29CF0A_C6FF_4EEE_8EBD_E38147B5EFB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WorldEditorDoc.h"

class COpenGLView : public CView
{
protected:
	COpenGLView();
	DECLARE_DYNCREATE(COpenGLView)

// Attributes
public:
	CWorldEditorDoc *	GetDocument();
	int winHeight;
	int winWidth;

public:
	HGLRC				m_hRC;
	HDC					m_hDC;
	CDC *				m_pDC;

// Operations
public:
	virtual BOOL		InitOpenGL();
	virtual void		Render();
	void				SetContext();
	BOOL				SetupPixelFormat();
	void				SwapGLBuffers();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COpenGLView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~COpenGLView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(COpenGLView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPENGLVIEW_H__BA29CF0A_C6FF_4EEE_8EBD_E38147B5EFB0__INCLUDED_)
