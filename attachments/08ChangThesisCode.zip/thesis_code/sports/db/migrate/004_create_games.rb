class CreateGames < ActiveRecord::Migration
  def self.up
    create_table :games do |t|
			t.column :name, :string
			t.column :date, :datetime
      t.timestamps
    end
  end

  def self.down
    drop_table :games
  end
end
