#include "AlphaEngine/PBrush/Shape.h"
#include "AlphaEngine/Math/Math.h"

CPBrush* CShape::createBox(float lengthX, float lengthY, float lengthZ)
{
	unsigned int x;

	float dx = lengthX * 0.5f;
	float dy = lengthY * 0.5f;
	float dz = lengthZ * 0.5f;
	
	// create a polygon oriented at about origin, looking down z-axis
	CPBrush brush;
	brush.allocate(1);
	brush.pPolygon[0].allocate(4);
	
	brush.pPolygon[0].pVert[0] = CVector3(dx ,  dy, -dz);
	brush.pPolygon[0].pVert[1] = CVector3(dx,  -dy, -dz);
	brush.pPolygon[0].pVert[2] = CVector3(-dx, -dy, -dz);
	brush.pPolygon[0].pVert[3] = CVector3(-dx , dy, -dz);

	CVector2 txCoords[4];
	txCoords[0] = CVector2(1,1);
	txCoords[1] = CVector2(1,0);
	txCoords[2] = CVector2(0,0);
	txCoords[3] = CVector2(0,1);

	for (x = 0; x < 4; x++)
	{
		brush.pPolygon[0].pBTxCoord[x] = txCoords[x];
		brush.pPolygon[0].pDTxCoord[x] = txCoords[x];
	}
	
	// default texture for all objects created;
	brush.pPolygon[0].bTxId = 1;

	brush.setNormals();

	return brush.intrudePolygon(0, lengthZ);
}

CPBrush* CShape::createSphere(float radius, int slices, int stacks)
{
	
	float lat, lng;
	float latStep = 180.0f / (float)stacks;
	float lngStep = 360.0f / (float)slices;
	unsigned int numPolygons = 0;
	CPolygon* polygonList = 0;
	for (lat = -90.0f; lat < 90.0f; lat += latStep)
	{
		float latAngle = CMath::DEG_TO_RAD * lat;

		for (lng = 0.0f; lng < 360.0f; lng += lngStep)
		{
			float lngAngle = CMath::DEG_TO_RAD * lng;

			float z = radius * CMath::Sin(latAngle);
			float rp = radius * CMath::Cos(latAngle);
			float y = rp * CMath::Sin(lngAngle);
			float x = rp * CMath::Cos(lngAngle);
			CVector3 pt1(x, y, z);
			CVector2 b1(lng / 360.0f, (90+lat) / 180.0f);

			float latPrime = CMath::DEG_TO_RAD * (lat + latStep);
			float lngPrime = CMath::DEG_TO_RAD * (lng + lngStep);

			z = radius * CMath::Sin(latPrime);
			rp = radius * CMath::Cos(latPrime);
			y = rp * CMath::Sin(lngAngle);
			x = rp * CMath::Cos(lngAngle);
			CVector3 pt2(x, y, z);
			CVector2 b2(lng / 360.0f, (90+lat+latStep) / 180.0f);

			z = radius * CMath::Sin(latPrime);
			rp = radius * CMath::Cos(latPrime);
			y = rp * CMath::Sin(lngPrime);
			x = rp * CMath::Cos(lngPrime);
			CVector3 pt3(x,y,z);
			CVector2 b3((lng + lngStep)/ 360.0f, (90+lat+latStep) / 180.0f);

			z = radius * CMath::Sin(latAngle);
			rp = radius * CMath::Cos(latAngle);
			y = rp * CMath::Sin(lngPrime);
			x = rp * CMath::Cos(lngPrime);
			CVector3 pt4(x,y,z);
			CVector2 b4((lng+lngStep) / 360.0f, (90+lat) / 180.0f);

			CPolygon* pPolygon = new CPolygon();
			pPolygon->insertVert(pt1, b1, b1);
			pPolygon->insertVert(pt2, b2, b2);
			if (pt3 != pt2)
				pPolygon->insertVert(pt3, b3, b4);
			if (pt4 != pt1)
				pPolygon->insertVert(pt4, b4, b4);

			if (polygonList)
				polygonList->add(pPolygon);
			else
				polygonList = pPolygon;

			numPolygons++;
		}
	}

	CPBrush* pBrush = new CPBrush();
	pBrush->allocate(numPolygons);
	CPolygon* curPolygon = polygonList;
	unsigned int x = 0;
	while (curPolygon != 0)
	{
		pBrush->pPolygon[x].allocate(curPolygon->numVert);
		pBrush->pPolygon[x].bTxId = 1;
		for (unsigned int y = 0; y < curPolygon->numVert; y++)
		{
			pBrush->pPolygon[x].pVert[y] = curPolygon->pVert[y];
			pBrush->pPolygon[x].pBTxCoord[y] = curPolygon->pBTxCoord[y];
			pBrush->pPolygon[x].pDTxCoord[y] = curPolygon->pDTxCoord[y];
		}
		curPolygon = curPolygon->pNext;
		x++;
	}

	delete polygonList;

	return pBrush;
}