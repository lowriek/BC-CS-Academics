#ifndef _SECTOR_H_
#define _SECTOR_H_

#include "AlphaEngine/PVS/Portal.h"

class CSector
{
public:
	CSector();
	virtual ~CSector();

	void	addPortal(CPortal* pPortal);
	void	addPolygon(CPolygon* pPolygon);
	bool	serialize(FILE* filePtr, bool isStoring);

	CPortalList portalList;
	CPolygon* pPolygon;
	bool beingVisited;

private:
};

#endif