class AddTestData < ActiveRecord::Migration
  def self.up
  	Profile.create(:first_name => 'John',
  		:last_name => 'Doe',
  		:phone_number => '617-555-1212',
  		:email => 'jdoe@microsoft.com',
  		:street_address => '123 Pleasant Street',
  		:available => true)
   	Profile.create(:first_name => 'James',
  		:last_name => 'Smith',
  		:phone_number => '732-342-392',
  		:email => 'jsmith@apple.com',
  		:street_address => '123 Commonwealth Avenue',
   		:available => true)
  	Profile.create(:first_name => 'Marisa',
  		:last_name => 'Tester',
  		:phone_number => '507-321-6677',
  		:email => 'mtester@hp.com',
  		:street_address => '99 Infinite Loop',
  		:available => false)
  	Profile.create(:first_name => 'Father',
  		:last_name => 'Leahy',
  		:phone_number => '617-655-6392',
  		:email => 'leahy@bc.edu',
  		:street_address => '26 Campanella Way',
  		:available => false)
  end

  def self.down
	Profile.delete_all
  end
end
