/* ------------------------------------------------------------------
   ------------------------------------------------------------------
   --															   --
   --						ENGINE.CPP							   --
   --															   --
   --		Created By:		Cris Stauffer						   --
   --		Creation Date:	September 17, 2001					   --
   --														       --
   --		Notes:												   --
   --                                                              --
   --															   --
   --															   --
   --															   --
   --		Bugs:												   --
   --															   --
   --															   --
   --															   --
   --															   --
   ------------------------------------------------------------------
   ------------------------------------------------------------------ */

#include "engine.h"


extern MEngine * GblEngine;
//extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
//extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;


MEngine::MEngine()
{

	hRC = NULL;
	hDC = NULL;
	hWnd = NULL;
	active = true;
	fullscreen = true;
	parent = NULL;
    child = NULL;
	next = NULL;
    prev = NULL;
	Entity();
	debugOut = true;
	MasterSound = NULL; MasterClock = NULL; myCamera = NULL;
	
	for(int i = 0; i <256; i++)
		keys[i] = false;

	
	frameRate[0] = 0;
	frameRate[1] = 0;
	frameRate[2] = 0;
}

MEngine::~MEngine()
{
}

int		MEngine::DrawScene()
{
	double pi = 3.1415926535;
	double tmp = GetTickCount();
	double res = tmp - frameRate[0];
	res /= 1000;
	res = 1 / res;
	frameRate[0] = tmp;
	frameRate[1] = (int)(frameRate[1] + 1) % 15;
	if(frameRate[1] == 0)
		frameRate[2] = res;

	// Set BackDrop to coordinate with time



	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	if(debugOut)
	{
	messenger->FontPrint("Magi Game Engine Data:");
	messenger->FontPrint("Frame Rate: %d frames per second",(int)frameRate[2]);
	messenger->FontPrint("Current Time: %d:%d:%d",(int)(MasterClock->GetTime()/3600),
										int((MasterClock->GetTime() % 3600)/60), (MasterClock->GetTime() % 3600) % 60 );
		messenger->FontPrint("Counter: %d",(int)MasterClock->GetTime());
	}


	// Reset The Modelview Matrix											
	Entity * e = child;
	
	while(e != NULL)
	{
		e->Draw();
	    e = e->next;
	}

	/* Output State Info */
	messenger->FontFlush();

	 return 1;

}
bool	MEngine::SpawnWindow(char * title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= MAKEINTRESOURCE(IDR_MENU1);	
	wc.lpszClassName	= "Cris";								// Set The Class Name


	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen = false;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return false;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"Cris",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		32,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeWindow(width, height);					// Set Up Our Perspective GL Screen

	if (!InitWindow())									// Initialize Our Newly Created GL Window
	{
		Kill();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

/*	
		glMultiTexCoord2fARB	= NULL;
		glActiveTextureARB		= NULL;
		glActiveTextureARB		= (PFNGLACTIVETEXTUREARBPROC)		wglGetProcAddress("glActiveTextureARB");
	    glMultiTexCoord2fARB	= (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress("glMultiTexCoord2fARB");
	
		if(!glActiveTextureARB || !glMultiTexCoord2fARB)
	{
		// Print a error message and quit.
		MessageBox(hWnd, "Your version of OpenGL does not support multitexturing", "Error", MB_OK);
		Kill();
		return false;
	}
*/
	return true;									// Success
}

void	MEngine::ReSizeWindow(int width, int height)
{
	if (!height)									// Protect from divide by zero if later use perspective
		height = 1;

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,3.0f,30000.0f);
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

bool	MEngine::InitWindow(void)
{
	drawMode = 0;
	glShadeModel(GL_SMOOTH);										// Enable Smooth Shading
	glClearColor(0.0f, 0.1f, 0.7f, 0.1f); 							// Background
	glClearDepth(1.0f);												// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);										// Enables Depth Testing
	glDepthFunc(GL_LESS);											// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);				// Really Nice Perspective Calculations
	return TRUE;		
}




void	MEngine::Kill()
{
	fclose(demo);
	if(MasterSound != NULL)
		MasterSound->Kill();

	if(next != NULL)
		next->Kill();
	if(child != NULL)
		child->Kill();

		if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("Cris",hInstance))				// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}

	




	
}


void	MEngine::Draw()
{
	MSG msg;
	running = true;
	float tempX, tempY, tempZ, tempDir, tempDec;
	bool beginControl = true;

	if (MessageBox(NULL,"Run In Fullscreen Mode?", "Choose Wisely",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen = false;							// Windowed Mode
	}
	
if (!SpawnWindow("Magi Game Engine",800,600,32,fullscreen))
		return;										// If Window Was Not Created


messenger = new Font(hDC);

InitScene();


tempX = myCamera->GetX();
tempZ = myCamera->GetZ();
tempY = myCamera->GetY();
tempDir = myCamera->GetDir();
tempDec = myCamera->GetDec();

	while(running)
	{
		
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				running = false;				
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawScene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				running = false;					// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1] = false;				// If So Make Key FALSE
				Kill();						// Kill Our Current Window
				fullscreen =! fullscreen;        	// Toggle Fullscreen / Windowed Mode
				if (!SpawnWindow("Magi Game Engine",1400,1050,16,fullscreen))
					return;				
			}

			if(myCamera->MainCameraControl())
			{

			if(beginControl)
			{
				myCamera->MutDec(tempDec);
				myCamera->MutDir(tempDir);
				myCamera->MutX(tempX);
				myCamera->MutY(tempY);
				myCamera->MutZ(tempZ);
				beginControl = false;
			}

			///keys[fgetc(demo)] = true;
				
			if	(keys[VK_LEFT])
			{
				tempDir -= 3;
				myCamera->MutDir(tempDir);
			}
			if	(keys[VK_RIGHT])
			{
				tempDir += 3;
				myCamera->MutDir(tempDir);
			}
			if	(keys[VK_F2])
			{
				tempDec += 3;
				myCamera->MutDec(tempDec);
			}
			if	(keys[VK_F3])
			{
				tempDec -= 3;
				myCamera->MutDec(tempDec);
			}

			if	(keys[VK_F4])
			{
				myCamera->ToggleCameraControl();
				keys[VK_F4] = false;
			}

			if	(keys[VK_F5])
			{
				MasterClock->AdvanceHour();
				keys[VK_F5] = false;
			}

			if	(keys[VK_F6])
			{
				MasterClock->ReverseHour();
				keys[VK_F6] = false;
			}

			if	(keys[VK_F7])
			{
				drawMode = (drawMode + 1) % 2;
				keys[VK_F7] = false;
			}
			if	(keys[VK_UP])
			{
				tempX = tempX + sin(tempDir * 3.14/180.0)* cos(tempDec * 3.14/180.0);
				myCamera->MutX(tempX);
				
				
				tempZ = tempZ -  cos(tempDir * 3.14/180) * cos(tempDec * 3.14/180);
				myCamera->MutZ(tempZ);
		        
			
				tempY = tempY + sin(tempDec * 3.14/180);
				myCamera->MutY(tempY);

			
			}
			if	(keys[VK_DOWN])
			{
				tempX = tempX - sin(tempDir * 3.14/180.0) * cos(tempDec * 3.14/180.0);
				myCamera->MutX(tempX);
				

				tempZ = tempZ + cos(tempDir * 3.14/180) * cos(tempDec * 3.14/180);
				myCamera->MutZ(tempZ);

		        
				tempY = tempY - sin(tempDec * 3.14/180);
				myCamera->MutY(tempY);
			}

			
			}
			else
				beginControl = true;
		}
	}
	Kill();	

}


void	MEngine::InitScene()
{

	drawMode = 0x0001;
	demo = fopen("demo.data","r");
	MasterSound = new SoundManager(hWnd);
SoundObject * theme = new SoundObject();

if(!MasterSound->Init())
{
	MessageBox( NULL, "Could not Initialize Music", "Error", MB_OK | MB_ICONERROR );
	Kill();
	return;
}

MasterSound->Create(theme, "Sounds/Theme.wav", true);
MasterSound->Play(theme, 10);
MasterSound->SetVolume(1.0);

SoundManager * environ = new SoundManager(hWnd);
SoundObject *  wave = new SoundObject();

if(!environ->Init())
{
	MessageBox( NULL, "Could not Initialize Music", "Error", MB_OK | MB_ICONERROR );
	Kill();
	return;
}

environ->Create(wave,"Sounds/wind.wav",true);

	Intro(true);
	
	float dLight[] = {0.9f,0.9f,0.9f,0.1f};
	float lPos[] = {15100,24200.0f,15100.0f,1.0f};

	float aLight[] = {0.1f,0.1f,0.1f,0.1f};
	float aPos[]={25000,15000,25000,1.0f};

	
	Model * pModel = new MilkshapeModel(3000,-1,3000,3000, 1, 1, 1,false);									// Memory To Hold The Model
	if ( pModel->loadModelData( "data/fort2.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;												// If Model Didn't Load Quit
	}
	//pModel->reloadTextures();
	
Model * player = new MilkshapeModel(5000,-1,5000,50, .07, .07, .07, false);
	if ( player->loadModelData( "data/mainplayer4.ms3d" ) == false )
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;									// If model Didn't Load Quit
	}

Model * boat = new MilkshapeModel(6200,30,6200,500, 1, 1, 1, false);									// Memory To Hold The Model
	if ( boat->loadModelData( "data/boat4.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;												// If Model Didn't Load Quit
	}

	float pts[] = {4000,-1,4000,4900,-1,4900,4100,-1,4000,4050,-1,4067, 4200,-1,4100,4400,-1,4200};

Model * plantfield = new MilkshapeModel(pts,6,50, 1, 1, 1,false);									// Memory To Hold The Model
	if ( plantfield->loadModelData( "data/plant.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;												// If Model Didn't Load Quit
	}
	
		float pts2[] = {6000,25,6000,6100,35,6000,6300,20,6300,6100,20,6200};
Model * fish = new MilkshapeModel(pts2,4,30, 1, 1, 1,false);									// Memory To Hold The Model
	if ( fish->loadModelData( "data/fish.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;												// If Model Didn't Load Quit
	}

	float pts3[] = {4500,-1,4500,4600,-1,4600,4550,-1,4500,4450,-1,4410};
Model * forest = new MilkshapeModel(pts3,4,30, 1, 1, 1,true);									// Memory To Hold The Model
	if ( forest->loadModelData( "data/tree.ms3d" ) == false )		// Loads The Model And Checks For Errors
	{
		MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
		return;												// If Model Didn't Load Quit
	}

myCamera = new MCamera(5565,400,5565,190,0);
MasterClock = new TimeKeeper();






FogFX * fg = new FogFX();
SkyBox * sky = new SkyBox(MasterClock);
MasterTerrain * land = new MasterTerrain(500, 20,20, 0, 0, 0, 1000);
Celestial * moon = new Celestial(MasterClock);
moon->CreateCelestial("data/moon.tga");

if(!land->TerrainLoad("data/test3.tga"))
{
	MessageBox(NULL,"Can't Load Terrain Data","ERROR",MB_OK|MB_ICONEXCLAMATION);
	running = 0;
}

land->Init();
editorInsert = land;




Cloud * cld = new Cloud();
cld->CreateCloud("data/cloud2.tga", 2500, CLOUD_LIGHT, 1);

LightFX * lght = new LightFX();

lght->AddLight(1,dLight,lPos);
lght->AddLight(0,aLight,aPos);

Avatar * Snape = new Avatar(myCamera, MasterClock);


land->AddChild(Snape);


land->AddChild(pModel);
land->AddChild(boat);
land->AddChild(plantfield);
land->AddChild(player);
land->AddChild(fish);
land->AddChild(forest);

AddChild(myCamera);
AddChild(MasterClock);

  myCamera->AddChild(lght);

  lght->AddChild(sky);

  sky->AddChild(fg);
  sky->AddChild(moon);

  sky->AddChild(cld);
  sky->AddChild(land);

  
 
glEnable(GL_CULL_FACE);
glCullFace(GL_BACK);
glFrontFace(GL_CCW);
Intro(false);

environ->SetVolume(0.8);
environ->Play(wave, 100);



}

BOOL CALLBACK DlgProc(HWND dlg, UINT msg, WPARAM wParam, LPARAM lParam) {

      switch(msg)
	  {

            case WM_INITDIALOG:
				{
					//static CTreeCtrl * treeControl;	 
					//GetDlgControl(IDC_TREE1,treeControl);
                 return true;
				}
            case WM_COMMAND:
				switch(LOWORD(wParam))
				{

                     case IDC_MODEL_CREATE: 
                     {
					   char filename[30], xVal[10], yVal[10], zVal[10], radiusVal[10];

					   GetDlgItemText(dlg, IDC_MODEL_FILENAME, (LPTSTR)filename, 30);               
					   GetDlgItemText(dlg, IDC_MODEL_X, (LPTSTR)xVal, 10);               
					   GetDlgItemText(dlg, IDC_MODEL_Y, (LPTSTR)yVal, 10);		   
					   GetDlgItemText(dlg, IDC_MODEL_Z, (LPTSTR)zVal, 10);
					   GetDlgItemText(dlg, IDC_MODEL_RADIUS, (LPTSTR)radiusVal, 10);
					   int dialogX = atoi(xVal);
					   int dialogY = atoi(yVal);
					   int dialogZ = atoi(zVal);
					   int dialogRad = atoi(radiusVal);

					   Model * mdl = new MilkshapeModel(dialogX,dialogY,dialogZ,dialogRad, 1, 1, 1, true);
						if ( mdl->loadModelData(filename) == false )
						{
						MessageBox( NULL, "Couldn't load the model data\\model.ms3d", "Error", MB_OK | MB_ICONERROR );
						return true;									// If model Didn't Load Quit
						}
						GblEngine->editorInsert->AddChild(mdl);
						return true;
                     }
					 
						case IDC_MODEL_CANCEL:
						{
							ShowWindow(dlg,SW_HIDE);
							EndDialog(dlg,IDOK);
						}
				}
				return true;
            case WM_CLOSE:

                 EndDialog(dlg, IDOK);                 
                 return true;
	}
      return false;
 }



LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{

	
	switch (uMsg)									// Check For Windows Messages
	{
		
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				GblEngine->active = true;			// Program Is Active
				ShowWindow(hWnd,SW_SHOW);
			}
			else
			{
				GblEngine->active = false;			// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		
		case WM_COMMAND:
		{
			switch(LOWORD(wParam)) 
			{

                  case ID_M_EXIT:
				{
					PostQuitMessage(0);
					return 0;
				}

				  case ID_M_GRAPHIC_TEXTURE:
				 {
					 if(GblEngine->drawMode & RENDER_TEXTURE)
						 GblEngine->drawMode = GblEngine->drawMode - RENDER_TEXTURE;
					 else
						 GblEngine->drawMode = GblEngine->drawMode | RENDER_TEXTURE;
					return 0;
				 }

				  case ID_M_GRAPHIC_LIGHTING:
				 {
					 if(GblEngine->drawMode & RENDER_LIGHTING)
						 GblEngine->drawMode = GblEngine->drawMode - RENDER_LIGHTING;
					 else
						 GblEngine->drawMode = GblEngine->drawMode | RENDER_LIGHTING;
					return 0;
				 }

				  case ID_M_MODEL_CREATE:
				{
					static HWND modelHWnd;
					 modelHWnd=CreateDialog(GblEngine->hInstance, 
															MAKEINTRESOURCE(IDD_MODELFORM), GblEngine->hWnd,DlgProc);
					if(modelHWnd == NULL)
						MessageBox(NULL,"Cant Create Model Creator Window","ERROR",MB_OK|MB_ICONEXCLAMATION);
					else
						ShowWindow(modelHWnd, SW_SHOW);

					
				return 0;
				}
				
			}

                  return 0;
		}

		


		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;
		}


		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back

		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
		//	fputc(wParam,GblEngine->demo);
			GblEngine->keys[wParam] = true;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
		//	fputc(wParam,GblEngine->demo);
			GblEngine->keys[wParam] = false;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The Window
		{
			GblEngine->ReSizeWindow(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

void	MEngine::Intro(bool start)
{

	float mask = 0.0f;
//	static int id = LoadTGA("Data/hourglass2.tga",0);
	static int id = LoadTGA("Data/hourglass.tga",0);
	static int idTitle = LoadTGA("Data/title.tga",0);
	if(start)
	{
	
	glClearColor(0.0f, 0.0f, 0.0f, .5f); 							// Background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glMatrixMode(GL_MODELVIEW);		

	glPushMatrix();
	glLoadIdentity();
	glTranslatef(0.0,0.0,-5.2);
	
	
	
		for(mask = 0.0; mask<=2.0; mask +=.01)
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		

			if(mask<=1.0)
				glColor4f(mask,mask,mask, 1.0);
			else
				glColor4f(1.0,1.0,1.0,1.0);

			glEnable(GL_TEXTURE_2D);
			
			
			glBindTexture(GL_TEXTURE_2D,  id);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
			glBegin(GL_QUADS);

			glTexCoord2f( 0, 0);
			glVertex3f(-1,-1,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(1,-1,-1);
			glTexCoord2f( 1, 1);
			glVertex3f(1,1,-1);
			glTexCoord2f( 0, 1);
			glVertex3f(-1,1,-1);
			glEnd();
			glDisable(GL_TEXTURE_2D);

		
			if(mask>=1.0)
				glColor4f(mask-1.0,mask-1.0,mask-1.0, 1.0);
			else
				glColor4f(0.0,0.0,0.0,1.0);

			glEnable(GL_TEXTURE_2D);
		
			glBindTexture(GL_TEXTURE_2D,  idTitle);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
			glBegin(GL_QUADS);

			glTexCoord2f( 0, 0);
			glVertex3f(-2.0,-2.0,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(2.2,-2.0,-1);
			glTexCoord2f( 1, 1);
			glVertex3f(2.2,2.0,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(-2.0,2.0,-1);
			glEnd();
			glDisable(GL_TEXTURE_2D);



			SwapBuffers(hDC);
	
		}


		glPopMatrix();
		glLoadIdentity();
		glClearColor(0.0f, 0.1f, 0.7f, 0.1f); 							// Background

	}

	else
	{
		glMatrixMode(GL_MODELVIEW);		

		glPushMatrix();
		glLoadIdentity();
		glTranslatef(0.0,0.0,-5.2);
		glClearColor(0.0f, 0.0f, 0.0f, .5f); 							// Background
	
	
		for(mask = 0.0; mask<=2.0; mask +=.01)
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
			if(mask>=1.0)
				glColor4f(1.0-(mask-1),1.0-(mask-1),1.0-(mask-1), 1.0);
			else
				glColor4f(1.0,1.0,1.0,1.0);

			glEnable(GL_TEXTURE_2D);
			
			glBindTexture(GL_TEXTURE_2D,  id);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
			glBegin(GL_QUADS);

			glTexCoord2f( 0, 0);
			glVertex3f(-1,-1,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(1,-1,-1);
			glTexCoord2f( 1, 1);
			glVertex3f(1,1,-1);
			glTexCoord2f( 0, 1);
			glVertex3f(-1,1,-1);
			glEnd();
			glDisable(GL_TEXTURE_2D);
		
			if(mask>=1.0)
				glColor4f(0.0,0.0,0.0, 1.0);
			else
				glColor4f(1.0-mask,1.0-mask,1.0-mask,1.0);

			glEnable(GL_TEXTURE_2D);
			
			glBindTexture(GL_TEXTURE_2D,  idTitle);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE);
			glBegin(GL_QUADS);

			glTexCoord2f( 0, 0);
			glVertex3f(-2.0,-2.0,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(2.2,-2.0,-1);
			glTexCoord2f( 1, 1);
			glVertex3f(2.2,2.0,-1);
			glTexCoord2f( 1, 0);
			glVertex3f(-2.0,2.0,-1);
			glEnd();
			glDisable(GL_TEXTURE_2D);



			SwapBuffers(hDC);
	
		}

		unsigned int temp = id;
		
		glPopMatrix();
		glLoadIdentity();
		glClearColor(0.0f, 0.1f, 0.7f, 0.1f); 							// Background
		glDeleteTextures(1,&temp);
		temp = idTitle;
		glDeleteTextures(1,&temp);

	}

	
}


