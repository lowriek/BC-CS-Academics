#ifndef _ALPHACONSTANTS_H_
#define _ALPHACONSTANTS_H_

// RENDERING FLAGS (MESHES)
#define ALPHA_WIREFRAME				1
#define ALPHA_FILL					2
#define ALPHA_B_TX					4
#define ALPHA_D_TX					8
#define ALPHA_L_TX					16
#define ALPHA_TRANSPARENT			32

// RENDERING FLAGS (ALPHA_ENGINE)
#define ALPHA_RENDER_BRUSH			1
#define ALPHA_RENDER_CSG			2
#define ALPHA_RENDER_FINAL			4

#define ALPHA_STATIC_MESH			1

// PLANE EQUATION
#define	ALPHA_BEHIND				0
#define ALPHA_INFRONT				1
#define ALPHA_COINCIDING			2
#define ALPHA_SPANNING				3

// SHAPE TYPES
#define ALPHA_BOX					0
#define ALPHA_SPHERE				1

// CSG OPS
#define ALPHA_ADD					0
#define ALPHA_SUB					1

// BSP TYPES
#define ALPHA_NO_ID					60001
#define ALPHA_MAX_ID				60000
#endif