function [A] = faceMatrix(width,height)
%  function [] = faceMatrix()
%  OUTPUT:
%     A :  A matrix of all the crop*.jpg faces in the directory
%          M by N dimensions, M is the number of faces
%     S :  A similarity 

files = dir('crop*.jpg');
[numFaces,x] = size(files);
A = zeros(numFaces,width*height);
%filt = d2gauss(8,5,8,5,0);
for I=1:numFaces%91
    im = double(imread(files(I).name))/255;
    im = imresize(im, [height width], 'bilinear');
    im = im / sum(abs(im(:)));
    %im = imfilter(im,filt);
    %figure(1);clf;imagesc(im);axis image;truesize;colormap gray;
    A(I,:) = reshape(im,1,width*height);
end