#include "Render.h"

PFNGLMULTITEXCOORD2FARBPROC Render::glMultiTexCoord2fARB = 0;
PFNGLACTIVETEXTUREARBPROC Render::glActiveTextureARB = 0;
PFNGLCLIENTACTIVETEXTUREARBPROC	Render::glClientActiveTextureARB = 0;
int Render::maxTextureUnits = 0;

bool Render::init()
{
	char * extensionStr;
	extensionStr = (char *)glGetString(GL_EXTENSIONS);
	
	if (!inString("GL_ARB_multitexture", extensionStr))
		return false;
	
	// MULTITEXTURING IS SUPPORTED
	glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress("glMultiTexCoord2fARB");
	glActiveTextureARB =		(PFNGLACTIVETEXTUREARBPROC)			wglGetProcAddress("glActiveTextureARB");
	glClientActiveTextureARB =	(PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress("glClientActiveTextureARB");
	glGetIntegerv(GL_MAX_TEXTURE_UNITS_ARB, &maxTextureUnits);

	// we need at least 2 texture units because of lightmap support
	if (Render::maxTextureUnits < 2)
		return false;

	return true;
}

bool Render::inString(char *searchStr, char *str)
{
	char * endOfStr;
	unsigned int idx = 0;
	endOfStr = str + strlen(str);
	while (str < endOfStr)
	{
		idx = strcspn(str, " ");

		if (strlen(searchStr) == idx && strncmp(searchStr, str, idx)==0)
			return true;

		str+=(idx+1);
	}
	return false;
}

void Render::shutdown()
{
	glActiveTextureARB = 0;
	glClientActiveTextureARB = 0;
	glMultiTexCoord2fARB = 0;
	glMultiTexCoord2fARB = 0;
	maxTextureUnits = 0;
}