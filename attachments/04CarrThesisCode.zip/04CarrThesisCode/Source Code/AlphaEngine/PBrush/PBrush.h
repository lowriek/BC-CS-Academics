#ifndef _PBRUSH_H_
#define _PBRUSH_H_

#include "AlphaEngine/Math/Matrix44.h"
#include "AlphaEngine/Core/Polygon.h"
#include "AlphaEngine/Core/Color4.h"

#define FRONT 0
#define BACK 1

typedef unsigned int PBRUSHID;

class CPBrush 
{
public:
	CPBrush();
	~CPBrush();

	void			allocate(unsigned int numPoly);
	CPBrush*		clone();
	CPBrush*		intrudePolygon(PBRUSHID polygonId, float distance);
	CPolygon*		getPolygonList();
	void			setPolygonPickColor();
	void			setPickColor();
	void			setNormals();
	void			pickBrush(const int& mode);
	void			render(int flags);
	virtual bool	serialize(FILE * filePtr, bool isStoring);
	void			transform(const CMatrix44& matrix);
	static PBRUSHID pickColor2BrushId(CColor4& pickColor);

	PBRUSHID		brushId;
	unsigned int	numPolygon;
	CPolygon*		pPolygon;
	CColor4			pickColor;
	CColor4*		pPolygonPickColor;
	int				opType;

private:
	static CColor4	brushId2PickColor(PBRUSHID brushId);
};
#endif 