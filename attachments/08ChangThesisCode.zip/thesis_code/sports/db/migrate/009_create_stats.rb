class CreateStats < ActiveRecord::Migration
  def self.up
    create_table :stats do |t|
			t.column :player_id, :integer, :null => false
			t.column :statconcept_id, :integer, :null => false
			t.column :game_id, :integer, :null => false
			t.column :value, :integer
			t.column :start, :datetime
			t.column :end, :datetime
      t.timestamps
    end
  end

  def self.down
    drop_table :stats
  end
end
