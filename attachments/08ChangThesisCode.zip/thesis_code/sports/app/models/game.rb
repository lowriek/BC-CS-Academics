class Game < ActiveRecord::Base
	validates_uniqueness_of :name

	has_many :gameteams
	has_many :teams, :through => :gameteams
end
