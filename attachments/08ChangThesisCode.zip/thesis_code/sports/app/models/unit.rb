class Unit < ActiveRecord::Base
end
