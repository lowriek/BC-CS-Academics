# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
class ApplicationController < ActionController::Base

private

def authorize
	unless User.find_by_id(session[:user_id])
		session[:original_uri] = request.request_uri
		flash[:notice] = "Please log in"
		redirect_to(:controller => "login", :action => "login")
	end
end

def authorizeadmin
	@user = User.find_by_id(session[:user_id])
	
	unless  @user != nil and user.admin = 1
				flash[:notice] = "You must be logged in as an administrator to access this area."
				redirect_to(:controller => "login", :action => "login")
	end		
end			

end