/* ----------------------------------------------
   -											-
   -	PROJECT:		MAGI     				-
   -	FILE:			vector.h				-	
   -	CREATED:		07/20/01				-
   -	MODIFIED:		07/20/01				-
   -											-
   -	NOTES:									-
   -	BUGS:									-
   -											-
   ---------------------------------------------- */

#ifndef _VECTOR_H
#define _VECTOR_H

#include <stdio.h>


class Vector3D {

	public:
	float x,y,z;

	Vector3D();
	Vector3D(float a, float b, float c);
	~Vector3D();
	Vector3D operator +(const Vector3D & v) const;
	Vector3D operator -(const Vector3D & v) const;
	Vector3D operator *(const float f) const;
	float	 operator *(const Vector3D & v) const;

};

#endif	//_VECTOR_H