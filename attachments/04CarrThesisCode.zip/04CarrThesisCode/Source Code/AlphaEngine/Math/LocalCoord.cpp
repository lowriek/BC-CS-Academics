#include "AlphaEngine/Math/LocalCoord.h"

CLocalCoord::CLocalCoord() {}
CLocalCoord::~CLocalCoord() {}

bool CLocalCoord::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	if (isStoring)
	{
	}
	else
	{
	}

	return true;
}