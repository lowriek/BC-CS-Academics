#include "AlphaEngine/Core/BaseObjectMgr.h"

CBaseObjectMgr* CBaseObjectMgr::objMgr = 0;

CBaseObjectMgr::CBaseObjectMgr()
{
	nextId = 1;
	freeIds.clear();
}

CBaseObjectMgr::~CBaseObjectMgr()
{
}

void CBaseObjectMgr::freeObjectId(unsigned long n)
{
	if (n == 0)
		return;

	freeIds.push_back(n);
}

CBaseObjectMgr* CBaseObjectMgr::getInstance()
{
	if (objMgr==0)
		objMgr = new CBaseObjectMgr();

	return objMgr;
}

unsigned long CBaseObjectMgr::getObjectId()
{
	if (freeIds.empty())
	{
		unsigned long val = nextId;
		nextId++;
		return val;
	}
	else
	{
		unsigned long t = freeIds.front();
		freeIds.pop_front();
		return t;
	}
}

bool CBaseObjectMgr::serialize(FILE * filePtr, bool isStoring)
{
	bool objMgrExists = objMgr != 0;
	
	if (!filePtr)
		return false;

	if (isStoring)
	{
		fwrite(&objMgrExists, sizeof(bool), 1, filePtr);
		if (objMgrExists)
		{
			unsigned long value = 0;
			list<unsigned long>::iterator iter;
			unsigned int listSize = objMgr->freeIds.size();

			fwrite(&listSize, sizeof(unsigned int), 1, filePtr);
			for (iter = objMgr->freeIds.begin(); iter != objMgr->freeIds.end(); ++iter)
			{
				value = (*iter);
				fwrite(&value, sizeof(unsigned long), 1, filePtr);
			}
			fwrite(&objMgr->nextId, sizeof(unsigned long), 1, filePtr);
		}
	}
	else
	{
		if (objMgr)
			delete objMgr;

		objMgr = 0;

		fread(&objMgrExists, sizeof(bool), 1, filePtr);
		if (objMgrExists)
		{
			objMgr = new CBaseObjectMgr();
			unsigned int listSize = 0;
			unsigned long value = 0;

			fread(&listSize, sizeof(unsigned int), 1, filePtr);
			for (unsigned int x = 0; x < listSize; x++)
			{
				fread(&value, sizeof(unsigned long), 1, filePtr);
				objMgr->freeObjectId(value);
			}
			fread(&objMgr->nextId, sizeof(unsigned long), 1, filePtr);
		}
	}

	return true;
}

void CBaseObjectMgr::shutdown()
{
	if (objMgr)
		delete objMgr;

	objMgr = 0;
}
