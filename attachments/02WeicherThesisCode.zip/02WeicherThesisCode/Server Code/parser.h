/*	parser.h
	John Weicher
	9-25-01
*/

#ifndef _PARSER_H
#define _PARSER_H

//Include object definitions
#include "sphere.h"
#include "plane.h"

//function prototypes
void processLine(char * input);
void parseFile(char * fName);
void checkName(char * name);
void closeFile(FILE * theFile);
void parseHeader(FILE * theFile);
void buildScene(FILE * theFile);
FILE * openFile(char * fName);

//Object attribute methods
void processAttribute(char * input);
void setGlobalAttribute(char attrib[50], char val[50]);
void setObjectAttribute(char attrib[50], char val[50]);
void setLightSourceAttribute(char attrib[50], char val[50]);
void setSphereAttribute(char attrib[50], char val[50]);
void setPlaneAttribute(char attrib[50], char val[50]);


//object generation methods
void generateSphereObject();
void generatePlaneObject();
void generateLightObject();

//General utility methods
char * trimString(char input[150]);
int extractThreeComponents(char input[50], int *comp1, int *comp2, int *comp3);
int extractThreeComponents(char input[50], float *comp1, float *comp2, float *comp3);
int extractFourComponents(char input[50], int *comp1, int *comp2, int *comp3, int * comp4);
int extractFourComponents(char input[50], float *comp1, float *comp2, float *comp3, float *comp4);

#endif
