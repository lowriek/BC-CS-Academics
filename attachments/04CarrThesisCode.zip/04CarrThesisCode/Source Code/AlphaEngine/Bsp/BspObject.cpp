#include "AlphaEngine/Bsp/BspObject.h"
#include <windows.h>
#include <gl/gl.h>

CBspObject::CBspObject() : CBaseObject(), CParticle(), CLocalCoord()
{
	pMesh = 0;
	pNext = 0;
	pPrev = 0;
	type = 0;
}

CBspObject::~CBspObject()
{
	destroy();
}

void CBspObject::addBspObject(CBspObject* pBspObject)
{
	if (pNext)
		pNext->addBspObject(pBspObject);
	else
		pNext = pBspObject;
}

CBspObject * CBspObject::clone()
{
	CBspObject * pBspObj = new CBspObject();
	pBspObj->pMesh = pMesh->clone();
	pBspObj->type = type;
	// TODO : Add particle properties if necessary, assign an object id?
	return pBspObj;
}

void CBspObject::destroy()
{
	if (pMesh)
		delete pMesh;

	pMesh = 0;
}

CMesh * CBspObject::getMesh()
{
	if (pMesh)
		return pMesh;

	return 0;
}

bool CBspObject::init()
{
	return true;
}

bool CBspObject::rayIntersect(CVector3 &ro, CVector3 &rd, CVector3 &ip, float &t, float rad)
{
	CMesh * tMesh = getMesh();
	if (tMesh == 0)
		return false;

	unsigned int faceId;

	return tMesh->rayIntersect(ro, rd, ip, t, faceId, rad);
}

void CBspObject::render(int flags)
{
	CMesh * tMesh = getMesh();
	if (tMesh)
	{
		glPushMatrix();
			glTranslatef(pos.points[0], pos.points[1], pos.points[2]);
				tMesh->render(flags);
		glPopMatrix();
	}
}

bool CBspObject::serialize(FILE * filePtr, bool isStoring)
{
	if (!filePtr)
		return false;

	bool hasMesh = pMesh != 0;
	if (isStoring)
	{
		fwrite(&type, sizeof(int), 1, filePtr);
		fwrite(&hasMesh, sizeof(bool), 1, filePtr);
	}
	else
	{
		fwrite(&type, sizeof(int), 1, filePtr);
		fwrite(&hasMesh, sizeof(bool), 1, filePtr);
		if (hasMesh)
			pMesh = new CMesh();
	}

	if (hasMesh)
	{
		if (!pMesh->serialize(filePtr, isStoring))
			return false;
	}

	if (!CBaseObject::serialize(filePtr, isStoring))
		return false;

	if (!CParticle::serialize(filePtr, isStoring))
		return false;

	if (!CLocalCoord::serialize(filePtr, isStoring))
		return false;

	return true;
}

bool CBspObject::update(long deltaTime)
{
	return CParticle::update(deltaTime);
}