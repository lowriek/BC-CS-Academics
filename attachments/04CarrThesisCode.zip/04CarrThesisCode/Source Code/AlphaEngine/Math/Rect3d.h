#ifndef _CRECT3D_H_
#define _CRECT3D_H_

#include "AlphaEngine/Math/Vector3.h"
#include "AlphaEngine/Math/Matrix44.h"

class CRect3d  
{
public:
	CRect3d();
	virtual ~CRect3d();

	CMatrix44	GetScaleMatrix();
	CVector3	GetCenter();

	CVector3 p1;
	CVector3 p2;
};

#endif 
